package edu.njupt.radon.exp.pattern2018;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class CreateOntoMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String ontoName = "testOnto";
		String ontPath = "d:\\"+ontoName+".owl";
		OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
		OWLOntology onto=manager.createOntology();	
		
		OWLDataFactory df = manager.getOWLDataFactory();
		
		OWLClass oc1 = df.getOWLClass(IRI.create("http://radon#oc1"));
		OWLClass oc2 = df.getOWLClass(IRI.create("http://radon#oc2"));
		OWLClass oc3 = df.getOWLClass(IRI.create("http://radon#oc3"));
		OWLAxiom  ax = df.getOWLSubClassOfAxiom(oc3, df.getOWLObjectUnionOf(oc1, oc2));
		manager.addAxiom(onto, ax);
 
		manager.saveOntology(onto, IRI.create(ontPath));
	}

}
