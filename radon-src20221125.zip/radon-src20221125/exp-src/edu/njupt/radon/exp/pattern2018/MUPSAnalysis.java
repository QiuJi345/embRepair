package edu.njupt.radon.exp.pattern2018;

import java.util.Set;

import org.semanticweb.owlapi.model.OWLAxiom;

public class MUPSAnalysis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static void analyzeMUPS(Set<Set<OWLAxiom>> mups) {
	       
		int disNum = 0;
		int opDomNum = 0;
		int dpDomNum = 0;
		int opRanNum = 0;
		int dpRanNum = 0;
		int invPropNum = 0;
		
		int someValNum = 0;
		int allValNum = 0;
		int unionNum = 0;
		int intersectionNum = 0;
		int negNum = 0;
		int cardiNum = 0;
		
		System.out.print("Number of all axioms: ");
		for(Set<OWLAxiom> oneMUPS : mups) {
			for(OWLAxiom ax : oneMUPS) {
				String axStr = ax.toString();
				if(axStr.contains("DisjointClasses")) {
					disNum ++;
				} else if(axStr.contains("ObjectPropertyDomain")) {
					opDomNum ++;
				} else if(axStr.contains("DatePropertyDomain")) {
					dpDomNum ++;
				} else if(axStr.contains("ObjectPropertyRange")) {
					opRanNum ++;
				} else if(axStr.contains("DatePropertyRange")) {
					dpRanNum ++;
				} else if(axStr.contains("OWLObjectComplementOf")) {
					negNum ++;
				} else if(axStr.contains("Cardinality")) {
					cardiNum ++;
				} else if(axStr.contains("ObjectUnionOf")) {
					unionNum ++;
				} else if(axStr.contains("ObjectIntersectionOf")) {
					intersectionNum ++;
				} else if(axStr.contains("ObjectAllValuesFrom")) {
					allValNum ++;
				} else if(axStr.contains("ObjectPropertyDomain")) {
					someValNum ++;
				}  else if(axStr.contains("OWLObjectInverseOf")) {
					invPropNum ++;
				}
			}
		}
	}

}
