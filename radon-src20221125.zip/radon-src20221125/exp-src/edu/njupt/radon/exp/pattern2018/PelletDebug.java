package edu.njupt.radon.exp.pattern2018;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import com.clarkparsia.owlapi.explanation.BlackBoxExplanation;
import com.clarkparsia.owlapi.explanation.HSTExplanationGenerator;
import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class PelletDebug {

	public static void main(String[] args)  throws Exception {
		String ontoName = "buggyPolicy";
		String ontPath = "data/kbs2014/"+ontoName+".owl";
		String ucURI = "http://www.owl-ontologies.com/unnamed.owl#AC_Agent";
		String resultPath = "results/mups/"+ontoName;
		
		System.setOut((new PrintStreamObject(resultPath)).ps);
		
		OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
		OWLOntology onto=manager.loadOntologyFromOntologyDocument(new File(ontPath));	
		
		OWLReasonerFactory reasonerFactory = PelletReasonerFactory.getInstance();
		OWLReasoner reasoner = reasonerFactory.createReasoner(onto);
		
		BlackBoxExplanation blackboxExplanation = new BlackBoxExplanation(onto,reasonerFactory,reasoner);
		HSTExplanationGenerator hstExpGen=new HSTExplanationGenerator(blackboxExplanation);
		
		computeMUPS(hstExpGen, onto);

	}
	
	public static void computeMUPS(HSTExplanationGenerator hstExpGen, OWLOntology onto) {
		OWLReasonerFactory reasonerFactory = PelletReasonerFactory.getInstance();
		OWLReasoner reasoner = reasonerFactory.createReasoner(onto);
		int counter = 1;
		for(OWLClass unsatconcept : reasoner.getUnsatisfiableClasses()) {
			System.out.println("unsatconcept <"+ (counter++) + "> " + unsatconcept);
			Set<Set<OWLAxiom>> mups = hstExpGen.getExplanations(unsatconcept);
			printMUPS(mups);	
			if(counter > 200){
				break;
			}
		}		
	}
	
	public static void computeMUPS(HSTExplanationGenerator hstExpGen, OWLClass unsatconcept) {
		System.out.println("unsatconcept: "+unsatconcept);
		
		long oneunsatconceptStart=System.currentTimeMillis();
		Set<Set<OWLAxiom>> mups = hstExpGen.getExplanations(unsatconcept);
		printMUPS(mups);		
		long  oneunsatconceptEnd=System.currentTimeMillis();		
		System.out.println("Time to compute MUPS for one uc: "+(oneunsatconceptEnd - oneunsatconceptStart)/1000.0+"s"+"\n------------------------");
		
	}
	
	
	public static void computeMUPS(HSTExplanationGenerator hstExpGen, OWLOntology onto, String ucURI){
		if(ucURI != null && ucURI.length()>0){
			OWLClass unsatconcept = null;
			if(ucURI.indexOf("http:")!=-1){
				unsatconcept = OWLTools.getOWLClass(onto, ucURI);
			} else {
				unsatconcept = OWLTools.getOWLClass(onto, ucURI);
			}
			Set<Set<OWLAxiom>> mups = hstExpGen.getExplanations(unsatconcept);
			printMUPS(mups);		
			modi(mups);
		} 
	}
	
	public static void modi(Set<Set<OWLAxiom>> mups){
		for(Set<OWLAxiom> oneMups : mups){
			HashSet<OWLAxiom> oneMups2 =  new HashSet<OWLAxiom>(oneMups);
			System.out.println("************************");
			CommonTools.printAxioms(oneMups2);
			printUcs(oneMups2);
			
			HashSet<OWLAxiom> checkMups = new HashSet<OWLAxiom>();			
			for(OWLAxiom ax : oneMups){
				if(ax instanceof OWLEquivalentClassesAxiom){
					OWLEquivalentClassesAxiom eqAx = (OWLEquivalentClassesAxiom)ax;
					for(OWLSubClassOfAxiom subAx : eqAx.asOWLSubClassOfAxioms()){
						if(!subAx.getSubClass().isAnonymous()){
							checkMups.add(subAx);
						}
					}
				} else {
					checkMups.add(ax);
				}
			}
			//check
			System.out.println("************************");
			CommonTools.printAxioms(checkMups);
			printUcs(checkMups);
		}
	}
	
	public static void printUcs(HashSet<OWLAxiom> axioms){
		for(OWLClass oc : ReasoningTools.getUnsatiConcepts(axioms)){
			System.out.println(oc.toString());
		}
	}
	
	public static void printMUPS(Set<Set<OWLAxiom>> mups) {
		int mupsNum = 0;
		for(Set<OWLAxiom> oneMUPS : mups) {
			System.out.println("mups<"+(++mupsNum)+">");
			int axiomNum = 0;
			for(OWLAxiom ax : oneMUPS) {
				System.out.println("["+(++axiomNum)+"] "+ax.toString());
			}
			System.out.println();
		}
		System.out.println();
	}
	
	

}
