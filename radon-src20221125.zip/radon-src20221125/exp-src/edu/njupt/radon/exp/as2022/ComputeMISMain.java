package edu.njupt.radon.exp.as2022;

import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.inconsistency.ComputeMIS;
import edu.njupt.radon.utils.io.MyPrinter;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class ComputeMISMain {

	public static void main(String[] args) throws Exception {
		String ontoName = "hongloumeng1000";
		String ontoPath = "onto/newSi/"+ontoName+".owl";
		OWLOntology ont = OWL.manager.loadOntology(IRI.create("file:"+ontoPath));
				
		System.setOut((new PrintStreamObject("results/mis/"+ontoName+"-log.txt")).ps);	
		
		System.out.println("onto: "+ontoPath);
		System.out.println("axioms: "+ont.getLogicalAxiomCount());
		ComputeMIS comp = new ComputeMIS();
		HashSet<HashSet<OWLAxiom>> mises = comp.getAllMIS(ont);

		//MyPrinter.printMultiSets(mises, null);
	}

}
