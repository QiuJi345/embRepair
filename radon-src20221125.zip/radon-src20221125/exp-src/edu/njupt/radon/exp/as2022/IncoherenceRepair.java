package edu.njupt.radon.exp.as2022;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.exp.cplex2018.res.CollectMIPS;
import edu.njupt.radon.repair.ChooseSubsets;
import edu.njupt.radon.repair.RankWithLogReasoning;
import edu.njupt.radon.repair.RankWithScore;
import edu.njupt.radon.repair.RankWithShapley;
import edu.njupt.radon.repair.RankWithSigVector;
import edu.njupt.radon.repair.RankWithSignatures;
import edu.njupt.radon.repair.RankWithVector;
import edu.njupt.radon.repair.ilp.ILPAlgorithm;
import edu.njupt.radon.repair.ilp.ILPTools;
import edu.njupt.radon.repair.ilp.ILPWeights;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import ilog.cplex.IloCplex;

public class IncoherenceRepair {	
	
	public static String modelName = "m2";
	public static String edName = "euc";	
	public static int topk = 1;
	public static double threshold = 0.7;

	public static void main(String[] args)  throws Exception {		
		IncoherenceRepair repair = new IncoherenceRepair();
		//repair.process("km1500_i500-3500");
		repair.process();
	}
	
	public void process() throws Exception {
		/*String[] ontos = {"ALOD2Vec-confof-edas","ATBox-cmt-confof",
				"CHEM-A","dbpedia_2014","Economy","Geography",
				"koala","Lily-cmt-conference","Lily-edas-ekaw","km1500_i500-3500"};
		String[] ontos = {"MGED","miniTambis",
				"pizza","proton","Terrorism","Transportation","University",
				"VeeAlign-edas-iasted","Wiktionary-cmt-confof","Wiktionary-confof-edas"};*/
		String[] ontos = {"MGED","miniTambis",
				"pizza","proton","Terrorism","Transportation","University",
				"VeeAlign-edas-iasted","Wiktionary-cmt-confof","Wiktionary-confof-edas","ALOD2Vec-confof-edas","ATBox-cmt-confof",
				"CHEM-A","dbpedia_2014","Economy","Geography",
				"koala","Lily-cmt-conference","Lily-edas-ekaw","km1500_i500-3500"};
				
		for(int i=0; i<ontos.length; i++) {			
			String ontoName = ontos[i];
			this.process(ontoName);
		}		
	}

	public void process(String ontoName) throws Exception {		
		System.setOut(System.out);
		System.out.println(ontoName);
		//processOneOntology(ontoName, "base", topk);
		//processOneOntology(ontoName, "score", topk);
		//processOneOntology(ontoName, "sig", topk);		
		//processOneOntology(ontoName, "sigVec", topk);
		//processOneOntology(ontoName, "vector", topk);
		//processOneOntology(ontoName, "logic", topk);
		processOneOntology(ontoName, "shapley", topk);
	}
	
	public void processOneOntology(String ontoName, String repairStrategy, int topk) throws Exception {
		String ontoPath = "as2022/onto/" + ontoName+".owl";
		String mupsPath = "as2022/mups/"+ontoName+"/log.txt";
		String resPath = "as2022/repair/"+ontoName+"/";
		String logPath = resPath+repairStrategy+"-log.txt";
		
		if(repairStrategy.contains("vec")||repairStrategy.contains("Vec")) {
			logPath = resPath+repairStrategy+"-"+modelName+"-"+edName+"-"+threshold+"-log.txt";
		}
				
		FileTools.fileExists(resPath);
		FileTools.fileExists(resPath+"models/");		
		
        OWLOntology sourceOnto = OWL.manager.loadOntology(IRI.create("file:"+ontoPath));
        System.out.println(sourceOnto.getClassesInSignature().size());
        System.out.println(" Onto size: "+sourceOnto.getLogicalAxiomCount());
        
		// Obtain conflicts
		//HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> ucMUPS = getMUPSFromDump(sourceOnto, mupsPath);
		//HashSet<HashSet<OWLAxiom>> conflicts = getConflicts(ucMUPS);
        System.setOut((new PrintStreamObject(logPath)).ps);	
        System.out.println(" axiom number: "+sourceOnto.getLogicalAxiomCount());
        HashSet<HashSet<String>> mips = CollectMIPS.getMIPSStrFromText(mupsPath);
		System.out.println("num of mupsstr: "+mips.size());
		HashSet<HashSet<OWLAxiom>> conflicts = CollectMIPS.transferStrToMUPS(sourceOnto, mips);
		System.out.println("num of conflicts: "+conflicts.size());		
		
				
		HashMap<OWLAxiom, Double> axiomRankMap = new HashMap<OWLAxiom, Double>();
		HashSet<HashSet<OWLAxiom>> diags = new HashSet<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();	
		//solution = RepairWithScore.getOneDiagnoseByHST(diags);
		
		//solution = repair.repairByCPlex(resPath, diags);
		
		long st = System.currentTimeMillis();
		if(repairStrategy.equals("base")) {				
			axiomRankMap = RankWithScore.computeRanks(conflicts);
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, 1000);
			solution = this.repairByCPlex(resPath, diags);
		} else if(repairStrategy.equals("score")) {				
			axiomRankMap = RankWithScore.computeRanks(conflicts);
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
			solution = this.repairByCPlex(resPath, diags);			
		} else if(repairStrategy.equals("sig")) {	
			RankWithSignatures rs = new RankWithSignatures(sourceOnto);
			axiomRankMap = rs.computeRanks(conflicts);		
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, topk);
			//diags = ChooseSubsets.getSubsetsWithLowRanks(conflicts, axiomRankMap, 10);
			solution = this.repairByCPlex(resPath, diags);
		} else if(repairStrategy.equals("logic")) {	
			RankWithLogReasoning rr = new RankWithLogReasoning(sourceOnto);
			axiomRankMap = rr.computeRanks(conflicts);		
			//diags = ChooseSubsets.getSubsetsWithLowRanks(conflicts, axiomRankMap, 1);
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, topk);
			solution = this.repairByCPlex(resPath, diags);
		} else if(repairStrategy.equals("vector")) {
			RankWithVector rv = new RankWithVector(sourceOnto, ontoName);
			axiomRankMap = rv.computeRanks(conflicts);			
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, topk);
			solution = this.repairByCPlex(resPath, diags);
		} else if(repairStrategy.equals("sigVec")) {
			RankWithSigVector rv = new RankWithSigVector(sourceOnto, ontoName);
			axiomRankMap = rv.computeRanks(conflicts);	
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, topk);
			solution = this.repairByCPlex(resPath, diags);
		} else if(repairStrategy.equals("shapley")) {	
			RankWithShapley rr = new RankWithShapley();
			axiomRankMap = rr.computeRanks(conflicts);
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
			solution = this.repairByCPlex(resPath, diags);		
		}
		long time = System.currentTimeMillis() - st;	
		
		// output ranks for the axioms in MUPS
		HashSet<OWLAxiom> conflictUnion = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> conflict : conflicts) {
			conflictUnion.addAll(conflict);
		}
		for(OWLAxiom axiom : conflictUnion) {
			double rank = axiomRankMap.get(axiom);		
			System.out.println("** axiom in MUPS: "+ axiom.toString()+" , rank = "+rank);
		}		
		
        // output removed axioms and the time to compute a solution based on MUPS/MIPS
		System.out.println("\n***Axioms removed: ");
		CommonTools.printAxioms(solution);
		System.out.println("Time to compute diagnosis (ms): " + time);	
		System.out.println("************************************ \n");
		
		OWL.manager.removeOntology(sourceOnto);
	}
	
	
	public HashSet<OWLAxiom> repairByCPlex(String resPath, 
			HashSet<HashSet<OWLAxiom>> multiSets, 
			HashMap<OWLAxiom, Double> axiomRankMap){		
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		
		long st = System.currentTimeMillis();
		try {
			// Translate OWL axioms to cplex representation as a model (.mps file)
			ILPWeights.createModel(resPath+"models/", multiSets, inputAxioms, axiomRankMap, 2);
			IloCplex cplex = new IloCplex();
			cplex.importModel(resPath+"models/ilpModel2.mps");
			cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
			cplex.solve();
			solution = ILPTools.getCplexResult(cplex, inputAxioms);
			cplex.end();			
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
		long time = System.currentTimeMillis() - st;		
		System.out.println("Time to apply cplex (ms): " + time);
		return solution;
	}

	public HashSet<OWLAxiom> repairByCPlex(String resPath, HashSet<HashSet<OWLAxiom>> multiSets){		
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		
		long st = System.currentTimeMillis();
		try {
			// Translate OWL axioms to cplex representation as a model (.mps file)
			ILPAlgorithm.createModel(resPath+"models/", multiSets, inputAxioms);
			IloCplex cplex = new IloCplex();
			// Import the saved model
			cplex.importModel(resPath+"models/" + "ilpModel1.mps");
			// Set parameters for CPlex
			cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
			// Begin to compute diagnosis
			cplex.solve();
			solution = ILPTools.getCplexResult(cplex, inputAxioms);
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
		long time = System.currentTimeMillis() - st;		
		System.out.println("Time to apply cplex (ms): " + time);
		return solution;
	}
}
