package edu.njupt.radon.exp.as2022;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.repair.RankWithLogReasoning;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class MyMain {
	
	public static String modelName = "m1";
	public static String edName = "euc";
	public static String str = "all";

	public static void main(String[] args) throws Exception {
	    aa();
	}
	
	public static void aa() {
		String ontoPath = "as2022/onto/km1500_i500-3500.owl";
		try {
			OWLOntology sourceOnto = OWL.manager.loadOntology(IRI.create("file:"+ontoPath));
			
			RankWithLogReasoning rl = new RankWithLogReasoning(sourceOnto);
			for(OWLAxiom ax : sourceOnto.getLogicalAxioms()) {
				if(ax.toString().contains("#knowledge_c")) {
					rl.computeRelaventEntailments(ax);
				}
			}
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	public static void bb() {
		/*String[] ontos = {"ALOD2Vec-confof-edas","ATBox-cmt-confof",
		"CHEM-A","dbpedia_2014","Economy","Geography",
		"koala","Lily-cmt-conference","Lily-edas-ekaw","km1500_i500-3500"};*/
		String[] ontos = {"MGED","miniTambis",
				"pizza","proton","Terrorism","Transportation","University",
				"VeeAlign-edas-iasted","Wiktionary-cmt-confof","Wiktionary-confof-edas"};
				
		for(int i=0; i<ontos.length; i++) {		
			iniSimList(ontos[i]);
		}
	
	}
	
	private static void iniSimList(String ontoName) {
		//String path = "onto/info/"+DebuggingParameters.ontoName+"_cos.txt"; 
		String path = "as2022/sim-"+modelName+"-"+edName+"/"+ontoName+"_"+str+"_euc.txt";
		String logPath = "as2022/sim/"+ontoName+"_"+str+".txt";
		//System.out.println("reading similarity file: "+path);
		String line = null;
		System.setOut((new PrintStreamObject(logPath)).ps);	
		try {
			FileInputStream fileInputStream = new FileInputStream(path);
			BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
			br.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		}		
		
	}

}
