package edu.njupt.radon.exp.as2022;

import java.io.PrintStream;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.exp.cplex2018.res.CollectMIPS;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class AxiomsInfoPrepare {

    public static void main(String[] args) throws Exception {
    	outputOntInfo("koala");
    }
    
    public static void outputOntInfo() throws Exception {
    	String[] ontos = {"ALOD2Vec-confof-edas","ATBox-cmt-confof",
				"CHEM-A","dbpedia_2014","Economy","Geography","km1500_i500-3500",
				"koala","Lily-cmt-conference","Lily-edas-ekaw"};
    	String[] ontos2 = {"MGED","miniTambis",
				"pizza","proton","Terrorism","Transportation","University",
				"VeeAlign-edas-iasted","Wiktionary-cmt-confof","Wiktionary-confof-edas"};
    	
		for(int i=0; i<ontos.length; i++) {			
			String ontoName = ontos[i];
			outputOntInfo(ontoName);
		}	
		for(int i=0; i<ontos2.length; i++) {			
			String ontoName = ontos2[i];
			outputOntInfo(ontoName);
		}	
    }
    
    public static void outputOntInfo(String ontoName)  throws Exception {
    	String ontoRoot = "as2022/onto/";           
        String mupsPath = "as2022/mups/"+ontoName+"/log.txt";
        String sentsPath = "as2022/nlp2/"+ontoName+"_sentencesList.txt";
        String axiomsPath = "as2022/nlp2/"+ontoName+"_axiomList.txt";
        String sigPairsPath = "as2022/nlp2/"+ontoName+"_axiomSigPairs.txt";  
        String axiomsInConfPath = "as2022/nlp2/"+ontoName+"_axiomsInConf.txt"; 
        Vector<OWLAxiom> axioms = new Vector<OWLAxiom>();
        OWLOntology o = OWL.manager.loadOntology(IRI.create("file:" + ontoRoot + ontoName+".owl"));
        PrintStream console = System.out;

        System.setOut((new PrintStreamObject(sentsPath)).ps);          
        long st = System.currentTimeMillis();
        AxiomsToSentences transf = new AxiomsToSentences();       
        for(OWLAxiom ax: o.getLogicalAxioms()) {
            ax=ax.getAxiomWithoutAnnotations();
            axioms.add(ax);
           /* if(ax.toString().contains("http://dbpedia.org/ontology/club") && ax.toString().contains("SubObjectPropertyOf")) {
            	System.out.println("stop");
            }*/
            transf.printAxiomInfo(ax);
        }
        console.print("\n"+ontoName+"\t"+(System.currentTimeMillis()-st)+"\t");
        
        System.setOut((new PrintStreamObject(axiomsPath)).ps);	 
        for(int i =0; i<axioms.size(); i++) {
        	System.out.print(axioms.get(i)+"\n");
        }
        
        System.setOut((new PrintStreamObject(sigPairsPath)).ps);	 
        st = System.currentTimeMillis();
        printSigPairs(sigPairsPath, mupsPath, o, axioms);
        console.print((System.currentTimeMillis()-st)+"\t");
        
        System.setOut((new PrintStreamObject(axiomsInConfPath)).ps);	 
        st = System.currentTimeMillis();
        printAllPairs(axiomsInConfPath, mupsPath, o, axioms);
        System.setOut(console);   
        System.out.print((System.currentTimeMillis()-st));
    }
    
    
    private static void printSigPairs(
    		String pairsPath, String mupsPath,
    		OWLOntology o,
    		Vector<OWLAxiom> axioms) {
    	HashSet<HashSet<String>> mips = CollectMIPS.getMIPSStrFromText(mupsPath);
    	HashSet<HashSet<OWLAxiom>> conflicts = CollectMIPS.transferStrToMUPS(o, mips);
    	HashSet<OWLAxiom> axiomsInMIPS = new HashSet<OWLAxiom>();
    	for(HashSet<OWLAxiom> conf : conflicts) {
    		axiomsInMIPS.addAll(conf);
    	}
    	
    	System.setOut((new PrintStreamObject(pairsPath)).ps);	  
    	for(OWLAxiom ax : axiomsInMIPS) {   
    		int index1 = axioms.indexOf(ax);
    		for(int i =0; i<axioms.size(); i++) {
            	OWLAxiom a1 = axioms.get(i);            	
            	if(ax.equals(a1)) {
            		continue;
            	}            	
            	if(isRelevant(ax, a1)) {
            		int index2 = axioms.indexOf(a1);
        			System.out.print(index1+","+index2+"\n");
        		}
    		}
    	}    	  
    }
    
    
    private static void printAllPairs(
    		String pairsPath, String mupsPath,
    		OWLOntology o,
    		Vector<OWLAxiom> axioms) {
    	HashSet<HashSet<String>> mips = CollectMIPS.getMIPSStrFromText(mupsPath);
    	HashSet<HashSet<OWLAxiom>> conflicts = CollectMIPS.transferStrToMUPS(o, mips);
    	HashSet<OWLAxiom> axiomsInMIPS = new HashSet<OWLAxiom>();
    	for(HashSet<OWLAxiom> conf : conflicts) {
    		axiomsInMIPS.addAll(conf);
    	}
    	
    	System.setOut((new PrintStreamObject(pairsPath)).ps);	  
    	for(OWLAxiom ax : axiomsInMIPS) {   
    		int index1 = axioms.indexOf(ax);
    		System.out.print(index1+"\n");
    	}    	  
    }
    
    private static void printSigPairs(String pairsPath, Vector<OWLAxiom> axioms) {
    	System.setOut((new PrintStreamObject(pairsPath)).ps);	         
        for(int i =0; i<axioms.size(); i++) {
        	OWLAxiom a1 = axioms.get(i);
        	for(int j = i+1; j < axioms.size(); j++) {
        		if(i == j) {
        			continue;
        		}        		
        		OWLAxiom a2 = axioms.get(j);
        		if(isRelevant(a1, a2)) {
        			System.out.print(i+","+j+"\n");
        		}
        	}
        }
    }
    
    private static boolean isRelevant(OWLAxiom a1, OWLAxiom a2) {
    	HashSet<OWLEntity> s1 = new HashSet<OWLEntity>(a1.getSignature());
    	for(OWLEntity ent : a2.getSignature()) {
    		if(s1.contains(ent))
    			return true;
    	}
    	return false;
    }

    
}
