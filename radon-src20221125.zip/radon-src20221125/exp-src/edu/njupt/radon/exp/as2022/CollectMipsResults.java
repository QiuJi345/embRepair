package edu.njupt.radon.exp.as2022;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class CollectMipsResults {
	
	public static void main(String[] args) throws Exception{

		readDiagResults();
	}
	
	public static void readDiagResults()  throws Exception{	
		String resPath = "as2022/mups/";
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(resPath+"mups-results.xls")),true); 
		outputHeader(output);
				
		String resFilePath = "";
		File f = new File(resPath);
		for(File ontoF : f.listFiles()) {	
			if(!ontoF.isDirectory()) {
				continue;
			}
			String ontoName = ontoF.getName();
			System.out.println("onto: "+ontoName);			
			resFilePath = resPath+ontoName+"/";	
			for(File algF : ontoF.listFiles()) {
				if(algF.isDirectory()) {
					continue;
				}
				if(algF.getName().equals("log.txt")) {
					System.out.println(ontoF.getName());
					output.print(ontoName);
					output.print("\t");
					outPutInfo(resFilePath+algF.getName(), output);
				}else {
					continue;
				}
			}
		}
	}

public static void outPutInfo(String filePath, PrintWriter output) throws Exception {
		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		
		double avg = 0.00;
		int min = 99;
		int max = 0;
		String mipsNum = "N/A>";
		boolean counter_1 = false;
		boolean counter_2 = false;
		int count = 0;
		int all = 0;
		
		String line ;
		while ((line=reader.readLine())!=null) {
			//���number
			if(line.startsWith("******************** mips")){
				counter_1 = true;
			}else if(line.startsWith("Explanation")) {
				mipsNum = line.substring(line.indexOf("<")+1);
				counter_2 = true;
				count = 0;
			}else if(counter_1 && counter_2 && line.contains("[")) {
				count +=1;
			}else if(counter_1 && counter_2 && line.length()==0) {
				counter_2 = false;
				all += count;
				if(count < min)
					min = count;
				if(count > max)
					max = count;
			}
			
		}
		mipsNum = mipsNum.substring(0, mipsNum.lastIndexOf(">"));
		avg = (double)all / Integer.parseInt(mipsNum);
		
		if(avg == 0) {
			System.out.println("   mips size avg : "+"N/A");
			output.print("N/A");
		}else {
			System.out.println("   mips size avg : "+avg);
			output.print(String.format("%.1f", avg));
		}
		output.print("\t");
		
		if(min==99) {
			System.out.println("   mips size min : "+"N/A");
			output.print("N/A");
		}else {
			System.out.println("   mips size min : "+min);
			output.print(""+min);
		}
		output.print("\t");
		
		if(max==0) {
			System.out.println("   mips size max : "+"N/A");
			output.print("N/A");
		}else {
			System.out.println("   mips size max : "+max);
			output.print(""+max);
		}
		output.print("\t");
		
		if(max==0 &&min==99) {
			System.out.println("   mips : "+"N/A");
			output.print("N/A");
		}else {
			System.out.println("   mips : "+mipsNum);
			output.print(mipsNum);
		}
		output.println();
	}
	
	public static void outputHeader(PrintWriter  output){
		output.print("Onto");
	    output.print("\t");		    
		output.print("Mips Size Avg");		
		output.print("\t");
		output.print("Mips Size Min");
		output.print('\t');
		output.print("Mips Size Max");
		output.print('\t');
		output.print("MIPS");
		output.println();
	}
	
}
