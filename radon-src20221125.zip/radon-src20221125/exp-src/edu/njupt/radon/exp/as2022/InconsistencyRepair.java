package edu.njupt.radon.exp.as2022;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.inconsistency.ComputeMIS;
import edu.njupt.radon.exp.cplex2018.res.CollectMIPS;
import edu.njupt.radon.repair.RankWithLogReasoning;
import edu.njupt.radon.repair.RankWithScore;
import edu.njupt.radon.repair.RankWithSigVector;
import edu.njupt.radon.repair.RankWithSignatures;
import edu.njupt.radon.repair.RankWithVector;
import edu.njupt.radon.repair.ilp.ILPAlgorithm;
import edu.njupt.radon.repair.ilp.ILPTools;
import edu.njupt.radon.repair.ilp.ILPWeights;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import ilog.cplex.IloCplex;

public class InconsistencyRepair {

	public static void main(String[] args) {
		String repairStrategy = "vec"; // score, sig, logic, vector  sigVec
		String datasetType = "real"; // real 1.3-subOnts
		String ontoName = "hongloumeng1000";		// km1500_i500-3000
		
		String ontoPath = "data/"+datasetType+"/" + ontoName+".owl";
		String resPath = "results/repairMIS/"+datasetType+"/"+ontoName+"/";
		String logPath = resPath+repairStrategy+"-log.txt";
		
		FileTools.fileExists(resPath);
		FileTools.fileExists(resPath+"models/");
		System.setOut((new PrintStreamObject(logPath)).ps);	
		
        OWLOntology sourceOnto = OWLTools.openOntology(ontoPath);
		
        ComputeMIS comp = new ComputeMIS();
		HashSet<HashSet<OWLAxiom>> conflicts = comp.getAllMIS(sourceOnto);
				
				
		HashMap<OWLAxiom, Double> axiomRankMap = new HashMap<OWLAxiom, Double>();
		HashSet<HashSet<OWLAxiom>> diags = new HashSet<HashSet<OWLAxiom>>();
		
		long st = System.currentTimeMillis();
		if(repairStrategy.equals("score")) {				
			axiomRankMap = RankWithScore.computeRanks(conflicts);
			//diags = ChooseSubsets.getSubsetsWithHighRanks(conflicts, axiomRankMap, 0);
			//diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, 1);
			
		} else if(repairStrategy.equals("sig")) {	
			RankWithSignatures rs = new RankWithSignatures(sourceOnto);
			axiomRankMap = rs.computeRanks(conflicts);		
			//diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, 3);
			//diags = ChooseSubsets.getSubsetsWithLowRanks(conflicts, axiomRankMap, 10);
		} else if(repairStrategy.equals("logic")) {	
			RankWithLogReasoning rr = new RankWithLogReasoning(sourceOnto);
			axiomRankMap = rr.computeRanks(conflicts);		
			//diags = ChooseSubsets.getSubsetsWithLowRanks(conflicts, axiomRankMap, 1);
			//diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, 1);
		} else if(repairStrategy.equals("vec")) {
			RankWithVector rv = new RankWithVector(sourceOnto, ontoName);
			long st1 = System.currentTimeMillis();
			axiomRankMap = rv.computeRanks(conflicts);	
			System.out.println(" Time to compute ranks: "+(System.currentTimeMillis()-st1));
			//diags = ChooseSubsets.getSubsetsWithLowRanks(conflicts, axiomRankMap, 100000);
			/*st1 = System.currentTimeMillis();
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, 1);
			System.out.println(" Time to compute subsets: "+(System.currentTimeMillis()-st1));*/
		} else if(repairStrategy.equals("sigVec")) {
			RankWithSigVector rv = new RankWithSigVector(sourceOnto, ontoName);
			long st1 = System.currentTimeMillis();
			axiomRankMap = rv.computeRanks(conflicts);	
			System.out.println(" Time to compute ranks: "+(System.currentTimeMillis()-st1));
			/*st1 = System.currentTimeMillis();
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, 2);
			System.out.println(" Time to compute subsets: "+(System.currentTimeMillis()-st1));*/
		}
				
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();	
		//solution = RepairWithScore.getOneDiagnoseByHST(diags);
		InconsistencyRepair repair = new InconsistencyRepair();
		//solution = repair.repairByCPlex(resPath, diags);
		
		
		HashSet<OWLAxiom> conflictUnion = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> conflict : conflicts) {
			conflictUnion.addAll(conflict);
		}
		
		solution = repair.repairByCPlex(resPath, conflicts, axiomRankMap);
		
        long time = System.currentTimeMillis() - st;		
		System.out.println("Time to compute diagnosis (ms): " + time);	

		System.out.println("***Axioms removed: ");
		CommonTools.printAxioms(solution);
		System.out.println("************************************ \n");

		
	}
	
	
	public HashSet<OWLAxiom> repairByCPlex(String resPath, 
			HashSet<HashSet<OWLAxiom>> multiSets, 
			HashMap<OWLAxiom, Double> axiomRankMap){		
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		
		long st = System.currentTimeMillis();
		try {
			// Translate OWL axioms to cplex representation as a model (.mps file)
			ILPWeights.createModel(resPath+"models/", multiSets, inputAxioms, axiomRankMap, 2);
			IloCplex cplex = new IloCplex();
			cplex.importModel(resPath+"models/ilpModel2.mps");
			cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
			cplex.solve();
			solution = ILPTools.getCplexResult(cplex, inputAxioms);
			cplex.end();			
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
		long time = System.currentTimeMillis() - st;		
		System.out.println("Time to apply cplex (ms): " + time);
		return solution;
	}

	public HashSet<OWLAxiom> repairByCPlex(String resPath, HashSet<HashSet<OWLAxiom>> multiSets){		
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		
		long st = System.currentTimeMillis();
		try {
			// Translate OWL axioms to cplex representation as a model (.mps file)
			ILPAlgorithm.createModel(resPath+"models/", multiSets, inputAxioms);
			IloCplex cplex = new IloCplex();
			// Import the saved model
			cplex.importModel(resPath+"models/" + "ilpModel1.mps");
			// Set parameters for CPlex
			cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
			// Begin to compute diagnosis
			cplex.solve();
			solution = ILPTools.getCplexResult(cplex, inputAxioms);
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
		long time = System.currentTimeMillis() - st;		
		System.out.println("Time to apply cplex (ms): " + time);
		return solution;
	}


}
