package edu.njupt.radon.exp.as2022;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ObtainData {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String ontoPath = "onto/sida/theory.owl";
		String triplesPath = "onto/sida/all_comp.csv";
		
		OWLOntology sourceOnto = OWL.manager.loadOntology(IRI.create("file:"+ontoPath));
		System.out.println("Tbox size : "+sourceOnto.getLogicalAxiomCount());

		ObtainData od = new ObtainData();
		od.addAxiomsFromTriples(sourceOnto, triplesPath);
	}
	
	public void addAxiomsFromTriples(OWLOntology ont, String filePath) {
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(filePath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line
			boolean ignore = true;
			int counter = 0;
			while ((strLine = br.readLine()) != null) {	
				if(ignore) {
					ignore = false;
					continue;
				} else if(strLine.trim().length()==0){
					continue;
				}
				String[] triples = strLine.replaceAll("\"", "").split(",");
				OWLAxiom ax = this.getIndividual(triples[2], triples[1], triples[0]);
				OWL.manager.addAxiom(ont, ax);
				counter ++;
				if(counter % 1000 == 0) {
					if(!ReasoningTools.isConsistent(ont, OWL.manager)) {
						// save new ontology
						File f = new File("onto/newSi/hongloumeng"+counter+".owl");
						OWL.manager.saveOntology(ont, IRI.create(f.toURI()));
						System.out.println("assertions number: "+counter);
						System.out.println("is consistent? false");
					}
					
				}
			}
			in.close();
			
			// check consistency
			System.out.println("assertions number: "+counter);
			System.out.println("is consistent? "+ReasoningTools.isConsistent(ont, OWL.manager));
			
			// save new ontology
			File f = new File("onto/newSi/hongloumeng"+counter+".owl");
			OWL.manager.saveOntology(ont, IRI.create(f.toURI()));
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
	
	public OWLAxiom getIndividual(String relName, String indiName1, String indiName2) {
		String prefix = "http://www.semanticweb.org/admin/ontologies/2018/2/untitled-ontology-4#";
		OWLObjectProperty op = OWL.factory.getOWLObjectProperty(IRI.create(prefix+relName));
		OWLNamedIndividual ind1 = OWL.factory.getOWLNamedIndividual(IRI.create(prefix+indiName1));
		OWLNamedIndividual ind2 = OWL.factory.getOWLNamedIndividual(IRI.create(prefix+indiName2));
		OWLAxiom ax = OWL.factory.getOWLObjectPropertyAssertionAxiom(op, ind1, ind2);
		return ax;
	}

}
