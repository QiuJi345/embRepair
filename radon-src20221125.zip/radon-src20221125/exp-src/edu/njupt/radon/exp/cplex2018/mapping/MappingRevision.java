package edu.njupt.radon.exp.cplex2018.mapping;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parser.AlignmentParser;
import edu.njupt.radon.revision.RelativeRevision;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class MappingRevision {
	
	//final static String REVISEUCS =

    public static void main(String[] args) throws Exception {	
    	String system = "ALOD2Vec";
    	String o1Name = "cmt";
    	String o2Name = "confof";
    	String sourceOntoPath = "data/oaei2018/"+o1Name+".owl";
		String targetOntoPath = "data/oaei2018/"+o2Name+".owl";
		String mappingPath = "data/oaei2018/results/"+system+"-"+o1Name+"-"+o2Name+".rdf";						
		String resultPath = "results/oaei2018/";
		
		File f = new File(resultPath);
		if(!f.exists()){
			f.mkdirs();
		}
		System.setOut((new PrintStreamObject(resultPath+system+"-"+o1Name+"-"+o2Name+"-")).ps);	
		
	    //read two source ontologies
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+sourceOntoPath);	
		OWLOntology targetOnto = OWLTools.openOntology("file:"+targetOntoPath);	
		HashSet<OWLAxiom> stableAxioms = new HashSet<OWLAxiom>(sourceOnto.getLogicalAxioms());		
		stableAxioms.addAll(targetOnto.getLogicalAxioms());			
		
		//read the mapping between two source ontologies
		AlignmentParser align = new AlignmentParser(sourceOnto, targetOnto);
		HashMap<OWLAxiom,Double> weights = align.readMappingsFromFile(mappingPath);		
		HashSet<OWLAxiom> incoAxioms = new HashSet<OWLAxiom>(weights.keySet());
		
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(stableAxioms);
		allAxioms.addAll(incoAxioms);
				
		// Revise ontology using different strategies
		RelativeRevision rev = new RelativeRevision(allAxioms, incoAxioms);
		//System.out.println("*************  revise ucs with weights");
		//rev.reviseUcsWithWeights(weights);
		//System.out.println("*************  revise ucs");
		//rev.reviseUcs();
		System.out.println("*************  revise ont");
		rev.reviseOnt();
		//System.out.println("*************  revise ont with weights");
		//rev.reviseOntWithWeights(weights);
		
	}



}
