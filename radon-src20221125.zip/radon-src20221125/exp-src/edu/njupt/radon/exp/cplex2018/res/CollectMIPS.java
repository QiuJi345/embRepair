package edu.njupt.radon.exp.cplex2018.res;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.DumpFile;

public class CollectMIPS {
	
	
	public static HashSet<HashSet<String>> getMIPSStrFromText(String filePath)  {
		//String filePath = "results/mups/AROMA-cmt-cocus/res.txt";
		String line;
		boolean mupsStart = false;
		HashSet<HashSet<String>> mupsStr = new HashSet<HashSet<String>>();
		HashSet<String> oneMUPS = new HashSet<String>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(filePath));	
			// Go to the part of MIPS
			line=reader.readLine();
			while(!line.contains("mips : ")) {
				line=reader.readLine();
			}
			// Read MIPS
			while ((line=reader.readLine())!=null) {
				if(line.trim().startsWith("Explanation <")) { 
					mupsStart = true;	
								
				} else if(line.trim().length() == 0 || !line.trim().startsWith("[")) {
					mupsStart = false;
					if(!oneMUPS.isEmpty()) {
						mupsStr.add(new HashSet<String>(oneMUPS));	
						oneMUPS.clear();
						//System.out.println("  num :"+(num++));
						//System.out.println();
					}
				} else if(mupsStart) {
					String str = line.substring(line.indexOf("]")+1).trim();
					/*if(!str.contains("SubClassOf(<http://cmt#Paper> <http://cmt#Document>)")&&
							!str.contains("ObjectPropertyDomain(<http://cocus#execute> <http://cocus#Person>)") &&
							!str.contains("DisjointClasses(<http://cmt#Document> <http://cmt#Person>)")&&
							!str.contains("SubClassOf(<http://cmt#Paper> ObjectMinCardinality(1 <http://cmt#readByReviewer> owl:Thing))")) {
						oneMUPS.add(str);
						//System.out.println("    "+str);
					}	*/
					oneMUPS.add(str);
				}			
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return mupsStr;
	}
	
	
	
	public static HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPSFromDumps(String ontoPath, String mupsPath) {
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> ucMUPS = null;
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		OWLOntology sourceOnto = OWLTools.openOntology(ontoPath);
		
		File f = new File(mupsPath);
		for(File subF : f.listFiles()) {
			String fileName = subF.getName();
			if(fileName.startsWith("11-mups")||
					fileName.startsWith("12-mups")||
					fileName.startsWith("31-mups")||
					fileName.startsWith("37-mups")) {
				
				ucMUPS = getMUPSFromDump(sourceOnto, mupsPath+fileName);
				for(OWLClass uc : ucMUPS.keySet()) {
					System.out.println(uc.toString()+" :  "+ucMUPS.get(uc).size());
				}
				System.out.println("-------------------------------");
				allMUPS.putAll(ucMUPS);
			}
		}
		System.out.println("uc num: "+allMUPS.size());
		for(OWLClass uc : allMUPS.keySet()) {
			System.out.println(uc.toString()+" :  "+allMUPS.get(uc).size());
		}
		
		//DebugMain.printMUPS(allMUPS);
		return allMUPS;
	}

/*	public static HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPSFromDump(String ontoPath, String mupsPath) {
		OWLOntology sourceOnto = OWLTools.openOntology(ontoPath);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> ucMUPS = getMUPSFromDump(sourceOnto, mupsPath);
		return ucMUPS;
	}*/
	
	/**
	 * Read mups from a dump file.
	 * 
	 * @param sourceOnto
	 * @param mupsPath
	 * @return
	 */
	public static HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPSFromDump(OWLOntology sourceOnto, String mupsPath) {
				
		HashMap<OWLClass, HashSet<HashSet<String>>> ucMUPSStr = (HashMap<OWLClass, HashSet<HashSet<String>>>)DumpFile.getObject(mupsPath);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> ucMUPS = transferStrToMUPS(sourceOnto, ucMUPSStr);
		return ucMUPS;
	}
	
	public static HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> transferStrToMUPS(
			OWLOntology sourceOnto, HashMap<OWLClass, HashSet<HashSet<String>>> ucMUPSStr) {
		
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> ucMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();		
		// Transfer an axiom string to the corresponding axiom
		for (OWLClass cl : ucMUPSStr.keySet()) {
			HashSet<HashSet<OWLAxiom>> allMUPS = transferStrToMUPS(sourceOnto, ucMUPSStr.get(cl));			
			ucMUPS.put(cl, allMUPS);
		}
		return ucMUPS;
	}
	
	public static HashSet<HashSet<OWLAxiom>> transferStrToMUPS(
			OWLOntology sourceOnto, HashSet<HashSet<String>> ucMUPSStr) {
		// Obtain the correspondences between an axiom and its string from an ontology
		HashMap<String, OWLAxiom> strAxiomMap = new HashMap<String, OWLAxiom>();
		for(OWLAxiom ax : sourceOnto.getLogicalAxioms()) {
			strAxiomMap.put(ax.toString(), ax);
		}
		// Transfer an axiom string to the corresponding axiom
		HashSet<HashSet<OWLAxiom>> allMUPS = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<String> oneMUPS : ucMUPSStr) {				
    		HashSet<OWLAxiom> strs = new HashSet<OWLAxiom>();
    		for(String ax : oneMUPS) {
    			OWLAxiom a = strAxiomMap.get(ax);
    			
    			if(a == null) {
    				for(String ax2 : oneMUPS) {
    					System.out.println("  str:  "+ax2);
    				}
    				
    				System.out.println("null \n");
    				continue;
    			}
    			strs.add(a);
    		}
    		allMUPS.add(strs);
    	}
		return allMUPS;
	}

}
