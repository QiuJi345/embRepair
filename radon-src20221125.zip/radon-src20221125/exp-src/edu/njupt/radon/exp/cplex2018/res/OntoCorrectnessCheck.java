package edu.njupt.radon.exp.cplex2018.res;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashSet;

import edu.njupt.radon.repair.ilp.RepairParameters;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class OntoCorrectnessCheck {

	public static void main(String[] args)  throws Exception {

		String expType = "real";	
		String resPath = "results-diag-"+expType+"/";
		
		//System.setOut((new PrintStreamObject(resPath+"correctness.txt")).ps);
		
		File f = new File(resPath);
		for(File ontoF : f.listFiles()) {	
			if(!ontoF.isDirectory()) {
				continue;
			}
			if(!ontoF.getName().contains("km1500-5000")) {
				continue;
			}
			
			String mupsPath = "results-mups-"+expType+"/"+ontoF.getName()+"/";
			HashSet<HashSet<String>> conflicts = CollectMIPS.getMIPSStrFromText(mupsPath);
			System.out.println("num of conflicts: "+conflicts.size());
			
			System.out.println("*********** Checking Result for onto:  "+ontoF.getName());	
			for(File resF : ontoF.listFiles()) {
				if(resF.isDirectory()) {
					continue;
				}
				if(!resF.getName().contains("hstScore")) {
					continue;
				}
				System.out.println("**** Checking Result : "+resF.getName());	
				HashSet<String> solution = getRemovedAxioms(resPath+ontoF.getName()+"/"+resF.getName());
				System.out.println("solution: ");
				print(solution);
				
				check(conflicts, solution);
				System.out.println("******************end ***************** \n ");
			}
			
		}
	}
	public static void print(HashSet<String> solution) {
		int i = 1;
		for(String s : solution) {
			System.out.println("["+(i++)+"] "+s);
		}
		System.out.println();
	}
	
	public static void check(HashSet<HashSet<String>> conflicts, HashSet<String> solution) {
		int j = 1;
		for(HashSet<String> conf : conflicts) {
			System.out.println(" Conflict "+(j++));
								
			boolean isBroken = false;
			for(String str : conf) {
				if(solution.contains(str)) {
					isBroken =true;
					break;
				}
			}
			if(!isBroken) {		
				print(conf);
				System.err.println("  [Info] The current conflict cannot be broken by the given solution");
				return;
			} else {
				System.out.println("  [Info] This conflict can be broken");
			}
		}
	}
	
	public static HashSet<String> getRemovedAxioms(String filePath) throws Exception {
		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));		
		boolean counterBegin = false;
		String line ;
		HashSet<String> axioms = new HashSet<String>();
		while ((line=reader.readLine())!=null) {
			if(line.startsWith("*** Axioms removed") || 
					line.startsWith("***Axioms removed")||
					line.startsWith("********** Axioms removed")){
				counterBegin = true;
			} else if(counterBegin && line.contains("[")) {
				String str = line.substring(line.indexOf("]")+2).trim();
				axioms.add(str);
			}
			
		}
		return axioms;
	}

}
