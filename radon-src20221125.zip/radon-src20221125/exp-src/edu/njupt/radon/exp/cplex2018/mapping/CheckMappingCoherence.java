package edu.njupt.radon.exp.cplex2018.mapping;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parser.AlignmentParser;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class CheckMappingCoherence {

	public static void main(String[] args) {
		String mappingPath = "data\\oaei2018\\results\\";
		checkMappingsCoherence(mappingPath);
	}
	
	public static void checkMappingsCoherence(String path) {
		File f = new File(path);
		System.out.println(f.exists());
		for(File subF : f.listFiles()) {
			String fName = subF.getName();
			String system = fName.substring(0, fName.indexOf("-"));
			if(!system.equals("LogMap")) {
				continue;
			}
			String o1Name = fName.substring(fName.indexOf("-")+1,fName.lastIndexOf("-"));
			String o2Name = fName.substring(fName.lastIndexOf("-")+1, fName.indexOf(".rdf"));
			checkMappingCoherence(o1Name, o2Name, system);
		}
		
	}
	
	public static void checkMappingCoherence(String o1Name, String o2Name, String system) {
		String sourceOntoPath = "data/oaei2018/"+o1Name+".owl";
		String targetOntoPath = "data/oaei2018/"+o2Name+".owl";
		String mappingPath = "data/oaei2018/results/"+system+"-"+o1Name+"-"+o2Name+".rdf";			
				
	    //read two source ontologies
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+sourceOntoPath);	
		OWLOntology targetOnto = OWLTools.openOntology("file:"+targetOntoPath);	
		HashSet<OWLAxiom> stableAxioms = new HashSet<OWLAxiom>(sourceOnto.getLogicalAxioms());		
		stableAxioms.addAll(targetOnto.getLogicalAxioms());			
		
		//read the mapping between two source ontologies
		AlignmentParser align = new AlignmentParser(sourceOnto, targetOnto);
		HashMap<OWLAxiom,Double> weights = align.readMappingsFromFile(mappingPath);		
		HashSet<OWLAxiom> incoAxioms = new HashSet<OWLAxiom>(weights.keySet());
		
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(stableAxioms);
		allAxioms.addAll(incoAxioms);
		
		if(!ReasoningTools.isConsistent(allAxioms)) {
			return;
		}
				

		if(!ReasoningTools.isCoherent(allAxioms)) {
			try {
				OWLTools.saveOntology(allAxioms, "data/oaei2018/merged/"+system+"-"+o1Name+"-"+o2Name+".owl");
			} catch (Exception ex) {
				ex.printStackTrace();
			}			
		}
		System.out.println(system+"-"+o1Name+"-"+o2Name+": "+ReasoningTools.isCoherent(allAxioms));
	}

}
