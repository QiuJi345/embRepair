package edu.njupt.radon.exp.cplex2018.res;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class CollectResultsWeights {

	public static void main(String[] args) throws Exception{

		readDiagResults();
	}

	public static void readDiagResults()  throws Exception{	
		String resPath = "results-diag-weights/";
		PrintWriter output =  new PrintWriter(new BufferedWriter(
				new FileWriter(resPath+"pattern-results.xls")),true); 
		outputHeader(output);
				
		String resFilePath = "";
		File f = new File(resPath);
		for(File ontoF : f.listFiles()) {	
			if(!ontoF.isDirectory()) {
				continue;
			}
			String ontoName = ontoF.getName();
			System.out.println("onto: "+ontoName);			
			resFilePath = resPath+ontoName+"/";	
			for(File algF : ontoF.listFiles()) {
				if(algF.isDirectory()) {
					continue;
				}
				output.print(ontoName);
				output.print("\t");
				
				String algName = algF.getName();
				System.out.println("   alg : "+algName);
				algName = algName.substring(0, algName.indexOf("-"));
				output.print(algName);
				output.print("\t");
				outputTime(resFilePath+algF.getName(), output);
			}
		}
	}	
	
	public static void outputTime(String filePath, PrintWriter output) throws Exception {
		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		String time = "1000000";
		int numOfRemovedAx = 0;
		boolean counterBegin = false;
		String mupsNum = "0";
		double weightSum = 0;
		
		String line ;
		while ((line=reader.readLine())!=null) {
			if(line.startsWith("Number of conflicts:")) {
				mupsNum = line.substring(line.indexOf(":")+1);
			} else if(line.startsWith("Time to compute")) {
				time = line.substring(line.indexOf(":")+1);
			} else if(line.startsWith("*** Axioms removed") || 
					line.startsWith("***Axioms removed")||
					line.startsWith("********** Axioms removed")){
				counterBegin = true;
			} else if(counterBegin && line.contains("[")) {
				numOfRemovedAx++;
				String weight = line.substring(line.lastIndexOf(":")+1);
				double w = Double.valueOf(weight);
				weightSum += w;
			}
			
		}
		output.print(numOfRemovedAx);
		output.print("\t");		
		output.print(String.format("%.2f", weightSum));
		output.print("\t");
		output.print(mupsNum);
		output.print("\t");
		output.print(time);
		output.println();
	}
	
	public static void outputHeader(PrintWriter  output){
		output.print("Ontology");
	    output.print("\t");		    
		output.print("Algorithm");		
		output.print("\t");
		output.print("# of removed axioms");
		output.print('\t');
		output.print("Sum of Weights");
		output.print('\t');
		output.print("# MUPS");		
		output.print("\t");
		output.print("Time (ms)");
		output.println();
	}
}
