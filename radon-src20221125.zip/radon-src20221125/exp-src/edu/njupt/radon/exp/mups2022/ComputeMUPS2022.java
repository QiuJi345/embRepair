package edu.njupt.radon.exp.mups2022;

import java.io.File;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.heuristic.HeuristicDebug;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceDebug;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceParameters;
import edu.njupt.radon.exp.explanation.RaDONMUPS;
import edu.njupt.radon.parameters.DebuggingArgumentsProcessing;
import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.TimeoutException;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTask;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ComputeMUPS2022 {


	
	OWLOntology ontology ;   
	OWLClass unsatConcept;
	
	RadonDebug debug ;
	HeuristicDebug heuristicDebug;
	
	public static Thread thread = null;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		System.setProperty("entityExpansionLimit", "10000000");
	
		if(args.length > 0 ){
			DebuggingArgumentsProcessing process = new DebuggingArgumentsProcessing();
			process.processArguments(args, RaDONMUPS.class.getName());
		}
		
		// Open an OWL ontology
		OWLOntology onto = OWL.manager.loadOntology( IRI.create( DebuggingParameters.ontoPath ) );
		//OWLClass uc = OWLTools.getOWLClass(onto, DebuggingParameters.ucName);
		
		ComputeMUPS2022 radon = new ComputeMUPS2022(onto);
		radon.debugUcs();
	}
	
	public ComputeMUPS2022(OWLOntology ontology){
		this.ontology = ontology;
		
	}
		
	public void debugUc(OWLClass uc) throws Exception {
		this.unsatConcept = uc;
		// Perform debugging task
		this.computeJusts();		
	}
	
	public void debugUcs() throws Exception {		
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(this.ontology);
		int counter = 1;
		for(OWLClass uc : ucs){
			/*if(!uc.toStringID().contains("#business_c")) {
				continue;
			}*/
			this.unsatConcept = uc;
			System.out.println(" UC_"+(counter++)+" : "+uc.toString());
			// Perform debugging task
			this.computeJusts();
		}				
	}
		
		
	public void computeJusts(){
		if(!needContinue(unsatConcept)){
			return;
		}
		
		System.out.println("The debugged concept is : "+unsatConcept.getIRI().toString());	

		long startTime = System.currentTimeMillis();
		try{			
			doCompute();
		} catch (TimeoutException tex){
			tex.printStackTrace();
			System.out.println(" Time is out!");
		} catch (OutOfMemoryError oex){
			oex.printStackTrace();
			System.out.println(" Memory is out!");
		} catch (Exception ex){
			ex.printStackTrace();
			System.out.println(" Exception is thrown when computing MUPS for concept "+unsatConcept.toString());
		} finally {
			long exeTime = System.currentTimeMillis()-startTime;
			postProcessing();        	
        	try{
				Thread.sleep(10);
			} catch (InterruptedException ex){
				ex.printStackTrace();
			}        	
        	System.out.println("[Info] finish!");
			System.out.println("\nTime : "+exeTime);	
			//System.exit(1);  
		}	
	}	

	private void doCompute() 
	throws TimeoutException, OutOfMemoryError, Exception {	
		final MyThread myThread = new MyThread();
	    thread = new Thread(myThread);
        // Start a new thread
	    thread.start();
	    // Set timeout for the thread
	    thread.join(DebuggingParameters.timeout);  
	    // If time is out, then interrupt the current thread
	    if (thread.isAlive()) {
	        thread.interrupt();  
	    }
	}
	
	private boolean needContinue(OWLClass unsatConcept){
		boolean needContinue = true;
		if(unsatConcept == null){
			System.out.println("The concept to be explained is null !");	
			needContinue = false;
		} else if(unsatConcept.equals(OWL.factory.getOWLNothing())){
			System.out.println("The concept is nothing which can be explained by itself !");	
			needContinue = false;
		} else if(hasBeenExplained(unsatConcept)){
			System.out.println("This concept has been explained!");
			needContinue = false;
		}
		return needContinue;
	}
	
	public static boolean hasBeenExplained(OWLClass concept){
		boolean hasBeenExplained = false;
		String conceptName = OWLTools.getFileName(concept);
		String ucPath = DebuggingParameters.resultPath + conceptName+"/";	
		// Check the path to store results
		File file = new File(ucPath);
		if(!file.exists()){
			file.mkdirs();
		} else if(FileTools.isLogFileExists(ucPath+"log.txt")){
			hasBeenExplained = true;
		}
		// If the concept has not been explained, we save the debugging results to a local file.
		if(!hasBeenExplained){
			System.setOut((new PrintStreamObject(ucPath+"log.txt")).ps);
		}
		return hasBeenExplained;
	}
	
	private void postProcessing(){
		if(DebuggingParameters.debugMethod.equalsIgnoreCase("pattern")){
    		//System.out.println("================== Correctness Checking ======================");        	
    		//InconsistencyTools.checkMUPSCorrectness(ucMUPS, unsatConcept);
    	} else if(DebuggingParameters.debugMethod.equalsIgnoreCase("relevance-cm")){
			// Output global hitting sets and check their correctness. 
			HashSet<Vector<OWLAxiom>> hittingSets = debug.getHittingSets();
			if(!RelevanceParameters.debugStrategy.equals(RelevanceParameters.COMPUTE_ALL_HS_REL)){
				System.out.println("    "+hittingSets.size()+" hitting sets have been found: ");
				int i = 0;
				for(Vector<OWLAxiom> hittingSet : hittingSets){
					System.out.println("    Hitting set <"+(i++)+">");
					for(OWLAxiom axiom : hittingSet){
						System.out.println("      "+axiom.toString());
					}
					// Check the correctness of a hitting set
					HashSet<OWLAxiom> axiomsInOnto = new HashSet<OWLAxiom>(ontology.getLogicalAxioms());
					axiomsInOnto.removeAll(hittingSet);
					System.out.println("Does <"+unsatConcept.getIRI().toString()+
							"> become satisfiable? "+
							ReasoningTools.isSatisfiable(axiomsInOnto, unsatConcept));	
				}
			}
		}		   
    	
	}

	private void iniDebugMethod(HashSet<OWLAxiom> debuggingAxiomSet){
		// Generate an object for the interface ComputeMUPS
		if(DebuggingParameters.debugMethod.equals(DebuggingParameters.radonPatDebug)){
			// prepare
			if(debug == null){
				long startTime = System.currentTimeMillis();
				OntologyInfo myOnto = new OntologyInfo(debuggingAxiomSet);
	    		ClassHierarchy classHier = new ClassHierarchy(myOnto);
	    		PropertyHierarchy propHier = new PropertyHierarchy(myOnto.getOriginalAxioms());
	    		long prepareTime = System.currentTimeMillis() - startTime;
	    		System.out.println("Prepare time : "+prepareTime);
	    		// debug
	    		debug = new HeuristicDebug(myOnto, classHier, propHier); 
			}    		   		
		} else if(DebuggingParameters.debugMethod.equals(DebuggingParameters.radonRelAllDebug)){	
			if(DebuggingParameters.ontoName.equals("km1500")){
				RelevanceParameters.selectionFunction = RelevanceParameters.SubSeleFunc;
			}
			RelevanceParameters.debugStrategy = RelevanceParameters.COMPUTE_ALL_HS_REL;
			debug = new RelevanceDebug(debuggingAxiomSet, null);
		} else if(DebuggingParameters.debugMethod.equals(DebuggingParameters.radonRelCmDebug)){
			if(DebuggingParameters.ontoName.equals("km1500")){
				RelevanceParameters.selectionFunction = RelevanceParameters.SubSeleFunc;
			}
			RelevanceParameters.debugStrategy = RelevanceParameters.COMPUTE_All_CM_HS_REL;
			debug = new RelevanceDebug(debuggingAxiomSet, null);
		} else if(DebuggingParameters.debugMethod.equals(DebuggingParameters.radonBlPatDebug)){
			if(debug == null){
				OntologyInfo myOnto = new OntologyInfo(debuggingAxiomSet);
	    		ClassHierarchy classHier = new ClassHierarchy(myOnto);
	    		PropertyHierarchy propHier = new PropertyHierarchy(myOnto.getOriginalAxioms());
	    		// debug
	    		heuristicDebug = new HeuristicDebug(myOnto, classHier, propHier); 
			}   
			debug = new BlackboxDebug(debuggingAxiomSet);
		} else if(DebuggingParameters.debugMethod.equals(DebuggingParameters.radonRelPatDebug)){
			if(debug == null){
				OntologyInfo myOnto = new OntologyInfo(debuggingAxiomSet);
	    		ClassHierarchy classHier = new ClassHierarchy(myOnto);
	    		PropertyHierarchy propHier = new PropertyHierarchy(myOnto.getOriginalAxioms());
	    		// debug
	    		heuristicDebug = new HeuristicDebug(myOnto, classHier, propHier); 
			}   
			if(DebuggingParameters.ontoName.equals("km1500")){
				RelevanceParameters.selectionFunction = RelevanceParameters.SubSeleFunc;
			}
			RelevanceParameters.debugStrategy = RelevanceParameters.COMPUTE_ALL_HS_REL;
			debug = new RelevanceDebug(debuggingAxiomSet, null);
		} else {
			debug = new BlackboxDebug(debuggingAxiomSet);
		}	
		
	}
				 
	class MyThread implements Runnable {
	    public void run() { 
	    	if(DebuggingParameters.useModule){
	    		long startTime = System.currentTimeMillis();
	    		Set<OWLAxiom> module = OWLTools.extractModule(ontology, unsatConcept);
	    		long extractModuleTime = System.currentTimeMillis()-startTime;
	        	//module = new HashSet<OWLAxiom>(axiomsInOnto);
	        	System.out.println("Module size : "+module.size());
	        	System.out.println("Extration time : "+extractModuleTime);
	        	iniDebugMethod(new HashSet<OWLAxiom>(module));
	    	} else {
	    		iniDebugMethod(new HashSet<OWLAxiom>(ontology.getLogicalAxioms()));
	    	}
	    	
	    	HashSet<HashSet<OWLAxiom>> foundMUPS = new HashSet<HashSet<OWLAxiom>>();
	    	if(DebuggingParameters.debugMethod.equals(DebuggingParameters.radonBlPatDebug) ||
	    			DebuggingParameters.debugMethod.equals(DebuggingParameters.radonRelPatDebug)){
	    		long  startTime = System.currentTimeMillis();
	    		foundMUPS = heuristicDebug.getMUPS(unsatConcept);
	    		System.out.println("Time for pattern-based debugging: "+ (System.currentTimeMillis()-startTime));
	    		
	    		startTime = System.currentTimeMillis();
	    		debug.getMUPS(unsatConcept, foundMUPS);	    
	    		System.out.println("Time for default debugging: "+ (System.currentTimeMillis()-startTime));
	    	} else {
	    		debug.getMUPS(unsatConcept);
	    	}
	    }
	}
	
	

}
