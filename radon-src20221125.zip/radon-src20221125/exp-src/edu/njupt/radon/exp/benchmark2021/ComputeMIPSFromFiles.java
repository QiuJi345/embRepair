package edu.njupt.radon.exp.benchmark2021;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class ComputeMIPSFromFiles {

	
	static String dataset = "3-InjectIncoHybrid";
	static String logPathRoot = "F:/Experiments/2021-kbs/r/"+dataset+"/";
	static String ontoRoot = "d:/Data/yanfa/";
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub		
		ComputeMIPSFromFiles main = new ComputeMIPSFromFiles();
		//main.computeMIPS(ontoRoot);

		main.outputMUPS(ontoRoot);
	}
	
	private void outputMUPS(String ontoRoot)  throws Exception {
		
		
		File ontFiles = new File(logPathRoot);
		for(File ontFile : ontFiles.listFiles()) {
			String ontoName = ontFile.getName();
			System.out.println("onto: "+ontoName);
			
			String resultPath = "results/mips/"+dataset+"/"+ontoName+"/";
			FileTools.fileExists(resultPath);
			File f = new File(resultPath+"mupslog.txt");
			if(f.exists()) {
				f.delete();
			}
			
			System.setOut((new PrintStreamObject(resultPath+"mupslog.txt")).ps);	
			String logPath2 = logPathRoot + ontoName +"/ProtegeBl/";
			File ucFiles = new File(logPath2);
			int ucNum = 0;
			for(File ucFile : ucFiles.listFiles()) {
				ucNum++;
				String ucName = ucFile.getName();			
				System.out.println(ucNum+"> concept: "+ucName);		
				
				String logPath = logPath2 + ucName+"/log.txt";				
				HashSet<HashSet<String>> oneMUPSString = readMUPS(logPath);
				int mupsNum = 1;
				for(HashSet<String> aMUPS : oneMUPSString) {
					System.out.println("  Found explanation <"+(mupsNum++)+"> for concept <"+ucName);	
					int axNum =1;
					for(String s : aMUPS) {
						System.out.println(" ["+(axNum++)+"] "+s);		
					}
					System.out.println();
				}
				System.out.println();
				System.out.println("The time (ms) to compute all\n");
			}
			System.out.println("The number of unsatisfiable concepts is "+ucNum+"\n");
			
		}
		
	}
	
	private void computeMIPS(String ontoRoot)  throws Exception {		
		File ontFiles = new File(logPathRoot);
		for(File ontFile : ontFiles.listFiles()) {
			String ontoName = ontFile.getName();
			String ontoPath = ontoRoot+dataset+"/"+ontoName+".owl";
			System.out.println("onto: "+ontoPath);
			
			String resultPath = "results/mips/"+dataset+"/"+ontoName+"/";
			FileTools.fileExists(resultPath);
			File f = new File(resultPath+"log.txt");
			if(f.exists()) {
				continue;
			}
			
			OWLOntology onto = OWL.manager.loadOntology( IRI.create( "file:" + ontoPath ) );
			HashMap<String,OWLAxiom> strAxMap = this.getMap(onto);
			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		

			System.setOut((new PrintStreamObject(resultPath+"mupslog.txt")).ps);	
			String logPath2 = logPathRoot + ontoName +"/ProtegeBl/";
			File ucFiles = new File(logPath2);
			
			for(File ucFile : ucFiles.listFiles()) {
				String ucName = ucFile.getName();						
				OWLClass uc = OWLTools.getOWLClassWithLocalName(onto, ucName);
				
				String logPath = logPath2 + ucName+"/log.txt";				
				HashSet<HashSet<String>> oneMUPSString = readMUPS(logPath);
				HashSet<HashSet<OWLAxiom>> ucMUPS = this.translateAxioms(strAxMap, oneMUPSString);
				allMUPS.put(uc, ucMUPS);				
			}
			
			// compute mups and mips			
			System.setOut((new PrintStreamObject(resultPath+"log.txt")).ps);	
			long st = System.currentTimeMillis();
			HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(allMUPS);
			long time = System.currentTimeMillis() - st;
			System.out.println("******************** mips : ");
			CommonTools.printMultiSets(mips, null);
			System.out.println("Time (ms) to compute mips: "+time+"\n");
		}
		
	}
	
	private HashMap<String,OWLAxiom> getMap(OWLOntology onto) {
		HashMap<String,OWLAxiom> strAxMap = new HashMap<String,OWLAxiom>();
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		for(OWLAxiom ax : axioms) {
			strAxMap.put(ax.toString(), ax);
		}
		return strAxMap;
	}
	
	private HashSet<HashSet<OWLAxiom>> translateAxioms(HashMap<String,OWLAxiom> strAxMap, HashSet<HashSet<String>> mupsString) {
		HashSet<HashSet<OWLAxiom>> justs = new HashSet<HashSet<OWLAxiom>>();
		
		for(HashSet<String> oneMUPSString : mupsString) {
			HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
			for(String str : oneMUPSString) {
				OWLAxiom ax = strAxMap.get(str);
				if(ax==null) {
					System.err.println("Error to translate a string to an OWLAxiom");
				} else {
					axioms.add(ax);
				}
			}
			justs.add(axioms);
		}
		
		return justs;
	}
	
	private HashSet<HashSet<String>> readMUPS(String logPath) throws Exception {
		HashSet<HashSet<String>> justs = new HashSet<HashSet<String>>();
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneMUPSBegin = false;
				
		FileInputStream fileStream = new FileInputStream(logPath);
		// Get the object of DataInputStream
		DataInputStream dataStream = new DataInputStream(fileStream);
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
		
		String oneLine;	
		// Read File Line By Line			
		while ((oneLine = bufferedReader.readLine()) != null) {	
			if(oneLine.indexOf("Found explanation <") != -1 ){
				isOneMUPSBegin = true;
				oneMUPSString.clear();
				continue;
			} 
			
			if(isOneMUPSBegin){
				// In this case, the output of one MUPS has been finished.
				if(oneLine.trim().length() == 0 && oneMUPSString.size()>0){
					// Add the found MUPS to the collection of MUPS
					justs.add(new HashSet<String>(oneMUPSString));
					// Set the start
					isOneMUPSBegin = false;
				} else {
					int index1 = oneLine.indexOf("]");
					if(index1 != -1){
						// Get the string after ]
						String axiomString = oneLine.substring(index1+1).trim();
						// Remove the first blank space if exists
						if(axiomString.indexOf(" ")==0){
							axiomString = axiomString.substring(1);
						}
						// Add the axiom string to the the collection of axiom strings.
						oneMUPSString.add(axiomString);							
					} 
				}
			}
		}
		// Close the input stream
		dataStream.close();
		return justs;
	}
	

}
