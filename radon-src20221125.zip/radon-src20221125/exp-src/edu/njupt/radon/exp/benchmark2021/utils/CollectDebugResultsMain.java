package edu.njupt.radon.exp.benchmark2021.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import edu.njupt.radon.parameters.DebuggingParameters;

public class CollectDebugResultsMain {
	// 定义各个文件夹名称
	static String algorithmName = "";
	static String dataSet = "";
	static String ontoName = "";
	static String debugMethod = "";
	static String ucName = "";
	static String ontoId = "";
	/** 计算所有MUPs的时间，初始值设置timeout的时间（1000秒）  */
	//static long time = DebuggingParameters.timeout;
	/** 计算每个UC的时间和MUPS数量  */
	static long Time= 0;
	static long UCmupsNumber= 0;
	public static String remark = "";
	public static ArrayList<String> nameList=new ArrayList<String>(); 
	public static ArrayList<String> idList=new ArrayList<String>();  
	 

	public static void main(String[] args) throws Exception {
		// 测试文件路径
		String resultPath = "F:/Experiments/2021-kbs/newResults/evalTools/";
		// 结果存放在debugResult.xls
		PrintWriter output =  new PrintWriter(new BufferedWriter(
				new FileWriter("results/ucMUPS.xls")),true); 
		
		CollectDebugResultsMain col = new CollectDebugResultsMain();
		col.outputJustHeader(output);
		col.listDataSets(output, resultPath);
		
		output.flush();
        output.close();
	}
	
	
	public CollectDebugResultsMain() {
		ini();
	}
	/**
	 * 依次读取各层文件夹<br>
	 * 第1层，文件夹名称为数据集名字
	 * @param output
	 * @param resultPath
	 */
	public void listDataSets(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			if(!subFile.isDirectory()) {
				continue;
			}
			// 读取数据集名称
			dataSet = subFile.getName();
			if(!dataSet.contains("3-InjectIncoHybrid")) {
				continue;
			}
			// 继续读取下一层
			String path = resultPath + dataSet + "/";
			System.out.println("*** dataset: "+path);
			listOnts(output, path);
			dataSet = "";
		}
	}
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第2层，文件夹名称为本体名字
	 * @param output
	 * @param resultPath
	 */
	public void listOnts(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			// 读取本体名称
			ontoName = subFile.getName();
			if(ontoName.contains(".")) {
				continue;
			}			
			ontoId = getOntId(ontoName);
			System.out.println("   onto: "+ontoName+", id: "+ontoId);
			
			// 继续读取下一层
			String path = resultPath + ontoName + "/";
			// radon \ pellet
//			listDebugMethods(output, path);
//			// swoop \ 张瑜
			listAlgorithms(output, path);
			ontoName = "";
		}
	}
	
	
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第3层，文件夹名称为算法名字
	 * @param output
	 * @param resultPath
	 */
	public void listAlgorithms(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		//System.out.println("     "+resultPath);
		if(file==null) {
			System.out.println("        error");
			return;
		}
		for(File subFile : file.listFiles()){
			// 读取算法名称
			algorithmName = subFile.getName();
			
			// 继续读取下一层
			String path = resultPath + algorithmName + "/";
			listEntailments(output, path);
			algorithmName = "";
		}
	}

	/**
	 * 依次读取各层文件夹<br>
	 * 第五层，文件夹名称为UC名称
	 * 求单个UC的时间
	 * @param output
	 * @param resultPath
	 */
	public void listEntailments(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			CollectDebugResultsMain.remark = "";
			// 读取UC名称
			String entailmentString = subFile.getName();
			/*if(!entailmentString.contains("derivedOntoUC")) {
				continue;
			}*/
			if (entailmentString.contains("#")) {
				ucName = entailmentString.substring(entailmentString.indexOf("#") + 1);
			}else {
				ucName = entailmentString;
			}
			String path = resultPath + entailmentString;
			// 测试用
			//System.out.println(path);
			// 读取log文档，计算所需值
			Time = computeJust(output, path+"/log.txt");
			// radon 和 pellet
			UCmupsNumber = computeJustSize(output, path+"/log.txt");	
			if(UCmupsNumber==0) {
				UCmupsNumber = computeJustSizeForSwoop(output, path+"/log.txt");
			}
			// 输出到表格
			printFileInfo(output);
			ucName = "";
		}
	}
	
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第五层，文件夹名称为UC名称
	 * 求单个UC的时间
	 * @param output
	 * @param resultPath
	 */
	public void listEntailmentsforSwoop(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			CollectDebugResultsMain.remark = "";
			// 读取UC名称
			String entailmentString = subFile.getName();
			/*if(!entailmentString.contains("derivedOntoUC")) {
				continue;
			}*/
			if (entailmentString.contains("#")) {
				ucName = entailmentString.substring(entailmentString.indexOf("#") + 1);
			}else {
				ucName = entailmentString;
			}
			String path = resultPath + entailmentString;
			// 测试用
			//System.out.println(path);
			// 读取log文档，计算所需值
			Time = computeJust(output, path+"/log.txt");			
			// swoop 和 张瑜
			UCmupsNumber = computeJustSizeForSwoop(output, path+"/log.txt");
			// 输出到表格
			printFileInfo(output);
			ucName = "";
		}
	}
	
	
	
	/**
	 * radon & pellet
	 * @param output
	 * @param logPath
	 * @return
	 */
	public int computeJustSize(PrintWriter  output, String logPath) {		
		CollectDebugResults reader = new CollectDebugResults(logPath);
		int mupsNum = reader.getMUPSNum();
		return mupsNum;
	}
	
	/**
	 * swoop & 张瑜
	 * @param output
	 * @param logPath
	 * @return
	 */
	public int computeJustSizeForSwoop(PrintWriter  output, String logPath) {		
		CollectDebugResults reader = new CollectDebugResults(logPath, 0);				
		int justsNumber = reader.getMupsNumForSwoop();
		return justsNumber;
	}
	
	/**
	 * 		
	 * @param output
	 * @param logPath
	 */
	public long computeJust(PrintWriter  output, String logPath) {		
		CollectDebugResults reader = new CollectDebugResults(logPath);			
		/*time = reader.getTime();
		if(time > 1000000) {
			time = 1000000;
		}*/
		return reader.getTime();
	}
	
	
	/**
	 * 输出对应结果
	 * @param output
	 */
	private void printFileInfo(PrintWriter output){
	    output.print(dataSet);
	    output.print("\t");
	    output.print(ontoName);
	    output.print("\t");
	    output.print(ontoId);
	    output.print("\t");
	    output.print(algorithmName);
	    output.print("\t");
	    output.print(ucName);
	    output.print("\t");
	    output.print(Time);
		output.print('\t');
		output.print(UCmupsNumber);
		output.print('\t');
		output.print(remark);
		output.println();
		
	}

	/**
	 * 打印表格表头
	 * @param output
	 */
	public void outputJustHeader(PrintWriter  output){	
		output.print("dataSet");
		output.print("\t");
		output.print("ontoName");
	    output.print("\t");
	    output.print("OntoId");
	    output.print("\t");
	    output.print("algorithm Name");
	    output.print("\t");
	    output.print("UC");
	    output.print("\t");
		output.print("Time (ms)");
		output.print("\t");
		output.print("#mups");
		output.print("\t");
		output.print("remark");
		output.println();
	}
	
	private String getOntId(String ontoName) {
		String id = "";
		
        int index = nameList.indexOf(ontoName);
        if(index!=-1) {
        	id = idList.get(index);
        } else {
        	System.out.println("********************************fail to find id for onto "+ontoName);
        }
		return id;
	}
	
	private void ini() {
        for(int i=0;i<OntoIDMap.names.length;i++){  
        	nameList.add(OntoIDMap.names[i]);  
        }  
       
        for(int i=0;i<OntoIDMap.ids.length;i++){  
        	idList.add(OntoIDMap.ids[i]);  
        }  

	}
	
	
	
}
