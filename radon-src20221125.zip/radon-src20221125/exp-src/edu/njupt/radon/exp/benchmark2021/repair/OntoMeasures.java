package edu.njupt.radon.exp.benchmark2021.repair;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

public class OntoMeasures {
	HashSet<HashSet<String>> justs = new HashSet<HashSet<String>>();
	long ucNumber = 0;
	long MinRemovalNumber = 0;
	long maxMUPNum = 0;
	long minMUPNum = 10000;
	long MUPSNum = 0;
	long repairTime = 3*60*60*1000;
	
	public OntoMeasures(String resultPath, String ontoName) {
		if(ontoName.contains("km1500_i500-3500")) {
			doComputeMUPSForkm3500(resultPath);
		} else {
			doComputeMUPS(resultPath);
		}
		
	}

	public OntoMeasures(String resultPath, int a) {
		doComputeMIPS(resultPath);
	}

	// 计算cplex-log.txt
	public OntoMeasures(String resultPath, boolean flag) {
		doComputecplex(resultPath);
	}

	/**
	 * @param logPath
	 */
	private void doComputecplex(String logPath) {
		System.out.println("logPath: "+logPath);
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			// Read File Line By Line
			// 得到 #minRemoval
			int counter = 0;
			while ((oneLine = bufferedReader.readLine()) != null) {
				//  Time to compute diagnosis (ms): 268215
				// Time (ms) to compute a minimal removal: 129
				if(oneLine.contains("Time") && oneLine.contains("compute")) {
					int index1 = oneLine.indexOf(": ");
					if(index1 != -1) {
						String str = oneLine.substring(index1+2);
						repairTime = Long.valueOf(str);
					} else {
						System.err.println("Error: index out of array");
					}
					
				}
				String MinRemovalNum = getMinRemovalNum(oneLine);
				if (MinRemovalNum.length() > 0) {
					MinRemovalNumber = Long.valueOf(MinRemovalNum);
				}
				if(oneLine.contains("[")) {
					counter++;
				}
			}
			if(MinRemovalNumber<=0) {
				MinRemovalNumber = counter;
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	
	
	/**
	 * 读取mups 除km1500_i500-3500之外的
	 * @param logPath
	 */
	private void doComputeMUPS(String logPath) {
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneUCBegin = false;
		boolean isOneMUPSBegin = false;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			// Read File Line By Line
			int counter = 0;
			while ((oneLine = bufferedReader.readLine()) != null) {
				if(oneLine.contains("**** mips : ")) {
					break;
				}
				String ucNum = getUCNum(oneLine);
				if (ucNum.length() > 0) {
					ucNumber = Long.valueOf(ucNum);
				}
				// 寻找UC
				if (oneLine.indexOf("> concept") != -1 || oneLine.indexOf("Unsati concept") != -1) {
					System.out.println(oneLine);
					isOneUCBegin = true;
					MUPSNum = 0;
					counter++;
					continue;				
				}
				// 寻找mups
				if (oneLine.indexOf("Found explanation ") != -1) {
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				}
				if (isOneUCBegin) {
					if (isOneMUPSBegin) {
						// In this case, the output of one MUPS has been finished.
						if (oneLine.trim().length() == 0 && oneMUPSString.size() > 0) {
							// Add the found MUPS to the collection of MUPS
							justs.add(new HashSet<String>(oneMUPSString));
							++MUPSNum;
							// Set the start
							isOneMUPSBegin = false;
						} else {
							int index1 = oneLine.indexOf("]");
							if (index1 != -1) {
								// Get the string after ]
								String axiomString = oneLine.substring(index1 + 1).trim();
								// Remove the first blank space if exists
								if (axiomString.indexOf(" ") == 0) {
									axiomString = axiomString.substring(1);
								}
								// Add the axiom string to the the collection of axiom strings.
								oneMUPSString.add(oneMUPSString.size() + axiomString);
							}
						}
						// !-----
					} else if ((oneLine.contains("The time (ms) to compute all") )||(oneLine.contains("Time"))) {
						if (MUPSNum > maxMUPNum) {
							maxMUPNum = MUPSNum;
						}
						if (MUPSNum < minMUPNum) {
							minMUPNum = MUPSNum;
						}
						isOneUCBegin = false;
					}
				}
			}
			ucNumber = counter;
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	/**
	 * 读取mups，针对km1500_i500-3500
	 * 事先把mips部分删掉
	 * @param logPath
	 */	
	private void doComputeMUPSForkm3500(String logPath) {
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneUCBegin = false;
		boolean isOneMUPSBegin = false;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			// Read File Line By Line
			int counter = 0;
			while ((oneLine = bufferedReader.readLine()) != null) {
				String ucNum = getUCNum(oneLine);
				if (ucNum.length() > 0) {
					ucNumber = Long.valueOf(ucNum);
				}
				// 寻找UC
				if (oneLine.indexOf("> Unsati concept : ") != -1) {
					isOneUCBegin = true;
					counter++;
					MUPSNum = 0;
					continue;
				}
				// 寻找mups
				if (oneLine.indexOf("Explanation <") != -1 || oneLine.startsWith("Explanation <")) {
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				}
				if (isOneUCBegin) {
					if (isOneMUPSBegin) {
						// In this case, the output of one MUPS has been finished.
						if (oneLine.trim().length() == 0 && oneMUPSString.size() > 0) {
							// Add the found MUPS to the collection of MUPS
							justs.add(new HashSet<String>(oneMUPSString));
							++MUPSNum;
							// Set the start
							isOneMUPSBegin = false;
						} else {
							int index1 = oneLine.indexOf("]");
							if (index1 != -1) {
								// Get the string after ]
								String axiomString = oneLine.substring(index1 + 1).trim();
								// Remove the first blank space if exists
								if (axiomString.indexOf(" ") == 0) {
									axiomString = axiomString.substring(1);
								}
								// Add the axiom string to the the collection of axiom strings.
								oneMUPSString.add(oneMUPSString.size() + axiomString);
							}
						}
					} else if (oneLine.indexOf("Time to debug an UC:") != -1) {
						if (MUPSNum > maxMUPNum) {
							maxMUPNum = MUPSNum;
						}
						if (MUPSNum < minMUPNum) {
							minMUPNum = MUPSNum;
						}
						isOneUCBegin = false;
					}
				}
			}
			if(ucNumber<=0) {
				ucNumber = counter;
			}
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}


	/**
	 * 求解km1500_i500-3500之外的
	 * 读取mips
	 * @param logPath
	 */
	private void doComputeMIPS(String logPath) {
		HashSet<String> oneMIPSString = new HashSet<String>();
		boolean isOneMIPSBegin = false;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			// Read File Line By Line
			boolean tobeCon = false;
			while ((oneLine = bufferedReader.readLine()) != null) {
				if(oneLine.contains("**** mips")) {
					tobeCon = true;
					continue;
				}
				if(!tobeCon) {
					continue;
				}
				// 寻找mips
				if (oneLine.startsWith("Explanation")) {
					isOneMIPSBegin = true;
					oneMIPSString.clear();
					continue;
				}

				if (isOneMIPSBegin) {
					// In this case, the output of one MiPS has been finished.
					if (oneLine.trim().length() == 0 && oneMIPSString.size() > 0) {
						// Add the found MUPS to the collection of MUPS
						justs.add(new HashSet<String>(oneMIPSString));
						// Set the start
						isOneMIPSBegin = false;
					} else {
						int index1 = oneLine.indexOf("]");
						if (index1 != -1) {
							// Get the string after ]
							String axiomString = oneLine.substring(index1 + 1).trim();
							// Remove the first blank space if exists
							if (axiomString.indexOf(" ") == 0) {
								axiomString = axiomString.substring(1);
							}
							// Add the axiom string to the the collection of axiom strings.
							oneMIPSString.add(axiomString);
						}
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	/**
	 * 获得#UC
	 * @param line
	 * @return
	 */
	private String getUCNum(String line) {
		String UCNumStr = "";
		// 预设#UC输出格式
		// 除km1500-3500
		String prefix = "The number of unsatisfiable concepts is ";
		// 针对km1500-3500
//		String prefix = "All unsatisfiable concepts: ";
		if (line.startsWith(prefix)) {
			UCNumStr = line.substring(prefix.length());
		}
		int symbolIndex = UCNumStr.indexOf(" ");
		if (symbolIndex != -1) {
			UCNumStr = UCNumStr.substring(0, symbolIndex).trim();
		}
		return UCNumStr;
	}

	/**
	 * 获得#minRemoval
	 * @param line
	 * @return
	 */
	private String getMinRemovalNum(String line) {
		String MinRemovalNumStr = "";
		// 预设时间输出格式
		String prefix = "minHS size: ";
		if (line.startsWith(prefix)) {
			MinRemovalNumStr = line.substring(prefix.length());
		}
		int symbolIndex = MinRemovalNumStr.indexOf(" ");
		if (symbolIndex != -1) {
			MinRemovalNumStr = MinRemovalNumStr.substring(0, symbolIndex).trim();
		}
		return MinRemovalNumStr;
	}

	public long getMinRemovalNum() {
		return MinRemovalNumber;
	}

	public long getUCNum() {
		return ucNumber;
	}

	public long getMaxMUPNum() {
		return maxMUPNum;
	}

	public long getMinMUPNum() {
		return minMUPNum;
	}

	public HashSet<HashSet<String>> getJusts() {
		return justs;
	}
	
	public long getRepairTime() {
		return repairTime;
	}

//	public HashSet<HashSet<String>> getmupJusts() {
//		return mupsjusts;
//	}
//
//	public HashSet<HashSet<String>> getmipJusts() {
//		return mipsjusts;
//	}

}
