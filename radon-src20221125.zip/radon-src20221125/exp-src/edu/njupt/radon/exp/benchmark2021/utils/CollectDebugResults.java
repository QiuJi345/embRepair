package edu.njupt.radon.exp.benchmark2021.utils;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * 得到 计算单个UC的Time 和 #mups
 * @author zsq
 */
public class CollectDebugResults {
	// 未找到，则为超时本体
	long time = -1;
	int mupsNumber = 0;
	int mupsNumForSwoop = 0;

	/**
	 * radon  pellet
	 * @param resultPath
	 */
	public CollectDebugResults(String resultPath) {
		 doComputeMUPS(resultPath);
	}
	
	/**
	 * swoop 和 张瑜
	 * @param resultPath
	 * @param a
	 */
	public CollectDebugResults(String resultPath, int a) {
		doComputeMUPS2(resultPath);
	}

	/**
	 * 
	 * @param logPath
	 */
	private void doComputeMUPS2(String logPath) {
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			// Read File Line By Line
			while ((oneLine = bufferedReader.readLine()) != null) {
				String timeStr = getTime(oneLine);
				if (timeStr.length() > 0) {
					time = Long.valueOf(timeStr);
				} else if (oneLine.indexOf("[") != -1) {
					mupsNumForSwoop = appearTime(oneLine, "[");
					if(mupsNumForSwoop>0) {
						mupsNumForSwoop = mupsNumForSwoop -1;
					}
				} else if(oneLine.contains("ERROR:")) {
					CollectDebugResultsMain.remark = "Fail to find some MUPS!";
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	/**
	 * @param s1
	 * @param s2
	 * @return s2在字符串s1中出现的次数
	 */
	private int appearTime(String s1, String s2) {
		// 记录出现次数
		int time = 0;
		// 遍历s1
		for (int i = 0; i < s1.length(); i++) {
			// 调用方法indexOf,计算s2在s1字符串中出现的下标
			int s2index = s1.indexOf(s2, i);
			// 当用if判断，当遍历开始下标i与s2在s1中出现的下标位置相等时,time+1
			if (i == s2index) {
				time++;
			}
		}
		return time;
	}

	/**
	 * 读取Time 和 #mups
	 * @param logPath
	 */
	private void doComputeMUPS(String logPath) {
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			// Read File Line By Line
			end: while ((oneLine = bufferedReader.readLine()) != null) {
				if (oneLine.indexOf("Found explanation") != -1) {
					mupsNumber++;
					continue;
				}else{
					String timeStr = getTime(oneLine);
					if (timeStr.length() > 0) {
						//System.out.println(logPath+",  timestr: "+timeStr);
						time = Long.valueOf(timeStr);
						break end;
					} else if(oneLine.contains("ERROR:")) {
						CollectDebugResultsMain.remark = "Fail to find some MUPS!";
					} 
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * 获得对应的时间
	 * @param line
	 * @return
	 */
	private String getTime(String line) {
		String timeStr = "";
		// 预设时间输出格式
		String prefix = "The time (ms) to compute all MUPS for a concept is: ";
		String prefix2 = "* The time (ms) to compute all MUPS for the unsatisfiable concept is: ";
		if (line.startsWith(prefix)) {
			timeStr = line.substring(prefix.length());
		} else if(line.startsWith(prefix2)) {
			timeStr = line.substring(prefix2.length());
		} else {
			prefix = "Time : ";
			if (line.startsWith(prefix)) {
				int symbolIndex = line.indexOf(":");
				timeStr = line.substring(symbolIndex + 1).trim();
			}
		}
		int symbolIndex = timeStr.indexOf(" ");
		if (symbolIndex != -1) {
			timeStr = timeStr.substring(0, symbolIndex).trim();
		}
		if (timeStr.contains("ms")) {
			System.out.println("stop");
		}
		return timeStr;
	}

	public long getTime() {
		return time;
	}
	
	public int getMUPSNum() {
		return mupsNumber;
	}
	
	public int getMupsNumForSwoop() {
		return mupsNumForSwoop;
	}
}
