package edu.njupt.radon.exp.benchmark2021.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.AxiomType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;


public class CollectOntoInfoMain {
	
	
	public static void main(String[] args) throws Exception {	
		String ds = "3-InjectIncoHybrid";
		String ontoRoot = "F:/Experiments/2021-kbs/data/"+ds+"/";
		//System.setOut((new PrintStreamObject( "results/log6.txt")).ps);
		
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(
				"results/ontoInfo-"+ds+".xls")),true);    	
		outputHeader(output);
		printOntoInfo(output, ontoRoot);
					
		output.flush();
        output.close();
	}
	

	
	public static void printOntoInfo(PrintWriter  output, String ontoRoot) throws Exception {
		int oCounter = 1;
		File rootFile = new File(ontoRoot);
		for(File file : rootFile.listFiles()){
			if(!file.isDirectory()){
				String ontoName = file.getName();

				String ontoPath = ontoRoot+ontoName;
				System.out.println((oCounter++)+" ) Obtaining onto info: "+ontoPath);
				OWLOntology o = OWL.manager.loadOntology(IRI.create("file:"+ontoPath));
				
				output.print(ontoName.substring(0,ontoName.indexOf(".")));
			    output.print("\t");
			    // compute tbox and abox
			    HashSet<OWLAxiom> abox = OWLTools.getABox(o);
			    HashSet<OWLAxiom> tbox = new HashSet<OWLAxiom>(o.getLogicalAxioms());
			    tbox.removeAll(abox);
			    output.print(tbox.size());
			    output.print("\t");
			   /* int i = 0;
			    System.out.println("------------ O ------------");
			    for(OWLAxiom a : o.getLogicalAxioms()) {
			    	System.out.println((i++)+"> "+a.toString());
			    }
			    i = 0;
			    HashSet<OWLAxiom> axioms = new HashSet<>(o.getLogicalAxioms());
			    axioms.removeAll(o.getTBoxAxioms(true));
			    System.out.println("------------ O - tbox ------------");
			    for(OWLAxiom a : axioms) {
			    	System.out.println((i++)+"> "+a.toString());
			    }
			    HashSet<OWLAxiom> axioms2 = new HashSet<>(o.getLogicalAxioms());
			    axioms2.removeAll(o.getRBoxAxioms(true));
			    System.out.println("------------ O - rbox ------------");
			    for(OWLAxiom a : axioms2) {
			    	System.out.println((i++)+"> "+a.toString());
			    }
			    HashSet<OWLAxiom> axioms3 = new HashSet<>(o.getLogicalAxioms());
			    axioms3.removeAll(axioms);
			    axioms3.removeAll(axioms2);
			    System.out.println("------------ O - tbox - rbox ------------");
			    for(OWLAxiom a : axioms3) {
			    	System.out.println((i++)+"> "+a.toString());
			    }*/		    
			    
			    output.print(abox.size());
			    output.print("\t");
				output.print(o.getAxiomCount(AxiomType.SUBCLASS_OF));
				output.print('\t');	
				output.print(o.getAxiomCount(AxiomType.EQUIVALENT_CLASSES));
			    output.print("\t");
				output.print(o.getAxiomCount(AxiomType.DISJOINT_CLASSES));
				output.print('\t');
				output.print(o.getAxiomCount(AxiomType.SUB_DATA_PROPERTY)+
						o.getAxiomCount(AxiomType.SUB_OBJECT_PROPERTY));		    
			    output.print("\t");
			    output.print(o.getAxiomCount(AxiomType.OBJECT_PROPERTY_DOMAIN)+o.getAxiomCount(AxiomType.DATA_PROPERTY_DOMAIN));
				output.print('\t');
				output.print(o.getAxiomCount(AxiomType.OBJECT_PROPERTY_RANGE)+o.getAxiomCount(AxiomType.DATA_PROPERTY_RANGE));
				output.print('\t');
				
			    output.print(o.getClassesInSignature().size());
			    System.out.println("    number of classes: "+o.getClassesInSignature().size());
				output.print('\t');
				output.print(o.getObjectPropertiesInSignature().size());
				output.print('\t');
				output.print(o.getDataPropertiesInSignature().size());
				output.print('\t');		    
			    output.print(o.getIndividualsInSignature().size());
			    output.print('\t');	
			    // output 
			    HashSet<OWLClass> ucs = new HashSet<>();
			    /*if(ontoName.startsWith("mad") || ontoName.startsWith("opengalen-no-")) {
			    	ucs = new HashSet<>();
			    } else*/ {
			    	ucs = ReasoningTools.getUnsatiConcepts(tbox);
			    	/*int size = o.getObjectPropertiesInSignature().size()+o.getDataPropertiesInSignature().size();
			    	for(OWLClass uc : ucs) {
			    		Set<OWLAxiom> module = OWLTools.extractModule(o, uc);			    		
			    		if(size>10) {
			    			getOp(module, uc);
			    		}			    		
			    	}*/
			    }			    
			    // output uc number
			    output.print(ucs.size());
			    System.out.println("    UC:　"+ucs.size());
			    output.print('\t');
			    // output DL expressivity
			    String s = "$\\mathcal{"+ExpressivityChecker.getExpressivity(o)+"}$";
			    output.print(s);
			    output.println();
			    //OWL.manager.clearIRIMappers();

			    OWL.manager.removeOntology(o);	
			}
		}
	}
	
	public static void getOp(Set<OWLAxiom> ax, OWLClass uc) {
		try {
			
			OWLOntology onto = OWLTools.createOntology(new HashSet<OWLAxiom>(ax));
			int op=onto.getObjectPropertiesInSignature().size();
			int dp = onto.getDataPropertiesInSignature().size();
			if(op+dp > 10) {
				System.out.println("uc: "+uc.getIRI().toString()+", ");
				System.out.println("  op: "+ op +", dp: "+dp);
			}
			
		} catch(Exception ex) {
			
		}
		
	}
	
	public static void outputHeader(PrintWriter  output){
		output.print("Ontology Name");
	    output.print("\t");
	    output.print("T");
	    output.print("\t");
	    output.print("ABox");
	    output.print("\t");
		output.print("\\#Sub");
		output.print('\t');	
		output.print("EquClass");
		output.print('\t');	
		output.print("\\#Dis");
		output.print('\t');
		output.print("SubProp");		    
	    output.print("\t");
	    output.print("domain");		    
	    output.print("\t");
	    output.print("range");		    
	    output.print("\t");
	    
	    
	    output.print("\\#C");
	    output.print("\t");
	    output.print("ObjectProperties");
	    output.print("\t");
	    output.print("DataProperties");
	    output.print("\t");
	    output.print("Individuals");
	    output.print("\t");
	    output.print("\\#UC");
	    output.print("\t");
	    output.print("Expressivity");
		output.println();
	}
	
	
	/*
	public static OWLOntology openOntology(String ontoPath){		
		
		String path = checkOntoPath(ontoPath);
		IRI physicalURI = IRI.create(path);	
		OWLOntology ontology = null;
		manager = OWLManager.createOWLOntologyManager();
		
		try{
			ontology = manager.loadOntology(physicalURI);  
		} catch (OWLOntologyCreationException ex){
			ex.printStackTrace();
		}   
       	return ontology;
	}
	
	public static String checkOntoPath(String ontoPath) {
		String path = ontoPath;
		if (!ontoPath.startsWith("http:"))
	        if (!ontoPath.startsWith("https:"))
		        if (!ontoPath.startsWith("ftp:"))
		        	if (!ontoPath.startsWith("file:"))
		        		path =  "file:" + ontoPath;
		return path;
	}
	
	public static HashSet<OWLClass> getUnsatiConcepts(
			OWLOntology onto) {		
		HashSet<OWLClass> uncon = new HashSet<OWLClass>();		
					
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		OWLReasoner owlReasoner = reasonerFactory.createReasoner(onto);
		System.out.println("Orignial onto size: "+onto.getAxiomCount());
		
		
		OWLOntology o = onto;
		if(!owlReasoner.isConsistent()) {
			System.out.println("inconistent onto");
			info = "inconsistent";
			// Obtain Tbox
			HashSet<OWLAxiom> tbox = new HashSet<OWLAxiom>(onto.getTBoxAxioms(true));	
			try {
				o = OWL.manager.createOntology();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
			OWL.manager.addAxioms(o, tbox);
			System.out.println("Extracted onto size: "+o.getAxiomCount());
			owlReasoner = reasonerFactory.createReasoner(onto);
			
		} else {
			info = "";
		}
		
		for(OWLClass oc : o.getClassesInSignature()){
        	if(oc.equals(OWL.factory.getOWLNothing())||
        			oc.equals(OWL.factory.getOWLThing())){
        		continue;
        	}
        	boolean f = true;
    		if(o.containsClassInSignature(oc.getIRI())){
    			f = owlReasoner.isSatisfiable(oc);
    		}
			if(!f){
				uncon.add(oc);
				System.out.println("This onto is incoehrent");
			}					
		}				
		return uncon;
	}*/
	
	
}
