package edu.njupt.radon.exp.benchmark2021;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import com.clarkparsia.owlapiv3.OWL;
import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.PelletDebug;
import edu.njupt.radon.debug.incoherence.heuristic.HeuristicDebug;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceDebug;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceParameters;
import edu.njupt.radon.parameters.DebuggingArgumentsProcessing;
import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.TimeoutException;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTask;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

// 修改后
public class DebugWithTimeout {
	//static OWLOntologyManager manager = null;
	OWLOntology ontology;
	OWLClass unsatConcept;
	RadonDebug debug;
	HeuristicDebug heuristicDebug;

	public static Thread thread = null;
	

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		System.setProperty("entityExpansionLimit", "10000000");

		if (args.length > 0) {
			DebuggingArgumentsProcessing process = new DebuggingArgumentsProcessing();
			process.processArguments(args, DebugWithTimeout.class.getName());
		}
		// set reasoner
		ReasoningTask.reasoner = DebuggingParameters.reasoner;
		
		int debugMode = 2;  // 1:debug ontos; 2: deubg ucs; 3:
		int ucNum = 150000;
		
		
		// 1、针对较小的本体，运行较快的，直接给出本体所在文件夹路径即可，由代码循环读入
		if(debugMode==1) {
			File rootFile = new File(DebuggingParameters.ontoRoot);
			// 循环遍历文件下中的所有本体
			for (File file : rootFile.listFiles()) {
				if (!file.isDirectory()) {
					String ontoName = file.getName();
					ontoName = ontoName.substring(0, ontoName.indexOf("."));
					
					DebuggingParameters.ontoPath = DebuggingParameters.ontoRoot +ontoName;
					DebuggingParameters.resultPath = DebuggingParameters.resultRoot+ontoName+"/"+DebuggingParameters.debugMethod+"/";
					
					OWLOntology onto = OWL.manager.loadOntology( IRI.create( "file:" + DebuggingParameters.ontoPath+".owl" ) );
					
					// get all UCs
					HashSet<OWLClass> UCs = getUnsatiConcepts(onto, OWL.manager);
					// UCs中的不可满足概念编序号
					List<OWLClass> list = new ArrayList<OWLClass>(UCs);
					int UCSize = UCs.size();								
					// unNum控制起始位置，当出现timeout时，可以从指定的位置继续
					for(int i = 0; i < ucNum && i < UCSize; i++) {
						OWLClass uc = list.get(i);		
						/*System.out.println(uc.getIRI().toString());
						if(!uc.getIRI().toString().contains("http://edas#Workshop")) {
							continue;
						}*/
						// Perform debugging task
						DebugWithTimeout debug = new DebugWithTimeout(onto, uc);
						debug.computeJusts(); 
					}
					OWL.manager.removeOntology(onto);
				}
			}
		} else if(debugMode==2) {
			// 2、针对运行较慢的本体，设置单个读入			
			String ontoName = "ATBox-confof-edas";			
			DebuggingParameters.ontoPath = DebuggingParameters.ontoRoot +DebuggingParameters.debugTask+"/"+ontoName;
			DebuggingParameters.resultPath = DebuggingParameters.resultRoot+DebuggingParameters.debugTask+"/"+ontoName+"/"+DebuggingParameters.debugMethod+"/";
			
			OWLOntology onto = openOntology("file:" + DebuggingParameters.ontoPath+".owl");
			// get all UCs
			HashSet<OWLClass> UCs = getUnsatiConcepts(onto, OWL.manager);
			// UCs中的不可满足概念编序号
			List<OWLClass> list = new ArrayList<OWLClass>(UCs);
			int UCSize = UCs.size();
			System.out.println(UCSize);

			int cou = 0;
			for(int i = 0; i < ucNum && i < UCSize; i++) {
				OWLClass uc = list.get(i);	
				System.out.println(i+"> "+uc.getIRI().toString());
				cou++;
				/*if(cou< 20) {
					continue;
				}*/
				
				
				// Perform debugging task
				DebugWithTimeout debug = new DebugWithTimeout(onto, uc);
				debug.computeJusts(); 
			}
		} else {
			// 3、主要针对运行有问题的本体，需要调试的（！注意，不是针对timeout的本体，timeout的可在2代码中改
			String ucUri = "ribosome-binding-site";
			String ontoName = "tambis";			
			DebuggingParameters.ontoPath = DebuggingParameters.ontoRoot +DebuggingParameters.debugTask+"/"+ontoName;
			DebuggingParameters.resultPath = DebuggingParameters.resultRoot+DebuggingParameters.debugTask+"/"+ontoName+"/"+DebuggingParameters.debugMethod+"/";
			
			OWLOntology onto = openOntology("file:" + DebuggingParameters.ontoPath+".owl");
			OWLClass uc = OWLTools.getOWLClass(onto, ucUri);
			// Perform debugging task
			DebugWithTimeout debug = new DebugWithTimeout(onto, uc);
			debug.computeJusts(); 
			
		}
		
	}

	/** 构造函数
	 * @param ontology
	 * @param uc
	 */
	public DebugWithTimeout(OWLOntology ontology, OWLClass uc) {
		this.ontology = ontology;
		this.unsatConcept = uc;
	}

	/**
	 * 
	 */
	public void computeJusts() {
		// 不需要继续则返回
		if (!needContinue(unsatConcept)) {
			return;
		}
		System.out.println("The debugging concept is : " + unsatConcept.getIRI().toString());
		long startTime = System.currentTimeMillis();
		try {
			doCompute();
		} catch (TimeoutException tex) {
			tex.printStackTrace();
			System.out.println(" Time is out!");
			System.exit(1);
		} catch (OutOfMemoryError oex) {
			oex.printStackTrace();
			System.out.println(" Memory is out!");
			System.exit(1);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println(" Exception is thrown when computing MUPS for concept " + unsatConcept.toString());
			System.exit(1);
		} finally {
			long exeTime = System.currentTimeMillis() - startTime;
			postProcessing();
			try {
				Thread.sleep(10);
			} catch (InterruptedException ex) {
				ex.printStackTrace();
				System.exit(1);
			}
			System.out.println("[Info] finish!");
			System.out.println("\nTime : " + exeTime);
//			System.exit(1);
		}
	}

	private void doCompute() throws TimeoutException, OutOfMemoryError, Exception {
		final MyThread myThread = new MyThread();
		thread = new Thread(myThread);
		// Start a new thread
		thread.start();
		// Set timeout for the thread
		thread.join(DebuggingParameters.timeout);
		// If time is out, then interrupt the current thread
		if (thread.isAlive()) {
			thread.interrupt();
		}
	}

	
	/** 判断是否需要继续
	 * @param unsatConcept
	 * @return
	 */
	private boolean needContinue(OWLClass unsatConcept) {
		boolean needContinue = true;
		// 不存在不可满足概念
		if (unsatConcept == null) {
			System.out.println("The concept to be explained is null !");
			needContinue = false;
		} else if (unsatConcept.equals(OWL.factory.getOWLNothing())) {
			System.out.println("The concept is nothing which can be explained by itself !");
			needContinue = false;
		} else if (hasBeenExplained(unsatConcept)) {
			System.out.println("   This concept has been explained!");
			needContinue = false;
		}
		return needContinue;
	}

	/**
	 * @param concept
	 * @param ontaName
	 * @return
	 */
	public boolean hasBeenExplained(OWLClass concept) {
		boolean hasBeenExplained = false;		
		String conceptName = OWLTools.getLocalName(concept);
		String resultPath = DebuggingParameters.resultPath+conceptName+"/";
		
		// Check the path to store results
		File file = new File(resultPath);
		if (!file.exists()) {
			file.mkdirs();
		} else {
			// 判断已经存在的这个文件夹对应的uc是不是跟目前的这个uc是同一个，
			// 如果不是，则需要对当前这个uc的local name重新命名，避免重复		
			if (FileTools.isLogFileExists(resultPath + "log.txt")) {
				String folderName = this.getUcFolderName(resultPath, this.unsatConcept);
				if(folderName == null) {
					hasBeenExplained = true;
				} else {
					resultPath=resultPath.replace(conceptName, folderName);
					file = new File(resultPath);
					if (!file.exists()) {
						file.mkdirs();
					} else if(FileTools.isLogFileExists(resultPath + "log.txt")) {
						hasBeenExplained = true;						
					}					 
				}
			}
		}
		// If the concept has not been explained, we save the debugging results to a
		// local file.
		if (!hasBeenExplained) {
			System.setOut((new PrintStreamObject(resultPath + "log.txt")).ps);
		}
		return hasBeenExplained;
	}
	
	private String getUcFolderName(String ucPath, OWLClass currentUc) {
		String folderName = null;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(ucPath+ "log.txt");
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			
			String oneLine = bufferedReader.readLine();	
			String s = "The debugging concept is : ";
			System.out.println(oneLine);
			boolean foundInfo = false;
			int index = oneLine.indexOf(s);
			if(index != -1) {
				foundInfo = true;
			} else {
				s = "The debugged concept is : ";
				index = oneLine.indexOf(s);
				if(index != -1) {
					foundInfo = true;
				} 
			}
			if(foundInfo) {
				index = oneLine.indexOf("http://");
				if(index != -1) {
					String ucUri = oneLine.substring(index).trim();
					if(!this.unsatConcept.getIRI().toString().equals(ucUri)) {
						folderName = OWLTools.getFileName(this.unsatConcept)+"radon2";
					}
				}
				
			}			
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		return folderName;
	}

	private void postProcessing() {
		if (DebuggingParameters.debugMethod.equalsIgnoreCase("pattern")) {
			// System.out.println("================== Correctness Checking
			// ======================");
			// InconsistencyTools.checkMUPSCorrectness(ucMUPS, unsatConcept);
		} else if (DebuggingParameters.debugMethod.equalsIgnoreCase("relevance-cm")) {
			// Output global hitting sets and check their correctness.
			HashSet<Vector<OWLAxiom>> hittingSets = debug.getHittingSets();
			if (!RelevanceParameters.debugStrategy.equals(RelevanceParameters.COMPUTE_ALL_HS_REL)) {
				System.out.println("    " + hittingSets.size() + " hitting sets have been found: ");
				int i = 0;
				for (Vector<OWLAxiom> hittingSet : hittingSets) {
					System.out.println("    Hitting set <" + (i++) + ">");
					for (OWLAxiom axiom : hittingSet) {
						System.out.println("      " + axiom.toString());
					}
					// Check the correctness of a hitting set
					HashSet<OWLAxiom> axiomsInOnto = new HashSet<OWLAxiom>(ontology.getLogicalAxioms());
					axiomsInOnto.removeAll(hittingSet);
					System.out.println("Does <" + unsatConcept.getIRI().toString() + "> become satisfiable? "
							+ ReasoningTools.isSatisfiable(axiomsInOnto, unsatConcept));
				}
			}
		}

	}

	private void iniDebugMethod(HashSet<OWLAxiom> debuggingAxiomSet) {
		System.out.println("******* debug method is : "+DebuggingParameters.debugMethod);
		// Generate an object for the interface ComputeMUPS
		if (DebuggingParameters.debugMethod.equals(DebuggingParameters.pelletBlDebug)) {
			System.out.println("pelletbl");
			debug = new PelletDebug(this.ontology, false);
		} else if (DebuggingParameters.debugMethod.equals(DebuggingParameters.radonPatDebug)) {
			OntologyInfo myOnto = new OntologyInfo(debuggingAxiomSet);
			ClassHierarchy classHier = new ClassHierarchy(myOnto);
			PropertyHierarchy propHier = new PropertyHierarchy(myOnto.getOriginalAxioms());
			debug = new HeuristicDebug(myOnto, classHier, propHier);
		} else if (DebuggingParameters.debugMethod.equals(DebuggingParameters.radonRelAllDebug)) {
			if (DebuggingParameters.ontoName.equals("km1500")) {
				RelevanceParameters.selectionFunction = RelevanceParameters.SubSeleFunc;
			}
			RelevanceParameters.debugStrategy = RelevanceParameters.COMPUTE_ALL_HS_REL;
			debug = new RelevanceDebug(debuggingAxiomSet, null);
		} else if (DebuggingParameters.debugMethod.equals(DebuggingParameters.radonRelCmDebug)) {
			if (DebuggingParameters.ontoName.equals("km1500")) {
				RelevanceParameters.selectionFunction = RelevanceParameters.SubSeleFunc;
			}
			RelevanceParameters.debugStrategy = RelevanceParameters.COMPUTE_All_CM_HS_REL;
			debug = new RelevanceDebug(debuggingAxiomSet, null);
		} else if (DebuggingParameters.debugMethod.equals(DebuggingParameters.radonBlPatDebug)) {
			if (debug == null) {
				OntologyInfo myOnto = new OntologyInfo(debuggingAxiomSet);
				ClassHierarchy classHier = new ClassHierarchy(myOnto);
				PropertyHierarchy propHier = new PropertyHierarchy(myOnto.getOriginalAxioms());
				heuristicDebug = new HeuristicDebug(myOnto, classHier, propHier);
			}
			debug = new BlackboxDebug(debuggingAxiomSet);
		} else if (DebuggingParameters.debugMethod.equals(DebuggingParameters.radonRelPatDebug)) {
			if (debug == null) {
				OntologyInfo myOnto = new OntologyInfo(debuggingAxiomSet);
				ClassHierarchy classHier = new ClassHierarchy(myOnto);
				PropertyHierarchy propHier = new PropertyHierarchy(myOnto.getOriginalAxioms());
				heuristicDebug = new HeuristicDebug(myOnto, classHier, propHier);
			}
			if (DebuggingParameters.ontoName.equals("km1500")) {
				RelevanceParameters.selectionFunction = RelevanceParameters.SubSeleFunc;
			}
			RelevanceParameters.debugStrategy = RelevanceParameters.COMPUTE_ALL_HS_REL;
			debug = new RelevanceDebug(debuggingAxiomSet, null);
		} else {
			debug = new BlackboxDebug(debuggingAxiomSet);
		}

	}

	class MyThread implements Runnable {
		public void run() {
			if (DebuggingParameters.useModule) {
				long startTime = System.currentTimeMillis();
				Set<OWLAxiom> module = OWLTools.extractModule(ontology, unsatConcept);
				long extractModuleTime = System.currentTimeMillis() - startTime;
				// module = new HashSet<OWLAxiom>(axiomsInOnto);
				System.out.println("Module size : " + module.size());
				System.out.println("Extraction time : " + extractModuleTime);
				iniDebugMethod(new HashSet<OWLAxiom>(module));
			} else {
				iniDebugMethod(new HashSet<OWLAxiom>(ontology.getLogicalAxioms()));
			}

			HashSet<HashSet<OWLAxiom>> foundMUPS = new HashSet<HashSet<OWLAxiom>>();
			if (DebuggingParameters.debugMethod.equals(DebuggingParameters.radonBlPatDebug)
					|| DebuggingParameters.debugMethod.equals(DebuggingParameters.radonRelPatDebug)) {
				long startTime = System.currentTimeMillis();
				foundMUPS = heuristicDebug.getMUPS(unsatConcept);
				System.out.println("Time for pattern-based debugging: " + (System.currentTimeMillis() - startTime));

				startTime = System.currentTimeMillis();
				debug.getMUPS(unsatConcept, foundMUPS);
				System.out.println("Time for default debugging: " + (System.currentTimeMillis() - startTime));
			} else {
				debug.getMUPS(unsatConcept);
			}
		}
	}
	

	/** 打开owl本体
	 * @param ontoPath
	 * @return
	 */
	public static OWLOntology openOntology(String ontoPath) {
		String path = checkOntoPath(ontoPath);
		IRI physicalURI = IRI.create(path);
		OWLOntology ontology = null;
		//manager = OWLManager.createOWLOntologyManager();
		try {
			ontology = OWL.manager.loadOntology(physicalURI);
		} catch (OWLOntologyCreationException ex) {
			ex.printStackTrace();
		}
		return ontology;
	}

	/** 检查本体路径
	* @param ontoPath
	* @return
	*/
	public static String checkOntoPath(String ontoPath) {
		String path = ontoPath;
		if (!ontoPath.startsWith("http:"))
			if (!ontoPath.startsWith("https:"))
				if (!ontoPath.startsWith("ftp:"))
					if (!ontoPath.startsWith("file:"))
						path = "file:" + ontoPath;
		return path;
	}

	/** 获得不可满足概念
	 * @param onto
	 * @param managerr
	 * @return UC（不可满足概念）
	 */
	public static HashSet<OWLClass> getUnsatiConcepts(OWLOntology onto, OWLOntologyManager manager) {
		HashSet<OWLClass> uncon = new HashSet<OWLClass>();
		OWLDataFactory factory = manager.getOWLDataFactory();
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		OWLReasoner owlReasoner = reasonerFactory.createReasoner(onto);
		for (OWLClass oc : onto.getClassesInSignature()) {
			if (oc.equals(factory.getOWLNothing()) || oc.equals(factory.getOWLThing())) {
				continue;
			}
			boolean f = true;
			if (onto.containsClassInSignature(oc.getIRI())) {
				f = owlReasoner.isSatisfiable(oc);
			}
			if (!f) {
				uncon.add(oc);
			}
		}
		owlReasoner.dispose();
		// 测试用
		//System.out.println(uncon);
		return uncon;
	}



}
