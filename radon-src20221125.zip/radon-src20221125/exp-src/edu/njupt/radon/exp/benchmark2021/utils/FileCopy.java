package edu.njupt.radon.exp.benchmark2021.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class FileCopy {
	public static void main(String[] args) {
		String algorithmName = "/CPDebug/";
		String dataset="3-InjectIncoHybrid/";
		String newRoot = "d:/new/"+dataset;
		String oripath = "H:/Programming/WorkspacesCurrent/debug/CSMUPS/results/"+dataset;
		
		File file = new File(oripath);
		for(File ontoFile : file.listFiles()){
			// 读取本体名称
			String ontoName = ontoFile.getName();
			if(!ontoName.contains("-")) {
				continue;
			}
			String newontoPath = newRoot + ontoName + algorithmName;
			// 继续读取下一层
			for(File ucFile : ontoFile.listFiles()){
				// 读取UC名称
				String ucName = ucFile.getName();
				String newUCPath = newontoPath + ucName + "/";
				
				for(File logFile : ucFile.listFiles()){
					File f = new File(newUCPath);
					if(!f.exists()) {
						f.mkdirs();
					}
					File newFile = new File(newUCPath + "log.txt");
					try {
						System.out.println("copy "+logFile.getPath());
						System.out.println("      to "+newFile.getPath());
						// 拷贝文件
						Files.copy(logFile.toPath(), newFile.toPath());
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}				
				}
				newUCPath = "";
			}
			newontoPath = "";
		}
	}
}
