package edu.njupt.radon.exp.benchmark2021.utils;

import java.io.File;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.util.DLExpressivityChecker;

import com.clarkparsia.owlapiv3.OWL;
import com.clarkparsia.pellet.owlapiv3.PelletReasoner;
import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;


/**
 * Author: Matthew Horridge<br>
 * The University Of Manchester<br>
 * Bio-Health Informatics Group<br>
 * Date: 20-Jun-2007<br><br>
 *
 * An example which shows how to interact with a reasoner.  In this example
 * Pellet is used as the reasoner.  You must get hold of the pellet libraries
 * from pellet.owldl.com.
 */
public class ExpressivityChecker {
	//static String ontoName = "";
	
	// Create our ontology manager in the usual way.
    //OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
    
    public static void main(String[] args) throws Exception {
    	// 输入本体所在文件夹路径
    	String ontoRoot = "F:/Experiments/2021-kbs/data/1.1-existingOnts/";
//    	String ontoRoot = "onto/yanfaData/subOnts/al/";
    	// 读入输入本体文件夹
    	File rootFile = new File(ontoRoot);
    	// 依次读入文件夹中的各个本体
    	for (File file : rootFile.listFiles()) {
    		if (!file.isDirectory() && file.getName().endsWith("owl")) {
    			String ontoName = file.getName();
    			String ontoPath = "file:" + ontoRoot + ontoName;
    			System.out.println(ontoName);
    			OWLOntology onto = OWL.manager.loadOntology( IRI.create( ontoPath ) );
    			ExpressivityChecker main = new ExpressivityChecker();
    			main.getOntInfo(onto);
    		}
    	}       
    }
    
    public void getOntInfo(OWLOntology onto) throws Exception {
//    	System.out.println(onto.getLogicalAxiomCount());
//    	System.out.println(OWLTools.getTBox(onto).size());
//    	System.out.println(OWLTools.getABox(onto).size());
    	this.getDLExpressivity(onto);
    }
    

    public static String getExpressivity(OWLOntology ont){
    	String exp = "unknown";
        try {
            
            // We need to create an instance of Reasoner.  Reasoner provides the basic
            // query functionality that we need, for example the ability obtain the subclasses
            // of a class etc.  To do this we use a reasoner factory.

            // Create a reasoner factory.  In this case, we will use pellet, but we could also
            // use FaCT++ using the FaCTPlusPlusReasonerFactory.
            // Pellet requires the Pellet libraries  (pellet.jar, aterm-java-x.x.jar) and the
            // XSD libraries that are bundled with pellet: xsdlib.jar and relaxngDatatype.jar
            // make sure these jars are on the classpath
           // PelletReasoner reasoner = PelletReasonerFactory.getInstance().createReasoner( ont );

            // We now need to load some ontologies into the reasoner.  This is typically the
            // imports closure of an ontology that we're interested in.  In this case, we want
            // the imports closure of the pizza ontology.  Note that no assumptions are made
            // about the dependency of one ontology on another ontology.  This means that if
            // we loaded just the pizza ontology (using a singleton set) then any imported ontologies
            // would not automatically be loaded.
            // Obtain and load the imports closure of the pizza ontology
            Set<OWLOntology> importsClosure = OWL.manager.getImportsClosure(ont);
            //reasoner.loadOntologies(importsClosure);
            //reasoner.classify();

            // We can examine the expressivity of our ontology (some reasoners do not support
            // the full expressivity of OWL)
            DLExpressivityChecker checker = new DLExpressivityChecker(importsClosure);
            //System.out.println("Expressivity: " + checker.getDescriptionLogicName());

            exp = checker.getDescriptionLogicName();
            System.out.println("here"+exp);
            
        } catch(UnsupportedOperationException exception) {
            System.out.println("Unsupported reasoner operation.");
    
        } 
        return exp;
    }
        
    public static void getDLExpressivity(OWLOntology ont){
        try {
            
            // We need to create an instance of Reasoner.  Reasoner provides the basic
            // query functionality that we need, for example the ability obtain the subclasses
            // of a class etc.  To do this we use a reasoner factory.

            // Create a reasoner factory.  In this case, we will use pellet, but we could also
            // use FaCT++ using the FaCTPlusPlusReasonerFactory.
            // Pellet requires the Pellet libraries  (pellet.jar, aterm-java-x.x.jar) and the
            // XSD libraries that are bundled with pellet: xsdlib.jar and relaxngDatatype.jar
            // make sure these jars are on the classpath
            PelletReasoner reasoner = PelletReasonerFactory.getInstance().createReasoner( ont );

            // We now need to load some ontologies into the reasoner.  This is typically the
            // imports closure of an ontology that we're interested in.  In this case, we want
            // the imports closure of the pizza ontology.  Note that no assumptions are made
            // about the dependency of one ontology on another ontology.  This means that if
            // we loaded just the pizza ontology (using a singleton set) then any imported ontologies
            // would not automatically be loaded.
            // Obtain and load the imports closure of the pizza ontology
            Set<OWLOntology> importsClosure = OWL.manager.getImportsClosure(ont);
            //reasoner.loadOntologies(importsClosure);
            //reasoner.classify();

            // We can examine the expressivity of our ontology (some reasoners do not support
            // the full expressivity of OWL)
            DLExpressivityChecker checker = new DLExpressivityChecker(importsClosure);
            //System.out.println("Expressivity: " + checker.getDescriptionLogicName());

            // We can determine if the pizza ontology is actually consistent.  (If an ontology is
            // inconsistent then owl:Thing is equivalent to owl:Nothing - i.e. there can't be any
            // models of the ontology)
            boolean consistent = reasoner.isConsistent();
            //System.out.println("Consistent: " + consistent);
            if(consistent){
            	 // We can easily get a list of inconsistent classes.  (A class is inconsistent if it
                // can't possibly have any instances).  Note that the getInconsistentClasses method
                // is really just a convenience method for obtaining the classes that are equivalent
                // to owl:Nothing.
                Node<OWLClass> inconsistentClasses = reasoner.getUnsatisfiableClasses();
                int counter = 0;
                if (inconsistentClasses != null) {
                    //System.out.println("The following classes are unsatifiable " );
                    for(OWLClass cls : inconsistentClasses.getEntities()) {
                    	if(cls.equals(OWL.Nothing)){
            	    		//System.out.println("Ignore the class of nothing.");
            	    		continue;
            	    	}
                        //System.out.println("    UC " + counter + " > " + cls.getIRI().toString());
                        counter ++;
                    }                
                } else {
                    //System.out.println("There are no unsatifiable classes");
                }
//                System.out.println(ontoName + " & " + ont.getLogicalAxiomCount() + " & "+
//                		checker.getDescriptionLogicName() + " & "+ counter + "\\\\");
                System.out.println(checker.getDescriptionLogicName());
            } else {
            	System.out.println(checker.getDescriptionLogicName());
            }
            
        } catch(UnsupportedOperationException exception) {
            System.out.println("Unsupported reasoner operation.");
       
        } 
        
       // System.out.println( " Time (ms): " + ( System.currentTimeMillis() - timer ));
       // System.out.println(); 
    }
}
