package edu.njupt.radon.exp.benchmark2021;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.debug.incoherence.heuristic.HeuristicDebug;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.repair.ilp.ILPAlgorithm;
import edu.njupt.radon.repair.ilp.ILPTools;
import edu.njupt.radon.repair.ilp.RepairParameters;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;
import ilog.cplex.IloCplex;

public class ComputeMinRemoval {

	OWLOntology currentOnt = null;
	
	public static void main(String[] args) throws Exception {
		//2.1-InjectUCsFromScratch 2.2-InjectUCsWithOnto 2.3-mipsRel  3-InjectIncoHybrid
		
		String ontoRoot = "yanfaData/1.2-MergeOntologies/";
				
		ComputeMinRemoval comp = new ComputeMinRemoval();
		comp.process(ontoRoot);

	}
	
	public void process(String ontoRoot,  String repairStrategy)  throws Exception {
		File rootFile = new File(ontoRoot);
		// 循环遍历文件下中的所有本体
		for (File file : rootFile.listFiles()) {
			if (!file.isDirectory()) {
				String ontoName = file.getName();
				String ontoPath =  ontoRoot + ontoName;
				
				System.out.println(" Current onto is : "+ontoPath);
				String name = ontoName.substring(0, ontoName.lastIndexOf("."));
				String resultPath = "results/"+ontoRoot+"/"+name+"/";	
				if(FileTools.fileExists(resultPath)) {
					System.out.println("   This ontology has been debuged.");
					continue;
				}
				
				this.setoutput(repairStrategy, resultPath);	
				File f  = new File(ontoPath);	
				OWLOntology o = OWL.manager.loadOntology(IRI.create(f.toURI()));
				computeMinRemoval(o, resultPath);
				OWL.manager.removeOntology(o);
				System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
			}
		}
	}
	
	public void process(String ontoRoot)  throws Exception {
		File rootFile = new File(ontoRoot);
		// 循环遍历文件下中的所有本体
		for (File file : rootFile.listFiles()) {
			if (!file.isDirectory()) {
				String ontoName = file.getName();
				String ontoPath =  ontoRoot + ontoName;
				File f  = new File(ontoPath);
				
				System.out.println(" Current onto is : "+ontoPath);
				String name = ontoName.substring(0, ontoName.lastIndexOf("."));
				String resultPath = "results/"+ontoRoot+name+"/";	
				if(FileTools.fileExists(resultPath)) {
					System.out.println("   This ontology has been debuged.");
					//continue;
				}
				
										
				OWLOntology o = OWL.manager.loadOntology(IRI.create(f.toURI()));
				
				this.setoutput("log", resultPath);	
				computeMinRemoval(o, resultPath);
				
				
				OWL.manager.removeOntology(o);
				System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
			}
		}
	}
	

	public void computeMinRemoval(OWLOntology o, String resPath) {
		HashSet<OWLAxiom> axioms = new HashSet<>(o.getLogicalAxioms());
		//HashSet<String> ucUris = this.getDebuggedUCs(resPath+"log.txt");
		
		//RadonDebug debug = new RelevanceDebug(o);
		RadonDebug debug = new HeuristicDebug(axioms);
		//RadonDebug debug = new BlackboxDebug(o);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
		//MUPSUtils.printAllMUPS(mups);
		
		long st = System.currentTimeMillis();
		HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(mups);
		long time = System.currentTimeMillis() - st;
		System.out.println("******************** mips : ");
		CommonTools.printMultiSets(mips, null);
		System.out.println("Time (ms) to compute mips: "+time+"\n");
					
		HashSet<OWLAxiom> minHS = this.compute(mips, RepairParameters.CPLEX, resPath);		
		OWL.manager.removeAxioms(o, minHS);
		System.out.println("Is onto coherent after removing axioms in the minRemoval: "+
		   ReasoningTools.isCoherent(o, OWL.manager));
		OWL.manager.addAxioms(o, minHS);
		
		/*minHS = this.compute(mips, RepairParameters.HST, resPath);		
		OWL.manager.removeAxioms(o, minHS);
		System.out.println("Is onto coherent after removing axioms in the minRemoval: "+
		   ReasoningTools.isCoherent(o, OWL.manager));
		OWL.manager.addAxioms(o, minHS);*/
	}
	
	public HashSet<OWLAxiom> compute(HashSet<HashSet<OWLAxiom>> mips, String repairStrategy, String resPath) {
		this.setoutput(repairStrategy, resPath);	
		System.out.println("******************** minimal diagnosis : ");
		long st = System.currentTimeMillis();
		HashSet<OWLAxiom> minHS = getMinRemoval(mips, repairStrategy, resPath);	
		long time = System.currentTimeMillis() - st;		
		System.out.println("minHS size: "+minHS.size());
		CommonTools.printOneSet(minHS, null);
		System.out.println("Time (ms) to compute a minimal removal: "+time);
		
		return minHS;
	}
	
	public void setoutput(String repairStrategy, String resPath) {
		if(repairStrategy.equals(RepairParameters.CPLEX)) {
			System.setOut((new PrintStreamObject(resPath+"cplex-log.txt")).ps);				
					
		} else if(repairStrategy.equals(RepairParameters.HST)) {
			System.setOut((new PrintStreamObject(resPath+"hst-log.txt")).ps);
			
		} else if(repairStrategy.equals(RepairParameters.HSTSCORE)) {
			System.setOut((new PrintStreamObject(resPath+"hstScore-log.txt")).ps);
		} else {
			System.setOut((new PrintStreamObject(resPath+"log.txt")).ps);		
		}
	}
	
	public HashSet<OWLAxiom> getMinRemoval(HashSet<HashSet<OWLAxiom>> conflicts, String repairStrategy, String resPath) {
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		if(repairStrategy.equals(RepairParameters.CPLEX)) {
			solution = repairByCPlex(resPath, conflicts);
					
		} else if(repairStrategy.equals(RepairParameters.HST)) {
			solution = repairWithHst(conflicts);
			
		} else if(repairStrategy.equals(RepairParameters.HSTSCORE)) {	
			solution = repairWithHstScore(conflicts);			
		} 

		return solution;
	}

	public HashSet<OWLAxiom> repairWithHst(HashSet<HashSet<OWLAxiom>> multiSets) {
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(multiSets);
		return minHS;
	}
	
	public HashSet<OWLAxiom> repairWithHstScore(HashSet<HashSet<OWLAxiom>> multiSets) {
		HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(multiSets);
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags);		
		return minHS;
	}

	// Compute diagnosis by CPlex
	public HashSet<OWLAxiom> repairByCPlex(String resPath, HashSet<HashSet<OWLAxiom>> multiSets) {
		
		FileTools.fileExists(resPath+"models/");
		
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		
		try {
			// Translate OWL axioms to cplex representation as a model (.mps file)
			ILPAlgorithm.createModel(resPath+"models/", multiSets, inputAxioms);
			IloCplex cplex = new IloCplex();
			// Import the saved model
			cplex.importModel(resPath+"models/" + "ilpModel1.mps");
			// Set parameters for CPlex
			cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
			// Begin to compute diagnosis
			cplex.solve();
			solution = ILPTools.getCplexResult(cplex, inputAxioms);
		} catch (Exception ex) {
			
		}
		return solution;
	}
	
	private HashSet<String> getDebuggedUCs(String logPath) {
		HashSet<String> ucUris = new HashSet<>();
		File f = new File(logPath);
		if(!f.exists()) {
			return ucUris;
		}
		try {
			FileInputStream fstream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line			
			while ((strLine = br.readLine()) != null) {	
				if(strLine.indexOf("> Unsati concept :")!=-1) {
					String ucUri = strLine.substring(strLine.lastIndexOf("<")).trim();
					ucUris.add(ucUri);
				}
			}
		} catch(Exception ex) {
			
		}
		return ucUris;
	}
	
}
