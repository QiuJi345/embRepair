package edu.njupt.radon.exp.benchmark2021.repair;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.exp.cplex2018.res.CollectMIPS;
import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.repair.ilp.ILPAlgorithm;
import edu.njupt.radon.repair.ilp.ILPTools;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.TimeoutException;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import ilog.concert.IloException;
import ilog.cplex.IloCplex;

public class RepairAllMethods {
	
	static String mipsRootPath = "F:/Programming/radon/radon/results/mips/3-InjectIncoHybrid/";
	static String ontoRootPath = "F:/Experiments/2021-kbs/data/3-InjectIncoHybrid/";
	static String resRootPath = "F:/Experiments/2021-kbs/results-repair/3-InjectIncoHybrid/";
	static String ontoName = "";
	public static Thread thread = null;
	
	public static void main(String[] args) throws Exception {
		// "koala.owl","buggyPolicy.owl",
							
		RepairAllMethods r = new RepairAllMethods();
		r.processAll();
	}
	
	
	public void processAll() throws Exception {
		
		File resFile = new File(mipsRootPath);
		for(File ontoFile : resFile.listFiles()){
			if(ontoFile.isDirectory()){
				ontoName = ontoFile.getName();
				/*if(!ontoName.contains("DICE-A")) {
					continue;
				}*/
				/*String ontoPath = ontoRootPath+ontoName+".owl";
				String mipsPath = mipsRootPath+ontoName+"/";
				String resPath = resRootPath + ontoName+"/";
				FileTools.fileExists(resPath);
				FileTools.checkPath(resPath+"models/");
				this.process(ontoPath, mipsPath, resPath);*/
				this.doCompute();
			}
		}
	}
	
	public void process(String ontoPath, String mipsPath, String resPath) throws Exception {		
		
		File f = new File(resPath+"hstScore-log.txt");
		boolean isHstScoreLogExist = f.exists();
		f = new File(resPath+"hst-log.txt");
		boolean isHstLogExist = f.exists();
		f = new File(resPath+"models/log.txt");
		boolean isCplexLogExist = f.exists();
		
		if(isHstScoreLogExist && isHstLogExist && isCplexLogExist) {
			return;
		}
		
        OWLOntology sourceOnto = OWL.manager.loadOntology(IRI.create("file:"+ontoPath));				
		HashSet<HashSet<String>> mips = CollectMIPS.getMIPSStrFromText(mipsPath);		
		HashSet<HashSet<OWLAxiom>> conflicts = CollectMIPS.transferStrToMUPS(sourceOnto, mips);		
		System.out.println("num of mipsstr: "+mips.size());
		System.out.println("num of conflicts: "+conflicts.size());
		
		// cplex repair
		if(!isHstScoreLogExist) {
			System.setOut((new PrintStreamObject(resPath+"cplex-log.txt")).ps);	
			repairByCPlex(resPath, conflicts);			
		}		
		
		// hstscore
		if(!isHstScoreLogExist) {
			System.setOut((new PrintStreamObject(resPath+"hstScore-log.txt")).ps);	
			repairWithHstScore(conflicts);	
		}
				
		// hst
		if(!isHstLogExist) {
			System.setOut((new PrintStreamObject(resPath+"hst-log.txt")).ps);	
			repairWithHst(conflicts);		
		}			
		
		//OWL.manager.removeOntology(sourceOnto);
	}
	
	
	// Compute diagnosis by Radon
	public HashSet<OWLAxiom> repairWithHst(HashSet<HashSet<OWLAxiom>> multiSets) {		

		System.out.println("Number of conflicts: " + multiSets.size());
		
		long st = System.currentTimeMillis();		
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(multiSets);
		long time = System.currentTimeMillis() - st;
				
		System.out.println("***Axioms removed: ");
		CommonTools.printAxioms(minHS);		
		System.out.println("\n Time to compute diagnosis (ms): " + time);
		System.out.println("************************************ \n");
		return minHS;
	}
	
	public HashSet<OWLAxiom> repairWithHstScore(HashSet<HashSet<OWLAxiom>> multiSets) {
		
		System.out.println("Number of conflicts: " + multiSets.size());
		
		long st = System.currentTimeMillis();
		HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(multiSets);
		//CommonTools.printMultiSets(diags, null);
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags);
		long time = System.currentTimeMillis() - st;
		
		CommonTools.printAxioms(minHS);		
		System.out.println("\n Time to compute diagnosis (ms): " + time);
		System.out.println("************************************ \n");
		return minHS;
	}

	// Compute diagnosis by CPlex
	public HashSet<OWLAxiom> repairByCPlex(String resPath, HashSet<HashSet<OWLAxiom>> multiSets)
			throws IloException, IOException {
		
		System.out.println("Number of conflicts: " + multiSets.size());
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> minHS = new HashSet<OWLAxiom>();
		
		
		long st = System.currentTimeMillis();
		// Translate OWL axioms to cplex representation as a model (.mps file)
		ILPAlgorithm.createModel(resPath+"models/", multiSets, inputAxioms);
		IloCplex cplex = new IloCplex();
		// Import the saved model
		cplex.importModel(resPath+"models/" + "ilpModel1.mps");
		// Set parameters for CPlex
		cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
		// Begin to compute diagnosis
		cplex.solve();
		minHS = ILPTools.getCplexResult(cplex, inputAxioms);
		long time = System.currentTimeMillis() - st;
		
		CommonTools.printAxioms(minHS);		
		System.out.println("\n Time to compute diagnosis (ms): " + time);
		return minHS;
	}


	private void doCompute() throws TimeoutException, OutOfMemoryError, Exception {
		final MyThread myThread = new MyThread();
		thread = new Thread(myThread);
		// Start a new thread
		thread.start();
		// Set timeout for the thread
		thread.join(DebuggingParameters.timeout);
		// If time is out, then interrupt the current thread
		if (thread.isAlive()) {
			thread.interrupt();
		}
	}
	
	class MyThread implements Runnable {
		public void run() {
			String ontoPath = ontoRootPath+ontoName+".owl";
			String mipsPath = mipsRootPath+ontoName+"/";
			String resPath = resRootPath + ontoName+"/";
			FileTools.fileExists(resPath);
			FileTools.checkPath(resPath+"models/");
			
			File f = new File(resPath+"hstScore-log.txt");
			boolean isHstScoreLogExist = f.exists();
			f = new File(resPath+"hst-log.txt");
			boolean isHstLogExist = f.exists();
			f = new File(resPath+"models/log.txt");
			boolean isCplexLogExist = f.exists();
			
			if(isHstScoreLogExist && isHstLogExist && isCplexLogExist) {
				return;
			}
			
			try {
				OWLOntology sourceOnto = OWL.manager.loadOntology(IRI.create("file:"+ontoPath));				
				HashSet<HashSet<String>> mips = CollectMIPS.getMIPSStrFromText(mipsPath);		
				HashSet<HashSet<OWLAxiom>> conflicts = CollectMIPS.transferStrToMUPS(sourceOnto, mips);		
				System.out.println("num of mipsstr: "+mips.size());
				System.out.println("num of conflicts: "+conflicts.size());
				
				// cplex repair
				if(!isCplexLogExist) {
					System.setOut((new PrintStreamObject(resPath+"cplex-log.txt")).ps);	
					repairByCPlex(resPath, conflicts);			
				}		
				
				// hstscore
				if(!isHstScoreLogExist) {
					System.setOut((new PrintStreamObject(resPath+"hstScore-log.txt")).ps);	
					repairWithHstScore(conflicts);	
				}
						
				// hst
				if(!isHstLogExist) {
					System.setOut((new PrintStreamObject(resPath+"hst-log.txt")).ps);	
					repairWithHst(conflicts);		
				}		
			}catch(Exception ex) {
				
			}
	        	
		}
	}
}
