package edu.njupt.radon.exp.benchmark2021.utils;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * divide minRemoval Files(all uc in one file)<br>
 * to one UC one file
 * @author zsq
 */
public class FileDivide {
	public static void main(String[] args) throws IOException {
		// set path and algorithmName
		// Put the dataset hierarchy directly "testdata", like "1.1-existingOnts"
		String dataset = "3-InjectIncoHybrid/";//2.3-mipsRel
		String oripath = "F:/Papers/MyPapers/2021/2021-准备-研发-不协调本体构建/实验结果/yanfaData-mips-minRemoval/"+dataset;
		String newRoot = "F:/Experiments/2021-Yanfa/debugToolEvalResults/"+dataset;
		
		File ofile = new File(oripath);
		for (File ontoFile : ofile.listFiles()) {
			String ontoName = ontoFile.getName();
			String newontoPath = newRoot + ontoName + "/RadonRelAll/";
			// the path of files to be divided
			String logPath = oripath + ontoName + "/log.txt";
			System.out.println("divide file : "+logPath);
			resolveLog(logPath, newontoPath);
		}
		System.out.println("------finish!--------");
	}

	/**
	 * read the log file, get the name of UC<br>
	 * Judge the beginning and end of each UC<br>
	 * and output the information of each UC to a new log file
	 * @param logPath
	 * @param newontoPath
	 * @throws IOException 
	 */
	public static void resolveLog(String logPath, String newontoPath) throws IOException {
		try {
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			String ucName;
			String newlogPath;
			FileWriter printLine = null;
			boolean isOneUCBegin = false;
			end: while ((oneLine = bufferedReader.readLine()) != null) {
				// one UC start Flag
				if (oneLine.indexOf("> concept :") != -1 || oneLine.indexOf("> Unsati concept") != -1) {
					// get the name of UC
					ucName = oneLine.substring(oneLine.indexOf("#") + 1, oneLine.lastIndexOf(">"));
					newlogPath = newontoPath + ucName + "/";
					// Create corresponding new file
					File f = new File(newlogPath);
					if (!f.exists()) {
						f.mkdirs();
					}
					printLine = new FileWriter(new File(newlogPath + "log.txt"), true);
					isOneUCBegin = true;
				}
				if (isOneUCBegin) { 
					// just for test
//					System.out.println(oneLine);
					
					// Output to new file line by line
					printLine.write(oneLine);
					printLine.write("\n");
					// one UC end Flag
					if (oneLine.indexOf("The time (ms) to compute all MUPS for") != -1) {
						isOneUCBegin = false;
						ucName = "";
						printLine.flush();
						printLine.close();
					}
				}
				// all UCs end Flag
				if (oneLine.indexOf("****** mips : ") != -1) {
					break end;
				}
			}
			dataStream.close();

		} catch (

		FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
}
