package edu.njupt.radon.exp.benchmark2021.repair;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.exp.benchmark2021.utils.OntoIDMap;

public class CollectRepairResultsMain {
	static String dataSet = "";
	static String ontoName = "";
	static String ontoID = "";
	static boolean flag = true;
	static int oSize = 0;
	static int tbox = 0;
	static int classNum = 0;
	
	static long minRemovalNum = 0;
	static long repairTime = 3*60*60*1000;
	
	static OntoIDMap idMap = new OntoIDMap();

	public static void main(String[] args) throws Exception {
		String resultPath = "F:/Experiments/2021-kbs/results-repair/";

		// 结果存放在debugResult.xls
		PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("results/repairResults.xls")), true);
		//resultPath += "all/";

		outputJustHeader(output);
		listDataSets(output, resultPath);

		output.flush();
		output.close();
	}

	/**
	 * 依次读取各层文件夹<br>
	 * 第一层，文件夹名称为数据集名字
	 * @param output
	 * @param resultPath
	 */
	public static void listDataSets(PrintWriter output, String resultPath) {
		
		File file = new File(resultPath);
		for (File subFile : file.listFiles()) {
			// 读取数据集名称
			dataSet = subFile.getName();
			if(dataSet.contains("1.")) {
				continue;
			}
			// 继续读取下一层
			String path = resultPath + dataSet + "/";
			listOnts(output, path);
			dataSet = "";
		}
	}

	/**
	 * 依次读取各层文件夹<br>
	 * 第二层，文件夹名称为本体名字
	 * @param output
	 * @param resultPath
	 */
	public static void listOnts(PrintWriter output, String resultPath) {
		File file = new File(resultPath);
		for (File subFile : file.listFiles()) {
			// 读取本体名称
			ontoName = subFile.getName();
			ontoID = idMap.getID(ontoName);
			String path = resultPath + ontoName;			

			// 计算 cplex-log.txt 中 #minRemoval
			computecplex(output, path + "/cplex-log.txt");
			printFileInfo(output, "Cplex");
			computecplex(output, path + "/hstScore-log.txt");
			printFileInfo(output, "HstScore");
			computecplex(output, path + "/hst-log.txt");
			printFileInfo(output, "Hst");
			
			ontoName = "";
		}
	}
	

	/**
	 * 计算 cplex-log.txt 中 #minRemoval
	 * @param output
	 * @param logPath
	 * @return
	 */
	public static long computecplex(PrintWriter output, String logPath) {
		OntoMeasures reader = new OntoMeasures(logPath, false);
		minRemovalNum = reader.getMinRemovalNum();
		repairTime = reader.getRepairTime();
		return minRemovalNum;
	}

	/**
	 * 输出表格的具体内容
	 * @param output
	 */
	private static void printFileInfo(PrintWriter output, String repairAlg) {
		output.print(dataSet);
		output.print("\t");
		output.print(ontoName);
		output.print("\t");
		output.print(ontoID);
		output.print("\t");
		output.print(repairAlg);
		output.print('\t');
		output.print(repairTime);
		output.print('\t');
		output.print(minRemovalNum);
		output.println();
	}

	/**
	 * 输出表头
	 * @param output
	 */
	public static void outputJustHeader(PrintWriter output) {
		output.print("DataSet");
		output.print("\t");
		output.print("Ontology Name");
		output.print('\t');
		output.print("Ontology ID");
		output.print('\t');		
		output.print("Repair strategy");
		output.print('\t');
		output.print("Time (ms)");
		output.print('\t');	
		output.print("#removal");		
		output.println();
	}
}
