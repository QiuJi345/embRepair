package edu.njupt.radon.exp.benchmark2021.repair;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.exp.benchmark2021.utils.OntoIDMap;

public class OntoMeasuresMain {
	static String dataSet = "";
	static String ontoName = "";
	static String ontoID = "";
	static boolean flag = true;
	static int oSize = 0;
	static int tbox = 0;
	static int classNum = 0;
	// 待测量
	static long ucNum = 0;
	static int mupsNumber = 0;
	static long maxMUPNum = 0;
	static long minMUPNum = 10000;
	static int minSize = 1000;
	static int maxSize = 0;
	static double meanSize = 0;
	static int mipsNumber = 0;
	static long minRemovalNum = 0;
	static int axiomsInMipsNum = 0;
	
	static OntoIDMap idMap = new OntoIDMap();

	public static void main(String[] args) throws Exception {
		// 结果存放路径
//		String resultPath = "d:/84917/桌面/result/";
		// 测试文件文件夹
		// String resultPath = "d:/84917/桌面/test/";
		 String resultPath = "F:/Experiments/2021-kbs/r/";

		// 结果存放在debugResult.xls
		PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("results/measure.xls")), true);
		//resultPath += "all/";

		outputJustHeader(output);
		listDataSets(output, resultPath);

		output.flush();
		output.close();
	}

	/**
	 * 依次读取各层文件夹<br>
	 * 第一层，文件夹名称为数据集名字
	 * @param output
	 * @param resultPath
	 */
	public static void listDataSets(PrintWriter output, String resultPath) {
		
		File file = new File(resultPath);
		for (File subFile : file.listFiles()) {
			// 读取数据集名称
			dataSet = subFile.getName();
			/*if(!dataSet.contains("3-InjectIncoHybrid")) {
				continue;
			}*/
			// 继续读取下一层
			String path = resultPath + dataSet + "/";
			listOnts(output, path);
			dataSet = "";
		}
	}

	/**
	 * 依次读取各层文件夹<br>
	 * 第二层，文件夹名称为本体名字
	 * @param output
	 * @param resultPath
	 */
	public static void listOnts(PrintWriter output, String resultPath) {
		File file = new File(resultPath);
		for (File subFile : file.listFiles()) {
			// 读取本体名称
			ontoName = subFile.getName();
			if(ontoName.contains("."))
				continue;
			System.out.println(" ontoName before finding id: "+ontoName);
			ontoID = idMap.getID(ontoName);
			String path = resultPath + ontoName;
			String ontoPath = "f:/Experiments/2021-kbs/data/"+dataSet+"/"+ontoName+".owl";
			try {
				OWLOntology o=OWL.manager.loadOntology(IRI.create("file:"+ontoPath));
				
				Set<OWLAxiom> abox = o.getABoxAxioms(true);
				Set<OWLAxiom> axioms = new HashSet<OWLAxiom>(o.getLogicalAxioms());
				oSize = axioms.size();
				axioms.removeAll(abox);
				tbox = axioms.size();
				classNum = o.getClassesInSignature().size();
				OWL.manager.removeOntology(o);
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
			
			// 读取log文档，计算所需值
			if(dataSet.contains("3-InjectIncoHybrid")) {
				computeMUPS(output, path + "/mupslog.txt");
			} else {
				computeMUPS(output, path + "/log.txt");
			}			
			
			computeMIPS(output, path + "/log.txt");

			// 计算 cplex-log.txt 中 #minRemoval
			computecplex(output, path + "/cplex-log.txt");

			// 输出到表格
			printFileInfo(output);
			ontoName = "";
		}
	}

	public static void computeMIPS(PrintWriter output, String logPath) {
		OntoMeasures reader = new OntoMeasures(logPath, 1);
		HashSet<HashSet<String>> mips = reader.getJusts();
		// HashSet<HashSet<String>> mips = reader.getmipJusts();
		HashSet<String> axiomsInMIPS = new HashSet<String>();
	
		for(HashSet<String> one : mips) {
			axiomsInMIPS.addAll(one);
		}
		axiomsInMipsNum = axiomsInMIPS.size();
		mipsNumber = mips.size();
	}

	public static void computeMUPS(PrintWriter output, String logPath) {
		OntoMeasures reader = new OntoMeasures(logPath, ontoName);
		HashSet<HashSet<String>> mupsSet = reader.getJusts();
		ucNum = reader.getUCNum();
		maxMUPNum = reader.getMaxMUPNum();
		minMUPNum = reader.getMinMUPNum();
		// 测试用
		// System.out.println(justs);
		mupsNumber = mupsSet.size();
		System.out.println("mupsNumber = "+mupsNumber);
		minSize = 1000;
		maxSize = 0;
		meanSize = 0;
		int totalSize = 0;
		for (HashSet<String> just : mupsSet) {
			int size = just.size();
			if (size > maxSize) {
				maxSize = size;
			}
			if (size < minSize) {
				minSize = size;
			}
			totalSize += size;
		}
		if (mupsNumber != 0) {
			
			meanSize = (double) (totalSize / mupsNumber);
			System.out.println("totalSize = "+totalSize+", meanSize= " +meanSize);
		}
	}


	/**
	 * 计算 cplex-log.txt 中 #minRemoval
	 * @param output
	 * @param logPath
	 * @return
	 */
	public static long computecplex(PrintWriter output, String logPath) {
		OntoMeasures reader = new OntoMeasures(logPath, false);
		minRemovalNum = reader.getMinRemovalNum();
		return minRemovalNum;
	}

	/**
	 * 输出表格的具体内容
	 * @param output
	 */
	private static void printFileInfo(PrintWriter output) {
		output.print(dataSet);
		output.print("\t");
		output.print(ontoName);
		output.print("\t");
		output.print(ontoID);
		output.print("\t");
		output.print(oSize);
		output.print("\t");
		output.print(tbox);
		output.print("\t");
		output.print(classNum);
		output.print("\t");
		output.print(ucNum);
		output.print("\t");
		output.print(mupsNumber);
		output.print('\t');
		output.print(minMUPNum);
		output.print('\t');
		output.print(maxMUPNum);
		output.print('\t');
		output.print(minSize);
		output.print('\t');
		output.print(maxSize);
		output.print('\t');
		output.print(meanSize);
		output.print('\t');
		output.print(mipsNumber);
		output.print('\t');
		output.print(axiomsInMipsNum);
		output.print('\t');
		output.print(minRemovalNum);
		output.print('\t');
		output.println();
	}

	/**
	 * 输出表头
	 * @param output
	 */
	public static void outputJustHeader(PrintWriter output) {
		output.print("DataSet");
		output.print("\t");
		output.print("Ontology Name");
		output.print('\t');
		output.print("Ontology ID");
		output.print('\t');
		output.print("Onto Size");
		output.print('\t');
		output.print("TBox");
		output.print("\t");
		output.print("#Class");
		output.print('\t');
		// 测试的量
		output.print("#UC");
		output.print('\t');
		output.print("#MUPS");
		output.print('\t');
		output.print("MUPS min Num");
		output.print('\t');
		output.print("MUPS max Num");
		output.print('\t');
		output.print("MUPS Min size");
		output.print('\t');
		output.print("MUPS Max size");
		output.print('\t');
		output.print("MUPS Mean size");
		output.print('\t');
		output.print("#MIPS");
		output.print('\t');		
		output.print("#AxiomsInMIPS");
		output.print('\t');
		output.print("#minRemoval");		
		output.println();
	}
}
