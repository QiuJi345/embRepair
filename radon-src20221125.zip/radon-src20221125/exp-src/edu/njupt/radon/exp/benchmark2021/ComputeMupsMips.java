package edu.njupt.radon.exp.benchmark2021;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ComputeMupsMips {

	public static void main(String[] args) throws Exception  {
		String ontoName = "mad";
		String ontPath = "onto/"+ontoName+".owl";
		//String ucURI = "";
		//String resultPath = "results/pattern2018/"+ontoName;
		//System.setOut((new PrintStreamObject(resultPath)).ps);
		
		OWLOntology onto=OWL.manager.loadOntology(IRI.create("file:"+ontPath));
		
		System.setOut((new PrintStreamObject("results/"+ontoName+"-log.txt")).ps);		
		System.out.println("classes: "+onto.getClassesInSignature().size());
		/*int i = 0;
		for(OWLClass oc: onto.getClassesInSignature()) {
			System.out.println("class ["+(i++)+"] "+oc.getIRI().toString());
		}*/
		//HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);
		ReasoningTools.setReasoner("hermit");
		System.out.println(ReasoningTools.getUnsatiConcepts(onto).size());
				
		//HashSet<OWLAxiom> axioms = OWLTools.getTBox(onto);
		
		
		//BlackboxDebug.setMUPSNumLimit(10);
		//computeMUPS(debug, axioms);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = computeAllMUPSByRadon(onto);
		
		HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(mups);
		System.out.println("\nFound MIPS: ");
		printAxiomSets(mips);
		
	}
	
	public static HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> computeAllMUPSByRadon(OWLOntology onto) {
		HashSet<OWLAxiom> axioms = new HashSet<>(onto.getLogicalAxioms());
		// Compute MUPS by RaDON
		RadonDebug debug = new BlackboxDebug(axioms);
		//RadonDebug debug = new HeuristicDebug(axioms);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
		return mups;
	}
	
	public static void computeMUPS(RadonDebug debug, HashSet<OWLAxiom> tbox){
		System.out.println("****************************************");
		debug.getMUPS();
		for(OWLClass uc : ReasoningTools.getUnsatiConcepts(tbox)) {
			if(!uc.toString().contains("Retry-Until-SucceedUsernamePolicy")) {
				continue;
			}
			debug.getMUPS(uc);
			//break;
		}		
	}
	
	
	public static void computeMUPS(OWLOntology onto, RadonDebug debug, String ucURI){
		if(ucURI != null && ucURI.length()>0){
			OWLEntity uc = null;
			if(ucURI.indexOf("http:")!=-1){
				uc = OWLTools.getEntity(onto, ucURI);
			} else {
				uc = OWLTools.getEntityWithLocalName(onto, ucURI);
			}
		    debug.getMUPS(uc.asOWLClass());		
		} 
	}
	
	public static void printAxiomSets(HashSet<HashSet<OWLAxiom>> axiomSets) {
		int mupsNum = 0;
		for(Set<OWLAxiom> axiomSet : axiomSets) {
			System.out.println("Set <"+(++mupsNum)+">");
			int axiomNum = 0;
			for(OWLAxiom ax : axiomSet) {
				System.out.println("["+(++axiomNum)+"] "+ax.toString());
			}
			System.out.println();
		}
		System.out.println();
	}
	

}
