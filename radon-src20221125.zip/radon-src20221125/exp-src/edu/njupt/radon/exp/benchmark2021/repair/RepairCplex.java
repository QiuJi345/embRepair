package edu.njupt.radon.exp.benchmark2021.repair;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.exp.cplex2018.res.CollectMIPS;
import edu.njupt.radon.repair.ilp.ILPAlgorithm;
import edu.njupt.radon.repair.ilp.ILPTools;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import ilog.concert.IloException;
import ilog.cplex.IloCplex;

public class RepairCplex {
	
	static String dsName = "1.2-MergeOntologies";
	static String ontoRootPath = "F:/Experiments/2021-kbs/data/"+dsName+"/";
	static String resRootPath = "F:/Experiments/2021-kbs/r/"+dsName+"/";
	static String ontoName = "";
	public static Thread thread = null;
	
	public static void main(String[] args) throws Exception {
		// "koala.owl","buggyPolicy.owl",
							
		RepairCplex r = new RepairCplex();
		r.processAll();
	}
	
	
	public void processAll() throws Exception {
		
		File resFile = new File(resRootPath);
		for(File ontoFile : resFile.listFiles()){
			if(ontoFile.isDirectory()){
				ontoName = ontoFile.getName();
				/*if(!ontoName.contains("mad")) {
					continue;
				}*/
				String ontoPath = ontoRootPath+ontoName+".owl";
				String resPath = resRootPath + ontoName+"/";
				
				this.process(ontoPath, resPath);
			}
		}
	}
	
	public void process(String ontoPath, String resPath) throws Exception {		
		FileTools.fileExists(resPath);
		FileTools.checkPath(resPath+"models/");
		File f = new File(resPath+"models/log.txt");
		boolean isCplexLogExist = f.exists();
		
		if(isCplexLogExist) {
			return;
		}
		
        OWLOntology sourceOnto = OWL.manager.loadOntology(IRI.create("file:"+ontoPath));				
		HashSet<HashSet<String>> mips = CollectMIPS.getMIPSStrFromText(resPath);		
		HashSet<HashSet<OWLAxiom>> conflicts = CollectMIPS.transferStrToMUPS(sourceOnto, mips);		
		System.out.println("num of mipsstr: "+mips.size());
		System.out.println("num of conflicts: "+conflicts.size());
		
		// cplex repair
		if(!isCplexLogExist) {
			System.setOut((new PrintStreamObject(resPath+"cplex-log.txt")).ps);	
			repairByCPlex(resPath, conflicts);			
		}		
			
		
		//OWL.manager.removeOntology(sourceOnto);
	}
	
	
	// Compute diagnosis by CPlex
	public HashSet<OWLAxiom> repairByCPlex(String resPath, HashSet<HashSet<OWLAxiom>> multiSets)
			throws IloException, IOException {
		
		System.out.println("Number of conflicts: " + multiSets.size());
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> minHS = new HashSet<OWLAxiom>();
		
		
		long st = System.currentTimeMillis();
		// Translate OWL axioms to cplex representation as a model (.mps file)
		ILPAlgorithm.createModel(resPath+"models/", multiSets, inputAxioms);
		IloCplex cplex = new IloCplex();
		// Import the saved model
		cplex.importModel(resPath+"models/" + "ilpModel1.mps");
		// Set parameters for CPlex
		cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
		// Begin to compute diagnosis
		cplex.solve();
		minHS = ILPTools.getCplexResult(cplex, inputAxioms);
		long time = System.currentTimeMillis() - st;
		
		CommonTools.printAxioms(minHS);		
		System.out.println("\n Time to compute diagnosis (ms): " + time);
		return minHS;
	}


}
