package edu.njupt.radon.exp.explanation;


import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.relevance.RelevanceJusts;
import edu.njupt.radon.parameters.DebuggingArgumentsProcessing;
import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.TimeoutException;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.reasoning.ReasoningTask;

/**
 * 
 * @author Qiu Ji
 * @modified 2014.04.10 Clean up the code
 *
 */
public class RaDONJusts {
	
	public static Thread thread = null;
	
	OWLOntology ontology = null;
	OWLClass subClass = null;
	OWLClass supClass = null;
	
	
	/**
	 * Find justifications for subsumptions by using the relevance-directed approach.
	 */
	public static void main(String[] args) throws Exception {
		System.setProperty("entityExpansionLimit", "10000000");
		
		if(args.length > 0 ){
			DebuggingArgumentsProcessing process = new DebuggingArgumentsProcessing();
			process.processArguments(args, RaDONMUPS.class.getName());
		}
		// set reasoner
		ReasoningTask.reasoner = DebuggingParameters.reasoner;
				
		// Open an OWL ontology
		OWLOntology onto = OWL.manager.loadOntology( IRI.create( DebuggingParameters.ontoPath ) );
			
		
		// Explain the given entailment		
		RaDONJusts debug = new RaDONJusts(onto, DebuggingParameters.entailmentString);
		debug.computeJusts();	
	}
	
	public RaDONJusts(OWLOntology onto, String entailmentString){
		this.ontology = onto;	
		if(entailmentString.contains("-subClassOf-")){
			entailmentString = entailmentString.replace("-subClassOf-", " ");
			String[] strings = entailmentString.split(" ");
			subClass = OWLTools.getOWLClass(ontology, strings[0]);
			supClass = OWLTools.getOWLClass(ontology, strings[1]);
			if(subClass == null || supClass == null){
				System.err.println("At least one of the signatures in the given subsumption is null.");
				System.exit(1);
			} else {
				checkPath();
			}
		} 
	}	
	
    private void checkPath(){
    	// Get the path to store results
    	String subLocalName = OWLTools.getFileName(subClass);
    	String supLocalName = OWLTools.getFileName(supClass);
    	String path = DebuggingParameters.resultPath + subLocalName+"+"+supLocalName+"/";	
    	FileTools.fileExists(path);
    }
	
	
	public void computeJusts(){							
		long startTime = System.currentTimeMillis();
		try{
			doCompute();
		} catch (TimeoutException tex){
			tex.printStackTrace();
			System.out.println(" Time is out!");
		} catch (OutOfMemoryError oex){
			oex.printStackTrace();
			System.out.println(" Memory is out!");
		} catch (Exception ex){
			ex.printStackTrace();
			System.out.println(" Exception is thrown when computing MIS!");
		} finally {
			long exeTime = (System.currentTimeMillis()-startTime);        	
        	try{
				Thread.sleep(10);
			} catch (InterruptedException ex){
				ex.printStackTrace();
			}
			System.out.println("[Info] finish!");
			System.out.println("\nTime : "+exeTime);	
			System.exit(1);
		}			
	}
	
	
	private void doCompute() 
	throws TimeoutException, OutOfMemoryError, Exception {	
		// Create a new thread
		final MyThread myThread = new MyThread();
	    thread = new Thread(myThread);
        // Start a new thread
	    thread.start();
	    // Set timeout for the thread
	    thread.join(DebuggingParameters.timeout);  
	    // If time is out, then interrupt the current thread
	    if (thread.isAlive()) {
	        thread.interrupt();  
	    }
	}

	class MyThread implements Runnable {
	    public void run() {   
	    	//DebuggingParameters.useModule = false;
	    	if(DebuggingParameters.useModule){
	    		long startTime = System.currentTimeMillis();
	    		Set<OWLAxiom> module = OWLTools.extractModule(ontology, subClass, supClass);
	    		long extractModuleTime = System.currentTimeMillis()-startTime;
	        	//module = new HashSet<OWLAxiom>(axiomsInOnto);
	        	System.out.println("Module size : "+module.size());
	        	System.out.println("Extration time : "+extractModuleTime);
	        	ontology = OWLTools.createOntology(new HashSet<OWLAxiom>(module));	
	    	} 
	    	
	    	RelevanceJusts debug = new RelevanceJusts(ontology, subClass, supClass);
    		debug.getRelevantJustifications();
	    }
	}  
}
