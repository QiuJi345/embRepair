package edu.njupt.radon.exp.explanation;


import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.inconsistency.ComputeMIS;
import edu.njupt.radon.parameters.DebuggingArgumentsProcessing;
import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.TimeoutException;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.reasoning.ReasoningTask;

public class RaDONMIS {
	
	public static Thread thread = null;	
	OWLOntology ontology = null;   
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		System.setProperty("entityExpansionLimit", "10000000");
		
		if(args.length > 0 ){
			DebuggingArgumentsProcessing process = new DebuggingArgumentsProcessing();
			process.processArguments(args, RaDONMUPS.class.getName());
		}
		// set reasoner
		ReasoningTask.reasoner = DebuggingParameters.reasoner;
		
		// Load an OWL ontology
		OWLOntology onto = OWL.manager.loadOntology( IRI.create( DebuggingParameters.ontoPath ) );
		
		// Perform debugging task
		RaDONMIS debug = new RaDONMIS(onto);
		debug.computeJusts();	
	}
			
	public RaDONMIS(OWLOntology onto){
		this.ontology = onto;		
	}
		
	public void computeJusts(){	
		// Check the path
		String path = DebuggingParameters.resultPath +"top+bot/";	
		FileTools.fileExists(path);		
				
		System.out.println("Begin to compute MIS for ontology : "+ontology.getOntologyID());
		
		long s = System.currentTimeMillis();
		try{
			computeMIS();
		} catch (TimeoutException tex){
			tex.printStackTrace();
			System.out.println(" Time is out!");
		} catch (OutOfMemoryError oex){
			oex.printStackTrace();
			System.out.println(" Memory is out!");
		} catch (Exception ex){
			ex.printStackTrace();
			System.out.println(" Exception is thrown when computing MIS!");
		} finally {
			long exeTime = (System.currentTimeMillis()-s);
        	try{
				Thread.sleep(10);
			} catch (InterruptedException ex){
				ex.printStackTrace();
			}
        	System.out.println("[Info] finish!");
			System.out.println("\nTime : "+exeTime);	
			System.exit(1);
		}			
	}
	

	private void computeMIS() 
	throws TimeoutException, OutOfMemoryError, Exception {	
		// Create a new thread
		final MyThread myThread = new MyThread();
	    thread = new Thread(myThread);
        // Start a new thread
	    thread.start();
	    // Set timeout for the thread
	    thread.join(DebuggingParameters.timeout);  
	    // If time is out, then interrupt the current thread
	    if (thread.isAlive()) {
	        thread.interrupt();  
	    }
	}
		
	 
	class MyThread implements Runnable {
	    public void run() {       
	    	// Generate an object for the interface ComputeMUPS
    		ComputeMIS debug = new ComputeMIS();
    		debug.getAllMIS(ontology);
	    }
	}
	
}
