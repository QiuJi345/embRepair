package edu.njupt.radon.exp.heuristic;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.heuristic.HeuristicDebug;
import edu.njupt.radon.utils.OWLTools;

public class HeuristicDebugMain {	
	// km1500: hardware_system_c sector_management_practice_c
	// SuperiorRectalArtery KneeJointCavity GreaterCurvatureOfStomach RenalPathology RenalAbscess
	public static String ucName = "OBI_1110118";
	public static String ucURI = "http://purl.obolibrary.org/obo/"+ucName;
	//public static String ucString = null;
/*	public static String ontoName = "merged2207"; //km1500-4000 proton_100_all
	public static String ontoPath = "file:data/learn/"+ontoName+".owl";
	public static String resPath = "results/heuristic/"+ontoName+"/";*/	
/*	
	public static String ucName = null;
	public static String ontoName = "asmov-cmt-confof"; //km1500-4000 proton_100_all
	public static String ontoPath = "file:data/conference2010/merged/"+ontoName+".owl";
	public static String resPath = "results/tmp/"+ontoName+"/";*/
	
	public static String ontoName = "DICE-A"; //km1500-4000 proton_100_all
	public static String ontoPath = "onto/"+ontoName+".owl";
	//public static String ontoName = "mups"; //km1500-4000 proton_100_all
	//public static String ontoPath = "file:onto/"+ontoName+".owl";
	public static String resPath = "results/debug/";
		
	public static void main(String[] args) throws Exception {
		if(args.length == 1){
			ontoPath = args[0];
			ontoName = getOntoName(ontoPath);
		}
		if(args.length == 2){
			ontoPath = args[0];
			ucName = args[1];
			ontoName = getOntoName(ontoPath);
		}
		resPath += ontoName+"/";
		
		if(ucURI != null && ucName != null && ucName.length()>0){
			resPath += ucName + "/";
		}
		/*CommonTools.mkdirs(resPath);
		CommonTools.deleteFile(resPath+"log.txt");		
		System.setOut((new PrintStreamObject(resPath)).ps);*/
				
		OWLOntology onto = OWLTools.openOntology(ontoPath); 	
		HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);
		/*int i = 1;
		for(OWLAxiom ax : tbox){
			System.out.println((i++)+"> "+ax);
		}
		*/
		
		HeuristicDebug debug = new HeuristicDebug(tbox);
		computeMUPSForAllUcs(debug);
		
	}
	
	public static void computeMUPSForAllUcs(RadonDebug debug){
		debug.getMUPS();
	}
	
	public static void computeMUPSForOneUc(RadonDebug debug){
		
		debug.getMUPS();
	}
	
	public static void computeMUPSForUc(OWLOntology onto, RadonDebug debug, String ucURI){
		if(ucURI != null && ucURI.length()>0){
			OWLEntity uc = null;
			if(ucURI.indexOf("http:")!=-1){
				uc = OWLTools.getEntity(onto, ucURI);
			} else {
				uc = OWLTools.getEntityWithLocalName(onto, ucURI);
			}
		    debug.getMUPS(uc.asOWLClass());		
		} 
	}
	
	public static String getOntoName(String path){
		if(path.indexOf(".")!=-1){
			if(path.lastIndexOf("#")!=-1){
				return path.substring(path.lastIndexOf("#")+1,path.indexOf("."));
			} else if(path.lastIndexOf("/")!=-1){
				return path.substring(path.lastIndexOf("/")+1,path.indexOf("."));
			}
		}
		String randomName = "onto-"+System.currentTimeMillis();
		return randomName;
	}

}
