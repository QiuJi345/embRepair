package edu.njupt.radon.exp.heuristic;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.heuristic.HeuristicDebug;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class HeuristicDisjDebugMain {
	
	// km1500: hardware_system_c sector_management_practice_c
	// SuperiorRectalArtery KneeJointCavity GreaterCurvatureOfStomach RenalPathology RenalAbscess
	public static String ucName = null;
/*	public static String ontoName = "merged2207"; //km1500-4000 proton_100_all
	public static String ontoPath = "file:data/learn/"+ontoName+".owl";
	public static String resPath = "results/heuristic/"+ontoName+"/";*/
	
/*	
	public static String ucName = null;
	public static String ontoName = "asmov-cmt-confof"; //km1500-4000 proton_100_all
	public static String ontoPath = "file:data/conference2010/merged/"+ontoName+".owl";
	public static String resPath = "results/tmp/"+ontoName+"/";*/
	
	public static String ontoName = "proton_50_all"; //km1500-4000 proton_100_all
	public static String ontoPath = "file:onto/"+ontoName+".owl";
	public static String resPath = "results/debug/";
		
	public static void main(String[] args) throws Exception {
		if(args.length == 1){
			ontoPath = args[0];
			ontoName = getOntoName(ontoPath);
		}
		if(args.length == 2){
			ontoPath = args[0];
			ucName = args[1];
			ontoName = getOntoName(ontoPath);
		}
		resPath += ontoName+"/";
		
		if(ucName != null && ucName.length()>0){
			resPath += ucName + "/";
		}
		CommonTools.mkdirs(resPath);
		CommonTools.deleteFile(resPath+"log.txt");		
		System.setOut((new PrintStreamObject(resPath)).ps);
				
		OWLOntology onto = OWLTools.openOntology(ontoPath); 
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(OWLTools.getTBox(onto));
		System.out.println("Axioms: "+axioms.size());
		/*int i = 0;
		for(OWLAxiom a : axioms){
			System.out.println((i++)+" > "+a.toString());
		}*/
		
		long s = System.currentTimeMillis();	
		// prepare
		OntologyInfo myOnto = new OntologyInfo(axioms);
		ClassHierarchy classHier = new ClassHierarchy(myOnto);
		PropertyHierarchy propHier = new PropertyHierarchy(axioms);
		// debug
		HeuristicDebug debug = new HeuristicDebug(myOnto, classHier, propHier);
		debug.getMUPS();			
		// output
		System.out.println("Time (ms): "+(System.currentTimeMillis()-s));
	}
	
	public static String getOntoName(String path){
		if(path.indexOf(".")!=-1){
			if(path.lastIndexOf("#")!=-1){
				return path.substring(path.lastIndexOf("#")+1,path.indexOf("."));
			} else if(path.lastIndexOf("/")!=-1){
				return path.substring(path.lastIndexOf("/")+1,path.indexOf("."));
			}
		}
		String randomName = "onto-"+System.currentTimeMillis();
		return randomName;
	}

}
