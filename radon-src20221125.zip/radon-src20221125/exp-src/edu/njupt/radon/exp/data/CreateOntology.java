package edu.njupt.radon.exp.data;

import java.io.File;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectUnionOf;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class CreateOntology {
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		a();
		//aa();
	}
	
	public static void merge() throws Exception {
		String ontoRoot = "D:/data/debugging/neon/FAO_glossaries/";
		File f = new File(ontoRoot);
		for(File subFile : f.listFiles()){
			String ontoName = subFile.getName();
			
		}
	}
	
	public static void a() throws Exception {		
		String ontoName = "merged2207"; //km1500-4000 proton_100_all
		String ontoPath = "file:data/learn/"+ontoName+".owl";		
		int axiomsNum = 10000;
		
		OWLOntology onto = OWLTools.openOntology(ontoPath);           
		HashSet<OWLAxiom> axioms = OWLTools.getTBox(onto);
		HashSet<OWLAxiom> newAxioms = new HashSet<OWLAxiom>();
        int i = 0;
		for(OWLAxiom a : axioms){ 
			if(a instanceof OWLEquivalentClassesAxiom){
				continue;
			}
			System.out.println(i+"> "+a.toString());
        	if(i >= axiomsNum){
        		break;
        	}
        	newAxioms.add(a);
        	i ++;
        }
	    System.out.println("new axioms : "+newAxioms.size());
	    OWLTools.saveOntology(newAxioms, "file:/d:/"+ontoName + "-" + axiomsNum+".owl");
	    System.out.println(ReasoningTools.getUnsatiConcepts(newAxioms).size());
	    System.out.println(ReasoningTools.isConsistent(newAxioms));
	}
	
	public static void createOnto(){

		OWLDataFactory df =OWLTools.manager.getOWLDataFactory();
		OWLClass c1 = df.getOWLClass(IRI.create("a1"));
		OWLClass b = df.getOWLClass(IRI.create("b1"));
		OWLClass c2 = df.getOWLNothing();
		OWLClassExpression c = df.getOWLObjectIntersectionOf(c1, df.getOWLObjectComplementOf(c2));
		OWLObjectUnionOf d = df.getOWLObjectUnionOf(c1, b);
		OWLObjectUnionOf d2 = df.getOWLObjectUnionOf(c1, b);
		System.out.println(d.equals(d2));
		
		boolean f =  c2.isOWLNothing();
		System.out.println(f);
	}
	
	public static void aa() throws Exception {
		int oldNum = 5000;
		int axiomsNum = 1000;
		String ontoName = "km1500-tbox"; //km1500-4000 proton_100_all
		String oldOntoName = "km1500-"+oldNum;
		String ontoPath = "file:data/learn/"+ontoName+".owl";	
		String oldOntoPath = "file:data/learn/"+oldOntoName+".owl";	
		
		
		OWLOntology onto = OWLTools.openOntology(ontoPath);           
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		System.out.println("total axioms : "+axioms.size());
		
		OWLOntology oldOnto = OWLTools.openOntology(oldOntoPath);           
		HashSet<OWLAxiom> oldAxioms = new HashSet<OWLAxiom>(oldOnto.getLogicalAxioms());
		System.out.println("old axioms : "+oldAxioms.size());
		
		HashSet<OWLAxiom> newAxioms = new HashSet<OWLAxiom>(oldAxioms);
        int i = 0;
		for(OWLAxiom a : axioms){ 
			if(oldAxioms.contains(a)){
        		continue;
        	}
			//System.out.println(i+"> "+a.toString());
        	if(i >= axiomsNum){
        		break;
        	}
        	
        	newAxioms.add(a);
        	i ++;
        }
	    System.out.println("new axioms : "+newAxioms.size());
	    OWLTools.saveOntology(newAxioms, "file:/d:/km1500-"+(oldNum+axiomsNum)+".owl");
	    System.out.println(ReasoningTools.isCoherent(newAxioms));
	}

}
