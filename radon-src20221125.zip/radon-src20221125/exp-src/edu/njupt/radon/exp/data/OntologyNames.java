package edu.njupt.radon.exp.data;

import java.io.File;

public class OntologyNames {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String dataSet = "abox-tool";
		String task = "coherent";
		String resultPath = "d:/Data/debugging/journal-paper-data/"+task+"/"+dataSet+"/";

		File f = new File(resultPath);
		for(File ontoF : f.listFiles()){
			if(ontoF.isDirectory()){
				continue;
			}			
			String ontoName = ontoF.getName();
			int index = ontoName.indexOf(".");
			ontoName = ontoName.substring(0, index);
			System.out.println(task + "\t" + dataSet + "\t"+ontoName);
		}
	}

}
