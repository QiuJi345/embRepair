package edu.njupt.radon.exp.data;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class CommonUnsatConcepts {

	public static void main(String[] args) throws Exception {
		
		String onto1Path = "file:d://km1500_2000-5.owl";
		String onto2Path = "file:d://km1500_2000-6.owl";
		// Open an OWL ontology
		OWLOntology onto1 = OWL.manager.loadOntology( IRI.create( onto1Path ) );
		OWLOntology onto2 = OWL.manager.loadOntology( IRI.create( onto2Path ) );
		
		HashSet<OWLAxiom> axiomsInOnto1 = new HashSet<OWLAxiom>(onto1.getLogicalAxioms());
		HashSet<OWLAxiom> axiomsInOnto2 = new HashSet<OWLAxiom>(onto2.getLogicalAxioms());
		HashSet<OWLAxiom> axioms = CommonTools.getIntersectSet(axiomsInOnto1, axiomsInOnto2);
		System.out.println(axioms.size());
		
		HashSet<OWLClass> ucs1 = ReasoningTools.getUnsatiConcepts(onto1, OWL.manager);
		HashSet<OWLClass> ucs2 = ReasoningTools.getUnsatiConcepts(onto2, OWL.manager);
		
		Set intersection = CommonTools.getIntersectSet(ucs1, ucs2);
		int counter = 1;
		for(Object element : intersection){
			System.out.println(counter++ + "> "+element.toString());
		}
	}
}
