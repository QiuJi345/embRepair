package edu.njupt.radon.exp.data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import edu.njupt.radon.utils.OWLTools;

public class OntoSizeMain {

	static String root = "F:/Data/debugging/oaei/mergedOnto/";
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		String ontoName = "UOBM-lite-40";
		String ontoRoot = "D:/Dropbox/Experiments/2013-Journal-Evaluation/odbm/inconsistent/tool/";
		String ontoPath = ontoRoot + ontoName+".owl";
		ontoPath = "d:/cmt.owl";
		outputOntoSize(ontoPath);
	}
	
	public static void outputOntoSize(String ontoPath){
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		outputOntoSize(onto);
	}
	
	public static OWLOntology openOntology(String ontoPath){		
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		IRI physicalURI = IRI.create(ontoPath);
		OWLOntology ontology = null;
		try{
			ontology = manager.loadOntology(physicalURI);  
		} catch (OWLOntologyCreationException ex){
			ex.printStackTrace();
		}   
       	return ontology;
	}
	
	public static void outputOntoSize(OWLOntology onto){
		System.out.println(onto.getLogicalAxiomCount());
		System.out.println(OWLTools.getTBox(onto).size()+"  &  "+OWLTools.getABox(onto).size());
	}

	
	public void aaaaa() throws Exception{
		String tablePath = root + "ontoSize.xls";

		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(tablePath)),true);    	
		output(output);
	}
	
	public void output(PrintWriter output) throws Exception {
		File rootFile = new File(root);
		for(File systemFile : rootFile.listFiles()){
			if(systemFile.isDirectory()){
				String systemName = systemFile.getName();
				System.out.println(systemName);				
				for(File possOntoFile : systemFile.listFiles()){
					String name = possOntoFile.getName();
					if(possOntoFile.isDirectory()){						
						for(File oFile : possOntoFile.listFiles()){
							String ontoName = oFile.getName();		
							String ontoPath = root + systemName + "/" + name +"/" + ontoName;
							this.getOntoSize(output, systemName, ontoPath, ontoName);
						}
					} else {	
						String ontoPath = root + systemName + "/" +name;
						this.getOntoSize(output, systemName, ontoPath, name);
					}
					
				}
			}
		}
	}
	
	public void getOntoSize(PrintWriter output, String systemName, String ontoPath, String ontoName) throws Exception {
		// Get ontology name		
		int index = ontoName.indexOf(".");
		if(index != -1){
			ontoName = ontoName.substring(0, index);
		}
        System.out.print("     "+ontoPath);
        // Get ontology size
        OWLOntology onto = OWLTools.openOntology(ontoPath);
        int size = onto.getLogicalAxiomCount();        
        System.out.println(" : "+size);
        
        output.print(systemName);
        output.print('\t'); 
        output.print(ontoName);
        output.print('\t'); 
        output.print(size);
        output.println();
	}
	
	public void outputHeader(PrintWriter output){
//		Output the titles for each column
		output.print("System Name");
        output.print('\t'); 
        output.print("Mapping Name");
        output.print('\t'); 
		output.print("Onto Size");
        output.println();
	}
}
