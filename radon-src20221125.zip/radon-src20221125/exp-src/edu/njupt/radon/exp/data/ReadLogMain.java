package edu.njupt.radon.exp.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.OWLTools;

public class ReadLogMain {

	static String root = "F:/Data/debugging/oaei/";
	static String logPath = root + "bak/log-all.txt";		
	static String tablePath = root + "bak/conflictInfo.xls";
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(tablePath)),true);    	
    	
		ReadLogMain main = new ReadLogMain();
		main.readResults(output, logPath);
	}
	
	public void readResults(PrintWriter output, String logPath){
		// Output header
		this.outputHeader(output);
		
		String beginStr = "======== begin ========";
		try  {  
	        FileInputStream fstream = new FileInputStream(logPath);  
	        DataInputStream in = new DataInputStream(fstream);  
	        BufferedReader br = new BufferedReader(new InputStreamReader(in));  
	        String strLine;  
	        boolean begin = false;
	        String mappingName = null;
	        String systemName = null;
	        while ((strLine = br.readLine()) != null) {  
	            System.out.println (strLine);  
	            if(strLine.equals(beginStr)){
	            	begin = true;
	            }
	            if(strLine.trim().length() == 0){
	            	begin = false;
	            	mappingName = null;
	            	systemName = null;
	            	output.println();
	            	System.gc();
	            	System.gc();
	            }
	            if(begin){
	            	if(strLine.startsWith("Mapping: ")){
	            		mappingName = strLine.substring(9);
	            		int index = mappingName.indexOf("-");
	            		systemName = mappingName.substring(0,index);
	            		output.print(systemName);
	                    output.print('\t'); 
	                    mappingName = mappingName.substring(index+1);
	                    output.print(mappingName);
	                    output.print('\t');                     
	                    
	            	} else if(strLine.startsWith("[")){
	            		int index = strLine.indexOf("]");
	            		String info = strLine.substring(1, index);
	            		if(info.equals("Incoherent")){
	            			// Obtain mapping size
		                    String ontoPath = root + "mergedOnto/"+ systemName + "/incoherent/" + mappingName + ".owl";
		                    this.printOntoSize(output, ontoPath);
		                    
	            			int index2 = strLine.indexOf("= ");
	            			int ucNum = Integer.valueOf(strLine.substring(index2+2));
	            			output.print("Yes");
		                    output.print('\t'); 
		                    output.print("No");
		                    output.print('\t'); 
		                    output.print(ucNum);
	            		} else if(info.equals("Coherent")){
	            			// Obtain mapping size
		                    String ontoPath = root + "mergedOnto/"+ systemName + "//" + mappingName + ".owl";
		                    this.printOntoSize(output, ontoPath);
		                    
	            			output.print("Yes");
		                    output.print('\t'); 
		                    output.print("Yes");
		                    output.print('\t'); 
		                    output.print(0);
	            		} else if(info.equals("Inconsistent")){
	            			// Obtain mapping size
		                    String ontoPath = root + "mergedOnto/"+ systemName + "/inconsistent/" + mappingName + ".owl";
		                    this.printOntoSize(output, ontoPath);
		                    
	            			output.print("No");
		                    output.print('\t'); 
		                    output.print("Unknown");
		                    output.print('\t'); 
		                    output.print(0);
	            		}
	            	}
	            	
	            }
	        }  
	        in.close();  
	    }  
	    catch(Exception e)  {  
	        System.err.println("Error: " + e.getMessage());  
	    }  
	}
	
	public void printOntoSize(PrintWriter output, String ontoPath){
		int size = -1;
		OWLOntology onto = null;
		File f = new File(ontoPath);
		if(f.exists()){
			try{
				onto = OWLTools.openOntology(ontoPath);
		        size = onto.getLogicalAxiomCount();      
			} catch (Exception ex){
				ex.printStackTrace();
			} finally {
				if(onto != null){
					try{
						OWLTools.clearOntology(onto, OWLTools.manager);
					} catch (Exception ex2){
						ex2.printStackTrace();
					}
				}			
			}
		}
		
        output.print(size);
        output.print('\t'); 
	}
	
	public void outputHeader(PrintWriter output){
//		Output the titles for each column
		output.print("Mapping System");
        output.print('\t'); 
		output.print("Mapping Name");
        output.print('\t');
        output.print("Mapping Size");
        output.print('\t');
    	output.print("Consistent?");
        output.print('\t'); 
        output.print("Coherent?");
        output.print('\t'); 
    	output.print("N. of Conflicts");
        output.println();
	}

}
