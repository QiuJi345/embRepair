package edu.njupt.radon.exp.data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.AxiomType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyChange;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.util.SimpleIRIMapper;

import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;


public class OntoInfoMain {
	
	/*static final String[] ontos = {
		"bt_km-3000", "bt_km-5000", 
		"Galen-500", 
		"Go-500", "Nci-500"
	};*/
	static OWLOntologyManager manager = null;
	static String info = "";
	static String ontoName = "";
	
	public static void main(String[] args) throws Exception {	
		//String dataSet = "onto";
		String ontoRoot = "as2022/onto/";
				
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(
				"results/ontoInfo.xls")),true);    	
		outputHeader(output);
		
		File rootFile = new File(ontoRoot);
		for(File file : rootFile.listFiles()){
			if(!file.isDirectory()){
				ontoName = file.getName();

				OWLOntology o = openOntology("file:"+ontoRoot+ontoName);	
				output.print(ontoName);
			    output.print("\t");
			    output.print(o.getTBoxAxioms(true).size());
			    output.print("\t");
			    output.print(o.getABoxAxioms(true).size());
			    output.print("\t");
				output.print(o.getAxiomCount(AxiomType.SUBCLASS_OF));
				output.print('\t');	
				output.print(o.getAxiomCount(AxiomType.EQUIVALENT_CLASSES));
			    output.print("\t");
				output.print(o.getAxiomCount(AxiomType.DISJOINT_CLASSES));
				output.print('\t');
				output.print(o.getAxiomCount(AxiomType.SUB_DATA_PROPERTY)+
						o.getAxiomCount(AxiomType.SUB_OBJECT_PROPERTY));		    
			    output.print("\t");
			    output.print(o.getAxiomCount(AxiomType.OBJECT_PROPERTY_DOMAIN)+o.getAxiomCount(AxiomType.DATA_PROPERTY_DOMAIN));
				output.print('\t');
				output.print(o.getAxiomCount(AxiomType.OBJECT_PROPERTY_RANGE)+o.getAxiomCount(AxiomType.DATA_PROPERTY_RANGE));
				output.print('\t');
				
			    output.print(o.getClassesInSignature().size());
				output.print('\t');
				output.print(o.getObjectPropertiesInSignature().size());
				output.print('\t');
				output.print(o.getDataPropertiesInSignature().size());
				output.print('\t');		    
			    output.print(o.getIndividualsInSignature().size());
			    output.print('\t');		    
			    output.print(getUnsatiConcepts(o, manager).size());
			    output.println();
			
			}
		}
					
		output.flush();
        output.close();
	}
	

	public static void outputHeader(PrintWriter  output){
		output.print("Ontology");
	    output.print("\t");
	    output.print("TBox");
	    output.print("\t");
	    output.print("ABox");
	    output.print("\t");
		output.print("SubClass");
		output.print('\t');	
		output.print("EquClass");
		output.print('\t');	
		output.print("DisjClass");
		output.print('\t');
		output.print("SubProp");		    
	    output.print("\t");
	    output.print("domain");		    
	    output.print("\t");
	    output.print("range");		    
	    output.print("\t");
	    
	    
	    output.print("Classes");
	    output.print("\t");
	    output.print("ObjectProperties");
	    output.print("\t");
	    output.print("DataProperties");
	    output.print("\t");
	    output.print("Individuals");
	    output.print("\t");
	    output.print("UC");
		output.println();
	}
	
	public static OWLOntology openOntology(String ontoPath){		
		
		String path = checkOntoPath(ontoPath);
		IRI physicalURI = IRI.create(path);	
		OWLOntology ontology = null;
		manager = OWLManager.createOWLOntologyManager();
		
		try{
			ontology = manager.loadOntology(physicalURI);  
		} catch (OWLOntologyCreationException ex){
			ex.printStackTrace();
		}   
       	return ontology;
	}
	
	public static String checkOntoPath(String ontoPath) {
		String path = ontoPath;
		if (!ontoPath.startsWith("http:"))
	        if (!ontoPath.startsWith("https:"))
		        if (!ontoPath.startsWith("ftp:"))
		        	if (!ontoPath.startsWith("file:"))
		        		path =  "file:" + ontoPath;
		return path;
	}
	
	public static HashSet<OWLClass> getUnsatiConcepts(
			OWLOntology onto, 
			OWLOntologyManager managerr) {		
		HashSet<OWLClass> uncon = new HashSet<OWLClass>();		
			
		OWLDataFactory factory = manager.getOWLDataFactory();
		
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		OWLReasoner owlReasoner = reasonerFactory.createReasoner(onto);
		System.out.println("Orignial onto size: "+onto.getAxiomCount());
		
		
		OWLOntology o = onto;
		if(!owlReasoner.isConsistent()) {
			System.out.println("inconistent onto");
			info = "inconsistent";
			// Obtain Tbox
			HashSet<OWLAxiom> tbox = new HashSet<OWLAxiom>(onto.getTBoxAxioms(true));		
			o = createOntology(manager, tbox, null, null);
			System.out.println("Extracted onto size: "+o.getAxiomCount());
			owlReasoner = reasonerFactory.createReasoner(onto);
			
		} else {
			info = "";
		}
		
		for(OWLClass oc : o.getClassesInSignature()){
        	if(oc.equals(factory.getOWLNothing())||
        			oc.equals(factory.getOWLThing())){
        		continue;
        	}
        	boolean f = true;
    		if(o.containsClassInSignature(oc.getIRI())){
    			f = owlReasoner.isSatisfiable(oc);
    		}
			if(!f){
				uncon.add(oc);
				System.out.println("This onto is incoehrent");
			}					
		}				
		return uncon;
	}
	
	public static OWLOntology createOntology(
			OWLOntologyManager conn_p, 
			HashSet<OWLAxiom> axioms_p,
			String logicalUrl_p, 
			String physicalUrl_p) {
		
		String logicalUrl = logicalUrl_p;
		String physicalUrl = physicalUrl_p;

		if(logicalUrl==null){
			logicalUrl = "http://radon.njupt.edu.cn/"+ontoName+"-tbox";			
		}
		if(physicalUrl==null){
			physicalUrl = "onto2/"+ontoName+"-tbox.owl";
		} else {
			checkOntoPath(physicalUrl);
		}
		
		IRI ontologyURI = IRI.create(logicalUrl);
		IRI physicalURI = IRI.create(physicalUrl);
        SimpleIRIMapper mapper = new SimpleIRIMapper(ontologyURI, physicalURI);
        OWLOntology o = null;
        try{
        	if(conn_p==null){
    			manager = OWLManager.createOWLOntologyManager();
    			manager.addIRIMapper(mapper);
    	        o = manager.createOntology(ontologyURI);
    	        addAxioms(o, manager, axioms_p);
    		} else {
    			conn_p.addIRIMapper(mapper);
    	        o = conn_p.createOntology(ontologyURI);
    	        addAxioms(o, conn_p, axioms_p);
    		}   
        	File f  = new File(physicalUrl);
    		manager.saveOntology(o, IRI.create(f.toURI()));
        } catch(Exception ex){
        	ex.printStackTrace();
        }		     
       
		return o;	
	}
	
	public static void addAxioms(
			OWLOntology o,
			OWLOntologyManager conn, 
			HashSet<OWLAxiom> axioms) {
		
		List<OWLOntologyChange> list = new ArrayList<OWLOntologyChange>();
		for (OWLAxiom axiom : axioms) {
			if(axiom==null){
				continue;
			}
			AddAxiom addAxiom = new AddAxiom(o, axiom);
			list.add(addAxiom);
		}
		if(list.size()>0){
			conn.applyChanges(list);  
		}		
	}
}
