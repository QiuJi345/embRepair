package edu.njupt.radon.exp.data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;

public class MergeResultsStatisticsMain {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String root = "F:/Data/debugging/oaei/";
		String systemsRoot = root + "mergedOnto/";		
		String tablePath = root + "reasoningRes.xls";
		
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(tablePath)),true);    	
    	
		MergeResultsStatisticsMain main = new MergeResultsStatisticsMain();
		main.output(output, systemsRoot);
	}
	
	public void output(PrintWriter output, String systemsRoot){
		// Output header
		this.outputHeader(output);
		// Obtain mapping systems
		File f = new File(systemsRoot);
		for(File systemFile : f.listFiles()){	
			System.out.println(systemFile.getName());
			output.print(systemFile.getName());
	        output.print('\t'); 
	        // Obtain the number of coherent ontologies for this system
			File[] subFiles = systemFile.listFiles();		
			int coherentOntoNum = subFiles.length - 2;
			output.print(coherentOntoNum);
	        output.print('\t'); 
	        // Obtain the number of incoherent ontologies for this system
			String systemPath = systemFile.getPath();
			File incoherentOntoFile = new File(systemPath+"\\incoherent");
			if(incoherentOntoFile != null){
				subFiles = incoherentOntoFile.listFiles();
				output.print(subFiles.length);
		        output.print('\t'); 
			} else {
				output.print(0);
				output.println();
			}
			// Obtain the number of inconsistent ontologies for this system
			File inconsistenttOntoFile = new File(systemPath+"\\inconsistent");
			if(inconsistenttOntoFile != null){
				subFiles = inconsistenttOntoFile.listFiles();
				output.print(subFiles.length);
				output.println();
			} else {
				output.print(0);
				output.println();
			}
			
		}
	}
	
	public void outputHeader(PrintWriter output){
//		Output the titles for each column
		output.print("Mapping System");
        output.print('\t'); 
    	output.print("N. of Coherent Onts");
        output.print('\t'); 
        output.print("N. of Incoherent Onts");
        output.print('\t'); 
    	output.print("N. of Inconsistent Onts");
        output.println();
	}
	

}
