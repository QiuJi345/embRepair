package edu.njupt.radon.exp.data;

public class GenerateD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
