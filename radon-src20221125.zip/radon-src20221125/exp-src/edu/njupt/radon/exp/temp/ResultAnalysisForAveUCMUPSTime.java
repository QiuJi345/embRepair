package edu.njupt.radon.exp.temp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.HashSet;

import edu.njupt.radon.parameters.DebuggingParameters;

public class ResultAnalysisForAveUCMUPSTime {
	// 定义各个文件夹名称
	static String algorithmName = "";
	static String dataSet = "";
	static String ontoName = "";
	static String debugMethod = "";
	static String entailmentString = "";
	/** 计算所有MUPs的时间，初始值设置timeout的时间（1000秒）  */
	static long time = DebuggingParameters.timeout;
	/** 计算单个UC所有MUPS的平均时间 */
	static long meanTime = 0;
	static int ucNumber = 0;
	static long mupsNumber= 0;

	public static void main(String[] args) throws Exception {
		// 结果存放路径
//		String resultPath = "d:/84917/桌面/result/";
		// 测试文件路径
		String resultPath = "d:/84917/桌面/test/";
		// 结果存放在debugResult.xls
		PrintWriter output =  new PrintWriter(new BufferedWriter(
				new FileWriter(resultPath+"debugResult.xls")),true); 
		// 待统计文件存放位置
		resultPath += "all/";
    
		outputJustHeader(output);
		listAlgorithms(output, resultPath);
		
		output.flush();
        output.close();
	}
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第一层，文件夹名称为算法名字
	 * @param output
	 * @param resultPath
	 */
	public static void listAlgorithms(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			// 读取算法名称
			algorithmName = subFile.getName();
			// 继续读取下一层
			String path = resultPath + algorithmName + "/";
			listDataSets(output, path);
			algorithmName = "";
		}
	}
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第二层，文件夹名称为数据集名字
	 * @param output
	 * @param resultPath
	 */
	public static void listDataSets(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			// 读取数据集名称
			dataSet = subFile.getName();
			// 继续读取下一层
			String path = resultPath + dataSet + "/";
			listOnts(output, path);
			dataSet = "";
		}
	}
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第三层，文件夹名称为本体名字
	 * @param output
	 * @param resultPath
	 */
	public static void listOnts(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			// 读取本体名称
			ontoName = subFile.getName();
			// 继续读取下一层
			String path = resultPath + ontoName + "/";
			// radon \ pellet
//			listDebugMethods(output, path);
//			// swoop \ 张瑜
			listEntailmentsforSwoop(output, path);
			ontoName = "";
		}
	}
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第四层，文件夹名称为DebugMethod<br>
	 * 这个在radon和pellet才有<br>
	 * 输出表格时不使用
	 * @param output
	 * @param resultPath
	 */
	public static void listDebugMethods(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			// 读取DebugMethod
			debugMethod = subFile.getName();
			// 继续读取下一层
			String path = resultPath + debugMethod + "/";
			listEntailments(output, path);
			debugMethod = "";
		}
	}
	
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第五层，文件夹名称为UC名称
	 * 求radon 和 pellet 输出格式  所有UC的平均
	 * @param output
	 * @param resultPath
	 */
	public static void listEntailments(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		long sumTime = 0;
		int sumMups = 0;
		int ucNum = 0;
		for(File subFile : file.listFiles()){
			// 读取UC名称
			entailmentString = subFile.getName();
			String path = resultPath + entailmentString;
			// 测试用
			System.out.println("2222");
			// 读取log文档，计算所需值
			sumTime = sumTime + computeJust(output, path+"/log.txt");
			// radon 和 pellet
			sumMups = sumMups + computeJustSize(output, path+"/log.txt");					
			++ucNum;
		}
		// 输出到表格
		meanTime = sumTime / ucNum;
		ucNumber = ucNum;
		mupsNumber = sumMups;
		printFileInfo(output);
		entailmentString = "";
	}
	
	
	/**
	 * 依次读取各层文件夹<br>
	 * 第五层，文件夹名称为UC名称
	 * 求swoop、张瑜 输出格式的所有UC的平均
	 * @param output
	 * @param resultPath
	 */
	public static void listEntailmentsforSwoop(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		long sumTime = 0;
		int sumMups = 0;
		int ucNum = 0;
		for(File subFile : file.listFiles()){
			// 读取UC名称
			entailmentString = subFile.getName();
			String path = resultPath + entailmentString;
			// 测试用
			System.out.println("2222");
			// 读取log文档，计算所需值
			sumTime = sumTime + computeJust(output, path+"/log.txt");		
			// swoop 和 张瑜
			sumMups = sumMups + computeJustSizeForSwoop(output, path+"/log.txt");			
			++ucNum;
		}
		// 输出到表格
		meanTime = sumTime / ucNum;
		ucNumber = ucNum;
		mupsNumber = sumMups;
		printFileInfo(output);
		entailmentString = "";
	}
	
	/**
	 * radon & pellet
	 * @param output
	 * @param logPath
	 * @return
	 */
	public static int computeJustSize(PrintWriter  output, String logPath) {		
		JustsReaderForUCMUPSTime reader = new JustsReaderForUCMUPSTime(logPath);			
		HashSet<HashSet<String>> justs = reader.getJusts();	
		int justsNumber = justs.size();
		return justsNumber;
	}
	
	/**
	 * swoop & 张瑜
	 * @param output
	 * @param logPath
	 * @return
	 */
	public static int computeJustSizeForSwoop(PrintWriter  output, String logPath) {		
		JustsReaderForUCMUPSTime reader = new JustsReaderForUCMUPSTime(logPath, 0);				
		int justsNumber = reader.getMupsNumForSwoop();
		return justsNumber;
	}
	
	/**
	 * 计算求解MUPs的平均时间		
	 * @param output
	 * @param logPath
	 */
	public static long computeJust(PrintWriter  output, String logPath) {		
		JustsReaderForUCMUPSTime reader = new JustsReaderForUCMUPSTime(logPath);			
		time = reader.getTime();
		return time;
	}
	
	
	/**
	 * 输出对应结果
	 * @param output
	 */
	private static void printFileInfo(PrintWriter output){
		output.print(algorithmName);
	    output.print("\t");
	    output.print(dataSet);
	    output.print("\t");
	    output.print(ontoName);
	    output.print("\t");
	    output.print(entailmentString);
	    output.print("\t");
		output.print(meanTime);
		output.print('\t');
		output.print(ucNumber);
		output.print('\t');
		output.print(mupsNumber);
		output.print('\t');
		output.println();
		
	}

	/**
	 * 打印表格表头
	 * @param output
	 */
	public static void outputJustHeader(PrintWriter  output){	
		output.print("algorithm Name");
	    output.print("\t");
		output.print("dataSet");
		output.print("\t");
		output.print("Ontology ID");
	    output.print("\t");
	    output.print("UC");
	    output.print("\t");
		output.print("Mean Time (ms)");
		output.print("\t");
		output.print("#UC");
		output.print("\t");
		output.print("#mups");
		output.print("\t");
		output.println();
	}
	
}
