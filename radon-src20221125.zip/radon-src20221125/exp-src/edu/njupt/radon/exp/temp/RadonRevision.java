package edu.njupt.radon.exp.temp;

import java.io.File;
import java.util.HashSet;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.repair.ilp.ILPAlgorithm;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class RadonRevision {



	public static void main(String[] args) throws OWLOntologyCreationException
	{
		
		//"koala.owl","buggyPolicy.owl", "University.owl","Terrorism.owl","miniTambis.owl","proton_50_studis.owl","CRS-SIGKDD.owl"
		//"Economy-SDA.owl",,"Transportation-SDA.owl","CONFTOOL-CMT.owl"
		
		//OWLTools.getTBox(ontology);
		
		String onto     ="data/CONFTOOL-CMT";
		String ontoPath =onto+".owl";
		File   file     = new File(ontoPath);
		
		HashSet<HashSet<OWLAxiom>> Union_Mups  = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> Golbal_Mips = new HashSet<HashSet<OWLAxiom>>();
		ComputeMIPS                allMips     = new ComputeMIPS();
		ILPAlgorithm              Algo_ILP    = new ILPAlgorithm();
		
		
		OWLOntologyManager manager    = OWLManager.createOWLOntologyManager();
		OWLOntology        local      = manager.loadOntologyFromOntologyDocument(file);
		OWLOntology        sourceOnto = OWLTools.openOntology(ontoPath);
		
		HashSet<OWLClass>  allUnsat   = ReasoningTools.getUnsatiConcepts(sourceOnto, OWLTools.manager);
		HashSet<OWLAxiom>  axioms     = new HashSet<OWLAxiom>(sourceOnto.getAxioms());
		RadonDebug  debug      = new BlackboxDebug(axioms);		
		
		for (OWLClass cl : allUnsat) 
		{   
			HashSet<HashSet<OWLAxiom>> mups = debug.getMUPS(cl);	
			Union_Mups.addAll(mups);
		}
		Golbal_Mips = ComputeMIPS.doCompute(Union_Mups);

		HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(Union_Mups);
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags);
		
	}



}
