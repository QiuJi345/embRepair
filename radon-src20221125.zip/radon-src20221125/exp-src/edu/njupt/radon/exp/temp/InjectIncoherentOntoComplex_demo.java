package edu.njupt.radon.exp.temp;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyID;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.heuristic.HeuristicDebug;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.OWLTools_New;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class InjectIncoherentOntoComplex_demo {
	static String URI="";
	static ArrayList<OWLClass> concepts= new ArrayList<OWLClass>();
	static ArrayList<OWLObjectProperty> objectproperties= new ArrayList<OWLObjectProperty>();
	static HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();	
	static HashSet<OWLAxiom> externalAxioms = new HashSet<OWLAxiom>();	
	static HashMap<OWLClass, Set<OWLClass>> subAxioms =new HashMap<OWLClass, Set<OWLClass>>();
	static HashMap<OWLClass, Set<OWLClass>> supAxioms =new HashMap<OWLClass, Set<OWLClass>>();
	static HashMap<OWLClass, Set<OWLClass>> disAxioms= new HashMap<OWLClass, Set<OWLClass>>();
	
	public static void main(String[] args) throws Exception  {
		String ontoName = "Transportation";
		String ontPath = "data/IncoherentOnto/"+ontoName+".owl";
		
//		String ontoName = "InjectTest2";
//		String ontPath = "data/ontologies/"+ontoName+".owl";
		
		//String resultPath = "results/pattern2018/"+ontoName;
		//System.setOut((new PrintStreamObject(resultPath)).ps);
					
		OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
		OWLOntology onto=manager.loadOntologyFromOntologyDocument(new File(ontPath));
			
		//获取本体的概念
		//Set<OWLClass> concepts=onto.getClassesInSignature();
		concepts= OWLTools_New.getAllConcepts(onto);
		System.out.println("The number of concetps is "+concepts.size());
		manager.getOntologyDocumentIRI(onto);
		 
		
		//获取本体的URI
		OWLOntologyID ontologyIRI = onto.getOntologyID();
		URI = ontologyIRI.getOntologyIRI().toString().replace("#", "");
		System.out.println("The URI of concepts of ontology is "+URI);
		
		//获取本体的对象属性
		objectproperties= OWLTools_New.getAllObjectProperty(onto);
		System.out.println("The number of objectproperties is "+objectproperties.size());
		
		//获取本体公理
		axioms = OWLTools_New.getTBox(onto);	
		System.out.println("The number of axioms is "+axioms.size());
		
		//获取包含公理
		subAxioms=OWLTools_New.getSubClass(onto);
		System.out.println("The number of subClassOf axioms is "+getNumberOfAxioms(subAxioms));
		
		supAxioms=OWLTools_New.getSupClass(onto);
		System.out.println("The number of supClassOf axioms is "+getNumberOfAxioms(supAxioms));
		
		//获取不相交公理
		disAxioms=OWLTools_New.getDisjointConcepts(onto);
		System.out.println("The number of disjointWith axioms is "+getNumberOfAxioms(disAxioms));
		
		
		//定义debug的类
		Long tic1=System.currentTimeMillis();
		RadonDebug debug = new BlackboxDebug(axioms);        //基于黑盒的debugging方法
		//HeuristicDebug debug = new HeuristicDebug(axioms); //基于启发式的debugging方法
		
		//获取本体不可满足的概念数目
		HashSet<OWLClass> unsatConcepts= ReasoningTools.getUnsatiConcepts(axioms);
		System.out.println("The number of unsatisfie concepts is "+unsatConcepts.size());
		//boolean coherent = ReasoningTools.isCoherent(axioms);	
		if(unsatConcepts.size()==0)
			System.out.println("This ontology is coherent");
		else
			System.out.println("This ontology is incoherent");	
		
//		//获取MUPS的数量
//		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
		
//		//获取特定数量概念对应的的MUPS
//		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups=new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
//		int Cnum=1;
//		for (OWLClass c: unsatConcepts)
//		{
//			HashSet<HashSet<OWLAxiom>> Cmups= debug.getMUPS(c);
//			mups.put(c, Cmups);
//			Cnum--;
//			if(Cnum==0)
//				break;
//		}
		
		//获取特定数量概念对应的的MUPS
//		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups=new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
//		int Mnum=100;
//		for (OWLClass c: unsatConcepts)
//		{
//			HashSet<HashSet<OWLAxiom>> Cmups= debug.getMUPS(c);
//			mups.put(c, Cmups);
//			Mnum=Mnum-Cmups.size();
//			if(Mnum<=0)
//				break;
//		}
		
			
		System.out.println("+++++++++++++++++");			
		//根据mups获取本体的mips
		//HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(mups);
		//System.out.println("\nFound MIPS: ");
		//printAxiomSets(mips);
				
		Long toc1=System.currentTimeMillis();		
		System.out.println("The consumption of debugging time is "+(toc1-tic1)+" ms");
		
		
		InjectIncoherentOntoComplex_demo inCoOn= new InjectIncoherentOntoComplex_demo();
				
		//type 的可选类型有"random"、"subClassOf"、"disjointWith"、"equivalence","intersection","existing"
		String type = "random";

	   Long tic2=System.currentTimeMillis();   
	   int injectNum=15;
	   if(injectNum<=0)
		   System.out.println("The number of injected Axioms is enough.");
	   else
		   inCoOn.complexNewConInjector(manager,injectNum,type); //不考虑mups的注入，方式为：不相干的概念以及儿子，注入subClassOf、disjointWith、equivalence,existing 四种类型
		   inCoOn.complexScaleInjector(unsatConcepts,injectNum,type); //不考虑mups的注入，方式为：不相干的概念以及儿子，注入subClassOf、disjointWith、equivalence,existing 四种类型
	   	   inCoOn.complexUnConInjector(unsatConcepts,injectNum,type); //注入的方式包含存在量词以及公理相交的方式 intersection, existing
	
	   //尝试添加存在量词（可行）
	   //generatedAxiomByObjectPropertySomeValuesFrom(unsatConcepts,1);
	   //generatedAxiomByObjectPropertyAllFrom(unsatConcepts,1);	但任意的话不会导致概念的不可满足
	   
	   //打印输出添加的本体
	   for(OWLAxiom ax:externalAxioms)
		   System.out.println(ax.toString());
	   System.out.println("The number of new injected axioms is "+externalAxioms.size());
	   axioms.addAll(externalAxioms);
	   System.out.println("The number of axioms of the injected ontology is "+ axioms.size());
	   
		//生成本体，进行路径保存
		//String newOntPath = "data/IncohOntologies/"+ontoName+"+"+time+".owl";
		String newOntPath = "data/InjectOntologies/"+ontoName+"-M0-"+injectNum+".owl";
		OWLTools.saveOntology(axioms,newOntPath);	
		Long toc2=System.currentTimeMillis();
		
		System.out.println("The consumption of injecting time is "+(toc2-tic2)+" ms");
			
	}
	
	public static void computeMUPS(RadonDebug debug, HashSet<OWLAxiom> tbox){
		System.out.println("****************************************");
		debug.getMUPS();
		for(OWLClass uc : ReasoningTools.getUnsatiConcepts(tbox)) {
			if(!uc.toString().contains("Retry-Until-SucceedUsernamePolicy")) {
				continue;
			}
			debug.getMUPS(uc);
			//break;
		}		
	}
	
	public static void computeMUPS(OWLOntology onto, RadonDebug debug, String ucURI){
		if(ucURI != null && ucURI.length()>0){
			OWLEntity uc = null;
			if(ucURI.indexOf("http:")!=-1){
				uc = OWLTools.getEntity(onto, ucURI);
			} else {
				uc = OWLTools.getEntityWithLocalName(onto, ucURI);
			}
		    debug.getMUPS(uc.asOWLClass());		
		} 
	}
		
	public static void printAxiomSets(HashSet<HashSet<OWLAxiom>> axiomSets) {
		int mupsNum = 0;
		for(Set<OWLAxiom> axiomSet : axiomSets) {
			System.out.println("Set <"+(++mupsNum)+">");
			int axiomNum = 0;
			for(OWLAxiom ax : axiomSet) {
				System.out.println("["+(++axiomNum)+"] "+ax.toString());
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public void complexNewConInjector(OWLOntologyManager manager, int injectNum, String type)
	{
		//生成的逻辑方式(即同一层的概念定义不相交关系，可以借助上一层的本体定义包含关系、相交关系、以及存在关系)
		//生成的方式以层为单位，生成2的指数概念
		int level=1;
		ArrayList<OWLClass> supconceptSet=new ArrayList<OWLClass>();
		ArrayList<OWLClass> newconceptSet=new ArrayList<OWLClass>();
		OWLClass initialConcept=generateNewClass(manager,1);
		supconceptSet.add(initialConcept);
		while (injectNum>0) //生成新公理的话，不存在数量不够的问题。
		{
			int startIndex=(int) Math.pow(2, level);
			int endIndex=(int) Math.pow(2, level+1);
			newconceptSet=generateNewClassSet(manager,startIndex,endIndex);
			if(!type.equals("random"))//指定类型的公理，包含subClassOf、disjointWith、equivalent
				injectNum=generateNewSpecialAxioms(supconceptSet,newconceptSet,injectNum,type);
			//选择n种类型，默认为subClassOf、disjointWith、existing、intersection四种类型
			else
				injectNum=generateNewRandomAxioms(supconceptSet,newconceptSet,injectNum);	
			level++;
			supconceptSet.clear(); //层次增加
			supconceptSet.addAll(newconceptSet); //父亲集合更新
			newconceptSet.clear();
		}
		System.out.println("The number of injected Axioms by ComplexInjector is completed.");		
	}
	
	private OWLClass generateNewClass(OWLOntologyManager manager,int id) 
	{
		String classIRI = URI+"#concept-"+id;
		//System.out.println("new class : "+classIRI);
		return manager.getOWLDataFactory().getOWLClass(IRI.create(classIRI));
	}
	
	private ArrayList<OWLClass> generateNewClassSet(OWLOntologyManager manager,int start, int end) 
	{
		ArrayList<OWLClass> conceptSet=new ArrayList<OWLClass>();
		for(int i=start;i<end;i++)
		{
			String classIRI = URI+"#concept-"+i;
			//System.out.println("new class : "+classIRI);
			OWLClass newConcept= manager.getOWLDataFactory().getOWLClass(IRI.create(classIRI));
			conceptSet.add(newConcept);
		}
		return conceptSet;
	}
	
	public int generateNewSpecialAxioms(ArrayList<OWLClass>supconcepts,ArrayList<OWLClass> newconcepts,int injectNum,String type)
	{	
		if(type.equals("subClassOf"))
		{
			 Random r = new Random();
			 int ran1 = r.nextInt(supconcepts.size()); 
			 OWLClass supC=supconcepts.get(ran1);
			 for(OWLClass c:newconcepts) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(c, supC);
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		}
		if(type.equals("disjointWith"))
		{
		 for(int i = 0; i<newconcepts.size(); i++) 
		 {
			for(int j = i+1; j < newconcepts.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLDisjointClassesAxiom(newconcepts.get(i), newconcepts.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		 }
		}
		if(type.equals("equivalence"))
		{	   
		 for(int i = 0; i<newconcepts.size(); i++) 
		 {
			for(int j = i+1; j < newconcepts.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLEquivalentClassesAxiom(newconcepts.get(i), newconcepts.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		 }
		}
		if(type.equals("existing"))
		{
			Random r = new Random();
			int ran1 = r.nextInt(supconcepts.size()); 
			OWLClass supC=supconcepts.get(ran1);
			for(int j = 0; j < newconcepts.size(); j++) 
			{
				int num=externalAxioms.size();
				if(objectproperties.isEmpty())
				{
					System.out.println("This ontology has no objectproperty!!!");
		    		return 0;
				}			
	    		for(OWLObjectProperty ob: objectproperties)
	    		{
	    			OWLObjectSomeValuesFrom b=OWL.factory.getOWLObjectSomeValuesFrom(ob, supC);		
		    		OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(newconcepts.get(j), b);	
		    		externalAxioms.add(a);
					if(externalAxioms.size()!=num) //表示增加了新的公理
						injectNum--;
					if(injectNum==0)
					{
						return 0;
					}
	    		}			
			}
			
		}
		if(type.equals("intersection"))
		{
			 Random r = new Random();
			 int ran1 = r.nextInt(supconcepts.size()); 
			 OWLClass supC=supconcepts.get(ran1);
			 for(int i = 0; i<newconcepts.size(); i++) 
			 {
				for(int j = i+1; j < newconcepts.size(); j++) 
				{
					 int num=externalAxioms.size();
					 OWLObjectIntersectionOf oce= OWL.factory.getOWLObjectIntersectionOf(newconcepts.get(j+1),supC); //基于不相交的原理进行添加
					 OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(newconcepts.get(i), oce);
					 externalAxioms.add(a);
					 if(externalAxioms.size()!=num) //表示增加了新的公理
						 injectNum--;
					 if(injectNum==0)
					 {
						 return 0;
					 }
				}
			}
		}
		return injectNum;				
	}
	
	public int generateNewRandomAxioms(ArrayList<OWLClass>supconcepts,ArrayList<OWLClass> newconcepts,int injectNum)
	{	
		Random r = new Random();
		for(int i = 0; i < newconcepts.size(); i++) 
		{
			int num=externalAxioms.size();	
		    int ran1 = r.nextInt(10);
		    OWLAxiom a=null;
		    int ran0 = r.nextInt(supconcepts.size()); 
			OWLClass supC=supconcepts.get(ran0);
		    if(ran1==0||ran1==1||ran1==2||ran1==3||ran1==4)	   
		    {
		    	 a = OWL.factory.getOWLSubClassOfAxiom(newconcepts.get(i), supC); //上层概念
		    }
		    else if(ran1==5)	
		    {
		    	 if(i+1!=newconcepts.size())
		    		 a = OWL.factory.getOWLDisjointClassesAxiom(newconcepts.get(i), newconcepts.get(i+1));
		    	 else  //不加这一句可能会出现空的axioms
		    		 continue;
		    }
		    else if(ran1==6||ran1==7)
		    {
		    	if(i+1!=newconcepts.size())
		    	{
		    		OWLObjectIntersectionOf oce= OWL.factory.getOWLObjectIntersectionOf(newconcepts.get(i+1),supC); //基于合取的原理进行添加
					a=OWL.factory.getOWLSubClassOfAxiom(newconcepts.get(i), oce);
		    	}
		    	else  //不加这一句可能会出现空的axioms
		    		 continue;
		    } 
		    else
		    {
		    	if(objectproperties.isEmpty())
		    		continue;
		    	else
		    	{
		    		Random rp = new Random();
		    		int ran2 = rp.nextInt(objectproperties.size());
		    		OWLObjectProperty ob=objectproperties.get(ran2);
		    		OWLObjectSomeValuesFrom b=OWL.factory.getOWLObjectSomeValuesFrom(ob, supC);		
		    		a = OWL.factory.getOWLSubClassOfAxiom(newconcepts.get(i), b);	
		    	}
		    }  
			externalAxioms.add(a);
			if(externalAxioms.size()!=num) //表示增加了新的公理
				injectNum--;
			if(injectNum==0)
			{
				return 0;
			}
		}
		return injectNum;				
	}
	
	public void complexScaleInjector(HashSet<OWLClass> unConcepts, int injectNum, String type)
	{
		Set<OWLClass> leftClass=new HashSet<OWLClass>();
		leftClass.addAll(concepts);
		leftClass.removeAll(unConcepts);		
		boolean flag=false;
		leftClass.retainAll(subAxioms.keySet());
		System.out.println("The number of the left classes is " + leftClass.size() );
		for(OWLClass a:leftClass)
		{
			if(!subAxioms.containsKey(a))
				continue;
			Set<OWLClass> sub= new HashSet<OWLClass>();
			sub= subAxioms.get(a); //如果规模不够，其实还可以加入概念本身
			sub.removeAll(unConcepts); //因为儿子里面可能存在不可满足概念
			if (sub.size()==0)
				continue;
			else
			{
				//injectNum=generateAxioms(sub,injectNum);	
				if(!type.equals("random"))//指定类型的公理，包含subClassOf、disjointWith、equivalent
					injectNum=generateSpecialAxioms(sub,injectNum,type);
				//选择n种类型，默认为subClassOf、disjointWith两种类型
				else
					injectNum=generateRandomAxioms(sub,injectNum);
			}
			if(injectNum==0)
			{
				flag=true;
				break;
			}		
		}
		if(injectNum!=0&&!objectproperties.isEmpty()) //将剩余的数量利用Existing的方案再注入一次
		{
			injectNum=generatedAxiomByObjectPropertySomeValuesFrom(unConcepts,injectNum);
			if(injectNum==0)
				flag=true;
			
		}
		if(flag)
			System.out.println("The number of injected Axioms by ComplexInjector is completed.");		
		else
			System.out.println("The injected Axioms by ComplexInjector is completed, but it is not enough.");

	}	
	
	public void complexUnConInjector(HashSet<OWLClass> unConcepts, int injectNum,String type)
	{
		Set<OWLClass> leftClass=new HashSet<OWLClass>();
		leftClass.addAll(concepts);
		leftClass.removeAll(unConcepts);	
		boolean flag=false;
		for(OWLClass a:leftClass)
		{
			//System.out.println(a.toString());
			Set<OWLClass> sub= new HashSet<OWLClass>();
			if(subAxioms.containsKey(a)) 
				sub.addAll(subAxioms.get(a));	
			sub.removeAll(unConcepts); //因为儿子里面可能存在不可满足概念, 可能父亲的操作效率更高
			if (sub.size()==0) //如果是叶子节点就不考虑了。
				continue;
			else
			{		
				if(!type.equals("random"))//指定类型的公理，包含subClassOf、equivalent
					injectNum=generateSpecialAxioms4UnConcepts(unConcepts,a,sub,injectNum,type);
				//选择n种类型，默认为subClassOf、Equivalent两种类型
				else
					injectNum=generateRandomAxioms4UnConcepts(unConcepts,a,sub,injectNum);				
			}
			if(injectNum==0)
			{
				flag=true;
				break;
			}		
		}
		if(flag)
			System.out.println("The number of injected Axioms by ComplexInjector is completed.");
		else
			System.out.println("The injected Axioms by ComplexInjector is completed, but it is not enough.");

	}
	

	public int generateSpecialAxioms(Set<OWLClass> concepts,int injectNum,String type)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		if(type.equals("subClassOf"))
		{
		 for(int i = 0; i<orderedSubs.size(); i++) 
		 {
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), orderedSubs.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		 }
		}
		if(type.equals("disjointWith"))
		{
		 for(int i = 0; i<orderedSubs.size(); i++) 
		 {
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLDisjointClassesAxiom(orderedSubs.get(i), orderedSubs.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		 }
		}
		if(type.equals("equivalence"))
		{
		 for(int i = 0; i<orderedSubs.size(); i++) 
		 {
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLEquivalentClassesAxiom(orderedSubs.get(i), orderedSubs.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		 }
		}
		if(type.equals("existing"))
		{
		 for(int i = 0; i<orderedSubs.size(); i++) 
		 {
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				if(objectproperties.isEmpty())
				{
					System.out.println("This ontology has no objectproperty!!!");
		    		return 0;
				}
//				Random rp = new Random();
//			    int ran2 = rp.nextInt(objectproperties.size());
//	    		OWLObjectProperty ob=objectproperties.get(ran2);
//	    		OWLObjectSomeValuesFrom b=OWL.factory.getOWLObjectSomeValuesFrom(ob, orderedSubs.get(j));		
//	    		OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), b);
//				externalAxioms.add(a);
//				if(externalAxioms.size()!=num) //表示增加了新的公理
//					injectNum--;
//				if(injectNum==0)
//				{
//					return 0;
//				}				
	    		for(OWLObjectProperty ob: objectproperties)
	    		{
	    			OWLObjectSomeValuesFrom b=OWL.factory.getOWLObjectSomeValuesFrom(ob, orderedSubs.get(j));		
		    		OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), b);	
		    		externalAxioms.add(a);
					if(externalAxioms.size()!=num) //表示增加了新的公理
						injectNum--;
					if(injectNum==0)
					{
						return 0;
					}
	    		}			
			}
		 }
		}
		return injectNum;				
	}
	
	public int generateRandomAxioms(Set<OWLClass> concepts,int injectNum)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		for(int i = 0; i<orderedSubs.size(); i++) 
		{
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				Random r = new Random();
			    int ran1 = r.nextInt(5);
			    OWLAxiom a=null;
			    if(ran1==0||ran1==1)	   
			    {
			    	 a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), orderedSubs.get(j));
			    }
			    else if (ran1==2)	
			    	 a = OWL.factory.getOWLDisjointClassesAxiom(orderedSubs.get(i), orderedSubs.get(j));
			    else
			    {
			    	if(objectproperties.isEmpty())
			    		continue;
			    	else
			    	{
			    		Random rp = new Random();
			    		int ran2 = rp.nextInt(objectproperties.size());
			    		OWLObjectProperty ob=objectproperties.get(ran2);
			    		OWLObjectSomeValuesFrom b=OWL.factory.getOWLObjectSomeValuesFrom(ob, orderedSubs.get(j));		
			    		a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), b);	
			    	}
			    }  
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		}
		return injectNum;				
	}
		
	
	public int generateSpecialAxioms4UnConcepts(HashSet<OWLClass> unconcepts,OWLClass concept, Set<OWLClass> concepts,int injectNum, String type)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		if(type.equals("intersection"))
		{
		  for (OWLClass unCon:unconcepts)
		  {
			for(int i = 0; i<orderedSubs.size(); i++) 
			{
				int num=externalAxioms.size();
				OWLObjectIntersectionOf oce= OWL.factory.getOWLObjectIntersectionOf(concept,unCon); //基于不相交的原理进行添加
				OWLAxiom a=OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), oce);			
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理		
					injectNum--;	
				if(injectNum==0)
				{
					return 0;
				}
			
			}
		  }
		}
		if(type.equals("existing"))
		{
		  for (OWLClass unCon:unconcepts)
		  {
			for(int i = 0; i<orderedSubs.size(); i++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a=null;
				if(objectproperties.isEmpty())
				{
					System.out.println("This ontology has no objectproperty!!!");
					return 0;
				}
				 Random rp = new Random();
				 int ran2 = rp.nextInt(objectproperties.size());
				 OWLObjectProperty ob=objectproperties.get(ran2);
				 OWLObjectSomeValuesFrom b=OWL.factory.getOWLObjectSomeValuesFrom(ob, unCon);
				 OWLObjectIntersectionOf oce= OWL.factory.getOWLObjectIntersectionOf(concept,b); //基于不相交的原理进行添加
				 a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), oce);		
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理		
					injectNum--;	
				if(injectNum==0)
				{
					return 0;
				}		
			}
		  }
		}
			
		return injectNum;				
	}

	public int generateRandomAxioms4UnConcepts(HashSet<OWLClass> unconcepts,OWLClass concept, Set<OWLClass> concepts,int injectNum)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		for (OWLClass unCon:unconcepts)
		{
			for(int i = 0; i<orderedSubs.size(); i++) 
			{
				int num=externalAxioms.size();
				Random r = new Random();
			    int ran1 = r.nextInt(2);
			    OWLAxiom a=null;
			    OWLObjectIntersectionOf oce=null;
			    OWLObjectSomeValuesFrom b=null;
			    if(ran1==1)	    
			    {
					oce= OWL.factory.getOWLObjectIntersectionOf(concept,unCon); //基于不相交的原理进行添加
					a=OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), oce);
			    }
			    else
			    {
			    	if(objectproperties.isEmpty())
			    		continue;
			    	else
			    	{
			    		Random rp = new Random();
					    int ran2 = rp.nextInt(objectproperties.size());
			    		OWLObjectProperty ob=objectproperties.get(ran2);
			    		b=OWL.factory.getOWLObjectSomeValuesFrom(ob, unCon);
			    		oce= OWL.factory.getOWLObjectIntersectionOf(concept,b); //基于不相交的原理进行添加
			    		a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), oce);
			    	}
			    }
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理		
					injectNum--;	
				if(injectNum==0)
				{
					return 0;
				}	
			}
		}
		return injectNum;				
	}
	
	//基于对象属性的存在量词生成公理
	public static int generatedAxiomByObjectPropertySomeValuesFrom(HashSet<OWLClass> unConcepts,int num)
	{
		Set<OWLClass> leftClass=new HashSet<OWLClass>();
		leftClass.addAll(concepts);
		leftClass.removeAll(unConcepts);	
		OWLAxiom a=null;
		OWLObjectSomeValuesFrom b=null;
	    for (OWLObjectProperty ob: objectproperties)
	    {
	    	for(OWLClass c:leftClass)
    		{
	    		for(OWLClass uc: unConcepts)
	    		{
	    			b=OWL.factory.getOWLObjectSomeValuesFrom(ob, uc);
	    			a = OWL.factory.getOWLSubClassOfAxiom(c, b);
	    			if(!externalAxioms.contains(a))
	    			{
	    		    	externalAxioms.add(a);  
	    		    	num--;
	    			}  			
	    			if(num==0)
	    				return 0;
	    		}
	    	}	    	
	    }       
	    return 0;
	}
	
	//基于对象属性的全称量词生成公理
	public static void generatedAxiomByObjectPropertyAllFrom(HashSet<OWLClass> unConcepts,int num)
	{
		Set<OWLClass> leftClass=new HashSet<OWLClass>();
		leftClass.addAll(concepts);
		leftClass.removeAll(unConcepts);	
		OWLAxiom a=null;
		OWLObjectAllValuesFrom b=null;
	    for (OWLObjectProperty ob: objectproperties)
	    {
	    	for(OWLClass c:leftClass)
    		{
	    		for(OWLClass uc: unConcepts)
	    		{
	    			b=OWL.factory.getOWLObjectAllValuesFrom(ob, uc);
	    			a = OWL.factory.getOWLSubClassOfAxiom(c, b);		
	    			num--;
	    			if(num==0)
	    				return ;
	    		}
	    	}	    	
	    }    
    	externalAxioms.add(a);   	
	}
	
	public static int getNumberOfAxioms(HashMap<OWLClass, Set<OWLClass>> axioms)
	{
		int num=0;
		for(OWLClass c:axioms.keySet())
		{
			num=num+axioms.get(c).size();
		}
		return num;
	}

}
