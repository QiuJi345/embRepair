package edu.njupt.radon.exp.temp;

import java.io.File;
import java.io.PrintWriter;

import edu.njupt.radon.parameters.DebuggingParameters;

public class Hello {
	
	static String algorithmName = "";
	static String dataSet = "";
	static String ontoName = "";
	static String debugMethod = "";
	static String UCName = "";
	/** 计算所有MUPs的时间，初始值设置timeout的时间（1000秒）  */
	static long time = DebuggingParameters.timeout;
	/** 计算每个UC的时间和MUPS数量  */
	static long Time= 0;
	static long UCmupsNumber= 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String path = "F:/Papers/MyPapers/2021/2021-准备-研发-不协调本体构建/实验结果/6.3节实验数据 - 全/swoop/1.2-oaei2020/";
		
		String newPath = "d:/1.2-oaei2020/";

		File file = new File(path);
		for(File ontoFile : file.listFiles()){
			// 读取本体名称
			ontoName = ontoFile.getName();
			// 继续读取下一层
			newPath += ontoName + "/swoop/";

			for(File ucFile : ontoFile.listFiles()){
				// 读取本体名称
				String ucName = ucFile.getName();
				// 继续读取下一层
				newPath += ucName + "/";
				File f = new File(newPath);
				if(!f.exists()) {
					f.mkdirs();
				}

				for(File logFile : ucFile.listFiles()){
					File newFile = new File(newPath+"log.txt");
					logFile.renameTo(newFile);					
				}
				//ucFile.delete();
			}
		}
	}
	
	public static void listOnts(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			// 读取本体名称
			ontoName = subFile.getName();
			// 继续读取下一层
			String path = resultPath + ontoName + "/";


		}
	}
	
}
