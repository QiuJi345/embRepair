package edu.njupt.radon.exp.temp;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceDebug;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.repair.RepairWithWeight;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;

public class SingleOntoRepair {

	public static void main(String[] args) {
		debugOnto();
	}

	/**
	 * 修补单个不可满足概念
	 */
	public static void debugUc(){
		String ontoPath = "data/ji/T13-incoherent_00507.owl";
		String ucName = "http://purl.obolibrary.org/obo/FLU_0000972";
		String resultPath = "results/";
		
		File f = new File(resultPath);
		if(!f.exists()){
			f.mkdirs();
		}
		/*System.setOut((new PrintStreamObject(resultPath+mappingPath.substring(
				21, mappingPath.length()-4)+"-")).ps);	*/	
		
	    //read an incoherent ontology
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+ontoPath);	
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(sourceOnto.getLogicalAxioms());		
				
		RadonDebug debug = new BlackboxDebug(allAxioms);
		//RadonDebug debug = new HeuristicDebug(sourceOnto);
		OWLClass unsatConcept = OWLTools.getOWLClassWithURI(sourceOnto, ucName);
		HashSet<HashSet<OWLAxiom>> mips = debug.getMUPS(unsatConcept);
		System.out.println("mips : ");
		CommonTools.printMultiSets(mips, null);
					
		long startTime = System.currentTimeMillis();
		HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(mips);
		//System.out.println("diagnosis : ");
		//CommonTools.printMultiSets(diags, null);
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags);
		
		
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		HashMap<OWLAxiom, Double> weights = new HashMap<OWLAxiom, Double>();
		for(OWLAxiom a : axioms) {
			HashSet<OWLEntity> ents = new HashSet<OWLEntity>();
			ents.addAll(a.getClassesInSignature());
			ents.addAll(a.getObjectPropertiesInSignature());
			ents.addAll(a.getDataPropertiesInSignature());
			weights.put(a, Double.valueOf(ents.size()));
		}
		
		HashSet<HashSet<OWLAxiom>> diags2 = RepairWithWeight.getLowWeights(mips, weights);		
		HashSet<OWLAxiom> minHS2 = RepairWithWeight.getOneDiagnoseByHST(diags2);
		
		
		long time = System.currentTimeMillis() - startTime;
		System.out.println("Axioms to be removed: ");
		CommonTools.printOneSet(minHS, null);
		System.out.println("Time to repair (exclude the time to compute MIPS) : "+time);
	}
	
	/**
	 * 修补整个不协调本体
	 */
	public static void debugOnto(){
		String ontoPath = "onto/buggyPolicy.owl"; // "data/ji/T13-incoherent_00507.owl";
		String resultPath = "results/";
		
		File f = new File(resultPath);
		if(!f.exists()){
			f.mkdirs();
		}
		/*System.setOut((new PrintStreamObject(resultPath+mappingPath.substring(
				21, mappingPath.length()-4)+"-")).ps);	*/	
		
	    //read an incoherent ontology
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+ontoPath);
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(sourceOnto.getLogicalAxioms());		
		
		//本体调试
		RadonDebug debug = new RelevanceDebug(allAxioms);
		//RadonDebug debug = new HeuristicDebug(sourceOnto);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = debug.getMUPS();		
		HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(allMUPS);
		System.out.println("mips : ");
		CommonTools.printMultiSets(mips, null);
				
		//本体修补
		long startTime = System.currentTimeMillis();
		HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(mips);
		//System.out.println("diagnosis : ");
		//CommonTools.printMultiSets(diags, null);
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags); //需要移除的公理集合
		long time = System.currentTimeMillis() - startTime;
		System.out.println("minimal diagnosis / removed axioms : ");
		CommonTools.printOneSet(minHS, null);
		System.out.println("Time to repair (exclude the time to compute MIPS) : "+time);

	}
}
