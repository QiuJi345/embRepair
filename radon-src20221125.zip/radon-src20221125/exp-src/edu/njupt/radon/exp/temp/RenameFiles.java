package edu.njupt.radon.exp.temp;

import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class RenameFiles {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String path = "d:/music/Ϸ��/";
		File file = new File(path);
		int i = 1;
		for(File f : file.listFiles()) {
			System.out.println(f.getName());
			//String name  = f.getName();
			//String id = String.format("%03d",(i++));
			//String newPath = f.getAbsolutePath().replace(name, id+"-"+name);
			//File newF = new File(newPath);
			//Files.copy(f.toPath(), newF.toPath());
		}
		
		//RenameFiles.readFiles(path);

	}
	
	public static void readFiles(String path) {
		File file = new File(path);
		File[] files = file.listFiles();
		List fl = Arrays.asList(files);
		Collections.sort(fl, new Comparator<File>() {
			public int compare(File o1, File o2) {
				if(o1.isDirectory() && o2.isFile())
					return -1;
				if(o1.isFile() && o2.isDirectory())
					return 1;
				return o1.getName().compareTo(o2.getName());
			}
		});
		//int i = 347;
		for(File f : files) {
			//System.out.println((i++)+": "+f.getName());
			System.out.println(f.getName());
		}
	}

}
