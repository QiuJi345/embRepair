package edu.njupt.radon.exp.temp;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.AxiomType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyChange;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.util.SimpleIRIMapper;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class GenerateGraph {


	
	/*static final String[] ontos = {
		"bt_km-3000", "bt_km-5000", 
		"Galen-500", 
		"Go-500", "Nci-500"
	};*/
	static OWLOntologyManager manager = null;
	static String info = "";
	static String ontoName = "CHEM-A";
	
	public static void main(String[] args) throws Exception {	
		//String dataSet = "onto";
		String ontoRoot = "data/";
		int axNum = 10000; //�������ϵ������
		HashSet<OWLSubClassOfAxiom> subAxioms2 = new HashSet<OWLSubClassOfAxiom>();
				
		OWLOntology o = openOntology("file:"+ontoRoot+ontoName+".owl");	
		System.out.println("original onto size : "+o.getLogicalAxiomCount());
		//printAxioms(o);
		HashSet<OWLSubClassOfAxiom> subAxioms = new HashSet<OWLSubClassOfAxiom>(o.getAxioms(AxiomType.SUBCLASS_OF, true));
		System.out.println("original subsumptions size : "+subAxioms.size());
		
		// ��ȡ���������ĸ��ӹ�ϵ
		int counter = 0;
		for(OWLSubClassOfAxiom a : subAxioms) {
			subAxioms2.add(a);
			counter++;
			if(counter >= axNum) {
				break;
			}
		}
		System.out.println("new onto size: "+subAxioms2.size());
		
		// ��������
		HashMap<String, String> matrix = new HashMap<String, String>();
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(subAxioms2);
		OWLOntology o2 = createOntology(axioms);
				
		// Construct matrix
		HashSet<OWLClass> cls = new HashSet<OWLClass>(o2.getClassesInSignature());
		for(OWLClass cl : cls) {
			String str = getLocalName(cl);
			matrix.put(str, "'"+str+"': 0");
		}
		for(OWLSubClassOfAxiom ax : subAxioms2) {
			OWLClassExpression subOce = ax.getSubClass();
			OWLClassExpression supOce = ax.getSuperClass();			
			if(subOce.isAnonymous() || supOce.isAnonymous()) {
				continue;
			}
			OWLClass subCl = subOce.asOWLClass();
			OWLClass supCl = supOce.asOWLClass();
			String c1 = getLocalName(subCl);
			String c2 = getLocalName(supCl);
			
			String str = matrix.get(c1);
			str = str + ", '"+c2+"': 1";
			matrix.put(c1, str);
		}
		
		// output matrix
		for(String key : matrix.keySet()) {
			System.out.println("'"+key+"': {"+matrix.get(key)+"},");
		}
	}
	
	
	
	public static String getLocalName(OWLEntity ent){
		String name = ent.getIRI().toString();
		String localName = "";
		int ind1 = name.lastIndexOf("#");		
		if(ind1 != -1){
			localName = name.substring(ind1+1);			
		} else {
			ind1 = name.lastIndexOf("/");
			if(ind1 != -1){
				localName = name.substring(ind1+1);
			} else {
				localName = name;
			}
		}		
		return localName;
	}

	public static void printAxioms(OWLOntology o) {
		int counter = 1;
		for(OWLAxiom ax : o.getLogicalAxioms()) {
			System.out.println((counter++)+" > "+ax.toString());
		}
	}
	
	public static void printAxioms(HashSet<OWLSubClassOfAxiom> axioms) {
		int counter = 1;
		for(OWLAxiom ax : axioms) {
			System.out.println((counter++)+" > "+ax.toString());
		}
	}
	
	public static OWLOntology openOntology(String ontoPath){		
		
		String path = checkOntoPath(ontoPath);
		IRI physicalURI = IRI.create(path);	
		OWLOntology ontology = null;
		manager = OWLManager.createOWLOntologyManager();
		
		try{
			ontology = manager.loadOntology(physicalURI);  
		} catch (OWLOntologyCreationException ex){
			ex.printStackTrace();
		}   
       	return ontology;
	}
	
	public static String checkOntoPath(String ontoPath) {
		String path = ontoPath;
		if (!ontoPath.startsWith("http:"))
	        if (!ontoPath.startsWith("https:"))
		        if (!ontoPath.startsWith("ftp:"))
		        	if (!ontoPath.startsWith("file:"))
		        		path =  "file:" + ontoPath;
		return path;
	}
	

	
	public static OWLOntology createOntology(
			HashSet<OWLAxiom> axioms_p) {
		
		String logicalUrl = null;
		String physicalUrl = null;

		if(logicalUrl==null){
			logicalUrl = "http://radon.njupt.edu.cn/"+ontoName+"-tbox";			
		}
		if(physicalUrl==null){
			physicalUrl = "onto2/"+ontoName+"-tbox.owl";
		} else {
			checkOntoPath(physicalUrl);
		}
		
		IRI ontologyURI = IRI.create(logicalUrl);
		IRI physicalURI = IRI.create(physicalUrl);
        SimpleIRIMapper mapper = new SimpleIRIMapper(ontologyURI, physicalURI);
        OWLOntology o = null;
        try{
        	manager = OWLManager.createOWLOntologyManager();
			manager.addIRIMapper(mapper);
	        o = manager.createOntology(ontologyURI);
	        addAxioms(o, manager, axioms_p);
        	File f  = new File(physicalUrl);
    		manager.saveOntology(o, IRI.create(f.toURI()));
        } catch(Exception ex){
        	ex.printStackTrace();
        }		     
       
		return o;	
	}
	
	public static void addAxioms(
			OWLOntology o,
			OWLOntologyManager conn, 
			HashSet<OWLAxiom> axioms) {
		
		List<OWLOntologyChange> list = new ArrayList<OWLOntologyChange>();
		for (OWLAxiom axiom : axioms) {
			if(axiom==null){
				continue;
			}
			AddAxiom addAxiom = new AddAxiom(o, axiom);
			list.add(addAxiom);
		}
		if(list.size()>0){
			conn.applyChanges(list);  
		}		
	}


}
