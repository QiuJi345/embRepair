package edu.njupt.radon.exp.temp;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;  

/** 
 * Created by gantianxing on 2017/5/26. 
 */  
public class User {  
         
    public static void main(String[] args) throws Exception{  
    	String ontoName = "buggyPolicy";
		String path = "data/kbs2014/" + ontoName;
		String resPath = "results/mups/"+ontoName+"/";
		String dumpFilePath = resPath+"mups.dump";
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> ucMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		FileTools.fileExists(resPath);
		System.setOut((new PrintStreamObject(resPath+"res.txt")).ps);
		

		OWLOntology sourceOnto = OWLTools.openOntology(path + ".owl");
		HashSet<OWLClass> allUnsat = ReasoningTools.getUnsatiConcepts(sourceOnto, OWLTools.manager);
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(sourceOnto.getAxioms());
		RadonDebug debug = new BlackboxDebug(axioms);
		System.out.println("Number of Ucs: " + allUnsat.size());
		
		// Compute MUPS for all unsatisfiable concepts
		/*int i = 1;
		
		for (OWLClass cl : allUnsat) {
			System.out.println("Uc " + (i++) + " : " + cl.toString());
			HashSet<HashSet<OWLAxiom>> mups = debug.getMUPS(cl);
			ucMUPS.put(cl, mups);
			if (i > 100) {
				break;
			}
		}
		*/
		
		/*int i = 1;
		
		for (OWLClass cl : allUnsat) {
			System.out.println("Uc " + (i++) + " : " + cl.toString());
			HashSet<HashSet<OWLAxiom>> mups = debug.getMUPS(cl);
			HashSet<HashSet<OWLAxiom>> allMUPS = new HashSet<HashSet<OWLAxiom>>();
			for(HashSet<OWLAxiom> oneMUPS : mups) {
        		HashSet<OWLAxiom> set = new HashSet<OWLAxiom>();
        		for(OWLAxiom ax : oneMUPS) {
        			set.add(ax);
        		}
        		//set.addAll(oneMUPS);	
        		allMUPS.add(new HashSet<OWLAxiom>(set));
        	}
			OWLClass c = cl;
			ucMUPS.put(c, allMUPS);
			if (i > 100) {
				break;
			}
		}
        */
        //ʵ����һ��user����  
        HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> MUPS = debug.getMUPS();
        for(OWLClass oc : MUPS.keySet()) {
        	HashSet<HashSet<OWLAxiom>> m = new HashSet<HashSet<OWLAxiom>>();
        	for(HashSet<OWLAxiom> s : MUPS.get(oc)) {
        		HashSet<OWLAxiom> t = new HashSet<OWLAxiom>(s);
        		HashSet<OWLAxiom> ss = new HashSet<OWLAxiom>();
        		ss.addAll(t);
        		m.add(ss);
        	}
        	ucMUPS.put(oc, m);
        }
        
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(dumpFilePath));  
        //���������л��洢��D:/user.txt �ļ���  
        out.writeObject(ucMUPS);  
   
        /*ObjectInputStream in = new ObjectInputStream(new FileInputStream("D://user.txt"));  
        //�����л�  
        Object newUser = in.readObject();  
        System.out.println(newUser);  */
    }  
}  
   