package edu.njupt.radon.exp.temp;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.heuristic.HeuristicDebug;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.OWLTools_New;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class InjectIncoherentOntoComplex {
	
	static ArrayList<OWLClass> concepts= new ArrayList<OWLClass>();
	static HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();	
	static HashSet<OWLAxiom> externalAxioms = new HashSet<OWLAxiom>();	
	static HashMap<OWLClass, Set<OWLClass>> subAxioms =new HashMap<OWLClass, Set<OWLClass>>();
	static HashMap<OWLClass, Set<OWLClass>> disAxioms= new HashMap<OWLClass, Set<OWLClass>>();
	
	public static void main(String[] args) throws Exception  {
		String ontoName = "OBO12";
		String ontPath = "data/IncoherentOnto/"+ontoName+".owl";
//		String ontoName = "InjectTest3";
//		String ontPath = "data/ontologies/"+ontoName+".owl";
		//String ucURI = "";
		//String resultPath = "results/pattern2018/"+ontoName;
		//System.setOut((new PrintStreamObject(resultPath)).ps);
			
		OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
		OWLOntology onto=manager.loadOntologyFromOntologyDocument(new File(ontPath));
		
		//获取本体的概念与公理
		//Set<OWLClass> concepts=onto.getClassesInSignature();
		concepts= OWLTools_New.getAllConcepts(onto);
		System.out.println("The number of concetps is "+concepts.size());
		
		//获取本体公理
		axioms = OWLTools_New.getTBox(onto);	
		System.out.println("The number of axioms is "+axioms.size());
		
		//获取包含公理
		subAxioms=OWLTools_New.getSubClass(onto);
		System.out.println("The number of subClassOf axioms is "+subAxioms.size());
		
		//获取不相交公理
		disAxioms=OWLTools_New.getDisjointConcepts(onto);
		System.out.println("The number of disjointWith axioms is "+disAxioms.size());
		
		
		//定义debug的类
		Long tic1=System.currentTimeMillis();
		RadonDebug debug = new HeuristicDebug(axioms);
		
		//HashSet<OWLClass> unsatConcepts=ReasoningTools.getUnsatiConcepts(onto, manager);
		//获取本体不可满足的概念数目
		HashSet<OWLClass> unsatConcepts= ReasoningTools.getUnsatiConcepts(axioms);
		System.out.println("The number of unsatisfie concepts is "+unsatConcepts.size());
		//boolean coherent = ReasoningTools.isCoherent(axioms);	
		if(unsatConcepts.size()==0)
			System.out.println("This ontology is coherent");
		else
			System.out.println("This ontology is incoherent");	
		//获取MUPS的数量
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
		
		System.out.println("+++++++++++++++++");
			
		//获取本体的mips
		//HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(mups);
		//System.out.println("\nFound MIPS: ");
		//printAxiomSets(mips);
		
//		//本体规模、本体MIPS的个数，不可满足概念的个数
		int ontoScale=axioms.size(); 
//		int mipsNum=mips.size();
//		int unconceptNum=unsatConcepts.size();
		
		Long toc1=System.currentTimeMillis();		
		System.out.println("The consumption of debugging time is "+(toc1-tic1)+" ms");
		
		InjectIncoherentOntoComplex inCoOn= new InjectIncoherentOntoComplex();
		
		//拟定本体规模的注入上界，进行注入公理，这里不可满足概念与MIPS的数量不变
		int scaleBounder=37000;
		
		//type 的可选类型有"random"、"subClassOf"、"disjointWith"、"equivalence"
		String type = "random";

   
	   Long tic2=System.currentTimeMillis();
	   //int injectNum=scaleBounder-ontoScale;
	   int injectNum=500;
	   if(injectNum<=0)
		   System.out.println("The number of injected Axioms is enough.");
	   else {
		    //注入方式为(保持MIPS与UC不变，增加本体规模)：不相干的概念以及儿子，注入subClassOf、disjointWith、equivalence三种类似
		    // inCoOn.complexScaleInjector(mups,scaleBounder-ontoScale,type); 
		    //注入方式为：不相干的概念以及儿子，注入subClassOf、disjointWith、equivalence三种类似
		   // inCoOn.complexScaleInjector(mups,injectNum,type); 
		   		   
		   //下面的注入方式（保持本体规模与MIPS不变，增加UC）没有disjointWith
	   	   inCoOn.complexUnConInjector(mups,unsatConcepts,injectNum,type); 
		   //下面的注入方式（保持本体规模与MIPS不变，增加UC）没有disjointWith//
	   	   //inCoOn.complexUnConInjector(mups,unsatConcepts,scaleBounder-ontoScale,type); 
	   }
	
//	   for(OWLAxiom ax:externalAxioms)
//		   System.out.println(ax.toString());
	   axioms.addAll(externalAxioms);
	  
	   
	   Calendar c = Calendar.getInstance();//可以对每个时间域单独修改   对时间进行加减操作等
//	   int year = c.get(Calendar.YEAR);  
//	   int month = c.get(Calendar.MONTH);   
//	   int date = c.get(Calendar.DATE);    
	   int hour = c.get(Calendar.HOUR_OF_DAY);   
	   int minute = c.get(Calendar.MINUTE);   
	   int second = c.get(Calendar.SECOND);    
	   String formalime=hour + ":" +minute + ":" + second;  
	   
		//生成本体，进行路径保存
		//String newOntPath = "data/IncohOntologies/"+ontoName+"ctest31.owl";
		//String newOntPath = "data/IncohOntologies/"+ontoName+"+"+time+".owl";
		String newOntPath = "data/InjectOntologies/"+ontoName+"-M1-"+injectNum+".owl";
		OWLTools.saveOntology(axioms,newOntPath);	
		Long toc2=System.currentTimeMillis();
		
		System.out.println("The consumption of injecting time is "+(toc2-tic2)+" ms");
			
	}
	
	public static void computeMUPS(RadonDebug debug, HashSet<OWLAxiom> tbox){
		System.out.println("****************************************");
		debug.getMUPS();
		for(OWLClass uc : ReasoningTools.getUnsatiConcepts(tbox)) {
			if(!uc.toString().contains("Retry-Until-SucceedUsernamePolicy")) {
				continue;
			}
			debug.getMUPS(uc);
			//break;
		}		
	}
	
	
	public static void computeMUPS(OWLOntology onto, RadonDebug debug, String ucURI){
		if(ucURI != null && ucURI.length()>0){
			OWLEntity uc = null;
			if(ucURI.indexOf("http:")!=-1){
				uc = OWLTools.getEntity(onto, ucURI);
			} else {
				uc = OWLTools.getEntityWithLocalName(onto, ucURI);
			}
		    debug.getMUPS(uc.asOWLClass());		
		} 
	}
	
	
	public static void printAxiomSets(HashSet<HashSet<OWLAxiom>> axiomSets) {
		int mupsNum = 0;
		for(Set<OWLAxiom> axiomSet : axiomSets) {
			System.out.println("Set <"+(++mupsNum)+">");
			int axiomNum = 0;
			for(OWLAxiom ax : axiomSet) {
				System.out.println("["+(++axiomNum)+"] "+ax.toString());
			}
			System.out.println();
		}
		System.out.println();
	}
	
	
	public Set<OWLClass> getConcepts4MUPSs(HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> MUPSs)
	{	
		Set<OWLClass> potentialConcepts=new HashSet<OWLClass>();
		HashSet<OWLAxiom> potentialMUPSAxioms =new HashSet<OWLAxiom>();
		potentialMUPSAxioms=getAxioms4MUPSs(MUPSs);
		for(OWLAxiom a: potentialMUPSAxioms)  //通过公理获取所有的概念
		{		
			potentialConcepts.addAll(a.getClassesInSignature());	  
		}	
		potentialConcepts.addAll(MUPSs.keySet());
		return potentialConcepts;
	}
	
//	public Set<OWLClass> getUnConcepts4MUPSs(HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> MUPSs)
//	{	
//		Set<OWLClass> potentialConcepts=new HashSet<OWLClass>();
//		HashSet<OWLAxiom> potentialMUPSAxioms =new HashSet<OWLAxiom>();
//		potentialMUPSAxioms=getAxioms4MUPSs(MUPSs);
//		for(OWLAxiom a: potentialMUPSAxioms)  //通过公理获取所有的概念
//		{		
//			potentialConcepts.addAll(a.getClassesInSignature());	  
//		}	
//		potentialConcepts.addAll(MUPSs.keySet());
//		return potentialConcepts;
//	}
	
	public static HashSet<OWLAxiom> getAxioms4MUPSs(HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> MUPSs)
	{	
		HashSet<OWLAxiom> potentialMUPSAxioms =new HashSet<OWLAxiom>();
		for(OWLClass a: MUPSs.keySet())
		{
			for(HashSet<OWLAxiom> mups:MUPSs.get(a))
			{
//				for(OWLAxiom ax: mups)
//				{
//					Set<OWLClass> set= ax.getClassesInSignature();
//					for (OWLClass c: set)
//					{
//						System.out.print(OWLTools_New.getLocalName(c.toString())+"  ");
//					}
//					System.out.println();
//				}
				potentialMUPSAxioms.addAll(mups);
			}
		}	
		return potentialMUPSAxioms;
	}
	
	public void complexScaleInjector(HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups, int injectNum, String type)
	{
		Set<OWLClass> potentialConcepts=new HashSet<OWLClass>();
		//potentialConcepts=getConcepts4MUPSs(mups);
		potentialConcepts=mups.keySet();
		Set<OWLClass> leftClass=new HashSet<OWLClass>();
		leftClass.addAll(concepts);
		leftClass.removeAll(potentialConcepts);		
		boolean flag=false;
		for(OWLClass a:leftClass)
		{
			if(!subAxioms.containsKey(a))
				continue;
			Set<OWLClass> sub= new HashSet<OWLClass>();
			sub= subAxioms.get(a); //如果规模不够，其实还可以加入概念本身
			sub.removeAll(mups.keySet()); //因为儿子里面可能存在不可满足概念
			if (sub.size()==0)
				continue;
			else
			{
				//injectNum=generateAxioms(sub,injectNum);	
				if(!type.equals("random"))//指定类型的公理，包含subClassOf、disjointWith、equivalent
					injectNum=generateSpecialAxioms(sub,injectNum,type);
				//选择n种类型，默认为subClassOf、disjointWith两种类型
				else
					injectNum=generateRandomAxioms(sub,injectNum);
			}
			if(injectNum==0)
			{
				flag=true;
				break;
			}		
		}
		if(flag)
			System.out.println("The number of injected Axioms by ComplexInjector is completed.");
		else
			System.out.println("The injected Axioms by ComplexInjector is completed, but it is not enough.");

	}
	
	public void complexUnConInjector(HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups,HashSet<OWLClass> unConcepts, int injectNum,String type)
	{
		
		Set<OWLClass> potentialConcepts=new HashSet<OWLClass>();
		// 获取MUPS中所有出现的实体
		potentialConcepts=getConcepts4MUPSs(mups);
		Set<OWLClass> leftClass=new HashSet<OWLClass>();
		leftClass.addAll(concepts);
		leftClass.removeAll(unConcepts);	
		leftClass.removeAll(potentialConcepts);	
		boolean flag=false;
		for(OWLClass a:leftClass)
		{
			//System.out.println(a.toString());
			Set<OWLClass> sub= new HashSet<OWLClass>();
			if(!subAxioms.containsKey(a))
				sub.add(a);
			else
				sub= subAxioms.get(a);				
			sub.removeAll(unConcepts); //因为儿子里面可能存在不可满足概念, 可能父亲的操作效率更高
			if (sub.size()==0)
				continue;
			else
			{		
				//injectNum=generateRandomAxioms(sub,injectNum);
				if(!type.equals("random"))//指定类型的公理，包含subClassOf、equivalent
					injectNum=generateSpecialAxioms4UnConcepts(unConcepts,sub,injectNum,type);
				//选择n种类型，默认为subClassOf、disjointWith两种类型
				else
				   injectNum=generateRandomAxioms4UnConcepts(unConcepts,sub,injectNum);				
			}
			if(injectNum==0)
			{
				flag=true;
				break;
			}		
		}
		if(flag)
			System.out.println("The number of injected Axioms by ComplexInjector is completed.");
		else
			System.out.println("The injected Axioms by ComplexInjector is completed, but it is not enough.");

	}
	

	
	public int generateAxioms(Set<OWLClass> concepts,int injectNum)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		for(int i = 0; i<orderedSubs.size(); i++) 
		{
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), orderedSubs.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		}
		return injectNum;				
	}
	
	public int generateRandomAxioms(Set<OWLClass> concepts,int injectNum)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		for(int i = 0; i<orderedSubs.size(); i++) 
		{
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				Random r = new Random();
			    int ran1 = r.nextInt(2);
			    OWLAxiom a=null;
			    if(ran1==1)	    
			    	 a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), orderedSubs.get(j));
			    else
			    	 a = OWL.factory.getOWLDisjointClassesAxiom(orderedSubs.get(i), orderedSubs.get(j));
			    //datatypeProperty还是objectProperty上做存在量词的约束，选用不同的函数进行复合概念的构造
			    //OWL.factory.getOWLDatahasValue(orderedSubs.get(i), orderedSubs.get(i));
			    //OWL.factory.getOWLObjecthasValue(orderedSubs.get(i), orderedSubs.get(j));
			    
//			    a = OWL.factory.getowlsubc.getOWLDisjointClassesAxiom(orderedSubs.get(i), orderedSubs.get(j));
//			    OWL.factory.getowlobj.getOWLObjecthasValue(orderedSubs.get(i), orderedSubs.get(j));
//			    
//			    a = OWL.factory.getowlob
			  
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		}
		return injectNum;				
	}
	
	public int generateSpecialAxioms(Set<OWLClass> concepts,int injectNum,String type)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		if(type.equals("subClassOf"))
		{
		 for(int i = 0; i<orderedSubs.size(); i++) 
		 {
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), orderedSubs.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		 }
		}
		if(type.equals("disjointWith"))
		{
		 for(int i = 0; i<orderedSubs.size(); i++) 
		 {
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLDisjointClassesAxiom(orderedSubs.get(i), orderedSubs.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		 }
		}
		if(type.equals("equivalence"))
		{
		 for(int i = 0; i<orderedSubs.size(); i++) 
		 {
			for(int j = i+1; j < orderedSubs.size(); j++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLEquivalentClassesAxiom(orderedSubs.get(i), orderedSubs.get(j));
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理
					injectNum--;
				if(injectNum==0)
				{
					return 0;
				}
			}
		 }
		}
		return injectNum;				
	}
	
	public int generateAxioms4UnConcepts(HashSet<OWLClass> unconcepts,Set<OWLClass> concepts,int injectNum)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		for (OWLClass unCon:unconcepts)
		{
			for(int i = 0; i<orderedSubs.size(); i++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), unCon);
				//OWL.factory.getOWLEquivalentClassesAxiom(orderedSubs.get(i), unCon);
				//OWL.factory.getOWLDisjointClassesAxiom(orderedSubs.get(i), unCon);
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理		
					injectNum--;	
				if(injectNum==0)
				{
					return 0;
				}
			
			}
		}
		return injectNum;				
	}
	
	public int generateSpecialAxioms4UnConcepts(HashSet<OWLClass> unconcepts,Set<OWLClass> concepts,int injectNum, String type)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		if(type.equals("subClassOf"))
		{
		  for (OWLClass unCon:unconcepts)
		  {
			for(int i = 0; i<orderedSubs.size(); i++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), unCon);
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理		
					injectNum--;	
				if(injectNum==0)
				{
					return 0;
				}
			
			}
		  }
		}
		if(type.equals("equivalence"))
		{
		  for (OWLClass unCon:unconcepts)
		  {
			for(int i = 0; i<orderedSubs.size(); i++) 
			{
				int num=externalAxioms.size();
				OWLAxiom a=OWL.factory.getOWLEquivalentClassesAxiom(orderedSubs.get(i), unCon);
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理		
					injectNum--;	
				if(injectNum==0)
				{
					return 0;
				}
			
			}
		  }
		}
		
		return injectNum;				
	}
	
	public int generateRandomAxioms4UnConcepts(HashSet<OWLClass> unconcepts,Set<OWLClass> concepts,int injectNum)
	{	
		ArrayList<OWLClass> orderedSubs = new ArrayList<OWLClass>();
		for (OWLClass a:concepts)
		{
			orderedSubs.add(a);
		}
		for (OWLClass unCon:unconcepts)
		{
			for(int i = 0; i<orderedSubs.size(); i++) 
			{
				int num=externalAxioms.size();
				Random r = new Random();
			    int ran1 = r.nextInt(2);
			    OWLAxiom a=null;
			    if(ran1==1)	    
			    	 a = OWL.factory.getOWLSubClassOfAxiom(orderedSubs.get(i), unCon);
			    else
			    	 a = OWL.factory.getOWLEquivalentClassesAxiom(orderedSubs.get(i), unCon);
				externalAxioms.add(a);
				if(externalAxioms.size()!=num) //表示增加了新的公理		
					injectNum--;	
				if(injectNum==0)
				{
					return 0;
				}
			
			}
		}
		return injectNum;				
	}
	
	
	//生成新的公理, 考虑是否需要加上一些约束，或者传递一些新的信息。
//	public int generateAxioms(Set<OWLClass> concepts)
//	{
//		HashSet<OWLAxiom> newAxioms=new HashSet<OWLAxiom>();
//		newAxioms.addAll(newAxioms);
//		Random r = new Random();
////		int lowerbound=2;// 随机数的上限
////		for(int i=0 ; i<num ;  i++)
////		{
////		   int ran1 = r.nextInt(100);
////		   System.out.println(ran1);
////		   
////		}
//	
//		//生成的方式	
//		OWLAxiom a = OWL.factory.getOWLDisjointClassesAxiom(orderedSups.get(i), orderedSups.get(j));
//		
//		
//					
//	}
	
	public static int getNumberOfAxioms(HashMap<OWLClass, Set<OWLClass>> axioms)
	{
		int num=0;
		for(OWLClass c:axioms.keySet())
		{
			num=num+axioms.get(c).size();
		}
		return num;
	}

}
