package edu.njupt.radon.exp.temp;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

/**
 * 得到 计算单个UC的所有mups的平均时间
 * mups总数
 * @author zsq
 */
public class JustsReaderForUCMUPSTime {

	HashSet<HashSet<String>> justs = new HashSet<HashSet<String>>();

	// 未找到，则超时
	long time = 1000000;
	int ucNum = 0;
	long sumTime = 0;
	int mupsNumForSwoop = 0;

	public JustsReaderForUCMUPSTime(String resultPath) {
		 doComputeMUPS(resultPath);
	}
	
	public JustsReaderForUCMUPSTime(String resultPath, int a) {
		// swoop 和 张瑜
		doComputeMUPS2(resultPath);
	}

	/**
	 * 
	 * @param logPath
	 */
	private void doComputeMUPS2(String logPath) {
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			// Read File Line By Line
			while ((oneLine = bufferedReader.readLine()) != null) {
				String timeStr = getTime(oneLine);
				if (timeStr.length() > 0) {
					time = Long.valueOf(timeStr);
//					if (time > DebuggingParameters.timeout) {
//						time = DebuggingParameters.timeout;
//					}
					continue;
				}
				if (oneLine.indexOf("[") != -1) {
					mupsNumForSwoop = appearTime(oneLine, "[") - 1;
					continue;
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	/**
	 * @param s1
	 * @param s2
	 * @return s2在字符串s1中出现的次数
	 */
	private int appearTime(String s1, String s2) {
		// 记录出现次数
		int time = 0;
		// 遍历s1
		for (int i = 0; i < s1.length(); i++) {
			// 调用方法indexOf,计算s2在s1字符串中出现的下标
			int s2index = s1.indexOf(s2, i);
			// 当用if判断，当遍历开始下标i与s2在s1中出现的下标位置相等时,time+1
			if (i == s2index) {
				time++;
			}
		}
		return time;
	}

	/**
	 * 读取mups
	 * @param logPath
	 */
	private void doComputeMUPS(String logPath) {
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneMUPSBegin = false;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			String oneLine;
			// Read File Line By Line
			while ((oneLine = bufferedReader.readLine()) != null) {
				String timeStr = getTime(oneLine);
				if (timeStr.length() > 0) {
					time = Long.valueOf(timeStr);
//					if (time > DebuggingParameters.timeout) {
//						time = DebuggingParameters.timeout;
//					}
					continue;
				} else if (oneLine.indexOf("  Found explanation <") != -1
						|| oneLine.startsWith("  Found explanation <")) {
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				}
				if (isOneMUPSBegin) {
					// In this case, the output of one MUPS has been finished.
					if (oneLine.trim().length() == 0 && oneMUPSString.size() > 0) {
						// Add the found MUPS to the collection of MUPS
						justs.add(new HashSet<String>(oneMUPSString));
						// Set the start
						isOneMUPSBegin = false;
					} else {
						int index1 = oneLine.indexOf("]");
						if (index1 != -1) {
							// Get the string after ]
							String axiomString = oneLine.substring(index1 + 1).trim();
							// Remove the first blank space if exists
							if (axiomString.indexOf(" ") == 0) {
								axiomString = axiomString.substring(1);
							}
							// Add the axiom string to the the collection of axiom strings.
							oneMUPSString.add(axiomString);
						}
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	/**
	 * 获得对应的时间
	 * @param line
	 * @return
	 */
	private String getTime(String line) {
		String timeStr = "";
		// 预设时间输出格式
		String prefix = "Time : ";
		if (line.startsWith(prefix)) {
			timeStr = line.substring(prefix.length());
		} else {
			prefix = "The time (ms) to compute all MUPS for a concept is: ";
			if (line.startsWith(prefix)) {
				int symbolIndex = line.indexOf(":");
				timeStr = line.substring(symbolIndex + 1).trim();
			}
		}
		int symbolIndex = timeStr.indexOf(" ");
		if (symbolIndex != -1) {
			timeStr = timeStr.substring(0, symbolIndex).trim();
		}
		if (timeStr.contains("ms")) {
			System.out.println("stop");
		}
		return timeStr;
	}

	public long getTime() {
		return time;
	}

	public int getMupsNumForSwoop() {
		return mupsNumForSwoop;
	}

	public HashSet<HashSet<String>> getJusts() {
		return justs;
	}
}
