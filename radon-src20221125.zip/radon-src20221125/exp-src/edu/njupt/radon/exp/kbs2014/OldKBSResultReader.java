package edu.njupt.radon.exp.kbs2014;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import edu.njupt.radon.parameters.DebuggingParameters;

public class OldKBSResultReader {
	
	private static String timeOut = "1000000";
	private static String pelletGlassboxMethod = "glassbox";
	private static String pelletBlackboxMethod = "blackbox";
	private static String radonDefaultMethod = "default";
	private static String patternBasedMethod = "pattern";
	private static String relevanceAllMethod = "RaDON-Rel-All";
	private static String relevanceCMMethod = "relevance-cm";
	
	static int less10Num = 0;
	static int less20Num = 0;
	static int less30Num = 0;
	static int less40Num = 0;
	static int less50Num = 0;
	static int otherNum = 0;
	
	static int ontoCounter = 20;
	
	static String debugMethod = null;
		
	public static void main(String[] args) throws Exception {		
		String debugTask = "consistent";
		String resultPath = DebuggingParameters.ontoRoot+"results/"+DebuggingParameters.debugTask+"/";
		//String resultPath = "D:/program-workspace/datamining/pellet-src/results/just/"+dataSet+"/";
		resultPath = "D:/Dropbox/Experiments/2013-Journal-Evaluation/results/" + debugTask + "/abox/";
		//String resultPath = "results/debug/mups/"+dataSet+"/";
		PrintWriter output =  new PrintWriter(new BufferedWriter(
				new FileWriter(resultPath+debugTask+"-time.xls")),true);    	
    	
		if(resultPath.contains("/consistent/")){
			outputJustHeader(output);
		} else if(resultPath.contains("/inconsistent/")){
			outputMISHeader(output);
		} else if(resultPath.contains("/incoherent/")){
			outputMUPSHeader(output);
		}
		
		processFile(output, resultPath);
		
		output.flush();
        output.close();
	}
	
	
	public static void processFile(PrintWriter output, String resultPath) {
		
		File f = new File(resultPath);
		for(File ontoF : f.listFiles()){
			if(!ontoF.isDirectory()){
				continue;
			}			
			ontoCounter++;
			String ontoName = ontoF.getName();
			for(File methodF : ontoF.listFiles()){
				if(!methodF.isDirectory()){
					continue;
				}
				debugMethod = methodF.getName();
				if(resultPath.contains("/inconsistent/")){
					output.print(ontoName);
				    output.print("\t");				    
					output.print(debugMethod);
					output.print('\t');
					
					String logPath = methodF.getPath().replace("\\", "/")+"/log.txt";						
					getExplanationInfo(output, logPath);
					//System.out.println(less10Num+" \t "+less20Num+"\t "+less30Num + "\t "+
						//	less40Num+"\t"+less50Num+"\t"+otherNum+"\t"+ontoName+"\t "+debugMethod+"\t"+DebuggingParameters.debugTask);
				} else {
					for(File ucF : methodF.listFiles()){
						if(!ucF.isDirectory()){
							continue;
						}				
						String method = getDebugMethod(debugMethod);
						if(method.length() == 0){
							continue;
						}
						
						if(ucF.getName().equals("cocus#Event_Tracks") && 
								ontoName.endsWith("AROMA-cmt-cocus")&&
								method.equals("RaDON-Default")){
							System.out.println("stop");
						}
						
						output.print(ontoCounter);
					    output.print("\t");
					    output.print(ontoName);
					    output.print("\t");
						output.print(method);
						output.print('\t');
						output.print(ucF.getName());		
						output.print("\t");
						
						String logPath = ucF.getPath().replace("\\", "/")+"/log.txt";						
						getExplanationInfo(output, logPath);	
						
						//System.out.println(less10Num+" \t "+less20Num+"\t "+less30Num + "\t "+
							//	less40Num+"\t"+less50Num+"\t"+otherNum+"\t"+ontoName+"\t "+debugMethod+"\t"+DebuggingParameters.debugTask);
					}
				}				
			}

		}
	}

			
	public static void getExplanationInfo(
			PrintWriter  output, String logPath) {
		boolean isOneMUPSBegin = false;
		int oneMUPSSize = 0;
		int totalMUPSSize = 0;
		int mupsNumber = 0;
		int minSize = 1000;
		int maxSize = 0;
		
		less10Num = 0;
		less20Num = 0;
		less30Num = 0;
		less40Num = 0;
		less50Num = 0;
		otherNum = 0;
		
		String time = timeOut;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line			
			while ((strLine = br.readLine()) != null) {	
				// In such case, all information about MUPS need to be recomputed.
				if(strLine.contains("Correctness Checking")){
					minSize = 1000;
					maxSize = 0;
					totalMUPSSize = 0;
					mupsNumber = 0;
					continue;
				}

				int radonStartIndex1 = strLine.indexOf("Found a new MUPS");
				int radonStartIndex2 = strLine.indexOf("MIS <");
				int pelletStartIndex = strLine.indexOf("Explanation");
				if(radonStartIndex1 != -1 || radonStartIndex2 != -1 || pelletStartIndex != -1){
					isOneMUPSBegin = true;
					oneMUPSSize = 0;
					time  = timeOut;
					continue;
				} 
				
				if(isOneMUPSBegin){
					if(strLine.trim().length() == 0 && oneMUPSSize != -1){
						if(debugMethod.equals(DebuggingParameters.radonRelAllDebug)){
							oneMUPSSize --;
						}
						if(oneMUPSSize > maxSize){
							maxSize = oneMUPSSize;
						}
						if(oneMUPSSize < minSize){
							minSize = oneMUPSSize;
						}
						if(oneMUPSSize < 10){
							less10Num ++;
						} else if(oneMUPSSize < 20){
							less20Num ++;
						} else if(oneMUPSSize < 30){
							less30Num ++;
						} else if(oneMUPSSize < 40){
							less40Num ++;
						} else if(oneMUPSSize < 50){
							less50Num ++;
						} else {
							otherNum ++;
						}
						totalMUPSSize += oneMUPSSize;
						mupsNumber ++;
						isOneMUPSBegin = false;
					} else {
						int index1 = strLine.indexOf("[");
						if(index1 != -1){
							oneMUPSSize ++;							
						} 
					}
				} else if(strLine.contains(" Time (ms)")){
					int j = strLine.indexOf(": ");
					if(j != -1){
						time = strLine.substring(j+2).trim();
						Integer timeReal = Integer.valueOf(time);
						if(timeReal > 1000000){
							time = timeOut;
						}
					}
					// If the information about time has been obtained, then the loop to read results can be terminated.
					break;
				}
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} finally {
			output.print(mupsNumber);
			output.print('\t');
			output.print(totalMUPSSize);
			output.print('\t');
			output.print(minSize);
			output.print('\t');
			output.print(maxSize);
			output.print('\t');
			output.print(time);
			output.println();
		}
	}
	
	private static String getDebugMethod(String methodString){
		String methodNameInFigure = "";
		if(methodString.equals(pelletGlassboxMethod)){
			methodNameInFigure = "Pellet-Glassbox";
		} else if(methodString.equals(pelletBlackboxMethod)){
			methodNameInFigure = "Pellet-Blackbox";
		} else if(methodString.equals(radonDefaultMethod)){
			methodNameInFigure = "RaDON-Default";
		} else if(methodString.equals(relevanceAllMethod)){
			methodNameInFigure = "RaDON-Relevance-All";
		} else if(methodString.equals(patternBasedMethod)){
			methodNameInFigure = "RaDON-Pattern";			
		} else if(methodString.equals(relevanceCMMethod)){
			methodNameInFigure = "RaDON-Relevance-CM";
		}
		return methodNameInFigure;
	}
	
	public static void outputMUPSHeader(PrintWriter  output){	
		output.print("Ontology ID");
	    output.print("\t");
		output.print("Ontology Name");
	    output.print("\t");
	    output.print("Tool");
		output.print('\t');
		output.print("UnsatConcept");		
		output.print("\t");
		output.print("# of MUPS");
		output.print('\t');
		output.print("Total size of MUPS");
		output.print('\t');
		output.print("Min size of a MUPS");
		output.print('\t');
		output.print("Max size of a MUPS");
		output.print('\t');
		output.print("Time (ms)");
		output.println();
	}
	
	public static void outputMISHeader(PrintWriter  output){		
		output.print("Ontology ID");
	    output.print("\t");
		output.print("Ontology Name");
	    output.print("\t");
	    output.print("Tool");
		output.print('\t');
		output.print("# of MIS");
		output.print('\t');
		output.print("Total size of MIS");
		output.print('\t');
		output.print("Min size of a MIS");
		output.print('\t');
		output.print("Max size of a MIS");
		output.print('\t');
		output.print("Time (ms)");
		output.println();
	}
	
	public static void outputJustHeader(PrintWriter  output){	
		output.print("Ontology ID");
	    output.print("\t");
		output.print("Ontology Name");
	    output.print("\t");
	    output.print("Tool");
		output.print('\t');
		output.print("Entailment");		
		output.print("\t");
		output.print("# of Justs");
		output.print('\t');
		output.print("Total size of all Justs");
		output.print('\t');
		output.print("Min size of a Justs");
		output.print('\t');
		output.print("Max size of a Justs");
		output.print('\t');
		output.print("Time (ms)");
		output.println();
	}

}
