package edu.njupt.radon.exp.kbs2014;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Vector;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class OldKBSResultCopy {

	static String newResultPath = "g:/Experiments/2014-KBS/results/pellet/";
	static String debugTask = "inconsistent"; //consistent-tbox
	
	public static void main(String[] args) {
		String oldResultPath = "D:/Dropbox/Experiments/2013-Journal-Evaluation/results/";
		if(debugTask.contains("-abox")){
			oldResultPath += "consistent/abox/";
		} else if(debugTask.contains("-tbox")){
			oldResultPath += "consistent/tbox/";
		} else {
			oldResultPath += debugTask+"/";
		}
		processFile(oldResultPath);
	}
	
	public static void processFile(String resultPath) {
		
		File f = new File(resultPath);
		for(File ontoF : f.listFiles()){
			if(!ontoF.isDirectory()){
				continue;
			}			
			String ontoName = ontoF.getName();
			if(!debugTask.startsWith("inco")){
				ontoName = ontoName.substring(ontoName.indexOf("-")+1);
			}
			
			for(File methodF : ontoF.listFiles()){
				if(!methodF.isDirectory()){
					continue;
				}
				String oldDebugMethod = methodF.getName();
				if(!oldDebugMethod.equalsIgnoreCase("glassbox") 
						&& !oldDebugMethod.equalsIgnoreCase("pattern")
						&& !oldDebugMethod.equalsIgnoreCase("relevance-cm")){
					continue;
				}
				String newDebugMethod = getDebugMethod(oldDebugMethod);
				
				if(resultPath.contains("/inconsistent/")){		
					
					String newLogPath = newResultPath + debugTask + "/" + ontoName 
							+ "/" + newDebugMethod + "/top+bot/";
					
					Vector<String> lines = getLogFile(methodF);	
					FileTools.fileExists(newLogPath);
					System.setOut((new PrintStreamObject(newLogPath+ "log.txt")).ps);
					
					output(lines);
					
					continue;
				} 
				
				
				for(File ucF : methodF.listFiles()){
					if(!ucF.isDirectory()){
						continue;
					}	
								
					String existRePath = newResultPath + debugTask + "/" + ontoName 
							+ "/PelletBl/" ;
					String entStr = getEntailment(existRePath, ucF.getName());				
					// Obtain the path to which a log file could be copied
					String newLogPath = newResultPath + debugTask + "/" + ontoName 
							+ "/" + newDebugMethod + "/" +entStr;
					
					
					Vector<String> lines = getLogFile(ucF);	
					FileTools.fileExists(newLogPath);
					System.setOut((new PrintStreamObject(newLogPath + "/log.txt")).ps);					
					output(lines);					
				}
			}

		}
	}
	
	private static String getEntailment(String existRePath, String oldEnt){
		File file = new File(existRePath);
		if(file.exists()){
			for(File subFile : file.listFiles()){
				String name = subFile.getName();
				int index = name.indexOf("++");
				if(index != -1){
					String[] tokens = name.split("\\++");
					String token1 = getLocalName(tokens[0]);
					String token2 = getLocalName(tokens[1]);
					name = token1 + "-" + token2;
					
				} else if(name.indexOf("+") != -1){
					String[] tokens = name.split("\\+");
					String token1 = getLocalName(tokens[0]);
					String token2 = getLocalName(tokens[1]);
					name = token1 + "+" + token2;
				}
				
				if(name.equals(oldEnt)){
					return subFile.getName();
				}
			}
		}	
		return oldEnt;
	}
	
	private static String getLocalName(String name){
		int index= name.indexOf("#");
		if(index != -1){
			return name.substring(index+1);
		} else {
			return name;
		}
	}
	
	private static String getDebugMethod(String oldDebugMethod){
		String method = "";
		if(oldDebugMethod.equalsIgnoreCase("glassbox")){
			method = DebuggingParameters.pelletGlDebug;
		} else if(oldDebugMethod.equalsIgnoreCase("relevance-all")){
			method = DebuggingParameters.radonRelAllDebug;
		} else if(oldDebugMethod.equalsIgnoreCase("relevance-cm")){
			method = DebuggingParameters.radonRelCmDebug;
		}  else if(oldDebugMethod.equalsIgnoreCase("pattern")){
			method = DebuggingParameters.radonPatDebug;
		} else {
			System.err.println("no such method");
			System.exit(1);
		}
		return method;
	}
	
	private static void output(Vector<String> lines){
		for(String line : lines){
			System.out.println(line);
		}
	}
	
	
	public static Vector<String> getLogFile(File logFile) {
		String logPath = logFile.getPath().replace("\\", "/")+"/log.txt";
		Vector<String> lines = new Vector<String>();
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			
			// Read File Line By Line			
			while ((strLine = br.readLine()) != null) {	
				lines.add(strLine);			
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		return lines;
	}


}
