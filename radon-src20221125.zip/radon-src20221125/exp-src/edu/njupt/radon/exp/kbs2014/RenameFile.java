package edu.njupt.radon.exp.kbs2014;

import java.io.File;

public class RenameFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String reasoner = "hermit";
		String path = "g:/Experiments/2014-KBS/results/"+reasoner+"/incoherent/";
		path = "D:/experiments/radon/results/pellet/incoherent/";
		processFile(path);
		/*path = "g:/Experiments/2014-KBS/results/"+reasoner+"/consistent-abox/";
		processFile(path);
		path = "g:/Experiments/2014-KBS/results/"+reasoner+"/consistent-tbox/";
		processFile(path);
		path = "g:/Experiments/2014-KBS/results/"+reasoner+"/inconsistent/";
		processFile(path);*/
	}

public static void processFile(String resultPath) {
		
		File f = new File(resultPath);
		for(File ontoF : f.listFiles()){
			if(!ontoF.isDirectory()){
				continue;
			}			
			String ontoName = ontoF.getName();
			ontoName = ontoName.substring(ontoName.indexOf("-")+1);
			for(File methodF : ontoF.listFiles()){
				if(!methodF.isDirectory()){
					continue;
				}
				String oldDebugMethod = methodF.getName();
				if(oldDebugMethod.equalsIgnoreCase("radonPat")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/RadonPat";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} else if(oldDebugMethod.equalsIgnoreCase("radonRelCm")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/RadonRelCm";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} else if(oldDebugMethod.equalsIgnoreCase("relevance-all")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/RadonRelAll";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} else if(oldDebugMethod.equalsIgnoreCase("pelletGl")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/PelletGl";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} else if(oldDebugMethod.equalsIgnoreCase("swoopBl")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/SwoopBl";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} else if(oldDebugMethod.equalsIgnoreCase("swoopGl")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/SwoopGl";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} else if(oldDebugMethod.equalsIgnoreCase("protege")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/Protege";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} else if(oldDebugMethod.equalsIgnoreCase("blackbox")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/PelletBl";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} else if(oldDebugMethod.equalsIgnoreCase("glassbox")){
					String newPath = ontoF.getPath().replace("\\", "/")+"/PelletGl";
					File newFile = new File(newPath);
					methodF.renameTo(newFile);
				} 
				
			}

		}
	}
	
}
