package edu.njupt.radon.exp.kbs2014;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Vector;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.result.JustsReader;

public class KBSResultReader {
		
	static String reasonerName = "";
	static String debugTask = "";
	static String ontoName = "";
	static String debugMethod = "";
	static String entailmentString = "";
	static long time = DebuggingParameters.timeout;
	static int justsNumber = 0;
	static int minSize = 1000;
	static int maxSize = 0;
	static double meanSize = 0;
		
	static int ontoCounter = 1;
	static Vector<String> ontoNames = new Vector<String>();
	
	public static void main(String[] args) throws Exception {	
		String resultPath = "g:/Experiments/2014-KBS-evaluation/results/";
		
		PrintWriter output =  new PrintWriter(new BufferedWriter(
				new FileWriter(resultPath+"debugResult.xls")),true);   
		
    	
		outputJustHeader(output);
		
		listReasoners(output, resultPath);
		
		output.flush();
        output.close();
	}
	
	
	public static void listReasoners(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			if(!subFile.isDirectory()){
				continue;
			}
			reasonerName = subFile.getName();
			if(!reasonerName.equals("hermit")){
				continue;
			}
			//System.out.println("[Reasoner] "+reasonerName);
			String path = resultPath + reasonerName + "/";
			listDebugTasks(output, path);
			reasonerName = "";
		}
	}
	
	public static void listDebugTasks(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			debugTask = subFile.getName();
			/*if(!debugTask.equals("incoherent")){
				continue;
			}*/
			//System.out.println("[debugTask] "+debugTask);
			String path = resultPath + debugTask + "/";
			listOnts(output, path);
			debugTask = "";
		}
	}
	
	public static void listOnts(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			ontoName = subFile.getName();
			//System.out.println("[ontoName] "+ontoName+" path = "+resultPath);
			/*if(!ontoName.equalsIgnoreCase("university")){
				continue;
			}*/
			String path = resultPath + ontoName + "/";
			listDebugMethods(output, path);
			ontoName = "";
		}
	}
	
	public static void listDebugMethods(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			debugMethod = subFile.getName();
			/*if(!debugMethod.equalsIgnoreCase("protegebl")){
				continue;
			}*/
			String path = resultPath + debugMethod + "/";
			listEntailments(output, path);
			debugMethod = "";
		}
	}
	
	public static void listEntailments(PrintWriter output, String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			entailmentString = subFile.getName();
			String path = resultPath + entailmentString;
			if(entailmentString.equalsIgnoreCase("log.txt")){
				entailmentString = "top+bot";
				computeJustSize(output, path);		
			} else {
				computeJustSize(output, path+"/log.txt");	
			}
			printFileInfo(output);
			entailmentString = "";
		}
	}
	
			
	public static void computeJustSize(PrintWriter  output, String logPath) {		
		JustsReader reader = new JustsReader(logPath, debugMethod);
		HashSet<HashSet<String>> justs = reader.getJusts();	
		justsNumber = justs.size();
		minSize = 1000;
		maxSize = 0;
		meanSize = 0;
		int totalSize = 0;
		for(HashSet<String> just : justs){
			int size = just.size();
			// If an entailment \phi can be explained by itself, Protege does not output the justification {\phi} 
			if(size == 0){
				size = 1;
			}
			/*if(debugMethod.equalsIgnoreCase("radonRelAll")
					&&!debugTask.startsWith("inco")){
				// Remove the newly added axiom
				size --;
			}*/
			if(size > maxSize){
				maxSize = size;
			}
			if(size < minSize){
				minSize = size;				
			}
			totalSize += size;
		}
		if(justsNumber != 0){
			meanSize = (double)(totalSize / justsNumber);
		}				
		time = reader.getTime();

	}
	
	private static void printFileInfo(PrintWriter output){
		output.print(reasonerName);
	    output.print("\t");
	    output.print(debugTask);
	    output.print("\t");
	    output.print(ontoName);
	    output.print("\t");
	    output.print(getOntoID(ontoName));
	    output.print("\t");
	    //debugMethod = getDebugMethod(debugMethod);
		output.print(debugMethod);
		output.print('\t');
		output.print(entailmentString);		
		output.print("\t");
		output.print(justsNumber);
		output.print('\t');
		output.print(minSize);
		output.print('\t');
		output.print(maxSize);
		output.print('\t');
		output.print(meanSize);
		output.print('\t');
		output.print(time);
		output.println();
		System.out.println(reasonerName+", "+debugTask+", "+ontoName + ", "+debugMethod+", "+entailmentString+", "+justsNumber+", "+time);
		
	}
	
	private static int getOntoID(String ontoName){
		if(ontoNames.contains(ontoName)){
			return (ontoNames.indexOf(ontoName)+1);
		} else {
			ontoNames.add(ontoName);
			return ontoNames.size();
		}
	}
	
/*	private static String getDebugMethod(String value){
		String debugMethod = "";
		if(value.equalsIgnoreCase(DebuggingParameters.pelletBlDebug) || value.equalsIgnoreCase("blackbox")){
			debugMethod = DebuggingParameters.pelletBlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.pelletGlDebug) || value.equalsIgnoreCase("glassbox")){
			debugMethod = DebuggingParameters.pelletGlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.swoopBlDebug)){
			debugMethod = DebuggingParameters.swoopBlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.swoopGlDebug)){
			debugMethod = DebuggingParameters.swoopGlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.protegeDebug)){
			debugMethod = DebuggingParameters.protegeDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.radonDefDebug) || value.equalsIgnoreCase("default")){
			debugMethod = DebuggingParameters.radonDefDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.radonPatDebug) || value.equalsIgnoreCase("pattern")){
			debugMethod = DebuggingParameters.radonPatDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.radonRelAllDebug) || value.equalsIgnoreCase("relevance-all")){
			debugMethod = DebuggingParameters.radonRelAllDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.radonRelCmDebug) || value.equalsIgnoreCase("relevance-cm")){
			debugMethod = DebuggingParameters.radonRelCmDebug;
		} else {
			System.err.println("Please input the correct name of an ontology debugging method!");
		}
		return debugMethod;
	}*/
	

	
	public static void outputJustHeader(PrintWriter  output){	
		output.print("Reasoner Name");
	    output.print("\t");
		output.print("Debugging Task");
		output.print("\t");
		output.print("Ontology Name");
	    output.print("\t");
	    output.print("Ontology ID");
	    output.print("\t");
	    output.print("Debugging Method");
		output.print('\t');
		output.print("Entailment");		
		output.print("\t");
		// Information about the found justifications
		output.print("# of Justs");
		output.print('\t');
		output.print("Min size");
		output.print('\t');
		output.print("Max size");
		output.print('\t');
		output.print("Mean size");
		output.print('\t');
		output.print("Time (ms)");
		output.println();
	}
}
