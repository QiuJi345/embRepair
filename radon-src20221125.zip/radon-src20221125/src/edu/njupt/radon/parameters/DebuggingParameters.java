package edu.njupt.radon.parameters;


public class DebuggingParameters {
	
	public static boolean useModule = true;
	
	public static int topK = 50;
	public static double simThreshold = 0.2;
	
	
	public final static String swoopBlDebug = "SwoopBlackbox";
	public final static String swoopGlDebug = "SwoopGlassbox";
	public final static String pelletGlDebug = "PelletGlassbox";
	public final static String pelletBlDebug = "PelletBlackbox";
	public final static String protegeDebug = "ProtegeBlackbox";
	public final static String radonBlDebug = "RadonBlackbox";
	public final static String radonPatDebug = "RadonPattern";
	public final static String radonRelAllDebug = "RadonRelAll";
	public final static String radonRelCmDebug = "RadonRelCm";
	public final static String radonBlPatDebug = "RadonBlPlusPattern";
	public final static String radonRelPatDebug = "RadonRelPlusPattern";
	
    public final static String pelletReasoner = "pellet";	
	public final static String factppReasoner = "factpp";	
	public final static String jfactReasoner = "jfact"; 
	public final static String hermitReasoner = "hermit"; 
	
	public static String libraries = "experiments.jar;org.semanticweb.HermiT.jar;uk.ac.manchester.cs.owl.factplusplus;jfact-1.2.1.jar;"+
			"pellet\\aterm-java-1.6.jar;"
			+ "pellet\\owlapiv3\\owlapi-bin.jar;pellet\\owlapi\\owlapi-bin.jar;"
			+ "pellet\\pellet-owlapiv3.jar;pellet\\pellet-owlapi.jar;" +
			"pellet\\pellet-cli.jar;pellet\\pellet-core.jar;pellet\\pellet-datatypes.jar;" +
			"pellet\\pellet-el.jar;pellet\\pellet-explanation.jar;" +
			"pellet\\pellet-jena.jar;pellet\\pellet-modularity.jar;" +
			"pellet\\pellet-pellint.jar;" +
			"pellet\\pellet-query.jar;pellet\\pellet-rules.jar;" +			
			"pellet\\xsdlib\\relaxngDatatype.jar;pellet\\xsdlib\\xsdlib.jar; ";
	

	public static String preFixedPara = "java -Xss64m -Xms64m -Xmx6g "
			+ "-Djava.library.path=\"lib/factplusplus/lib/native/64bit\" -cp ";
	
	public static String reasoner = pelletReasoner; 
	/** This parameter is used for setting the maximal time to wait **/
	public static int timeout = 1000*1000;	// 1000*1000
	
	/** These parameters are used for specifying a specific ontology to be debuged **/
	public static String debugTask = "explain";
	//public static String constructionType = "tool";
	public static String ontoName = "CHEM-A"; //km1500-4000 proton_100_all
	
	/** This parameter is used for specifying a specific debugging method **/
	public static String debugMethod = radonRelAllDebug; //radonRelAllDebug  pelletBlDebug
		
	/** These parameters are for configuring various paths **/
	//public static final String ontoRoot = "D:/program-workspace/datamining/pellet-src/results/module-mups/";
	public static String ontoRoot = "onto/";	
	public static String ontoPath = "file:"+ontoRoot + debugTask+"/"+ontoName+".owl";
	
	public static String resultRoot = "results/";	
	public static String resultPath = resultRoot + debugTask+"/"+ontoName+"/"+debugMethod+"/";
	
	/** These parameters are for computing MUPS  **/
	public static String ucName = "http://cmt#ProgramCommittee";
	public static String ucsFile = ontoRoot + "incoherent/selected-ucs/"+ ontoName + "_selected_ucs.txt";
		
	/** These parameters are for computing justifications of entailments **/
	public static String entailmentsFile = ontoRoot + "consistent/inferredAxioms/"+DebuggingParameters.ontoName+".txt";
	public static String entailmentString = "Athlete subClassOf Person";
	
	
	/** Update some parameters */
	
	public static void updateOntoPath(){
		ontoPath = "file:"+ontoRoot + debugTask+"/"+ontoName+".owl";
	}
	
	public static void updateResultPath(){
		resultPath = resultRoot + debugTask+"/"+ontoName+"/"+debugMethod+"/";
	}
	
	public static void updateUcsFile(){
		ucsFile = ontoRoot + "incoherent/selected-ucs/"+ ontoName + ".txt";		
	}
	
	public static void updateEntailmentsFile(){
		entailmentsFile = ontoRoot + "consistent/inferredAxioms/"+ontoName+".txt";
	}

}