package edu.njupt.radon.parameters;

import java.util.Vector;

import edu.njupt.radon.utils.io.FileTools;

public class DebuggingArgumentsProcessing {
	boolean unknownArg = true;
	
	boolean hasParameterFile = false;
	
	boolean hasTimeOut = false;
	boolean hasReasoner = false;
	boolean hasDebugTask = false;
	boolean hasDebugMethod = false;
	boolean hasConstructionType = false;
	boolean hasOntoName = false;
	boolean hasOntoRoot = false;
	boolean hasResultRoot = false;
	boolean hasUcName = false;
	boolean hasEntailment = false;
	
	String givenDebugMethod = "";
	
	public DebuggingArgumentsProcessing(){
		this.givenDebugMethod = null;
	}
	
	public DebuggingArgumentsProcessing(String givenDebugMethod){
		this.givenDebugMethod = givenDebugMethod;
	}
		
	/**
	 * process command line arguments
	 */
	public boolean processArguments(String[] args, String debuggingClass){

		int argc = args.length;
		if (argc == 0) {
			printUsage(debuggingClass);
			return false;
		}
		String s = args[0].toLowerCase();		
		if (argc == 1) {
			if ((s.equalsIgnoreCase("-?")) || (s.equalsIgnoreCase("?")) 
					|| (s.equalsIgnoreCase("-h")) || (s.equalsIgnoreCase("--help")) 
					|| (s.equalsIgnoreCase("-help")) || (s.equalsIgnoreCase("help")) 
					|| (s.equalsIgnoreCase("radon"))) {
				printUsage(debuggingClass);
				return false;
			}
		}
		
		// Iterate on all input parameters
		for (int i = 0; i < argc; ++i) {
			String arg = args[i];

			if ((arg.equalsIgnoreCase("-?")) || (arg.equalsIgnoreCase("?")) || 
					(arg.equalsIgnoreCase("-h")) || (arg.equalsIgnoreCase("--help")) || 
					(arg.equalsIgnoreCase("-help")) || (arg.equalsIgnoreCase("help"))) {
				printUsage(debuggingClass);
				return false;
			}

			if (arg.startsWith("-")) {
				switchOnParameter(arg);
			} else {
				if (arg.equalsIgnoreCase("radon") ) {
					unknownArg = false;
				} else {
					setParameterValue(arg);
				}
			}
			
			if (unknownArg) { 
				printUsageError(arg); 
				return false; 
			} 
		}
		// Update the debugging parameters in a Java file according to those input parameters.
		updateParameters();
		
		return true;
	
	}

	
	public void switchOnParameter(String arg){
		iniParameters();
		
		if (arg.equalsIgnoreCase("-timeout") || arg.equalsIgnoreCase("-to")) {
			hasTimeOut = true;
			unknownArg = false;
		} else if (arg.equalsIgnoreCase("-reasoner") || arg.equalsIgnoreCase("-re") ) {
			hasReasoner = true;
			unknownArg = false;
		} else if (arg.equalsIgnoreCase("-debugtask") || arg.equalsIgnoreCase("-dt") ) {
			hasDebugTask = true;
			unknownArg = false;
		} else if (arg.equalsIgnoreCase("-debugmethod") || arg.equalsIgnoreCase("-dm")) {
			hasDebugMethod = true;				
			unknownArg = false;
		} else if (arg.equalsIgnoreCase("-ontoname") || arg.equalsIgnoreCase("-on") ) {
			hasOntoName = true;					
			unknownArg = false;				
		} else if (arg.equalsIgnoreCase("-ontoroot") || arg.equalsIgnoreCase("-or") ) {
			hasOntoRoot = true;					
			unknownArg = false;
		} else if (arg.equalsIgnoreCase("-resultroot") || arg.equalsIgnoreCase("-rr") ) {
			hasResultRoot = true;					
			unknownArg = false;
		} else if (arg.equalsIgnoreCase("-ucname") || arg.equalsIgnoreCase("-un") ) {
			hasUcName = true;					
			unknownArg = false;				
		} else if (arg.equalsIgnoreCase("-entailment") || arg.equalsIgnoreCase("-en") ) {
			hasEntailment = true;					
			unknownArg = false;
		} else if (arg.equalsIgnoreCase("-parameterfile") || arg.equalsIgnoreCase("-pf") ) {
			hasParameterFile = true;					
			unknownArg = false;
		} 		
	}
	
	
	public void iniParameters(){
		hasTimeOut = false;
		hasReasoner = false;
		hasDebugTask = false;
		hasDebugMethod = false;
		hasConstructionType = false;
		hasOntoName = false;
		hasOntoRoot = false;
		hasResultRoot = false;
		hasUcName = false;
		hasEntailment = false;
	}
	
	public void setParameterValue(String arg){
		if (arg.equalsIgnoreCase("radon") ) {
			unknownArg = false;
		} else {			
			if(hasTimeOut){
				DebuggingParameters.timeout = Integer.valueOf(arg);
			} else if(hasReasoner){
				DebuggingParameters.reasoner = arg;			
			} else if(hasDebugTask){
				DebuggingParameters.debugTask = arg;			
			} else if(hasOntoName){
				if(arg.equals("null")){
					DebuggingParameters.ontoName = null;
				} else {
					DebuggingParameters.ontoName = arg;
				}
			} else if(hasDebugMethod){
				if(givenDebugMethod != null && givenDebugMethod.length() >0){
					arg = givenDebugMethod;
				}
				setDebugMethod(arg);
				
			} else if(hasOntoRoot){
				DebuggingParameters.ontoRoot = arg;
			} else if(hasResultRoot){
				DebuggingParameters.resultRoot = arg;
			} else if(hasUcName){
				DebuggingParameters.ucName = arg;
			} else if(hasEntailment){
				if(arg.equals("null")){
					DebuggingParameters.entailmentString = null;
				} else {
					// Ignore the
					//DebuggingParameters.entailmentString = arg.substring(1,arg.length()-2);
					DebuggingParameters.entailmentString = arg;
				}
			} else if(hasParameterFile){
				setParametersByFile(arg);
			}
		}
	}
	
	
	public void setParametersByFile(String inputFile){
		Vector<String> lines = FileTools.getStringVector(inputFile);
		for(String line : lines){
			if(line.trim().length() == 0 || line.startsWith("#")){
				continue;
			}
			setOneParameter(line);
		}
		updateParameters();
	}
	
	private void setOneParameter(String parameter){
		int index1 = parameter.indexOf("=");
		if(index1 == -1){
			return;
		}
		
		String variableName = parameter.substring(0,index1);
		String value = parameter.substring(index1+1).trim();
		
		if(variableName.equalsIgnoreCase("timeout")|| variableName == "timeout"){
			DebuggingParameters.timeout = Integer.valueOf(value);
		} else if(variableName.equalsIgnoreCase("reasoner")){
			if(value.equalsIgnoreCase(DebuggingParameters.factppReasoner) ||
					value.equals(DebuggingParameters.hermitReasoner)){
				DebuggingParameters.debugTask = value;	
			} else {
				DebuggingParameters.debugTask = DebuggingParameters.pelletReasoner;	
			}			
		} else if(variableName.equalsIgnoreCase("debugTask")){
			DebuggingParameters.debugTask = value;		
		} else if(variableName.equalsIgnoreCase("ontoName") || variableName.equals("o")){
			if(value.equals("null")){
				DebuggingParameters.ontoName = null;
			} else {
				DebuggingParameters.ontoName = value;
			}
		} else if(variableName.equalsIgnoreCase("debugMethod")){
			if(givenDebugMethod != null && givenDebugMethod.length() >0){
				value = givenDebugMethod;
			}
			setDebugMethod(value);
		} else if(variableName.equalsIgnoreCase("ontoRoot")){
			DebuggingParameters.ontoRoot = value;
		} else if(variableName.equalsIgnoreCase("resultRoot")){
			DebuggingParameters.resultRoot = value;
		} else if(variableName.equalsIgnoreCase("ucName")){
			DebuggingParameters.ucName = value;
		} else if(variableName.equalsIgnoreCase("entailmentString")){
			if(value.equals("null")){
				DebuggingParameters.entailmentString = null;
			} else {
				// Ignore the
				DebuggingParameters.entailmentString = value.substring(1,value.length()-2);
			}
		}	
	}
	
	private static void setDebugMethod(String value){
		if(value.equalsIgnoreCase(DebuggingParameters.pelletBlDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.pelletBlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.pelletGlDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.pelletGlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.swoopBlDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.swoopBlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.swoopGlDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.swoopGlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.protegeDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.protegeDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.radonBlDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.radonBlDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.radonPatDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.radonPatDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.radonRelAllDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.radonRelAllDebug;
			
		} else if(value.equalsIgnoreCase(DebuggingParameters.radonRelCmDebug)){
			DebuggingParameters.debugMethod = DebuggingParameters.radonRelCmDebug;
		} else {
			System.err.println("Please input the correct name of an ontology debugging method!");
			System.exit(1);
		}
	}
	

	
	private static void updateParameters(){
		DebuggingParameters.updateOntoPath();
		DebuggingParameters.updateResultPath();
		DebuggingParameters.updateUcsFile();
		DebuggingParameters.updateEntailmentsFile();
	}

	
    protected static void printUsage(String main) {
        System.out.println("Usage: "+main+" [-parameterfile|-pf] [-timeout|-to] [-reasoner|-re] " +
        		"[-debugtask|-dt] [-debugmethod|-dm] [-constructiontype|-ct]" +
                "[-ontoname|-on] [-ontoroot|-or] [-resultroot|-rr] " +
                "[-ucname|-un] [-entailment|-en] " +
        		"[-help|-h]");
        System.out.println("  -help:              print this message and terminate");	 
        System.out.println("  -parameterfile:     the file storing all parameters to be configured");	 
        System.out.println("  -timeout:           the timeout for each debugging process");
        System.out.println("  -debugtask:         a specific ontology debugging task which can be consistent, incoherent and inconsistent");
        System.out.println("  -debugmethod:       a specific debugging approach which can be default, pattern, relevance-all, relevance-cm");
        System.out.println("  -constructiontype:  the type of ontology construction which can be tool (newly generated) or real (existing)");
        System.out.println("  -ontoname:          the name of an ontology to be debugged");
        System.out.println("  -ontoroot:          the root path for storing ontologies");
        System.out.println("  -resultroot:        the path to store all outputs");
        System.out.println("  -ucname:            the local name or IRI of an unsatisfiable concept to be debugged");	        
        System.out.println("  -entailment:        the entailment to be debugged");
        System.exit(0);
    }


	/**
	 * prints a short excuse after not understandable input
	 */
	public void printUsageError(String arg) {
		System.out.println("Sorry, didn't understand the command line parameter : "+arg);
	}	
}
