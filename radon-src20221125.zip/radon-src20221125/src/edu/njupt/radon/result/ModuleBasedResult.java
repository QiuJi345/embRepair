package edu.njupt.radon.result;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ModuleBasedResult {
		
	private static String timeOut = "1000000";
	private static String method = "blackbox";
	
	static int ontoCounter = 0;
	static int ucCounter = 0;
	
	static String debugMethod = null;
	
	static String findAllJustsTime = "";
	static String reuseTime = "";
	static String earlyPathTermTime = "";
	static String findSingleJustsTime = "";
	
	static String reuseTimes = "";
	static String earlyPathTermTimes = "";
	static String findSingleJustsTimes = "";
		
	static String currentOntoName = "";
	static String currentUC = "";
			
	public static void main(String[] args) throws Exception {
		method = "blackbox";
		String constructionType = "tool";
		boolean useModule = true;
		
		
		String resultPath = "D:/data/debugging/odbm/results/incoherent/" +constructionType+"/";
		if(useModule){
			resultPath = "D:/data/debugging/odbm/module-results/incoherent/" +constructionType+"/";
		}
		
		if(constructionType.equals("tool")){
			ontoCounter = 10;
		}
		//String resultPath = "D:/program-workspace/datamining/pellet-src/results/just/"+dataSet+"/";
		//String resultPath = "results/debug/mups/"+dataSet+"/";
		PrintWriter output =  new PrintWriter(new BufferedWriter(
				new FileWriter(resultPath+constructionType+"-time.xls")),true);    	
    	
		outputMUPSHeader(output);
		
		processFile(output, resultPath);
		
		output.flush();
        output.close();
	}
	
	
	public static void processFile(PrintWriter output, String resultPath) {
		
		File f = new File(resultPath);
		for(File ontoF : f.listFiles()){
			if(!ontoF.isDirectory()){
				continue;
			}			
			ontoCounter++;
			currentOntoName = ontoF.getName();
			for(File methodF : ontoF.listFiles()){
				if(!methodF.isDirectory()){
					continue;
				}
				debugMethod = methodF.getName();
				if(!debugMethod.equals(method)){
					continue;
				}
				debugMethod = normalizeMethod(debugMethod);
				if(debugMethod.length() == 0){
					continue;
				}
				ucCounter = 0;

				for(File ucF : methodF.listFiles()){
					if(!ucF.isDirectory()){
						continue;
					}					
					
					currentUC = ucF.getName();
					ucCounter ++;
										
					String logPath = ucF.getPath().replace("\\", "/")+"/log.txt";						
					getExplanationInfo(output, logPath);	
					
				}
						
			}

		}
	}

	
	public static void getExplanationInfo(
			PrintWriter  output, 
			String logPath) {
		boolean isOneMUPSBegin = false;
		int oneMUPSSize = 0;
		int totalMUPSSize = 0;
		int mupsNumber = 0;
		int minSize = 1000;
		int maxSize = 0;
		ini();
				
		String time = timeOut;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line			
			while ((strLine = br.readLine()) != null) {	
				int radonStartIndex1 = strLine.indexOf("Found a new MUPS");
				int radonStartIndex2 = strLine.indexOf("MIS <");
				int pelletStartIndex = strLine.indexOf("Explanation");
				if(radonStartIndex1 != -1 || radonStartIndex2 != -1 || pelletStartIndex != -1){
					isOneMUPSBegin = true;
					oneMUPSSize = 0;
					time  = timeOut;
					continue;
				} 
				
				if(isOneMUPSBegin){
					if(strLine.trim().length() == 0 && oneMUPSSize != -1){
						if(debugMethod.equals("relevance-all")){
							oneMUPSSize --;
						}
						if(oneMUPSSize > maxSize){
							maxSize = oneMUPSSize;
						}
						if(oneMUPSSize < minSize){
							minSize = oneMUPSSize;
						}
						
						totalMUPSSize += oneMUPSSize;
						mupsNumber ++;
						isOneMUPSBegin = false;
					} else {
						int index1 = strLine.indexOf("[");
						if(index1 != -1){
							oneMUPSSize ++;							
						} 
					}
				} else if(strLine.contains(" Time (ms) to compute")){
					int j = strLine.indexOf(": ");
					if(j != -1){
						time = strLine.substring(j+2).trim();
						Integer intValue = Integer.valueOf(time);
						if(intValue > 1000000){
							time = timeOut;
						}
					}
					// If the information about time has been obtained, then the loop to read results can be terminated.
					break;
				} else if(strLine.contains("Time for") || strLine.contains("SatCheck")){
					setTimes(strLine);
				}
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} finally {
			output.print(ontoCounter);
		    output.print("\t");
		    output.print(currentOntoName);
		    output.print("\t");
			output.print(debugMethod);
			output.print('\t');
			output.print(currentUC);		
			output.print("\t");
			output.print(ucCounter);		
			output.print("\t");
			
			output.print(mupsNumber);
			output.print('\t');
			output.print(totalMUPSSize);
			output.print('\t');
			output.print(minSize);
			output.print('\t');
			output.print(maxSize);				
			output.print('\t');
			output.print(time);
			output.print('\t');
			
			output.print(findAllJustsTime);
			output.print('\t');
			output.print(reuseTime);
			output.print('\t');				
			output.print(earlyPathTermTime);
			output.print('\t');
			output.print(findSingleJustsTime);
			output.print('\t');
			output.print(reuseTimes);
			output.print('\t');				
			output.print(earlyPathTermTimes);
			output.print('\t');
			output.print(findSingleJustsTimes);
			output.println();
		}
	}

	
	private static void ini(){
		findAllJustsTime = "";
		reuseTime = "";
		earlyPathTermTime = "";
		findSingleJustsTime = "";
		
		reuseTimes = "";
		earlyPathTermTimes = "";
		findSingleJustsTimes = "";
		
	}
	
	private static void setTimes(String line){
		if(line.startsWith("Time for finding All Justs")){
			findAllJustsTime = line.substring(line.indexOf(":")+2).trim();
		}  else if(line.startsWith("Time for reusing")){
			reuseTime = line.substring(line.indexOf(":")+2, line.indexOf("(")).trim();
			reuseTimes = line.substring(line.indexOf("(")+1,line.indexOf(")")).trim();			
		}  else if(line.startsWith("Time for early path termination")){
			earlyPathTermTime = line.substring(line.indexOf(":")+2, line.indexOf("(")).trim();
			earlyPathTermTimes = line.substring(line.indexOf("(")+1,line.indexOf(")")).trim();
		} else if(line.startsWith("Time for finding single justs")){
			findSingleJustsTime = line.substring(line.indexOf(":")+2, line.indexOf("(")).trim();
			findSingleJustsTimes = line.substring(line.indexOf("(")+1,line.indexOf(")")).trim();
		} /*else if(line.startsWith("SatCheck ")){
			String time = line.substring(line.indexOf(":")+2, line.indexOf(",")).trim();
			satCheckBLTimes = line.substring(line.indexOf(",")+2,line.indexOf(", avg")).trim();
		}*/
	}
	
	private static String normalizeMethod(String methodString){
		String methodNameInFigure = "";
		if(methodString.equals("blackbox")){
			methodNameInFigure = "Pellet-BL";
		} else if(methodString.equals("glassbox")){
			methodNameInFigure = "Pellet-GL";
		}
		return methodNameInFigure;
	}
	
	public static void outputMUPSHeader(PrintWriter  output){	
		output.print("Ontology ID");
	    output.print("\t");
		output.print("Ontology");
	    output.print("\t");
	    output.print("Tool");
		output.print('\t');
		output.print("UnsatConcept");		
		output.print("\t");
		output.print("UCID");		
		output.print("\t");
		output.print("# of MUPS");
		output.print('\t');
		output.print("Total size of MUPS");
		output.print('\t');
		output.print("Min size of a MUPS");
		output.print('\t');
		output.print("Max size of a MUPS");
		output.print('\t');
		output.print("Time (total)");
		output.print('\t');
		output.print("Time (findAll)");
		output.print('\t');
		output.print("Time (reuse)");
		output.print('\t');
		output.print("Time (earlyPathTerm)");
		output.print('\t');
		output.print("Time (singleJusts)");
		output.print('\t');
		output.print("Times (reuse)");
		output.print('\t');
		output.print("Times (earlyPathTerm)");
		output.print('\t');
		output.print("Times (singleJusts)");
		output.println();
	}
	
}
