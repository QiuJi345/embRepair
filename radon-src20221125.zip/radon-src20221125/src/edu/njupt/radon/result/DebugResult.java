
package edu.njupt.radon.result;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;


/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 19.11.2007
 */
public class DebugResult implements Serializable {
	private static final long serialVersionUID=5454977328619881127L;
	private String debugStrategy = null;
	private HashMap<OWLClass,HashSet<HashSet<OWLAxiom>>> mups = null;
	private Vector<HashMap<OWLClass,HashSet<HashSet<OWLAxiom>>>> multiMUPS = null;
	private HashSet<HashSet<OWLAxiom>> mips = null;
	private HashMap<String,List> mupsList = null;
	HashMap<OWLClass,HashSet<Vector<OWLAxiom>>> hittingSets;
	private HashSet<OWLAxiom> testAxioms = null;
	private long testTime = 0;
	private long checkTime = 0;
	private int checkTimes = 0;
	
	public String getDebugStrategy(){
		return debugStrategy;
	}
		
	public HashMap<String,List> getMUPSList(){
		return mupsList;
	}
	
	public HashMap<OWLClass,HashSet<HashSet<OWLAxiom>>> getMUPS(){
		return mups;
	}
	
	public long getTestTime(){
		return testTime;
	}
	
	public long getCheckTime(){
		return checkTime;
	}
	
	public long getCheckTimes(){
		return checkTimes;
	}
	
    public void save(String fileName){
        ObjectOutputStream outputStream = null;        
        try {
        	outputStream = new ObjectOutputStream(
        			new BufferedOutputStream(
        					new FileOutputStream(fileName)));
            outputStream.writeObject(this);
        } catch (Exception e){
        	e.printStackTrace();
        } finally {
        	if(outputStream!=null){
        		try{
        			outputStream.close();
        		} catch (Exception e){
                	e.printStackTrace();
                }        		
        	}
        }
    }
    
    public static DebugResult load(String fileName) {
        ObjectInputStream inputStream= null;
        try {
        	inputStream = new ObjectInputStream(
        			new BufferedInputStream(
        					new FileInputStream(fileName)));
            return (DebugResult)inputStream.readObject();
        } catch (Exception e){
        	e.printStackTrace();
        	return null;
        } finally {
        	try{
        		inputStream.close();
        	} catch (Exception e){
            	e.printStackTrace();
            }            
        }
    }
	
	
	public void setDebugStrategy(String strategy){
		this.debugStrategy = strategy;
	}
	
	public void setMUPS(HashMap<OWLClass,HashSet<HashSet<OWLAxiom>>> mups){
		this.mups = mups;
	}
	
	public void setMUPSList(HashMap<String,List> mupsList){
		this.mupsList = mupsList;
	}
	
	public void setTestTime(long testTime){
		this.testTime = testTime;
	}
	
	public void setCheckTime(long checkTime){
		this.checkTime = checkTime;
	}
	
	public void setCheckTimes(int checkTimes){
		this.checkTimes = checkTimes;
	}

	public HashSet<HashSet<OWLAxiom>> getMIPS() {
		return mips;
	}

	public void setMIPS(HashSet<HashSet<OWLAxiom>> mips) {
		this.mips = mips;
	}

	public HashSet<OWLAxiom> getTestAxioms() {
		return testAxioms;
	}

	public void setTestAxioms(HashSet<OWLAxiom> testAxioms) {
		this.testAxioms = testAxioms;
	}

	public HashMap<OWLClass, HashSet<Vector<OWLAxiom>>> getHittingSets() {
		return hittingSets;
	}

	public void setHittingSets(HashMap<OWLClass, HashSet<Vector<OWLAxiom>>> hittingSets) {
		this.hittingSets = hittingSets;
	}

	public Vector<HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>> getMultiMUPS() {
		return multiMUPS;
	}

	public void setMultiMUPS(
			Vector<HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>> multiMUPS) {
		this.multiMUPS = multiMUPS;
	}

}
