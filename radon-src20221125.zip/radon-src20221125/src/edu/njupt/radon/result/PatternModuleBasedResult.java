package edu.njupt.radon.result;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class PatternModuleBasedResult {
		
	private static String timeOut = "1000000";
	
	static int ontoCounter = 0;
	static int ucCounter = 0;
	
	static String prepareTime = "";
	static String extractModuleTime = "";
	static String debugTime = "";
		
	static String currentOntoName = "";
	static String currentUC = "";
	static String debugMethod = "";
			
	public static void main(String[] args) throws Exception {
		String constructionType = "real";
		boolean useModule = true;
		
		
		String resultPath = "D:/data/debugging/odbm/results/incoherent/" +constructionType+"/";
		if(useModule){
			resultPath = "D:/data/debugging/odbm/module-results/incoherent/" +constructionType+"/";
		}
		
		if(constructionType.equals("tool")){
			ontoCounter = 10;
		}
		//String resultPath = "D:/program-workspace/datamining/pellet-src/results/just/"+dataSet+"/";
		//String resultPath = "results/debug/mups/"+dataSet+"/";
		PrintWriter output =  new PrintWriter(new BufferedWriter(
				new FileWriter(resultPath+"pattern-"+constructionType+"-time.xls")),true);    	
    	
		outputMUPSHeader(output);
		
		processFile(output, resultPath);
		
		output.flush();
        output.close();
	}
	
	
	public static void processFile(PrintWriter output, String resultPath) {
		
		File f = new File(resultPath);
		for(File ontoF : f.listFiles()){
			if(!ontoF.isDirectory()){
				continue;
			}			
			ontoCounter++;
			currentOntoName = ontoF.getName();
			for(File methodF : ontoF.listFiles()){
				if(!methodF.isDirectory()){
					continue;
				}
				debugMethod = methodF.getName();
				if(!debugMethod.equals("pattern")){
					continue;
				}
				ucCounter = 0;

				for(File ucF : methodF.listFiles()){
					if(!ucF.isDirectory()){
						continue;
					}					
					
					currentUC = ucF.getName();
					ucCounter ++;
										
					String logPath = ucF.getPath().replace("\\", "/")+"/log.txt";						
					getExplanationInfo(output, logPath);	
					
				}
						
			}

		}
	}

	
	public static void getExplanationInfo(
			PrintWriter  output, 
			String logPath) {
		boolean isOneMUPSBegin = false;
		int oneMUPSSize = 0;
		int totalMUPSSize = 0;
		int mupsNumber = 0;
		int minSize = 1000;
		int maxSize = 0;
				
		debugTime = timeOut;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line			
			while ((strLine = br.readLine()) != null) {	
				int radonStartIndex1 = strLine.indexOf("Found a new MUPS");
				int radonStartIndex2 = strLine.indexOf("MIS <");
				int pelletStartIndex = strLine.indexOf("Explanation");
				if(radonStartIndex1 != -1 || radonStartIndex2 != -1 || pelletStartIndex != -1){
					isOneMUPSBegin = true;
					oneMUPSSize = 0;
					debugTime  = timeOut;
					continue;
				} 
				
				if(isOneMUPSBegin){
					if(strLine.trim().length() == 0 && oneMUPSSize != -1){						
						if(oneMUPSSize > maxSize){
							maxSize = oneMUPSSize;
						}
						if(oneMUPSSize < minSize){
							minSize = oneMUPSSize;
						}
						
						totalMUPSSize += oneMUPSSize;
						mupsNumber ++;
						isOneMUPSBegin = false;
					} else {
						int index1 = strLine.indexOf("[");
						if(index1 != -1){
							oneMUPSSize ++;							
						} 
					}
				} else if(strLine.contains(" Time (ms) to compute")){
					int j = strLine.indexOf(": ");
					if(j != -1){
						debugTime = strLine.substring(j+2).trim();
						Integer intValue = Integer.valueOf(debugTime);
						if(intValue > 1000000){
							debugTime = timeOut;
						}
					}
					// If the information about time has been obtained, then the loop to read results can be terminated.
					break;
				} else if(strLine.contains("Time for preparing")){
					prepareTime = strLine.substring(strLine.indexOf(":")+2).trim();
				} else if(strLine.contains("Time for extracting a module")){
					extractModuleTime = strLine.substring(strLine.indexOf(":")+2).trim();
				}
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} finally {
			output.print(ontoCounter);
		    output.print("\t");
		    output.print(currentOntoName);
		    output.print("\t");
			output.print(debugMethod);
			output.print('\t');
			output.print(currentUC);		
			output.print("\t");
			output.print(ucCounter);		
			output.print("\t");
			
			output.print(mupsNumber);
			output.print('\t');
			output.print(totalMUPSSize);
			output.print('\t');
			output.print(minSize);
			output.print('\t');
			output.print(maxSize);				
			output.print('\t');
			output.print(debugTime);
			output.print('\t');			
			output.print(prepareTime);
			output.print('\t');
			output.print(extractModuleTime);
			output.println();
		}
	}
	
	
	public static void outputMUPSHeader(PrintWriter  output){	
		output.print("Ontology ID");
	    output.print("\t");
		output.print("Ontology");
	    output.print("\t");
	    output.print("Tool");
		output.print('\t');
		output.print("UnsatConcept");		
		output.print("\t");
		output.print("UCID");		
		output.print("\t");
		output.print("# of MUPS");
		output.print('\t');
		output.print("Total size of MUPS");
		output.print('\t');
		output.print("Min size of a MUPS");
		output.print('\t');
		output.print("Max size of a MUPS");
		output.print('\t');
		output.print("Time (total)");
		output.print('\t');
		output.print("Time (prepare)");
		output.print('\t');
		output.print("Time (extractModule)");
		output.println();
	}
	
}
