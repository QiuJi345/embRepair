package edu.njupt.radon.result;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;


public class RevisionResult extends DebugResult {
	private static final long serialVersionUID=5454977328619881127L;
	/** For each set in mipsSubset, it indicates a subset of a MIPS to 
	 * be considered to repair incoherence. */
	private HashSet<HashSet<OWLAxiom>> mipsSubset = null;
	private HashSet<OWLAxiom> removedAxioms = null;	
	private long repairTime =0;	
	private HashSet<OWLAxiom> originalOnto = null;
	private HashSet<OWLAxiom> newOnto = null;
	private String newOntoName = null;

	public HashSet<OWLAxiom> getRemovedAxioms() {
		return removedAxioms;
	}

	public void setRemovedAxioms(HashSet<OWLAxiom> removedAxioms) {
		this.removedAxioms = removedAxioms;
	}

	public long getRepairTime() {
		return repairTime;
	}

	public void setRepairTime(long repairTime) {
		this.repairTime = repairTime;
	}

	public HashSet<HashSet<OWLAxiom>> getMipsSubset() {
		return mipsSubset;
	}

	public void setMipsSubset(HashSet<HashSet<OWLAxiom>> mipsSubset) {
		this.mipsSubset = mipsSubset;
	}

	public HashSet<OWLAxiom> getOriginalOnto() {
		return originalOnto;
	}

	public void setOriginalOnto(HashSet<OWLAxiom> originalOnto) {
		this.originalOnto = originalOnto;
	}

	public HashSet<OWLAxiom> getNewOnto() {
		return newOnto;
	}

	public void setNewOnto(HashSet<OWLAxiom> newOnto) {
		this.newOnto = newOnto;
	}

	public String getNewOntoName() {
		return newOntoName;
	}

	public void setNewOntoName(String newOntoName) {
		this.newOntoName = newOntoName;
	}

}
