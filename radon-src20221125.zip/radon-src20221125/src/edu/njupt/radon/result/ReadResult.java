package edu.njupt.radon.result;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Set;

import edu.njupt.radon.utils.io.DumpFile;

public class ReadResult {
		
	public static void main(String[] args) throws Exception {
		String resultPath = "results/tmp/";
		PrintWriter output =  new PrintWriter(new BufferedWriter(
				new FileWriter(resultPath+"pattern-results.xls")),true);    	
    	
		outputHeader(output);
		
		processFile(output, resultPath);
		
		output.flush();
        output.close();
	}
	
	public static void processFile(PrintWriter output, String resultPath) {
		
		File f = new File(resultPath);
		for(File ontoF : f.listFiles()){
			if(!ontoF.isDirectory()){
				continue;
			}
			String ontoName = ontoF.getName();
			for(File ucF : ontoF.listFiles()){
				if(!ucF.isDirectory()){
					continue;
				}
				String ucName = ucF.getName();
				String path = ucF.getPath().replace("\\", "/")+"/";	
				
			    output.print(ontoName);
			    output.print("\t");
				output.print("Pattern-based");
				output.print('\t');
				output.print(ucName);		
				output.print("\t");
				
				// MUPS info
				HashMap<String, Set<Set<String>>> mups = new HashMap<String, Set<Set<String>>>();
				File file = new File(path + "mups.dump");
				if(file.exists()){
					mups = (HashMap<String, Set<Set<String>>>)DumpFile.getObject(path+"mups.dump");
				}
				
				int numOfMUPS = 0;
				int size = 0;
				int maxSize = 0;
				int minSize = 1000;
				for(String uc : mups.keySet()){
					Set<Set<String>> ucMUPS = mups.get(uc);
					
					numOfMUPS = ucMUPS.size();
					for(Set<String> oneMUPS : ucMUPS){
						int n = oneMUPS.size();
						size += n;
						if(n > maxSize){
							maxSize = n;
						}
						if(n < minSize){
							minSize = n;
						}
					}					
					break;
				}
				
				double avgSize = (double)size / (double)numOfMUPS;
				output.print(numOfMUPS);
				output.print('\t');
				output.print(avgSize);
				output.print('\t');
				output.print(maxSize);
				output.print('\t');
				output.print(minSize);
                // Time info
				getTimeInfo(path+"log.txt", output);
				output.println();
			}
		}
		
		
	
	}

	public static void getTimeInfo(String logPath, PrintWriter output){
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine = null ;	
			String debugTime = "0";
			String totalTime = "10000000";
			while ((strLine = br.readLine()) != null) {	
				if(strLine.contains("Time: ")){
					totalTime = strLine.substring(String.valueOf("Time: ").length()-1).trim();
					debugTime = totalTime;
				}
			}
			output.print('\t');
			output.print("0");
			output.print('\t');
			output.print(debugTime);
			output.print('\t');
			output.print(totalTime);
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
			
	public static void outputHeader(PrintWriter  output){
		output.print("Ontology");
	    output.print("\t");
		output.print("Debug method");
		output.print('\t');
		output.print("UnsatConcept");		
		output.print("\t");
		output.print("# of MUPS");
		output.print('\t');
		output.print("Avg size of a MUPS");
		output.print('\t');
		output.print("Max size of a MUPS");
		output.print('\t');
		output.print("Min size of a MUPS");
		output.print('\t');
		output.print("extract time (ms)");
		output.print('\t');
		output.print("debug time (ms)");
		output.print('\t');
		output.print("total time (ms)");
		output.println();
	}
}
