package edu.njupt.radon.result;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

import edu.njupt.radon.parameters.DebuggingParameters;

public class JustsReader {
	
	HashSet<HashSet<String>> justs = new HashSet<HashSet<String>>();
	
	// If time is -1, it means that no time is given in the log file.
	long time = -1;
	
	public JustsReader(String resultPath){
		doCompute(resultPath);
	}
	
	public JustsReader(String resultPath, String debugMethod){
		if(debugMethod.equalsIgnoreCase("protegebl")){
			doComputeForProtege(resultPath);
		} else if(debugMethod.equalsIgnoreCase("radonpat")){
			if(resultPath.contains("km1500-3000")){
				System.out.println("stop");
			}
			doComputeForRadonPat(resultPath);
		} else {
			if(debugMethod.equalsIgnoreCase("pelletbl") ){
				doComputeForMaa(resultPath);
			} else {
				doCompute(resultPath);
			}			
		}
		
	}
		
	
	private void doCompute(String logPath) {
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneMUPSBegin = false;
				
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {	
				String timeStr = getTime(oneLine);
				if(timeStr.length() > 0){
					time = Long.valueOf(timeStr);
					if(time > DebuggingParameters.timeout){
						time = DebuggingParameters.timeout;
					}
					continue;
				} else if(oneLine.indexOf("conflict <") != -1 
						|| oneLine.indexOf("Explanation <") != -1 
						|| oneLine.indexOf("Found ") != -1 
						|| oneLine.indexOf("MIS <") != -1 
						|| oneLine.startsWith("<")
						|| oneLine.startsWith("  Explanation")){
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS has been finished.
					if(oneLine.trim().length() == 0 && oneMUPSString.size()>0){
						// Add the found MUPS to the collection of MUPS
						justs.add(new HashSet<String>(oneMUPSString));
						// Set the start
						isOneMUPSBegin = false;
					} else {
						int index1 = oneLine.indexOf("]");
						if(index1 != -1){
							// Get the string after ]
							String axiomString = oneLine.substring(index1+1).trim();
							// Remove the first blank space if exists
							if(axiomString.indexOf(" ")==0){
								axiomString = axiomString.substring(1);
							}
							// Add the axiom string to the the collection of axiom strings.
							oneMUPSString.add(axiomString);							
						} 
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
	}
	
	
	
	private void doComputeForRadonPat(String logPath) {
		HashSet<String> oneMUPSString = new HashSet<String>();
		
		
		boolean isOneMUPSBegin = false;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {	
				/*if(oneLine.indexOf("Correctness Checking") != -1){
					justs.clear();
					continue;
				}	*/

				String timeStr = getTime(oneLine);
				if(timeStr.length() > 0){
					time = Long.valueOf(timeStr);
					if(time > DebuggingParameters.timeout){
						time = DebuggingParameters.timeout;
					}
					break;
				}  
				
				if(oneLine.indexOf("Justification <") != -1){
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS has been finished.
					if(oneLine.trim().length() == 0 && oneMUPSString.size()>0){
						// Add the found MUPS to the collection of MUPS
						justs.add(new HashSet<String>(oneMUPSString));
						// Set the start
						isOneMUPSBegin = false;
					} else {
						int index1 = oneLine.indexOf("]");
						if(index1 != -1){
							// Get the string after ]
							String axiomString = oneLine.substring(index1+1).trim();
							// Remove the first blank space if exists
							if(axiomString.indexOf(" ")==0){
								axiomString = axiomString.substring(1);
							}
							// Add the axiom string to the the collection of axiom strings.
							oneMUPSString.add(axiomString);							
						} 
					}
				}
			
				
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
	}
	
	
	private void doComputeForProtege(String logPath) {
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneMUPSBegin = false;
				//System.out.println(logPath);
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {	
				//System.out.println(oneLine);
				String timeStr = getTime(oneLine);
				if(timeStr.length() > 0){
					time = Long.valueOf(timeStr);
					if(time > DebuggingParameters.timeout){
						time = DebuggingParameters.timeout;
					}
					continue;
				} else if(oneLine.indexOf("Explanation ") != -1){
					isOneMUPSBegin = true;
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS is finished.
					if((oneLine.indexOf("Found explanation") != -1 
							|| oneLine.length() == 0 
							|| oneLine.startsWith("Debug time (ms):")) 
							|| oneLine.startsWith("[Info]")){
						// Add the found MUPS to the collection of MUPS
						justs.add(new HashSet<String>(oneMUPSString));
						oneMUPSString.clear();						
						isOneMUPSBegin = false;
					} else {
						// Add the axiom string to the the collection of axiom strings.
						oneMUPSString.add(oneLine.trim());	
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
	}
	
	int counter = 1;
	private void doComputeForMaa(String logPath) {
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneMUPSBegin = false;
				//System.out.println(logPath);
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {	
				//System.out.println(oneLine);
				String timeStr = getTime(oneLine);
				if(timeStr.length() > 0){
					time = Long.valueOf(timeStr);
					if(time > DebuggingParameters.timeout){
						time = DebuggingParameters.timeout;
					}
					continue;
				} else if(!isOneMUPSBegin && oneLine.indexOf("Found explanation ") != -1){
					isOneMUPSBegin = true;
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS is finished.
					if((oneLine.indexOf("Found explanation") != -1 
							|| oneLine.length() == 0 
							|| oneLine.startsWith("[Info]")) ){
						// Add the found MUPS to the collection of MUPS
						if(oneMUPSString.size() > 0){
							justs.add(new HashSet<String>(oneMUPSString));
							oneMUPSString.clear();
						} else {
							counter ++;
						}
					} else {
						// Add the axiom string to the the collection of axiom strings.
						if(oneLine.trim().startsWith("[")){
							oneLine = oneLine.substring(oneLine.indexOf("]")+2);
						}
						oneMUPSString.add(oneLine.trim());	
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		System.out.println("counter : "+counter);
	}
	
	private String getTime(String line){
		String timeStr = "";
		String prefix = "Time : ";
		if(line.startsWith(prefix)){
			timeStr = line.substring(prefix.length());
		} else {
			prefix = " Time (ms)";
			if(line.startsWith(prefix)){
				int symbolIndex = line.indexOf(":");
				timeStr = line.substring(symbolIndex+1).trim();				
			} 
		}
		int symbolIndex = timeStr.indexOf(" ");
		if(symbolIndex != -1){
			timeStr = timeStr.substring(0, symbolIndex).trim();
		}
		if(timeStr.contains("ms")){
			System.out.println("stop");
		}
		return timeStr;
	}

	
	public void printJusts(HashSet<HashSet<String>> allMUPSString){
		int mupsCounter = 0;
		for(HashSet<String> oneMUPSString : allMUPSString){
			mupsCounter ++;
			System.out.println("MUPS "+mupsCounter);
			
			int axiomCounter = 0;
			for(String oneString : oneMUPSString){
				System.out.println((axiomCounter++)+"> "+oneString);
			}
			System.out.println();
		}
	}
	
	
	public HashSet<HashSet<String>> getJusts(){
		return justs;
	}
	
	public long getTime(){
		return time;
	}

}
