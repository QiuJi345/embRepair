package edu.njupt.radon.repair;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;

public class RankWithShapley {
	
	public HashMap<OWLAxiom, Double> computeRanks(HashSet<HashSet<OWLAxiom>> sets) {
		HashMap<OWLAxiom, Double> scores = new HashMap<OWLAxiom, Double>();
		for (HashSet<OWLAxiom> set : sets) {			
			for (OWLAxiom ax : set) {
				if(!scores.containsKey(ax)){
					double score = getScore(sets, ax);
					score = new BigDecimal(score).setScale(2, RoundingMode.HALF_UP).doubleValue();
					scores.put(ax, score);
				}
			}					
		}

		return scores;
	
	}
	
	public double getScore(HashSet<HashSet<OWLAxiom>> sets, OWLAxiom ax) {
		double score = 0;
		for (HashSet<OWLAxiom> set : sets) {			
			if(set.contains(ax)) {
				score += 1.0 / set.size();
			}
		}
		return score;
	}


}
