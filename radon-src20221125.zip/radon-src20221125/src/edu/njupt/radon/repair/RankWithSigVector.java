package edu.njupt.radon.repair;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.exp.as2022.IncoherenceRepair;

public class RankWithSigVector {
	
	OWLOntology onto;
	public HashMap<OWLAxiom, Double> axiomRankMap;
	Vector<OWLAxiom> axiomList = new Vector<>();
	HashMap<Vector<Integer>,Double> pairSims = new HashMap<Vector<Integer>,Double>();
	String ontoName;
		
	public RankWithSigVector(OWLOntology onto, String ontoName)  {
		this.onto = onto;
		this.ontoName = ontoName;
		axiomRankMap = new HashMap<OWLAxiom, Double>();
		iniSimList();
		iniAxiomIDs();
	}
	
	private void iniSimList() {
		//String path = "onto/info/"+DebuggingParameters.ontoName+"_cos.txt"; 
		String path = "as2022/sim-"+IncoherenceRepair.modelName+"-"+IncoherenceRepair.edName+"/"+
		               ontoName+"_sig"+"_"+IncoherenceRepair.edName+".txt";
		System.out.println("reading similarity file...");
		String line = null;
		try {
			FileInputStream fileInputStream = new FileInputStream(path);
			BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				Vector<Integer> pair = new Vector<Integer>();
				pair.add(Integer.valueOf(info[0]));
				pair.add(Integer.valueOf(info[1]));
				this.pairSims.put(pair, Double.valueOf(info[2]));
			}
			br.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		}		
		System.out.println(" simList size: "+pairSims.size());
	}
	
	public void iniAxiomIDs() {
		String path = "as2022/nlp/"+ontoName+"_axiomList.txt";
		
		HashSet<OWLAxiom> allAxiomsDyn = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		System.out.println("reading axiom ID file...");
		String line = null;
		try {
			FileInputStream fileInputStream = new FileInputStream(path);
			BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream, "UTF-8"));
			while ((line = br.readLine()) != null) {
				//System.out.println(" transfering axiom: "+line);
				boolean found = false;
				for(OWLAxiom ax : allAxiomsDyn) {
					if(ax.toString().equals(line)) {
						axiomList.add(ax);
						allAxiomsDyn.remove(ax);
						found = true;
						break;
					}
				}
				if(found) {
					found = false;
				} else {
					System.out.println("error");
				}
			}
			br.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		}	
	    System.out.println(" axiomStrList size: " + axiomList.size());
	}
	
	/**
	 * In a conflict, an axiom is chosen if its rank w.r.t. signatures is lower than a threshold.
	 * 
	 * @param conflicts
	 * @param threshold
	 * @return
	 */
	public HashMap<OWLAxiom, Double> computeRanks(HashSet<HashSet<OWLAxiom>> conflicts) {	
		// Compute the relationship between an axiom and its rank
		HashSet<OWLAxiom> conflictUnion = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> conflict : conflicts) {
			conflictUnion.addAll(conflict);
		}
		this.computeRanksForAxioms(conflictUnion);		
		return axiomRankMap;
	}
		
	public HashMap<OWLAxiom, Double> computeRanksForAxioms(HashSet<OWLAxiom> axiomSet) {
		for(OWLAxiom axiom : axiomSet) {
			double rank = computeRankForAxiom(axiom);		
			//System.out.println("axiom in MUPS: "+ axiom.toString()+" , rank = "+rank);		
			this.axiomRankMap.put(axiom, rank);	
		}
		return axiomRankMap;
	}

	
	public double computeRankForAxiom(OWLAxiom axiom) {
		double sim = 0;
		int counter = 0;
		for(OWLAxiom a : onto.getLogicalAxioms()) {
			if(a.equals(axiom)) {
				continue;
			}
			int num = computeIntersection(axiom, a);
			if(num > 0) {
				counter ++;
				sim += this.getSimilarity(axiom, a);
			}
		}
		if(counter > 0) {
			sim = Math.round((sim / counter)*100);
		}			
		return sim;
	}
	
	public int computeIntersection(OWLAxiom a,OWLAxiom b) {
		Set<OWLEntity> set = new HashSet<OWLEntity>();
		set.addAll(a.getSignature());
		set.retainAll(b.getSignature());
		return set.size();
	}
	
	private Double getSimilarity(OWLAxiom a1, OWLAxiom a2) {		
		int i1 = axiomList.indexOf(a1);
		int i2 = axiomList.indexOf(a2);
		Vector<Integer> pair = new Vector<Integer>();
		if(i1 >= i2) {
			pair.add(i2);
			pair.add(i1);
		} else {
			pair.add(i1);
			pair.add(i2);
		}
		if(this.pairSims.containsKey(pair)) {
			return this.pairSims.get(pair);
		} else {
			return 0.0;
		}
	}

	
}
