package edu.njupt.radon.repair.ilp;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.exp.cplex2018.res.CollectMIPS;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.FileTools;
import ilog.concert.IloLPMatrix;
import ilog.cplex.IloCplex;

public class ILPRandomWeights {

	public static void main(String[] args) throws Exception {
		//String onto = "buggyPolicy";
		//String ontoPath = "data/kbs2014/" + onto + ".owl";

		OWLOntology sourceOnto = OWLTools.openOntology(RepairParameters.ontoPath);
		HashSet<HashSet<String>> ucMUPS = CollectMIPS.getMIPSStrFromText(RepairParameters.mupsPath);
		System.out.println("num of mupsstr: "+ucMUPS.size());
		HashSet<HashSet<OWLAxiom>> conflicts = CollectMIPS.transferStrToMUPS(sourceOnto, ucMUPS);
		System.out.println("num of conflicts: "+conflicts.size());
		
		ILPRandomWeights.run(RepairParameters.diagPath, conflicts);
		
	}
	

    public static void run(String resPath, HashSet<HashSet<OWLAxiom>> conflicts)  throws Exception {
		
        FileTools.fileExists(resPath);
				

		ArrayList<OWLAxiom> axiomsInMUPS = ILPTools.getAxiomList(conflicts);
		ArrayList<Double> weights = generateRandomWeights(axiomsInMUPS.size());
		double threshold = getThresholdWithMinMax(conflicts, axiomsInMUPS, weights);

		saveInfo(resPath, conflicts, axiomsInMUPS, weights);

		createModel(RepairParameters.diagPath, conflicts, axiomsInMUPS, weights, threshold);

		IloCplex cplex = new IloCplex();
		cplex.importModel(resPath + "ilpModel.mps");
		cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
		cplex.solve();

		int count = 0;
		if (cplex.populate()) {
			IloLPMatrix lp = (IloLPMatrix) cplex.LPMatrixIterator().next();
			double[] x = cplex.getValues(lp);
			for (int j = 0; j < x.length; ++j) {
				if (x[j] == 1) {
					count++;
				}
			}
		}
		cplex.end();
		System.out.println("\n\n");

		System.out.println("  size MUPS       : " + conflicts.size());
		System.out.println("  Axiom           : " + axiomsInMUPS.size());
		System.out.println("  Alpha           : " + threshold);
		System.out.println("  ILP function    : " + count);
	}
	

	static void createModel(String resPath,
			HashSet<HashSet<OWLAxiom>> Set, 
			ArrayList<OWLAxiom> Set_Axiom,
			ArrayList<Double> Wgh_Axiom, 
			double alpha) throws IOException {

		FileWriter ILP_File = new FileWriter(resPath + "ilpModel.mps");
		BufferedWriter Tamp_wrt = new BufferedWriter(ILP_File);
		PrintWriter File_Out = new PrintWriter(Tamp_wrt);

		int index = 1, i, nb = Set.size();

		File_Out.println("NAME exemples");
		File_Out.println("ROWS");
		File_Out.println("      N obj");

		for (i = 0; i < Set.size(); i++) {
			File_Out.println("      G c" + (i + 1));
		}

		File_Out.println();
		File_Out.println("COLUMNS");

		for (i = 0; i < Set_Axiom.size(); i++) {
			File_Out.println("      x" + (i + 1) + "  obj   " + Wgh_Axiom.get(i));
			index = 1;
			for (HashSet<OWLAxiom> confl : Set) {
				if (confl.contains(Set_Axiom.get(i))) {
					File_Out.println("      x" + (i + 1) + " c" + (index) + " 1");
				}
				index++;
			}
		}

		File_Out.println();
		File_Out.println("RHS");
		index = 1;

		if (Set.size() % 2 != 0) {
			nb = nb - 1;
			index = 0;
		}

		for (i = 0; i < nb; i++) {
			i++;
			File_Out.println("      rhs c" + (i) + "  1  c" + (i + 1) + "  1 ");
		}

		if (index == 0) {
			File_Out.println("      rhs c" + (nb + 1) + "  1");
		}

		File_Out.println();
		File_Out.println("BOUNDS");

		for (i = 0; i < Set_Axiom.size(); i++) {
			File_Out.println("      LI bnd x" + (i + 1) + " 0");
		}
		for (i = 0; i < Set_Axiom.size(); i++) {
			if (Wgh_Axiom.get(i) >= alpha) {
				File_Out.println("      UI bnd x" + (i + 1) + " 0");
			} else {
				File_Out.println("      UI bnd x" + (i + 1) + " 1");
			}
		}

		File_Out.println();
		File_Out.print("ENDATA");
		Tamp_wrt.close();
	}


	/**
	 * Randomly generate the given number of weights
	 * 
	 * @param size_Ax
	 * @return
	 */
	static ArrayList<Double> generateRandomWeights(int size_Ax) {
		ArrayList<Double> weights = new ArrayList<Double>();
		double value;
		for (int i = 0; i < size_Ax;) {
			value = Math.random() - 0.01;
			if (value > 0.0 & value < 1) {
				weights.add(value);
				i++;
			}
		}
		return weights;
	}

	// Need to be checked. There is some problem.
	static double getThresholdWithMinMax( HashSet<HashSet<OWLAxiom>> Set,
			ArrayList<OWLAxiom> Set_Axiom, ArrayList<Double> Wgh_Axiom) {
		// MimMax function
		double alpha = 0, Max = 0, Min = 1;
		int index;
		double weight;
		for (HashSet<OWLAxiom> confl : Set) {
			Max = 0;
			for (OWLAxiom axiom : confl) {
				index = Set_Axiom.indexOf(axiom);
				weight = Wgh_Axiom.get(index);
				if (Max < weight) {
					Max = weight;
				}
			}
			if (Min > Max) {
				Min = Max;
			}

		}
		alpha = Min;
		return alpha;
	}
	
	static double getThresholdWithMinMax(
			HashSet<HashSet<OWLAxiom>> sets,
			HashMap<OWLAxiom,Double> weights) {
		
		// MimMax function
		double max = 0;
		for (HashSet<OWLAxiom> axiomSet : sets) {
			double min = 1;
			for (OWLAxiom axiom : axiomSet) {
				double weight = weights.get(axiom);
				if (min > weight) {
					min = weight;
				}
			}
			if (min > max) {
				max = min;
			}
		}
		return max;
	}

	static void saveInfo(String resPath,
			HashSet<HashSet<OWLAxiom>> mupsUnion, 
			ArrayList<OWLAxiom> axiomsInMUPS,
			ArrayList<Double> axiomWeights) throws IOException {
		
		// Create the writer to output weights for all axioms in MUPS
		FileWriter weightsFile = new FileWriter(resPath + "/weightsInMUPS.txt");
		PrintWriter weightsPrinter = new PrintWriter(new BufferedWriter(weightsFile));

		// Create the writer to output the model information
		FileWriter modelFile = new FileWriter(resPath + "/modelInfo.txt");
		PrintWriter modelPrinter = new PrintWriter(new BufferedWriter(modelFile));

		// Output the variable and weight for each axiom in MUPS
		for (int i = 0; i < axiomsInMUPS.size(); i++) {
			modelPrinter.println("x_" + (i + 1) + "      " + axiomWeights.get(i));
		}
		modelPrinter.println();

		int index = 0;
		int j = 1;
		for (HashSet<OWLAxiom> oneMUPS : mupsUnion) {
			weightsPrinter.print("[ ");
			modelPrinter.print(" C_" + j);
			for (OWLAxiom axiom : oneMUPS) {
				index = axiomsInMUPS.indexOf(axiom);
				modelPrinter.print("    x_" + (index + 1));
				weightsPrinter.print("< " + axiom + " , " + axiomWeights.get(index) + " > ");
			}
			weightsPrinter.print(" ] ");
			modelPrinter.println();
			weightsPrinter.println();
			weightsPrinter.println();
		}
		weightsPrinter.close();
		modelPrinter.close();
	}

}
