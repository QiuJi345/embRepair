package edu.njupt.radon.repair.ilp;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;

import ilog.concert.IloException;
import ilog.concert.IloLPMatrix;
import ilog.cplex.IloCplex;

/**
 * @author khaoula
 *
 */
public class ILPAlgorithm {

	public String[] Cplex_Algorithm(HashSet<HashSet<OWLAxiom>> Set, String onto) throws IOException, IloException {
		String[] results = new String[4];

		ArrayList<OWLAxiom> Set_Axiom = ILPTools.getAxiomList(Set);
		
		createModel(onto, Set, Set_Axiom);

		HashSet<OWLAxiom> Remov_Axiom = new HashSet<OWLAxiom>();
		

		IloCplex cplex = new IloCplex();
		double Start = System.currentTimeMillis();
		cplex.importModel("ILP_Revsion.mps");
		cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
		double End = (System.currentTimeMillis() - Start) / 1000;
		String valeur = "";
		if (cplex.populate()) {
			IloLPMatrix lp = (IloLPMatrix) cplex.LPMatrixIterator().next();
			double[] x = cplex.getValues(lp);
			for (int j = 0; j < x.length; ++j) {
				if (x[j] == 1) {
					int i = 0;
					for (OWLAxiom axiom : Set_Axiom) {
						if (i == j) {
							Remov_Axiom.add(axiom);
						}
						i++;
					}
				}
			}
		}

		cplex.end();
		// Checking
		results[0] = " " + End;
		results[1] = " " + Remov_Axiom.size();
		results[2] = " " + ILPTools.Checking(Remov_Axiom, Set);
		results[3] = " " + Set_Axiom.size();

		return results;
	}

	public static void createModel(String path, 
			HashSet<HashSet<OWLAxiom>> multiSets,
			ArrayList<OWLAxiom> inputAxioms) throws IOException {

		FileWriter ilpFile = new FileWriter(path + "ilpModel1.mps");
		BufferedWriter writer = new BufferedWriter(ilpFile);
		PrintWriter outputs = new PrintWriter(writer);
		outputs.println("NAME examples");
		outputs.println();
		
		// Output axiom set information
		outputs.println("ROWS");
		outputs.println("      N obj");
		int numOfSets = multiSets.size();	
		/*int c = 0;
		for (HashSet<OWLAxiom> oneSet : multiSets) {
			outputs.println(c++);
			for(OWLAxiom a : oneSet){
				outputs.println(a.toString());
			}
			outputs.println();
		}*/
		for (int setCounter = 0; setCounter < numOfSets; setCounter++) {			
			outputs.println("      G c" + (setCounter + 1));
		}
		outputs.println();
		
		// Output axiom information
		outputs.println("COLUMNS");
		int axiomCounter = 0;
		for (OWLAxiom axiom : inputAxioms) {
			outputs.println("      x" + (axiomCounter + 1) + "  obj   " + 1);
			int setCounter = 0;
			for (HashSet<OWLAxiom> oneSet : multiSets) {
				if (oneSet.contains(axiom)) {
					outputs.println("      x" + (axiomCounter + 1) + " c" + (setCounter + 1) + " 1");
				}
				setCounter++;
			}
			axiomCounter++;
		}
		outputs.println();
		
		// Output 
		outputs.println("RHS");
		System.out.println("rani hna " + numOfSets);
		int index = 1;
		if (numOfSets % 2 != 0) {
			numOfSets = numOfSets - 1;
			index = 0;
		}
		for (int counter = 0; counter < numOfSets; counter++) {
			counter++;
			outputs.println("      rhs c" + (counter) + "  1  c" + (counter + 1) + "  1 ");
		}
		if (index == 0) {
			outputs.println("      rhs c" + (numOfSets + 1) + "  1");
		}
		outputs.println();
		
		// Output information of constrains
		outputs.println("BOUNDS");
		int Nb_Axiom = inputAxioms.size();
		for (axiomCounter = 0; axiomCounter < Nb_Axiom; axiomCounter++) {
			outputs.println("      LI bnd x" + (axiomCounter + 1) + " 0");
		}
		for (axiomCounter = 0; axiomCounter < Nb_Axiom; axiomCounter++) {
			outputs.println("      UI bnd x" + (axiomCounter + 1) + " 1");
		}
		outputs.println();
		
		// End of outputing information
		outputs.print("ENDATA");
		writer.close();
	}



	public static void save(String onto, HashSet<HashSet<OWLAxiom>> Union_Mups, HashSet<HashSet<OWLAxiom>> Union_Mips)
			throws IOException {
		FileWriter MUP_File = new FileWriter(onto + "_MUPS.txt");
		FileWriter MIP_File = new FileWriter(onto + "_MiPS.txt");

		BufferedWriter Tamp_MU = new BufferedWriter(MUP_File);
		BufferedWriter Tamp_MI = new BufferedWriter(MIP_File);

		PrintWriter File_MUP = new PrintWriter(Tamp_MU);
		int i = 1;
		for (HashSet<OWLAxiom> mup : Union_Mups) {
			File_MUP.println(i);
			i++;
			for (OWLAxiom axiom : mup) {
				File_MUP.print(ILPTools.change_Format_conf(axiom.toString()));
			}
			File_MUP.println();
			File_MUP.println();
		}
		Tamp_MU.close();

		PrintWriter File_MIP = new PrintWriter(Tamp_MI);
		i = 1;
		for (HashSet<OWLAxiom> mip : Union_Mips) {
			File_MIP.println(i);
			i++;
			for (OWLAxiom axiom : mip) {
				File_MIP.print(ILPTools.change_Format_conf(axiom.toString()));
			}
			File_MIP.println();
			File_MIP.println();
		}
		Tamp_MI.close();

	}




}
