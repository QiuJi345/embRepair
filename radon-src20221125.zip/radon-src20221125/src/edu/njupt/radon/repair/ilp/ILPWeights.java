package edu.njupt.radon.repair.ilp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.exp.cplex2018.res.CollectMIPS;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.repair.RepairWithWeight;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;
import ilog.concert.IloException;
import ilog.concert.IloLPMatrix;
import ilog.cplex.IloCplex;

public class ILPWeights {

	/*
    public static void run(String resPath, 
    		HashSet<HashSet<OWLAxiom>> conflicts,
    		HashMap<OWLAxiom,Double> weights)  throws Exception {
		
        FileTools.checkPath(resPath);
				

		ArrayList<OWLAxiom> axiomsInMUPS = getAxioms(conflicts);
		double threshold = getThresholdWithMinMax(conflicts, weights);

		//saveInfo(resPath, conflicts, axiomsInMUPS, weights);

		createModel(RepairParameters.diagPath, conflicts, axiomsInMUPS, weights, threshold);

		IloCplex cplex = new IloCplex();
		cplex.importModel(resPath + "ilpModel.mps");
		cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
		cplex.solve();

		
	}*/
    
 
	

	public static void createModel(String resPath,
			HashSet<HashSet<OWLAxiom>> axiomSets, 
			ArrayList<OWLAxiom> axiomsInSets,
			HashMap<OWLAxiom,Double> weights, double alpha) throws IOException {

		PrintWriter output = null;
		if(alpha > 1) {
			output = new PrintWriter(new BufferedWriter(new FileWriter(resPath + "ilpModel2.mps")));
		} else {
			output = new PrintWriter(new BufferedWriter(new FileWriter(resPath + "ilpModel3.mps")));
		}

		int index = 1, i, nb = axiomSets.size();

		output.println("NAME exemples");
		output.println("ROWS");
		output.println("      N obj");

		for (i = 0; i < axiomSets.size(); i++) {
			output.println("      G c" + (i + 1));
		}

		output.println();
		output.println("COLUMNS");

		for (i = 0; i < axiomsInSets.size(); i++) {
			output.println("      x" + (i + 1) + "  obj   " + weights.get(axiomsInSets.get(i)));
			index = 1;
			for (HashSet<OWLAxiom> confl : axiomSets) {
				if (confl.contains(axiomsInSets.get(i))) {
					output.println("      x" + (i + 1) + " c" + (index) + " 1");
				}
				index++;
			}
		}

		output.println();
		output.println("RHS");
		index = 1;

		if (axiomSets.size() % 2 != 0) {
			nb = nb - 1;
			index = 0;
		}

		for (i = 0; i < nb; i++) {
			i++;
			output.println("      rhs c" + (i) + "  1  c" + (i + 1) + "  1 ");
		}

		if (index == 0) {
			output.println("      rhs c" + (nb + 1) + "  1");
		}

		output.println();
		output.println("BOUNDS");

		for (i = 0; i < axiomsInSets.size(); i++) {
			output.println("      LI bnd x" + (i + 1) + " 0");
		}
		for (i = 0; i < axiomsInSets.size(); i++) {
			if (weights.get(axiomsInSets.get(i)) > alpha) {
				output.println("      UI bnd x" + (i + 1) + " 0");
			} else {
				output.println("      UI bnd x" + (i + 1) + " 1");
			}
		}

		output.println();
		output.print("ENDATA");
		output.close();
	}

	
	public static void saveInfo(String resPath,
			HashSet<HashSet<OWLAxiom>> mupsUnion, 
			ArrayList<OWLAxiom> axiomsInMUPS,
			HashMap<OWLAxiom,Double> weights) throws IOException {
		
		// Create the writer to output weights for all axioms in MUPS
		FileWriter weightsFile = new FileWriter(resPath + "models/weightsInMUPS.txt");
		PrintWriter weightsPrinter = new PrintWriter(new BufferedWriter(weightsFile));

		// Create the writer to output the model information
		FileWriter modelFile = new FileWriter(resPath + "models/modelInfo.txt");
		PrintWriter modelPrinter = new PrintWriter(new BufferedWriter(modelFile));

		// Output the variable and weight for each axiom in MUPS
		for (int i = 0; i < axiomsInMUPS.size(); i++) {
			modelPrinter.println("x_" + (i + 1) + "      " + weights.get(axiomsInMUPS.get(i)));
		}
		modelPrinter.println();

		int index = 0;
		int j = 1;
		for (HashSet<OWLAxiom> oneMUPS : mupsUnion) {			
			modelPrinter.print(" C_" + j);
			weightsPrinter.println(" MUPS ("+j+"):");
			int axCounter = 1;
			for (OWLAxiom axiom : oneMUPS) {	
				weightsPrinter.print(" ["+(axCounter++)+"] ");
				index = axiomsInMUPS.indexOf(axiom);
				modelPrinter.print("    x_" + (index + 1));
				weightsPrinter.println(axiom.toString() + " : " + weights.get(axiom));
			}
			weightsPrinter.println();
			modelPrinter.println();
			weightsPrinter.println();
			weightsPrinter.println();
			j++;
		}
		weightsPrinter.close();
		modelPrinter.close();
	}

}
