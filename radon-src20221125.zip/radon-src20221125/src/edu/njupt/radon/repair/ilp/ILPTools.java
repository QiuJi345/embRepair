package edu.njupt.radon.repair.ilp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import ilog.concert.IloException;
import ilog.concert.IloLPMatrix;
import ilog.cplex.IloCplex;

public class ILPTools {
	

	public static void assignWeights(OWLOntology onto, 
			HashMap<OWLAxiom,Double> weights, double defaultWeight) {
		for(OWLAxiom ax : onto.getLogicalAxioms()) {
			if(!weights.containsKey(ax)) {
				weights.put(ax, defaultWeight);
			}
		}
	}
	
	public static double getThresholdWithMinMax(
			HashSet<HashSet<OWLAxiom>> sets,
			HashMap<OWLAxiom,Double> weights) {
		
		// MimMax function
		double max = 0;
		for (HashSet<OWLAxiom> axiomSet : sets) {
			double min = 1;
			for (OWLAxiom axiom : axiomSet) {
				double weight = weights.get(axiom);
				if (min > weight) {
					min = weight;
				}
			}
			if (min > max) {
				max = min;
			}
		}
		return max;
	}
	
	/**
	 * Randomly generate the given number of weights
	 * 
	 * @param size_Ax
	 * @return
	 */
	public static ArrayList<Double> generateRandomWeights(int size_Ax) {
		ArrayList<Double> weights = new ArrayList<Double>();
		double value;
		for (int i = 0; i < size_Ax;) {
			value = Math.random() - 0.01;
			if (value > 0.0 & value < 1) {
				weights.add(value);
				i++;
			}
		}
		return weights;
	}
	

	public static boolean Checking(HashSet<OWLAxiom> Remov_Axiom, HashSet<HashSet<OWLAxiom>> Union_Mups) {
		boolean check = true;
		for (HashSet<OWLAxiom> confl : Union_Mups) {
			if (check == true) {
				check = false;
				for (OWLAxiom axiom : Remov_Axiom) {
					if (confl.contains(axiom)) {
						check = true;
					}
				}
			}
		}

		return check;
	}
	
	public static ArrayList<OWLAxiom> getAxiomList(HashSet<HashSet<OWLAxiom>> Union_Mups) {
		ArrayList<OWLAxiom> Set_Axiom = new ArrayList<OWLAxiom>();
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> confl : Union_Mups) {
			axioms.addAll(confl);
		}
		Set_Axiom.addAll(axioms);
		return Set_Axiom;
	}



	
	public static String change_Format_conf(String variable) {
		String variable0 = "", variable1 = "", variable2 = "";
		int indice1 = 0, indice2 = 0;

		indice1 = variable.indexOf("(") + 1;
		variable0 = (String) variable.subSequence(0, indice1);
		variable = variable.replace(variable0, "");
		variable = variable.replace(")", "");
		indice1 = variable.indexOf(" ") + 1;
		variable2 = (String) variable.subSequence(0, indice1);
		variable = variable.replace(variable2, "");
		variable2 = change_Format(variable2);
		variable1 = change_Format(variable);
		variable = variable0 + variable2 + " , " + variable1 + ")";
		return variable;
	}
	
	public static String change_Format(String variable) {
		int indice1 = 0, indice2 = 0;
		indice1 = variable.indexOf("#") + 1;
		indice2 = variable.length();
		variable = (String) variable.subSequence(indice1, indice2);
		variable = variable.replace(" ", "");
		variable = variable.replace(">", "");
		return variable;
	}
	
	public static HashSet<OWLAxiom> getCplexResult(IloCplex cplex, ArrayList<OWLAxiom> Set_Axiom)
			throws IloException {
        HashSet<OWLAxiom> axiomSet = new HashSet<OWLAxiom>();
		if (cplex.populate()) {
			IloLPMatrix lp = (IloLPMatrix) cplex.LPMatrixIterator().next();
			double[] x = cplex.getValues(lp);
			//System.out.println("cplex result: "+x);
			for (int j = 0; j < x.length; ++j) {
				if (x[j] == 1) {
					int i = 0;
					for (OWLAxiom axiom : Set_Axiom) {
						if (i == j) {
							axiomSet.add(axiom);
						}
						i++;
					}
				}
			}
		}
		return axiomSet;
	}
	
	public static void printAxioms(HashSet<OWLAxiom> axioms){
		int i = 0;
		for(OWLAxiom axiom : axioms){
			System.out.println("["+(i++)+"] "+axiom.toString());;
		}
		System.out.println();
	}
	
	public static void printAxioms(HashSet<OWLAxiom> axioms, HashMap<OWLAxiom,Double> weights){
		int i = 0;
		for(OWLAxiom axiom : axioms){
			System.out.println("["+(i++)+"] "+axiom.toString()+" : "+weights.get(axiom));;
		}
		System.out.println();
	}

}
