
package edu.njupt.radon.repair;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import edu.njupt.radon.result.RevisionResult;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.DumpFile;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 24.07.2007
 */
public class RepairWithWeight {
	
	public static double maxWeight = 1.0;
	
	public static HashMap<OWLAxiom, Double> scores = new HashMap<OWLAxiom, Double>();
	
	public static void main(String[] args) throws Exception {
		String path = "results/ecai2008/66_revisionResult.dump";
		String ns = "http://www.text2onto.org/ontology#";
		HashMap<OWLAxiom,Double> confvalues = 
			(HashMap<OWLAxiom, Double>)DumpFile.getObject("results/dump/confidenceValues/km1500_i500.dump");
				
		RevisionResult rs = (RevisionResult)DumpFile.getObject(path);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = rs.getMUPS();
		HashSet<OWLAxiom> ax = rs.getOriginalOnto();
		HashSet<OWLAxiom> rmAx = new HashSet<OWLAxiom>();
		for(OWLClass cl : mups.keySet()){
			HashSet<HashSet<OWLAxiom>> mips = mups.get(cl);
			HashSet<HashSet<OWLAxiom>> clMUPSSubset = RepairWithWeight.getIntersection(ax, mips);
			System.out.println("cl MUPS : ");
			CommonTools.printMultiSets(clMUPSSubset, ns, confvalues);
			
			
			HashSet<HashSet<OWLAxiom>> diags = 
				RepairWithWeight.getLowWeights(clMUPSSubset, confvalues);
			System.out.println("diagnosis : ");
			CommonTools.printMultiSets(diags, ns, confvalues);
			HashSet<OWLAxiom> minHS = RepairWithWeight.getOneDiagnoseByHST(diags);
			System.out.println("minimal diagnosis : ");
			CommonTools.printOneSet(new Vector<OWLAxiom>(minHS), ns, confvalues);
			rmAx.addAll(minHS);
		}
		ax.addAll(rs.getNewOnto());
		ax.removeAll(rmAx);
		System.out.println(ReasoningTools.isCoherent(ax));
		
	}
	
	private static HashSet<HashSet<OWLAxiom>> getIntersection(HashSet<OWLAxiom> onto, 
			HashSet<HashSet<OWLAxiom>> sets){
		HashSet<HashSet<OWLAxiom>> ax = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<OWLAxiom> set : sets){
			HashSet<OWLAxiom> x = new HashSet<OWLAxiom>();
			for(OWLAxiom a : set){
				if(onto.contains(a)){
					x.add(a);
				}
			}
			if(x.size()>0){
				ax.add(x);
			}
		}
		
		return ax;
	}
	
	public static HashSet<HashSet<OWLAxiom>> getLowWeights(HashSet<HashSet<OWLAxiom>> sets,
			HashSet<OWLAxiom> tbrAx, HashMap<OWLAxiom, Double> w) {
		HashSet<HashSet<OWLAxiom>> highScoreMips = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> mips_t = new HashSet<HashSet<OWLAxiom>>();
		
		if(tbrAx!=null && tbrAx.size()>0){
			for(HashSet<OWLAxiom> oneMips : sets){
				HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>();
				for(OWLAxiom a : oneMips){				
					if(tbrAx.contains(a)){
						subset.add(a);
					}
				}
				if(subset.size()>0){
					mips_t.add(subset);
				}
			}
		} else {
			mips_t.addAll(sets);
		}
		highScoreMips = getLowWeights(mips_t, w);	

		return highScoreMips;
	}
	
	public static HashSet<HashSet<OWLAxiom>> getLowWeights (HashSet<HashSet<OWLAxiom>> sets, 
			HashMap<OWLAxiom, Double> weights){
		
		HashSet<HashSet<OWLAxiom>> highScoreMips = new HashSet<HashSet<OWLAxiom>>();
		scores.clear();
		for (HashSet<OWLAxiom> mip : sets){
			HashMap<Double, HashSet<OWLAxiom>> scoreMipsMap = new HashMap<Double, HashSet<OWLAxiom>>();
			Double minscore = maxWeight;
			for (OWLAxiom axiomInSet: mip){
				Double score = weights.get(axiomInSet);
               
                if (score == null){
                	// when no such axiom exist, just assign 1
                	score = maxWeight;
                }
				
				if (score < minscore){
					minscore = score;
				}
				HashSet<OWLAxiom> as = scoreMipsMap.get(score);
				if (as == null){
					as = new HashSet<OWLAxiom>();
				}
				as.add(axiomInSet); 
				
				scoreMipsMap.put(score, as);
			}
			
			highScoreMips.add(scoreMipsMap.get(minscore));
			
			for(OWLAxiom a : scoreMipsMap.get(minscore)){
				if(!scores.containsKey(a)){
					scores.put(a, minscore);
				}
			}	
			
		}
		
		return highScoreMips;
	}
	
	public static HashSet<OWLAxiom> getOneDiagnoseByHST(HashSet<HashSet<OWLAxiom>> sets){
		HashSet<OWLAxiom> diagnose = new HashSet<OWLAxiom>();
		HSTDiagnose diag = new HSTDiagnose();
		diagnose = diag.getOneMinHS(sets);		
		return diagnose;
	}
	
	public static HashSet<OWLAxiom> getOneDiagnose(HashSet<HashSet<OWLAxiom>> sets){
		HashSet<OWLAxiom> diagnose = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> mip: sets){
			for (Iterator i = mip.iterator(); i.hasNext(); ){
				OWLAxiom a = (OWLAxiom)i.next();
				if (!diagnose.contains(a)){
					diagnose.add(a);
					break;
				}
			}
		}
		
		return diagnose;
	}

}
