package edu.njupt.radon.repair;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

public class LinearDiagnoseWithWeight {
	
	OWLOntology onto ;
	Set<OWLAxiom> axiomsToBeAdded ;
	public LinearDiagnoseWithWeight(OWLOntology onto, 
			Set<OWLAxiom> axioms){
		this.onto = onto;
		this.axiomsToBeAdded = new HashSet<OWLAxiom>(axioms);
	}

}
