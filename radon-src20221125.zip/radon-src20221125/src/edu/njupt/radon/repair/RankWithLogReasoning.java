package edu.njupt.radon.repair;

import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.reasoning.ReasoningTask;

public class RankWithLogReasoning {
	OWLOntology onto;
	
	public HashMap<OWLAxiom, HashSet<OWLClass>> axiomUnsatClaMap; //MUPS�е�һ����������ز����������Ĺ�ϵ�����ù���������ĳ��������������MUPS�У�
	public HashMap<OWLAxiom, HashSet<OWLAxiom>> axiomSOSMap; // Justs�е�һ���������������֮��Ĺ�ϵ�����ù���������ĳ�����۵Ľ����У�
	
	public HashMap<OWLClass, HashSet<OWLClass>> ocDescendants;
	public HashMap<OWLClass, HashSet<OWLClass>> ocAncestors;
	
	public HashMap<OWLAxiom, Double> axiomRankMap;
	public HashMap<Double, HashSet<OWLAxiom>> rankAxiomsMap;
	
	boolean enableImpactUnsat = true;
	
	ReasoningTask task;
	
	int total = 0;
		
	public RankWithLogReasoning(OWLOntology onto) {
		axiomSOSMap = new HashMap<OWLAxiom, HashSet<OWLAxiom>>();
		ocDescendants = new HashMap<OWLClass, HashSet<OWLClass>>();
		ocAncestors = new HashMap<OWLClass, HashSet<OWLClass>>();
		axiomRankMap = new HashMap<OWLAxiom, Double>();
		rankAxiomsMap = new HashMap<Double, HashSet<OWLAxiom>>();
		
		this.onto = onto;
		task = new ReasoningTask(onto, OWL.manager);
	}
	
	public HashMap<OWLAxiom, Double> computeRanks(HashSet<HashSet<OWLAxiom>> conflicts) {	
		// ��conflicts��ÿ���������������Ƶ��������ۣ����ֹ�ע�����ͣ�
		HashSet<OWLAxiom> conflictUnion = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> conflict : conflicts) {
			conflictUnion.addAll(conflict);
		}
		int total = 0;
		for(OWLAxiom axiom : conflictUnion) {
			computeRelaventEntailments(axiom);
			// create the relationship between an axiom and its rank
			double rank = 0;		
			if (axiomSOSMap.containsKey(axiom)) {
				rank = this.axiomSOSMap.get(axiom).size();
				total += rank;			
			}		
			this.axiomRankMap.put(axiom, rank);	
		}
		for(OWLAxiom axiom : conflictUnion) {			
			double rank = Math.round(((axiomRankMap.get(axiom)*1.0)/total)*100);			
			this.axiomRankMap.put(axiom, rank);	
		}
		return this.axiomRankMap;
	}
	
	
	public void computeRelaventEntailments(OWLAxiom axiom) {				
		if (axiom instanceof OWLSubClassOfAxiom) {
			// ���A��B�����࣬��A��ÿ�����ﶼ��B��ÿ�����ȵ�����
			OWLSubClassOfAxiom subAx = (OWLSubClassOfAxiom) axiom;
			if (!subAx.getSubClass().isAnonymous() && !subAx.getSuperClass().isAnonymous()) {
				OWLClass sub = (OWLClass) subAx.getSubClass();
				OWLClass sup = (OWLClass) subAx.getSuperClass();
				
				HashSet<OWLClass> subs = this.getSubs(sub);
				HashSet<OWLClass> sups = this.getSups(sup);
								
				for (OWLClass subOc : subs) {
					for (OWLClass supOc : sups) {
						if (!supOc.equals(OWL.Thing) && !subOc.equals(OWL.Nothing)) {
							OWLSubClassOfAxiom ax = OWL.factory.getOWLSubClassOfAxiom(subOc, supOc);
							this.addAxiom(axiom, ax);
						}
					}					
				}
			}						
		} else if (axiom instanceof OWLDisjointClassesAxiom) {
			// ���A��B���ཻ����A�����ﶼ��B���ཻ
			OWLDisjointClassesAxiom ax = (OWLDisjointClassesAxiom) axiom;
			HashSet<OWLClass> ocs = new HashSet<OWLClass>();
			
			for (OWLClassExpression desc : ax.getClassExpressions()) {
				if ((desc instanceof OWLClass) && !desc.isOWLNothing()) {
					ocs.add(desc.asOWLClass());
				}
			}
			
			if (ocs.size()>1) {
				for(OWLClass dis1 : ocs) {
					HashSet<OWLClass> descendants = this.getSubs(dis1);
					if (enableImpactUnsat) {//���һ����
						for(OWLClassExpression sub : dis1.getSubClasses(onto)) {
							if(!sub.isAnonymous() && !sub.isOWLNothing()) {
								descendants.add(sub.asOWLClass());
							}
						}						
					}
					for(OWLClass desc : task.getDescendants(dis1)) {
						if(desc.isOWLNothing()) {
							continue;
						}
						// ��ʱδʵ�֣�|| !pellet.equivalentClassesOf(desc1).contains(ontology.getOWLDataFactory().getOWLNothing())
						if (enableImpactUnsat ) {
							for (OWLClass dis2 : ocs) {
								if(dis1.equals(dis2)) {
									continue;
								}
								if (!dis2.equals(desc)) {
									HashSet<OWLClass> newDis = new HashSet<OWLClass>();
									newDis.add(desc);
									newDis.add(dis2);
									OWLDisjointClassesAxiom newAx = OWL.factory.getOWLDisjointClassesAxiom(newDis);
									this.addAxiom(axiom, newAx);
								}
							}
						}
					}
				}				
			}
		} else if (axiom instanceof OWLObjectPropertyDomainAxiom) {
			// �������p��domain��D����D��ÿ������Ҳ����p��domain
			OWLObjectPropertyDomainAxiom pd = (OWLObjectPropertyDomainAxiom) axiom;
			if (pd.getDomain() instanceof OWLClass) {
				OWLClass dom = (OWLClass) pd.getDomain();
				for(OWLClass sup : this.getSups(dom)) {
					OWLAxiom ax = OWL.factory.getOWLObjectPropertyDomainAxiom(pd.getProperty(), sup);
					this.addAxiom(axiom, ax);
				}
			}
		} else if (axiom instanceof OWLDataPropertyDomainAxiom) {
			OWLDataPropertyDomainAxiom pd = (OWLDataPropertyDomainAxiom) axiom;
			if (pd.getDomain() instanceof OWLClass) {
				OWLClass dom = (OWLClass) pd.getDomain();
				for(OWLClass sup : getSups(dom)) {
					OWLAxiom ax = OWL.factory.getOWLDataPropertyDomainAxiom(pd.getProperty(), sup);
					this.addAxiom(axiom, ax);
				}
			}
		} else if (axiom instanceof OWLObjectPropertyRangeAxiom) {
			// �������p��range��D����D��ÿ������Ҳ����p��range
			OWLObjectPropertyRangeAxiom pd = (OWLObjectPropertyRangeAxiom) axiom;
			if (pd.getRange() instanceof OWLClass) {
				OWLClass ran = (OWLClass) pd.getRange();
				for (OWLClass sup : getSups(ran)) {
					OWLAxiom ax = OWL.factory.getOWLObjectPropertyRangeAxiom(pd.getProperty(), sup);
					this.addAxiom(axiom, ax);
				}
			}
		} 		
	}
	
	private void addAxiom(OWLAxiom axiom, OWLAxiom entailment) {
		HashSet<OWLAxiom> elems = new HashSet<OWLAxiom>();
		elems.add(entailment);
		if (axiomSOSMap.containsKey(axiom)) {
			elems.addAll(axiomSOSMap.get(axiom));
		}
		this.axiomSOSMap.put(axiom, elems);
	}
	
	private HashSet<OWLClass> getSubs(OWLClass sub) {
		HashSet<OWLClass> subs = new HashSet<OWLClass>();
		if(this.ocDescendants.containsKey(sub)) {
			subs = this.ocDescendants.get(sub);
		} else {
			subs = task.getDescendants(sub);
			this.ocDescendants.put(sub, subs);
		}
		return subs;
	}
	
	private HashSet<OWLClass> getSups(OWLClass sup) {
		HashSet<OWLClass> sups = new HashSet<OWLClass>();
				
		if(this.ocAncestors.containsKey(sup)) {
			sups = this.ocAncestors.get(sup);
		} else {
			sups = task.getAncestors(sup);
			this.ocAncestors.put(sup, sups);
		}
		return sups;
	}
		
}
