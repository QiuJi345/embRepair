package edu.njupt.radon.repair;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

public class RankWithSignatures {
	
	OWLOntology onto;
	public HashMap<OWLAxiom, Double> axiomRankMap;
	HashMap<OWLEntity, Integer> entityFreq = new HashMap<OWLEntity, Integer>();
	int totalEntity = 0;
	
	public void main(String[] args) {}
	
	public RankWithSignatures(OWLOntology onto)  {
		this.onto = onto;
		axiomRankMap = new HashMap<OWLAxiom, Double>();
		for(OWLEntity ent : onto.getSignature()) {
			int counter = 0;
			for(OWLAxiom ax : onto.getLogicalAxioms()) {
				if(ax.getSignature().contains(ent)) {
					counter ++;
				}
			}
			entityFreq.put(ent, counter);
		}
		this.totalEntity = entityFreq.size();
	}
	
	/**
	 * In a conflict, an axiom is chosen if its rank w.r.t. signatures is lower than a threshold.
	 * 
	 * @param conflicts
	 * @param threshold
	 * @return
	 */
	public HashMap<OWLAxiom, Double> computeRanks(HashSet<HashSet<OWLAxiom>> conflicts) {	
		// Compute the relationship between an axiom and its rank
		HashSet<OWLAxiom> conflictUnion = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> conflict : conflicts) {
			conflictUnion.addAll(conflict);
		}
		this.computeRanksForAxioms(conflictUnion);		
		return axiomRankMap;
	}
		
	public HashMap<OWLAxiom, Double> computeRanksForAxioms(HashSet<OWLAxiom> axiomSet) {
		for(OWLAxiom axiom : axiomSet) {
			double rank = computeFreqSimilarity(axiom);		
			//System.out.println("axiom in MUPS: "+ axiom.toString()+" , rank = "+rank);		
			this.axiomRankMap.put(axiom, rank);	
		}
		return axiomRankMap;
	}

	
	public double computeRankForAxiom(OWLAxiom axiom) {
		double count = 0.0;
		for(OWLAxiom a : onto.getLogicalAxioms()) {
			if(a.equals(axiom)) {
				continue;
			}
			count += computeSimilarity(axiom, a);
		}
		return count;
	}
	
	public double computeSimilarity(OWLAxiom a,OWLAxiom b) {
		Set<OWLEntity> set1 = new HashSet<OWLEntity>(a.getSignature());
		Set<OWLEntity> set2 = new HashSet<OWLEntity>(b.getSignature());
		Set<OWLEntity> set = new HashSet<OWLEntity>(set1);
		set.addAll(set2);
		set1.retainAll(set2);		
		return (1.0*set1.size()) / set.size();
	}
	

	public double computeFreqSimilarity(OWLAxiom a) {
		int totalFreq = 0;
		for(OWLEntity ent : a.getSignature()) {
			int freq = entityFreq.get(ent);
			totalFreq += freq;
		}	
		double sim = Math.round(((totalFreq*1.0) / totalEntity)*100);
		return sim;
	}
	
	
}
