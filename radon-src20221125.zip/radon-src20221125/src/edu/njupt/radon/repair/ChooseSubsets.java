package edu.njupt.radon.repair;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;

public class ChooseSubsets {
	
	/**
	 * For a conflict, choose those axioms with ranks that are lower than a given threshold.
	 * If no axioms can be chosen, then choose those axioms with the lowest rank.
	 * 
	 * @param threshold
	 * @return
	 */
	public static HashSet<HashSet<OWLAxiom>> getSubsetsWithLowRanks(
			HashSet<HashSet<OWLAxiom>> conflicts,
			HashMap<OWLAxiom, Double> axiomRankMap, 
			double threshold) {
		
		HashSet<HashSet<OWLAxiom>> subsets = new HashSet<HashSet<OWLAxiom>>();				
		for (HashSet<OWLAxiom> conflict : conflicts) {
			HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>();
			HashMap<Double, HashSet<OWLAxiom>> map = new HashMap<Double, HashSet<OWLAxiom>>();		
			double lowestRank = 100000;
			for(OWLAxiom ax : conflict) {
				double rank = axiomRankMap.get(ax);
				if(rank <= threshold) {
					subset.add(ax);
				}
				if(rank < lowestRank) {
					lowestRank = rank;
				}
				HashSet<OWLAxiom> axes = new HashSet<OWLAxiom>();
				axes.add(ax);
				if(map.containsKey(rank)) {
					axes.addAll(map.get(rank));
				}
				map.put(rank, axes);	
			}
			// If no axioms are chosen, then choose those axioms in a conflict with the lowest rank 
			if(subset.size()==0) {
				subset.addAll(map.get(lowestRank));
			}
			subsets.add(subset);
		}
		return subsets;
	}
	
	public static HashSet<HashSet<OWLAxiom>> getSubsetsWithHighRanks(
			HashSet<HashSet<OWLAxiom>> conflicts,
			HashMap<OWLAxiom, Double> axiomRankMap, 
			double threshold) {
		
		HashSet<HashSet<OWLAxiom>> subsets = new HashSet<HashSet<OWLAxiom>>();				
		for (HashSet<OWLAxiom> conflict : conflicts) {
			HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>();
			HashMap<Double, HashSet<OWLAxiom>> map = new HashMap<Double, HashSet<OWLAxiom>>();		
			double highestRank = 0;
			for(OWLAxiom ax : conflict) {
				double rank = axiomRankMap.get(ax);
				if(rank >= threshold) {
					subset.add(ax);
				}
				if(rank > highestRank) {
					highestRank = rank;
				}
				HashSet<OWLAxiom> axes = new HashSet<OWLAxiom>();
				axes.add(ax);
				if(map.containsKey(rank)) {
					axes.addAll(map.get(rank));
				}
				map.put(rank, axes);	
			}
			// If no axioms are chosen, then choose those axioms in a conflict with the lowest rank 
			if(subset.size()==0) {
				subset.addAll(map.get(highestRank));
			}
			subsets.add(subset);
		}
		return subsets;
	}

	public static HashSet<HashSet<OWLAxiom>> getSubsetsLowTopk(
			HashSet<HashSet<OWLAxiom>> conflicts,
			HashMap<OWLAxiom, Double> axiomRankMap,
			int k) {			
		
		HashSet<HashSet<OWLAxiom>> subsets = new HashSet<HashSet<OWLAxiom>>();				
		for (HashSet<OWLAxiom> conflict : conflicts) {
			// create the relationship between a similarity and the axioms in a conflict with this similarity
			HashMap<Double, HashSet<OWLAxiom>> map = new HashMap<Double, HashSet<OWLAxiom>>();			
			for(OWLAxiom ax : conflict) {
				double sim = axiomRankMap.get(ax);
				HashSet<OWLAxiom> axes = new HashSet<OWLAxiom>();
				axes.add(ax);
				if(map.containsKey(sim)) {
					axes.addAll(map.get(sim));
				}
				map.put(sim, axes);
			}
			// order the similarities in an descending order
			Object[] sims = map.keySet().toArray();			
			Arrays.sort(sims);
			// Obtain the axioms  in a conflict with top k higher similarities
			int count = 0;
			HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>();		
			int len = sims.length;
			for(int i =0; (i < k)&&(i<len); i++) {
				double rank = (double)sims[i];
				subset.addAll(map.get(rank));
				count++;
				if(count >= k) {
					break;
				}
			}
			subsets.add(subset);
		}
		return subsets;
	}
	
	public static HashSet<HashSet<OWLAxiom>> getSubsetsHighTopk(
			HashSet<HashSet<OWLAxiom>> conflicts,
			HashMap<OWLAxiom, Double> axiomRankMap,
			int k) {			
		
		HashSet<HashSet<OWLAxiom>> subsets = new HashSet<HashSet<OWLAxiom>>();				
		for (HashSet<OWLAxiom> conflict : conflicts) {
			// create the relationship between a similarity and the axioms in a conflict with this similarity
			HashMap<Double, HashSet<OWLAxiom>> map = new HashMap<Double, HashSet<OWLAxiom>>();			
			for(OWLAxiom ax : conflict) {
				double sim = axiomRankMap.get(ax);
				HashSet<OWLAxiom> axes = new HashSet<OWLAxiom>();
				axes.add(ax);
				if(map.containsKey(sim)) {
					axes.addAll(map.get(sim));
				}
				map.put(sim, axes);
			}
			// order the similarities in an ascending order
			Object[] sims = map.keySet().toArray();			
			Arrays.sort(sims);
			// Obtain the axioms  in a conflict with top k higher similarities
			int count = 0;
			HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>();			
			for(int i = sims.length-1; i >= 0; i--) {
				double rank = (double)sims[i];
				subset.addAll(map.get(rank));
				count++;
				if(count >= k) {
					break;
				}
			}
			subsets.add(subset);
		}
		return subsets;
	}
}
