package edu.njupt.radon.repair;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;

import edu.njupt.radon.result.RevisionResult;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.DumpFile;

public class HSTDiagnose {
	
	private HashSet<HashSet<OWLAxiom>> justs;
	private HashSet<Vector<OWLAxiom>> hittingSets;
	int minLen = 1000;
	Vector<OWLAxiom> minHS = null;
	
	public static void main(String[] args){
		String path = "results/ecai2008/24_revisionResult.dump";
		String ns = "http://www.text2onto.org/ontology#";
		
		RevisionResult rs = (RevisionResult)DumpFile.getObject(path);
		HashSet<HashSet<OWLAxiom>> mips = rs.getMipsSubset();
		System.out.println("MIPS : ");
		CommonTools.printMultiSets(mips, ns);
		
		HSTDiagnose diag = new HSTDiagnose();
		HashSet<Vector<OWLAxiom>> diags = diag.getAllHittingSets(mips);
		System.out.println("diagnosis : ");
		Vector<Vector<OWLAxiom>> v = new Vector<Vector<OWLAxiom>>(diags);
		CommonTools.printMultiVectors(v, ns);
		HashSet<OWLAxiom> minHS = diag.getOneMinHS(mips);
		System.out.println("minimal diagnosis : ");
		CommonTools.printOneSet(minHS, ns);
	}
	
	public HSTDiagnose(){
		justs = new HashSet<HashSet<OWLAxiom>>();
		hittingSets = new HashSet<Vector<OWLAxiom>>();
	}
	
	public HashSet<OWLAxiom> getOneMinHS(HashSet<HashSet<OWLAxiom>> sets){
		this.getAllHittingSets(sets);			
		return new HashSet<OWLAxiom>(minHS); 
	}
		
	public HashSet<Vector<OWLAxiom>> getAllHittingSets(HashSet<HashSet<OWLAxiom>> sets) {
		
		HashSet<OWLAxiom> root = null;
		
		if((sets!=null)&&(sets.size()>0)){
			justs.addAll(sets);
			root = justs.iterator().next();
		}
		
		if(root==null){
			return null;
		}	        

		for (OWLAxiom axiom : root) {
			Vector<OWLAxiom> path = new Vector<OWLAxiom>();
			searchHST( axiom, path);
		}
	
		return hittingSets;
	}
	
	
	private void searchHST(OWLAxiom axiom,	Vector<OWLAxiom> path) {
			
		Vector<OWLAxiom> newPath = (Vector<OWLAxiom>) path.clone();
		HashSet<OWLAxiom> newJust = null;	
		newPath.add(axiom);
		
		if(newPath.size() >= minLen){
			return;
		}
							
		for (HashSet<OWLAxiom> exJust : justs ){
			if(!this.intersectant(exJust, newPath)){
				newJust = exJust;
				break;
			}			
		}
			
		if (newJust != null && newJust.size() > 0) {			
			for (OWLAxiom b : newJust) {
				searchHST(b, newPath); 
			}		
		} else {
			hittingSets.add(newPath);
			if(newPath.size()<minLen){
				minLen = newPath.size();
				minHS = newPath;
			}
		}		   
		
	}
	
	public boolean intersectant(HashSet<OWLAxiom> set, Vector<OWLAxiom> path){
		boolean flag = false;
		for(OWLAxiom a : path){
			if(set.contains(a)){
				flag = true;
				break;
			} 
		}
		return flag;
	}

}
