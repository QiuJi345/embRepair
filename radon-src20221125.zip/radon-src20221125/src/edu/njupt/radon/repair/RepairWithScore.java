
package edu.njupt.radon.repair;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import org.semanticweb.owlapi.model.OWLAxiom;

import edu.njupt.radon.result.RevisionResult;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.DumpFile;


/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 24.07.2007
 */
public class RepairWithScore {
		
	public static void main(String[] args) throws Exception {
		String path = "results/ecai2008/24_revisionResult.dump";
		String ns = "http://www.text2onto.org/ontology#";
		
		RevisionResult rs = (RevisionResult)DumpFile.getObject(path);
		HashSet<HashSet<OWLAxiom>> mips = rs.getMipsSubset();
		System.out.println("MIPS : ");
		CommonTools.printMultiSets(mips, ns);
		
		HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(mips);
		System.out.println("diagnosis : ");
		CommonTools.printMultiSets(diags, ns);
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags);
		System.out.println("minimal diagnosis : ");
		CommonTools.printOneSet(minHS, ns);
	}
	
	private static HashMap<OWLAxiom, Integer> axiomScore = new  HashMap<OWLAxiom, Integer>();
	
	public static HashMap<OWLAxiom, Integer> getScores(HashSet<HashSet<OWLAxiom>> sets,
			HashSet<OWLAxiom> tbrAx) {
		HashSet<HashSet<OWLAxiom>> mips_t = new HashSet<HashSet<OWLAxiom>>();
		
		if(tbrAx!=null && tbrAx.size()>0){
			for(HashSet<OWLAxiom> oneMips : sets){
				HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>();
				for(OWLAxiom a : oneMips){				
					if(tbrAx.contains(a)){
						subset.add(a);
					}
				}
				if(subset.size()>0){
					mips_t.add(subset);
				}
			}
		} else {
			mips_t.addAll(sets);
		}
		HashMap<OWLAxiom, Integer> scores = getScores(mips_t);	

		return scores;
	}
	
	public static HashMap<OWLAxiom, Integer> getScores(HashSet<HashSet<OWLAxiom>> sets) {
		HashMap<OWLAxiom, Integer> scores = new HashMap<OWLAxiom, Integer>();
		for (HashSet<OWLAxiom> set : sets) {			
			for (OWLAxiom a : set) {
				if(scores.containsKey(a)){
					scores.put(a, scores.get(a)+1);
				} else {
					scores.put(a, 1);
				}
			}					
		}

		return scores;
	
	}
	
	/**
	 * This method is to find axioms with the highest score from each axiom set .
	 * @param sets
	 * @param tbrAx axioms to be removed for resorting consistency
	 * @return
	 */
	public static HashSet<HashSet<OWLAxiom>> getHighScores(HashSet<HashSet<OWLAxiom>> sets,
			HashSet<OWLAxiom> tbrAx) {
		HashSet<HashSet<OWLAxiom>> highScoreMips = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> mips_t = new HashSet<HashSet<OWLAxiom>>();
		
		if(tbrAx!=null && tbrAx.size()>0){
			for(HashSet<OWLAxiom> oneMips : sets){
				HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>();
				for(OWLAxiom a : oneMips){				
					if(tbrAx.contains(a)){
						subset.add(a);
					}
				}
				if(subset.size()>0){
					mips_t.add(subset);
				}
			}
		} else {
			mips_t.addAll(sets);
		}
		highScoreMips = getHighScores(mips_t);	

		return highScoreMips;
	}
	
	/**
	 * This method is to find axioms with the highest score from each axiom set.
	 * 
	 * @param sets
	 * @return
	 */
	public static HashSet<HashSet<OWLAxiom>> getHighScores(HashSet<HashSet<OWLAxiom>> sets) {
		axiomScore.clear();
		HashSet<HashSet<OWLAxiom>> highScoreMips = new HashSet<HashSet<OWLAxiom>>();
		if(sets.isEmpty())
			return highScoreMips;
		for (HashSet<OWLAxiom> set : sets) {
			//System.out.println("**** current mips");
			//CommonTools.printAxioms(set);
			HashMap<Integer, HashSet<OWLAxiom>> scoreMipsMap = new HashMap<Integer, HashSet<OWLAxiom>>();
			int maxscore = 0;
			for (OWLAxiom a : set) {
				Integer score = score(sets, a);
				if (score > maxscore) {
					maxscore = score;
				}
				HashSet<OWLAxiom> as = scoreMipsMap.get(score);
				if (as == null) {
					as = new HashSet<OWLAxiom>();
				}
				as.add(a);
				scoreMipsMap.put(score, as);
			}
			highScoreMips.add(scoreMipsMap.get(maxscore));
			//System.out.println("**** axioms with high score");
			//CommonTools.printAxioms(scoreMipsMap.get(maxscore));
		}

		return highScoreMips;
	}
	
	/**
	 * This method is to compute the score of an axiom based on a set of axiom sets.
	 * 
	 * @param mips
	 * @param a
	 * @return
	 */
	private static int score(HashSet<HashSet<OWLAxiom>> multiSets, OWLAxiom a) {
		int score = 0;
		for (HashSet<OWLAxiom> oneSet : multiSets) {
			if (oneSet.contains(a)) {
				score++;
			}
		}
		return score;
	}
	
	public static HashSet<OWLAxiom> getOneDiagnoseByHST(HashSet<HashSet<OWLAxiom>> sets){
		HashSet<OWLAxiom> diagnose = new HashSet<OWLAxiom>();
		if(sets.isEmpty())
			return diagnose;
		HSTDiagnose diag = new HSTDiagnose();
		diagnose = diag.getOneMinHS(sets);		
		return diagnose;
	}
	
	public static HashSet<OWLAxiom> getOneRandomDiagnose(HashSet<HashSet<OWLAxiom>> sets){
		HashSet<OWLAxiom> diagnose = new HashSet<OWLAxiom>(); 
		for (HashSet<OWLAxiom> set: sets){
			for (Iterator i = set.iterator(); i.hasNext(); ){
				OWLAxiom a = (OWLAxiom)i.next();
				diagnose.add(a);
				break;
			}
		}
		
		return diagnose;
	}

}
