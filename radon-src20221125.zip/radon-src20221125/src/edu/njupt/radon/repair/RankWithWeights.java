package edu.njupt.radon.repair;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import edu.njupt.radon.result.RevisionResult;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.DumpFile;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class RankWithWeights {
	
	public static double maxWeight = 1.0;
	
	public static HashMap<OWLAxiom, Double> scores = new HashMap<OWLAxiom, Double>();
	
	
	private static HashSet<HashSet<OWLAxiom>> getIntersection(HashSet<OWLAxiom> onto, 
			HashSet<HashSet<OWLAxiom>> sets){
		HashSet<HashSet<OWLAxiom>> ax = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<OWLAxiom> set : sets){
			HashSet<OWLAxiom> x = new HashSet<OWLAxiom>();
			for(OWLAxiom a : set){
				if(onto.contains(a)){
					x.add(a);
				}
			}
			if(x.size()>0){
				ax.add(x);
			}
		}
		
		return ax;
	}
	
		
	public static HashSet<HashSet<OWLAxiom>> compute (HashSet<HashSet<OWLAxiom>> sets, 
			HashMap<OWLAxiom, Double> weights){
		
		HashSet<HashSet<OWLAxiom>> highScoreMips = new HashSet<HashSet<OWLAxiom>>();
		scores.clear();
		for (HashSet<OWLAxiom> mip : sets){
			HashMap<Double, HashSet<OWLAxiom>> scoreMipsMap = new HashMap<Double, HashSet<OWLAxiom>>();
			Double minscore = maxWeight;
			for (OWLAxiom axiomInSet: mip){
				Double score = weights.get(axiomInSet);
               
                if (score == null){
                	// when no such axiom exist, just assign 1
                	score = maxWeight;
                }
				
				if (score < minscore){
					minscore = score;
				}
				HashSet<OWLAxiom> as = scoreMipsMap.get(score);
				if (as == null){
					as = new HashSet<OWLAxiom>();
				}
				as.add(axiomInSet); 
				
				scoreMipsMap.put(score, as);
			}
			
			highScoreMips.add(scoreMipsMap.get(minscore));
			
			for(OWLAxiom a : scoreMipsMap.get(minscore)){
				if(!scores.containsKey(a)){
					scores.put(a, minscore);
				}
			}	
			
		}
		
		return highScoreMips;
	}

}
