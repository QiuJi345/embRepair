
package edu.njupt.radon.repair;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import org.semanticweb.owlapi.model.OWLAxiom;

import edu.njupt.radon.result.RevisionResult;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.DumpFile;


/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 2022.09.20
 */
public class RankWithScore {
		
	
	public static HashMap<OWLAxiom, Double> computeRanks(HashSet<HashSet<OWLAxiom>> sets) {
		HashMap<OWLAxiom, Double> scores = new HashMap<OWLAxiom, Double>();
		for (HashSet<OWLAxiom> set : sets) {			
			for (OWLAxiom ax : set) {
				if(scores.containsKey(ax)){
					scores.put(ax, scores.get(ax)+1);
				} else {
					scores.put(ax, 1.0);
				}
			}					
		}

		return scores;
	
	}


}
