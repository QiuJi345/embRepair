
package edu.njupt.radon.selefunc;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;



/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 19 March 2009
 */
public interface SelectionFunction {
	/*
	*//**
	 * 
	 * @param o
	 * @throws Exception
	 *//*
	public void init(OWLOntology o) throws Exception;
	
	*//**
	 * 
	 * @param axioms
	 * @throws Exception
	 *//*
	public void init(HashSet<OWLAxiom> axioms) throws Exception;	*/
	
	// Add one axiom to the current ontology and update the relevant information.
	public void addAxiom(OWLAxiom axiom);
	
	/**
	 * Remove one axiom from the current ontology and update the relevant information.
	 * @param axiom
	 */
	public void removeAxiom(OWLAxiom axiom);
	
	/**
	 * Get those axioms which are directly related to an entity 
	 */
	public HashSet<OWLAxiom> getRelatedAxioms(OWLEntity entity);
	
	/**
	 * Get those axioms which are directly related to a set of axioms
	 */
	public HashSet<OWLAxiom> getRelatedAxioms(HashSet<OWLAxiom> originalAxioms);
	
	/**
	 * Get all axioms which are related to an entity
	 */
	public Vector<HashSet<OWLAxiom>> getAllRelatedLayers(OWLEntity entity);
		
	/**
	 * Get all axioms which are related to a set of axioms
	 */
	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(HashSet<OWLAxiom> originalAxioms);
	
	/**
	 * Check whether an axiom is relevant to a set of axioms.
	 * @param ax
	 * @param a
	 * @return
	 */
	public boolean isRelevant(OWLAxiom a, HashSet<OWLAxiom> ax);
	
	/**
	 * Check whether an axiom is relevant to another axiom.
	 * 
	 * @param a1
	 * @param a2
	 * @return
	 */
	public boolean isRelevant(OWLAxiom a1, OWLAxiom a2);
	
	/**
	 * Check whether an entity is relevant to an axiom.
	 * 
	 * @param c: an entity
	 * @param a: an axiom
	 * @return
	 */
	public boolean isRelevant(OWLEntity c, OWLAxiom a);
	
	
}
