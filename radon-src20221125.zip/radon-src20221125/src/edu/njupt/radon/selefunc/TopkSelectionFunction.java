package edu.njupt.radon.selefunc;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class TopkSelectionFunction implements SelectionFunction {
	
	private HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	public HashMap<OWLAxiom,HashSet<OWLEntity>> axiomEntities = 
		new HashMap<OWLAxiom,HashSet<OWLEntity>>();
	
	private ArrayList<String> dic = new ArrayList<>();
	private ArrayList<OWLAxiom> dic_owl = new ArrayList<>();
	private ArrayList<Double> list = new ArrayList<>();
	private long number = 0;
	
	
	
	public TopkSelectionFunction(OWLOntology onto) {		
		allAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		initAxiomEntities(allAxioms);	
	}
	
	//����һ��top k�����ƶ�selectionFunction
	public TopkSelectionFunction(HashSet<OWLAxiom> axioms) throws IOException {		
		allAxioms.addAll(axioms);
		//��߲��������еĹ�������
//		for(OWLAxiom a : allAxioms) {
//			System.out.println(a);
//		}
//		System.out.println("allAxioms.size--"+allAxioms.size());
		initAxiomEntities(allAxioms);
		initList();
		initDic();
		dic2dic();
	}
	
	
	//add function
	private void initList() throws IOException{
//		String path = "D:\\Coding\\TorchLearning\\experiment\\sim_txt\\test3_sim.txt";
//		String path = "D:\\Coding\\TorchLearning\\experiment\\sim_txt\\km1500_i500-3000_sim.txt";
		String path = "onto/info/km1500_i500-3000_sim.txt";
        String string = null;
        FileInputStream fileInputStream = new FileInputStream(path);
        BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));
        while ((string = br.readLine()) != null){
            list.add(Double.parseDouble(string));
            number++;
        }
        br.close();
	}
	
	
	//xls�ļ���ȡ�������
	public void initDic() throws IOException {
      String path = "onto/info/km1500_i500-3000.xls";
    //1:����workbook
      Workbook workbook = null;
	try {
		workbook = Workbook.getWorkbook(new File(path));
	} catch (BiffException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}   //������������ĵ���·��������
      //2:��ȡ��һ��������sheet
      Sheet sheet=workbook.getSheet(0);  //�±��0��ʼ��ʾ��һ��������
      //3:��ȡ����
      for(int i=1;i<sheet.getRows();i++)    //����
      {
    	  Cell cell=sheet.getCell(0,i);
    	  dic.add(cell.getContents());
      }
      //4���ر���Դ
      workbook.close();
      return ;
	}
	
	public void dic2dic() {
		for(int i = 0;i<(int)Math.sqrt(number);i++) {
			dic_owl.add(str2axiom(dic.get(i)));
		}
		return ;
	}
	
	public OWLAxiom str2axiom(String s) {
		for(OWLAxiom o : allAxioms) {
			if(o.toString().equals(s))
				return o;
		}
		return null;
	}
	
	private void initAxiomEntities(HashSet<OWLAxiom> ax){
		for(OWLAxiom a : ax){
			axiomEntities.put(a, new HashSet<OWLEntity>(a.getSignature()));				
		}		
	}
	
	public HashSet<OWLEntity> getSignatures(HashSet<OWLAxiom> set){
		HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
		for(OWLAxiom a : set){
			sigs.addAll(axiomEntities.get(a));
		}
		return sigs;
	}

	@Override
	public void addAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiom == null)
			return;		
		if(!axiomEntities.containsKey(axiom)){
			axiomEntities.put(axiom, new HashSet<OWLEntity>(axiom.getSignature()));
		}
		this.allAxioms.add(axiom);
	}


	@Override
	public void removeAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiomEntities.containsKey(axiom)){
			axiomEntities.remove(axiom);
		}
		allAxioms.remove(axiom);
	}

	@Override
	public HashSet<OWLAxiom> getRelatedAxioms(OWLEntity entity) {
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		for(OWLAxiom a : allAxioms){			
			if(a.getSignature().contains(entity)){
				relatedAxioms.add(a);
			}
		}
		return relatedAxioms;
	}

	
//	version_3
	@Override
	public HashSet<OWLAxiom> getRelatedAxioms(HashSet<OWLAxiom> originalAxioms) {
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLEntity> originalEntities = new HashSet<OWLEntity>();
		
		for(OWLAxiom a : originalAxioms){
			if(axiomEntities.containsKey(a)){
				originalEntities.addAll(axiomEntities.get(a));
			}			
		}
		
		for(OWLEntity ent : originalEntities){
			for(OWLAxiom a : allAxioms){ // jiqiu: isRelevant������
				if((!originalAxioms.contains(a))&&(isRelevant(ent,a))){
					relatedAxioms.add(a);
				}				
			}
		}
				
		System.out.println("relatedAxioms.size: "+relatedAxioms.size());
		
		if(relatedAxioms.size() <= DebuggingParameters.topK) {
			return relatedAxioms;
		}
		
		HashSet<OWLAxiom> relatedAxioms2 = new HashSet<OWLAxiom>();
		HashMap<Double,Integer> i2d = new HashMap<>();
		int index_b,index_c;
		double[] sim_sum = new double[relatedAxioms.size()];
		int[] indexOf = new int[relatedAxioms.size()];
		int count = 0;
		for(OWLAxiom b : relatedAxioms){
			index_b = dic_owl.indexOf(b);
			for(OWLAxiom c : originalAxioms) {
				index_c = dic_owl.indexOf(c);
				int index = index_b * (int)Math.sqrt(number) + index_c;
				sim_sum[count] += list.get(index);
			}
			indexOf[count] = index_b;
			count++;
		}
		//�������ƶ����ݺ��±�֮��Ķ�Ӧ��ϵ
		for(int i = 0;i<relatedAxioms.size();i++) {
			i2d.put(sim_sum[i],indexOf[i]);
		}
		//��Key����һ������
		Set<Double> set = i2d.keySet();
		//ת����
		Object[] arr = set.toArray();
		
        //��������򷽷�
        //Arrays.sort(arr);
        Arrays.sort(arr, Collections.reverseOrder());        
        for(int i = 0 ; i < DebuggingParameters.topK && i < relatedAxioms.size(); i++) {
        	relatedAxioms2.add(dic_owl.get(i2d.get(arr[i])));
//        	System.out.println("relatedAxioms.size--"+relatedAxioms.size());
        	//relatedAxioms.remove(dic_owl.get(i2d.get(arr[i])));
//        	System.out.println("allAxioms.size--"+allAxioms.size());
        }
        System.out.println("topk relatedAxioms: "+relatedAxioms2.size());
		return relatedAxioms2;
	}
	

	@Override
	public Vector<HashSet<OWLAxiom>> getAllRelatedLayers(OWLEntity entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(HashSet<OWLAxiom> originalAxioms_in){
		Vector<HashSet<OWLAxiom>> allRelated = new Vector<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();
		
		relatedAxioms = getRelatedAxioms(originalAxioms_in);
		
		while(relatedAxioms.size()>0){
			allRelated.add((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms_all.addAll((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}
		
		return allRelated;
	}

	@Override
	public boolean isRelevant(OWLAxiom a, HashSet<OWLAxiom> ax) {
		// a�����й����ļ���
		boolean flag = false;		
		for(OWLAxiom at : ax){
			if(isRelevant(at, a)){
				flag = true;
				break;
			}
		}		
		return flag;
	}

	@Override	
	public boolean isRelevant(OWLAxiom a1, OWLAxiom a2){
		boolean isRelevant = false;
		HashSet<OWLEntity> ents1 = axiomEntities.get(a1);
		HashSet<OWLEntity> ents2 = axiomEntities.get(a2);
		for(OWLEntity ent : ents1){
			if(ents2.contains(ent)){
				isRelevant = true;
				break;
			}				
		}		
		return isRelevant;
	}

	//add function
	public int getIndexOfAxiom(OWLAxiom a){
		int count = 0;
		for(OWLAxiom ax:allAxioms) {
			if(ax != a)
				count++;
			else
				break;
		}
//		System.out.println(count);
		return count;
	}
	
	@Override
	public boolean isRelevant(OWLEntity c, OWLAxiom a){
		HashSet<OWLEntity> entities = axiomEntities.get(a);
		if(entities.contains(c))
			return true;
		else
			return false;
	}

}

