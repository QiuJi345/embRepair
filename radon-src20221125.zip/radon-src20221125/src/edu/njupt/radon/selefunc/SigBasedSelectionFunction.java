
package edu.njupt.radon.selefunc;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.OWLTools;


/**
 * ���㷨��˼�룺ʵ���˴�ͳ�Ļ���signature��ѡ������˼�롣
 *
 * @author Qiu Ji 
 * @date 29 Mar 2007
 */
public class SigBasedSelectionFunction implements SelectionFunction {
		
	private HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	public HashMap<OWLAxiom,HashSet<OWLEntity>> axiomEntities = 
		new HashMap<OWLAxiom,HashSet<OWLEntity>>();
	
	public static void main(String[] args) throws Exception{}
	
	
	public SigBasedSelectionFunction(OWLOntology onto) {		
		allAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());		
		initAxiomEntities(allAxioms);		
	}
	
	public SigBasedSelectionFunction(HashSet<OWLAxiom> axioms) {		
		allAxioms.addAll(axioms);
		initAxiomEntities(allAxioms);	
	}
	
	private void initAxiomEntities(HashSet<OWLAxiom> ax){
		for(OWLAxiom a : ax){
			axiomEntities.put(a, new HashSet<OWLEntity>(a.getSignature()));				
		}		
	}
	
	public HashSet<OWLEntity> getSignatures(HashSet<OWLAxiom> set){
		HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
		for(OWLAxiom a : set){
			sigs.addAll(axiomEntities.get(a));
		}
		return sigs;
	}
	
	@Override
	public HashSet<OWLAxiom> getRelatedAxioms(OWLEntity concept){
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		for(OWLAxiom a : allAxioms){			
			if(isRelevant(concept,a)){
				relatedAxioms.add(a);
			}
		}
		return relatedAxioms;
	}
	
	public Vector<HashSet<OWLAxiom>> getAllRelatedLayers(OWLEntity concept){
		Vector<HashSet<OWLAxiom>> allRelated = new Vector<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();
		
		relatedAxioms = getRelatedAxioms(concept);
		
		while(relatedAxioms.size()>0){
			allRelated.add((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms_all.addAll((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}
		
		return allRelated;
	}
	
	
	public HashSet<OWLAxiom> getAllRelatedAxioms(OWLEntity concept){
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();
		
		relatedAxioms = getRelatedAxioms(concept);
		
		while(relatedAxioms.size()>0){
			relatedAxioms_all.addAll((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}
		
		return relatedAxioms_all;
	}
	
	public HashSet<OWLAxiom> getRelatedAxioms(HashSet<OWLAxiom> originalAxioms_in){
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLEntity> originalEntities = new HashSet<OWLEntity>();
		HashSet<OWLAxiom> originalAxioms = new HashSet<OWLAxiom>(originalAxioms_in);
		
		for(OWLAxiom a : originalAxioms){
			if(axiomEntities.containsKey(a)){
				originalEntities.addAll(axiomEntities.get(a));
			}			
		}
		for(OWLEntity ent : originalEntities){
			for(OWLAxiom a : allAxioms){
				if((!originalAxioms.contains(a))&&(isRelevant(ent,a))){
					relatedAxioms.add(a);
				}				
			}
		}
		
		return relatedAxioms;
	}
	
	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(HashSet<OWLAxiom> originalAxioms_in){
		Vector<HashSet<OWLAxiom>> allRelated = new Vector<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();
		
		relatedAxioms = getRelatedAxioms(originalAxioms_in);
		
		while(relatedAxioms.size()>0){
			allRelated.add((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms_all.addAll((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}
		
		return allRelated;
	}
	
	
	public boolean isRelevant(OWLAxiom a, HashSet<OWLAxiom> ax){
		boolean flag = false;		
		for(OWLAxiom at : ax){
			if(isRelevant(at, a)){
				flag = true;
				break;
			}
		}		
		return flag;
	}
	
	public boolean isRelevant(OWLAxiom a1, OWLAxiom a2){
		boolean isRelevant = false;
		HashSet<OWLEntity> ents1 = axiomEntities.get(a1);
		HashSet<OWLEntity> ents2 = axiomEntities.get(a2);
		for(OWLEntity ent : ents1){
			if(ents2.contains(ent)){
				isRelevant = true;
				break;
			}				
		}		
		return isRelevant;
	}
	
	public boolean isRelevant(OWLEntity c, OWLAxiom a){
		HashSet<OWLEntity> entities = axiomEntities.get(a);
		if(entities.contains(c))
			return true;
		else
			return false;
	}


	@Override
	public void addAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiom == null)
			return;		
		if(!axiomEntities.containsKey(axiom)){
			axiomEntities.put(axiom, new HashSet<OWLEntity>(axiom.getSignature()));
		}
		this.allAxioms.add(axiom);
	}


	@Override
	public void removeAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiomEntities.containsKey(axiom)){
			axiomEntities.remove(axiom);
		}
		allAxioms.remove(axiom);
	}

}
