
package edu.njupt.radon.selefunc;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;


/**
 * ���㷨��˼���ǣ���signature-based������ѡ�����������ѡ�����Ĺ�������ĳ����ֵk��
 * �����ѡ�����Ĺ�����ѡȡ����k��������Ϊ��ع��� 
 *
 * @author Qiu Ji 
 * @date 06 Aug 2022
 */
public class SigWindowBasedSelectionFunction implements SelectionFunction {
		
	private HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	public HashMap<OWLAxiom,HashSet<OWLEntity>> axiomEntities = 
		new HashMap<OWLAxiom,HashSet<OWLEntity>>();
	
	public static void main(String[] args) throws Exception{}
	
	
	public SigWindowBasedSelectionFunction(OWLOntology onto) {		
		allAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());		
		initAxiomEntities(allAxioms);		
	}
	
	public SigWindowBasedSelectionFunction(HashSet<OWLAxiom> axioms) {		
		allAxioms.addAll(axioms);
		initAxiomEntities(allAxioms);	
	}
	
	private void initAxiomEntities(HashSet<OWLAxiom> ax){
		for(OWLAxiom a : ax){
			axiomEntities.put(a, new HashSet<OWLEntity>(a.getSignature()));				
		}		
	}
	
	public HashSet<OWLEntity> getSignatures(HashSet<OWLAxiom> set){
		HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
		for(OWLAxiom a : set){
			sigs.addAll(axiomEntities.get(a));
		}
		return sigs;
	}
	
	@Override
	public HashSet<OWLAxiom> getRelatedAxioms(OWLEntity concept){
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		for(OWLAxiom a : allAxioms){			
			if(isRelevant(concept,a)){
				relatedAxioms.add(a);
			}
		}
		return relatedAxioms;
	}
	
	public Vector<HashSet<OWLAxiom>> getAllRelatedLayers(OWLEntity concept){
		Vector<HashSet<OWLAxiom>> allRelated = new Vector<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();
		
		relatedAxioms = getRelatedAxioms(concept);
		
		while(relatedAxioms.size()>0){
			allRelated.add((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms_all.addAll((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}
		
		return allRelated;
	}
	
	
	public HashSet<OWLAxiom> getAllRelatedAxioms(OWLEntity concept){
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();
		
		relatedAxioms = getRelatedAxioms(concept);
		
		while(relatedAxioms.size()>0){
			relatedAxioms_all.addAll((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}
		
		return relatedAxioms_all;
	}
	
	public HashSet<OWLAxiom> getRelatedAxioms(HashSet<OWLAxiom> originalAxioms_in){
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLEntity> originalEntities = new HashSet<OWLEntity>();
		HashSet<OWLAxiom> originalAxioms = new HashSet<OWLAxiom>(originalAxioms_in);
		
		for(OWLAxiom a : originalAxioms){
			if(axiomEntities.containsKey(a)){
				originalEntities.addAll(axiomEntities.get(a));
			}			
		}
		for(OWLEntity ent : originalEntities){
			for(OWLAxiom a : allAxioms){
				if((!originalAxioms.contains(a))&&(isRelevant(ent,a))){
					relatedAxioms.add(a);
				}				
			}
		}
		
        // �����ع����������������£�����Ҫ��һ���ֲ�
		if (relatedAxioms.size() <= DebuggingParameters.topK) {
			return relatedAxioms;
		}
		
		HashSet<OWLAxiom> relatedAxioms2 = new HashSet<OWLAxiom>();
		int counter = 0;
		for(OWLAxiom ax : relatedAxioms) {
			relatedAxioms2.add(ax);
			counter ++;
			if(counter >= DebuggingParameters.topK) {
				break;
			}
		}
		
		return relatedAxioms2;
	}
	
	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(HashSet<OWLAxiom> originalAxioms_in){
		Vector<HashSet<OWLAxiom>> allRelated = new Vector<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();
		
		relatedAxioms = getRelatedAxioms(originalAxioms_in);
		
		while(relatedAxioms.size()>0){
			allRelated.add((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms_all.addAll((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}
		
		return allRelated;
	}
	
	
	public boolean isRelevant(OWLAxiom a, HashSet<OWLAxiom> ax){
		boolean flag = false;		
		for(OWLAxiom at : ax){
			if(isRelevant(at, a)){
				flag = true;
				break;
			}
		}		
		return flag;
	}
	
	public boolean isRelevant(OWLAxiom a1, OWLAxiom a2){
		boolean isRelevant = false;
		HashSet<OWLEntity> ents1 = axiomEntities.get(a1);
		HashSet<OWLEntity> ents2 = axiomEntities.get(a2);
		for(OWLEntity ent : ents1){
			if(ents2.contains(ent)){
				isRelevant = true;
				break;
			}				
		}		
		return isRelevant;
	}
	
	public boolean isRelevant(OWLEntity c, OWLAxiom a){
		HashSet<OWLEntity> entities = axiomEntities.get(a);
		if(entities.contains(c))
			return true;
		else
			return false;
	}


	@Override
	public void addAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiom == null)
			return;		
		if(!axiomEntities.containsKey(axiom)){
			axiomEntities.put(axiom, new HashSet<OWLEntity>(axiom.getSignature()));
		}
		this.allAxioms.add(axiom);
	}


	@Override
	public void removeAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiomEntities.containsKey(axiom)){
			axiomEntities.remove(axiom);
		}
		allAxioms.remove(axiom);
	}

}
