package edu.njupt.radon.selefunc;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.model.OWLSubObjectPropertyOfAxiom;

public class SubBasedSelectionFunction implements SelectionFunction {

	private HashSet<OWLAxiom> allAxioms;
	private HashMap<OWLAxiom,Vector<HashSet<OWLEntity>>> axiomLeftEntities;
	private HashMap<OWLAxiom,HashSet<OWLEntity>> axiomEntities;
		

	public SubBasedSelectionFunction(OWLOntology onto) throws Exception {
		this.init();
		allAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());		
		this.initAxiomEntities();	
	}

	public SubBasedSelectionFunction(HashSet<OWLAxiom> axioms) {
		this.init();
		allAxioms.addAll(axioms);
		initAxiomEntities();
	}
	
	private void init(){
		allAxioms = new HashSet<OWLAxiom>();
		axiomLeftEntities = new HashMap<OWLAxiom,Vector<HashSet<OWLEntity>>>();
		axiomEntities = new HashMap<OWLAxiom,HashSet<OWLEntity>>();
	}
	
	private void initAxiomEntities(){
		for(OWLAxiom a : allAxioms){
			//System.out.println(a.toString());
			axiomEntities.put(a, new HashSet<OWLEntity>(a.getSignature()));
			Vector<HashSet<OWLEntity>> ents = this.getLeftEntities(a);
			if(ents.size()>0){
				axiomLeftEntities.put(a, ents);
			}			
		}		
	}
	
	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(OWLEntity entity) {
		// TODO Auto-generated method stub
		return null;
	}

	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(
			HashSet<OWLAxiom> originalAxioms) {
		// TODO Auto-generated method stub
		return null;
	}

	public HashSet<OWLAxiom> getRelatedAxioms(OWLEntity entity) {
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		for(OWLAxiom a : allAxioms){	
			if(isRelevant(entity,a)){
				relatedAxioms.add(a);
			}
		}
		return relatedAxioms;
	}

	public HashSet<OWLAxiom> getRelatedAxioms(HashSet<OWLAxiom> originalAxioms_in) {
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLEntity> originalEntities = new HashSet<OWLEntity>();
		HashSet<OWLAxiom> originalAxioms = new HashSet<OWLAxiom>(originalAxioms_in);
		
		for(OWLAxiom a : originalAxioms){
			if(axiomEntities.containsKey(a)){
				originalEntities.addAll(axiomEntities.get(a));
			}			
		}
		for(OWLAxiom a : allAxioms){
			if(!originalAxioms.contains(a) && axiomLeftEntities.containsKey(a)){
				Vector<HashSet<OWLEntity>> leftEnts = axiomLeftEntities.get(a);
				int size = leftEnts.size();
				Iterator<HashSet<OWLEntity>> iter = leftEnts.iterator();
				if(size==1 && originalEntities.containsAll(iter.next())){
					relatedAxioms.add(a);			
				} else if(size==2 && (originalEntities.containsAll(iter.next()) ||
						originalEntities.containsAll(iter.next()))){
					relatedAxioms.add(a);
				}
			}				
		}
		return relatedAxioms;
	}

	@Override
	public Vector<HashSet<OWLAxiom>> getAllRelatedLayers(OWLEntity entity) {
		// TODO Auto-generated method stub
		return null;
	}

	public  Vector<HashSet<OWLEntity>> getLeftEntities(OWLAxiom axiom) {
		Vector<HashSet<OWLEntity>> entities = new Vector<HashSet<OWLEntity>>();
		HashSet<OWLEntity> leftEntities = new HashSet<OWLEntity>();
		
		if(axiom instanceof OWLSubClassOfAxiom) {
			OWLSubClassOfAxiom subClAxiom = (OWLSubClassOfAxiom)axiom;
			OWLClassExpression subClassExp = subClAxiom.getSubClass();
			leftEntities.addAll(SelectionFunctionUtils.getSchemaEntities(subClassExp));
			entities.add(leftEntities);
							
		} else if(axiom instanceof OWLDisjointClassesAxiom) {
			OWLDisjointClassesAxiom disjAxiom = (OWLDisjointClassesAxiom)axiom;
			Vector<OWLClassExpression> exps = new Vector<OWLClassExpression>(disjAxiom.getClassExpressions());
			leftEntities.addAll(SelectionFunctionUtils.getSchemaEntities(exps.get(0)));
			entities.add(new HashSet<OWLEntity>(leftEntities));
			leftEntities.clear();
			leftEntities.addAll(SelectionFunctionUtils.getSchemaEntities(exps.get(1)));
			entities.add(new HashSet<OWLEntity>(leftEntities));			
			
		} else if(axiom instanceof OWLEquivalentClassesAxiom) {
			OWLEquivalentClassesAxiom equAxiom = (OWLEquivalentClassesAxiom)axiom;
			Vector<OWLClassExpression> exps = new Vector<OWLClassExpression>(equAxiom.getClassExpressions());
			leftEntities.addAll(SelectionFunctionUtils.getSchemaEntities(exps.get(0)));
			entities.add(new HashSet<OWLEntity>(leftEntities));
			leftEntities.clear();
			leftEntities.addAll(SelectionFunctionUtils.getSchemaEntities(exps.get(1)));
			entities.add(new HashSet<OWLEntity>(leftEntities));	
			
		} else if(axiom instanceof OWLEquivalentObjectPropertiesAxiom){
			OWLEquivalentObjectPropertiesAxiom c = (OWLEquivalentObjectPropertiesAxiom)axiom;
			Set<OWLObjectPropertyExpression> opExp = c.getProperties();
			Iterator<OWLObjectPropertyExpression> iter = opExp.iterator();
			OWLObjectPropertyExpression ope1 = iter.next();
			OWLObjectPropertyExpression ope2 = iter.next();
			leftEntities.addAll(ope1.getSignature());
			entities.add(new HashSet<OWLEntity>(leftEntities));
			leftEntities.clear();
			leftEntities.addAll(ope2.getSignature());
			entities.add(new HashSet<OWLEntity>(leftEntities));						
			
		} else if(axiom instanceof OWLSubObjectPropertyOfAxiom) {
			OWLSubObjectPropertyOfAxiom c = (OWLSubObjectPropertyOfAxiom)axiom;
			OWLObjectPropertyExpression opExp = c.getSubProperty();			
			leftEntities.addAll(opExp.getSignature());
			entities.add(leftEntities);
			
		}  /*else if(a instanceof ObjectPropertyDomain){
			ObjectPropertyDomain ax = (ObjectPropertyDomain)a;
			leftEntities.add((OWLEntity)ax.getObjectProperty());
			
		} else if (a instanceof ObjectPropertyRange){
			ObjectPropertyRange ax = (ObjectPropertyRange)a;
			leftEntities.add((OWLEntity)ax.getObjectProperty());
		} */
		return (Vector<HashSet<OWLEntity>>)entities.clone();
	}

	@Override
	public boolean isRelevant(OWLAxiom a, HashSet<OWLAxiom> ax) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isRelevant(OWLAxiom a1, OWLAxiom a2) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isRelevant(OWLEntity c, OWLAxiom a) {
		boolean isRelevant = false;
		if(axiomLeftEntities.containsKey(a)){
			Vector<HashSet<OWLEntity>> entities = axiomLeftEntities.get(a);	
			
			int size = entities.size();
			Iterator<HashSet<OWLEntity>> iter = entities.iterator();
			if(size==1){
				HashSet<OWLEntity> oneSideEntities = iter.next();
				if(oneSideEntities.size()==1 && oneSideEntities.contains(c)){
					isRelevant = true;
				}		
			} else if(size==2){
				HashSet<OWLEntity> oneSideEntities = iter.next();
				if(oneSideEntities.size()==1 && oneSideEntities.contains(c)){
					isRelevant =  true;
				} 
				oneSideEntities = iter.next();
				if(oneSideEntities.size()==1 && oneSideEntities.contains(c)){
					isRelevant =  true;
				} 
			}
		} 
		return isRelevant;	
	}	
	
	@Override
	public void addAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiom == null)
			return;		
		if(!axiomEntities.containsKey(axiom)){
			axiomEntities.put(axiom, new HashSet<OWLEntity>(axiom.getSignature()));
		}
		if(!axiomLeftEntities.containsKey(axiom)){
			Vector<HashSet<OWLEntity>> ents = this.getLeftEntities(axiom);
			if(ents.size()>0){
				axiomLeftEntities.put(axiom, ents);
			}
		}
		
		this.allAxioms.add(axiom);
	}


	@Override
	public void removeAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiomEntities.containsKey(axiom)){
			axiomEntities.remove(axiom);
		}
		if(axiomLeftEntities.containsKey(axiom)){
			axiomLeftEntities.remove(axiom);
		}
		allAxioms.remove(axiom);
	}
}
