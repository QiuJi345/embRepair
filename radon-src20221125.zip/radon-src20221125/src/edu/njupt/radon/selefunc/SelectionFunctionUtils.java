package edu.njupt.radon.selefunc;

import java.util.HashMap;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLObjectProperty;


public class SelectionFunctionUtils {
	
	public static HashMap<OWLAxiom,OWLAxiom> transferedAxioms = new HashMap<OWLAxiom, OWLAxiom>();
	
/*	public static HashSet<OWLAxiom> transformOntoToGCI(HashSet<OWLAxiom> onto){
		transferedAxioms.clear();
		HashSet<OWLAxiom> newOnto = new HashSet<OWLAxiom>();
		for(OWLAxiom a : onto){
			HashSet<OWLAxiom> ax = transformAxiomToGCI(a);
			if(ax.size()>0){
				newOnto.addAll(ax);
			} else {
				newOnto.add(a);
			}
		}
		return newOnto;
	}
	*/
	
/*	public static HashSet<OWLAxiom> transformAxiomToGCI(OWLAxiom a){
		HashSet<OWLAxiom> ax = new HashSet<OWLAxiom>();
		OWLAxiom a1 = null;
		OWLAxiom a2 = null;
		if(a instanceof OWLDisjointClassesAxiom) {
			OWLDisjointClassesAxiom c = (OWLDisjointClassesAxiom)a;			
			Iterator<Description> desc = c.getDescriptions().iterator();
			Description d1 = desc.next();
			Description d2 = desc.next();
			a1 = KAON2Manager.factory().subClassOf(d1, KAON2Manager.factory().objectNot(d2));
			ax.add(a1);
			a2 = KAON2Manager.factory().subClassOf(d2, KAON2Manager.factory().objectNot(d1));
			ax.add(a2);
		}
		else if(a instanceof EquivalentClasses){
			EquivalentClasses c = (EquivalentClasses)a;
			Iterator<Description> desc = c.getDescriptions().iterator();
			Description d1 = desc.next();
			Description d2 = desc.next();
			a1 = KAON2Manager.factory().subClassOf(d1, d2);
			ax.add(a1);
			a2 = KAON2Manager.factory().subClassOf(d2, d1);
			ax.add(a2);
		}
		else if(a instanceof EquivalentObjectProperties){
			EquivalentObjectProperties c = (EquivalentObjectProperties)a;
			Iterator<ObjectPropertyExpression> desc = c.getObjectProperties().iterator();
			ObjectPropertyExpression d1 = desc.next();
			ObjectPropertyExpression d2 = desc.next();
			List<ObjectPropertyExpression> list = new ArrayList<ObjectPropertyExpression>();
			list.add(d1);
			a1 = KAON2Manager.factory().subObjectPropertyOf(list, d2);			
			ax.add(a1);
			list.clear();
			list.add(d2);
			a2 = KAON2Manager.factory().subObjectPropertyOf(list, d1);
			ax.add(a2);
		}
		else if(a instanceof EquivalentDataProperties){
			EquivalentDataProperties c = (EquivalentDataProperties)a;
			Iterator<DataPropertyExpression> desc = c.getDataProperties().iterator();
			DataPropertyExpression d1 = desc.next();
			DataPropertyExpression d2 = desc.next();
			a1 = KAON2Manager.factory().subDataPropertyOf(d1, d2);			
			ax.add(a1);
			a2 = KAON2Manager.factory().subDataPropertyOf(d2, d1);
			ax.add(a2);			
		}
		if(a1!=null && a2!=null){
			transferedAxioms.put(a1, a);
			transferedAxioms.put(a2, a);
		}
		
		return ax;
	}
		*/
	public static Vector<OWLEntity> getSchemaEntities(OWLClassExpression classExp){
		Vector<OWLEntity> v2 = new Vector<OWLEntity>();
		for(OWLEntity ent : classExp.getSignature()){
			if((ent instanceof OWLClass) ||(ent instanceof OWLObjectProperty)){
				v2.add(ent);
			}
		}		
		return v2;
	}
	
	static void addEntities(Vector<OWLEntity> v1, Vector<OWLEntity> v2) {
		for (int i = 0; i < v2.size(); i++) {
			v1.add(v2.elementAt(i));
		}
	}       

}
