package edu.njupt.radon.selefunc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/**
 * ���㷨��˼�룺ʵ����Ԥѵ��ģ�͵��������ƶ�����ѡ������˼�롣����һ��uc��
 * ����signature-based������ѡ���������ΪS�������湫������ѡ����Ԥѵ��ģ�ͽ������ƶȼ��㡣
 * ��ÿ����ѡʱ��һ�������еĹ�����Ϊ�Ѿ���ѡ�Ĺ���S1��δ��ѡ�����Ĺ���S2����Ҫ����S2��ÿ��������S1
 * ֮������ƶȣ�ֻ����S2�д����ߵ�k��������Ϊ��ǰ����ع�����
 * ���еĴ�ּ�SigSimBasedSelectionFunction�е�ע�͡�
 *
 * @author Qiu Ji 
 * @date 06 Aug 2022
 */
public class SimBasedSelectionFunction implements SelectionFunction {

	HashSet<OWLAxiom> allAxioms;
	
	public HashMap<OWLAxiom, HashSet<OWLEntity>> axiomEntities = new HashMap<OWLAxiom, HashSet<OWLEntity>>();
    private Vector<OWLAxiom> axiomList = new Vector<>();
	//private ArrayList<String> axiomStrList = new ArrayList<>();
	
	private HashMap<Vector<Integer>,Double> pairSims = new HashMap<Vector<Integer>,Double>();

	public SimBasedSelectionFunction(OWLOntology onto) {
		allAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		initAxiomEntities(allAxioms);
	}

	public SimBasedSelectionFunction(HashSet<OWLAxiom> axioms) {
		allAxioms.addAll(axioms);
		// ����ÿ����������ǩ��֮���ӳ��
		initAxiomEntities(allAxioms);
		// ��ȡÿ��������֮������ƶ�
		iniSimList();
		// �������Ĺ����б�
		//axiomList = new ArrayList(allAxioms);
		iniAxiomIDs();
		/*int i = 0;
		for(OWLAxiom ax : allAxioms) {
			System.out.println((i++)+"> "+ax.toString());
		}*/
	}

	// add function
	private void iniSimList() {
		//String path = "onto/info/"+DebuggingParameters.ontoName+"_cos.txt"; 
		String path = "onto/info/"+DebuggingParameters.ontoName+"_cos.txt";
		System.out.println("reading similarity file...");
		String line = null;
		try {
			FileInputStream fileInputStream = new FileInputStream(path);
			BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				Vector<Integer> pair = new Vector<Integer>();
				pair.add(Integer.valueOf(info[0]));
				pair.add(Integer.valueOf(info[1]));
				this.pairSims.put(pair, Double.valueOf(info[2]));
			}
			br.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		}		
		System.out.println(" simList size: "+pairSims.size());
	}
	
	public void iniAxiomIDs() {
		String path = "onto/info/"+DebuggingParameters.ontoName+"_axiomList.txt";
		
		HashSet<OWLAxiom> allAxiomsDyn = new HashSet<OWLAxiom>(allAxioms);
		System.out.println("reading similarity file...");
		String line = null;
		try {
			FileInputStream fileInputStream = new FileInputStream(path);
			BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));
			while ((line = br.readLine()) != null) {
				for(OWLAxiom ax : allAxiomsDyn) {
					if(ax.toString().equals(line)) {
						axiomList.add(ax);
						allAxiomsDyn.remove(ax);
						break;
					} else {
						axiomList.add(null);
					}
				}
			}
			br.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		}	
	    System.out.println(" axiomStrList size: " + axiomList.size());
	}
	
	private void initAxiomEntities(HashSet<OWLAxiom> ax) {
		for (OWLAxiom a : ax) {
			axiomEntities.put(a, new HashSet<OWLEntity>(a.getSignature()));
		}
	}

	public HashSet<OWLEntity> getSignatures(HashSet<OWLAxiom> set) {
		HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
		for (OWLAxiom a : set) {
			sigs.addAll(axiomEntities.get(a));
		}
		return sigs;
	}

	@Override
	public void addAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if (axiom == null)
			return;
		if (!axiomEntities.containsKey(axiom)) {
			axiomEntities.put(axiom, new HashSet<OWLEntity>(axiom.getSignature()));
		}
		this.allAxioms.add(axiom);
	}

	@Override
	public void removeAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if (axiomEntities.containsKey(axiom)) {
			axiomEntities.remove(axiom);
		}
		allAxioms.remove(axiom);
	}

	@Override
	public HashSet<OWLAxiom> getRelatedAxioms(OWLEntity entity) {
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		for (OWLAxiom a : allAxioms) {
			if (a.getSignature().contains(entity)) {
				relatedAxioms.add(a);
			}
		}
		return relatedAxioms;
	}

	@Override
	public HashSet<OWLAxiom> getRelatedAxioms(HashSet<OWLAxiom> originalAxioms) {
		// ��û�û�б���ѡ�Ĺ�������
		HashSet<OWLAxiom> candiAxioms = new HashSet<OWLAxiom>(allAxioms);
		candiAxioms.removeAll(originalAxioms);
		
        // ����һ����ѡ��������ѡ��������֮������ƶ�/��ֵ
		// ע�⣺��ͬ�������ܾ�����ͬ�ķ�ֵ�����һ����ֵ�ɶ�Ӧ��������		
		HashMap<Double, HashSet<OWLAxiom>> scoreAxiomMap = new HashMap<>();		
		for(OWLAxiom relatedAx : candiAxioms) {
			int index1 = axiomList.indexOf(relatedAx);
			double simSum = 0;
			// ����ѡ��������ѭ���������ۼ����ƶ�
			for (OWLAxiom c : originalAxioms) {
				int index2 = axiomList.indexOf(c);
				simSum += this.getSimilarity(index1, index2);				
			}
			// ����������ֵ���ֵ֮��Ķ�Ӧ��ϵ
			if(!scoreAxiomMap.containsKey(simSum)) {
				HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
				axioms.add(relatedAx);
				scoreAxiomMap.put(simSum, axioms);
			} else {
				scoreAxiomMap.get(simSum).add(relatedAx);
			}			
		}
	
		// �����÷�ֵ���н�������
		Set<Double> set = new HashSet<Double>(scoreAxiomMap.keySet());
		Object[] arr = set.toArray();
		Arrays.sort(arr, Collections.reverseOrder());
		
		// ���top k��صĹ���
		HashSet<OWLAxiom> relatedAxioms2 = new HashSet<OWLAxiom>();
		for (int i = 0; i < DebuggingParameters.topK && i < candiAxioms.size(); i++) {
			relatedAxioms2.addAll(scoreAxiomMap.get(arr[i]));
			// System.out.println("relatedAxioms.size--"+relatedAxioms.size());
		}
		System.out.println("topk relatedAxioms: " + relatedAxioms2.size());
		return relatedAxioms2;
	}
	
	private Double getSimilarity(int i1, int i2) {
		double sim = 0;
		Vector<Integer> pair = new Vector<Integer>();
		pair.add(i1);
		pair.add(i2);
		if(this.pairSims.containsKey(pair)) {
			sim = this.pairSims.get(pair);
		} else {
			pair.clear();
			pair.add(i2);
			pair.add(i1);
			if(this.pairSims.containsKey(pair)) {
				sim = this.pairSims.get(pair);
			} 
		}
		return sim;
	}

	@Override
	public Vector<HashSet<OWLAxiom>> getAllRelatedLayers(OWLEntity entity) {
		return null;
	}

	@Override
	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(HashSet<OWLAxiom> originalAxioms_in) {
		Vector<HashSet<OWLAxiom>> allRelated = new Vector<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();

		relatedAxioms = getRelatedAxioms(originalAxioms_in);

		while (relatedAxioms.size() > 0) {
			allRelated.add((HashSet<OWLAxiom>) relatedAxioms.clone());
			relatedAxioms_all.addAll((HashSet<OWLAxiom>) relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}

		return allRelated;
	}

	@Override
	public boolean isRelevant(OWLAxiom a, HashSet<OWLAxiom> ax) {
		// a�����й����ļ���
		boolean flag = false;
		for (OWLAxiom at : ax) {
			if (isRelevant(at, a)) {
				flag = true;
				break;
			}
		}
		return flag;
	}

	@Override
	public boolean isRelevant(OWLAxiom a1, OWLAxiom a2) {
		boolean isRelevant = false;
		HashSet<OWLEntity> ents1 = axiomEntities.get(a1);
		HashSet<OWLEntity> ents2 = axiomEntities.get(a2);
		for (OWLEntity ent : ents1) {
			if (ents2.contains(ent)) {
				isRelevant = true;
				break;
			}
		}
		return isRelevant;
	}

	// add function
	public int getIndexOfAxiom(OWLAxiom a) {
		int count = 0;
		for (OWLAxiom ax : allAxioms) {
			if (ax != a)
				count++;
			else
				break;
		}
		// System.out.println(count);
		return count;
	}

	@Override
	public boolean isRelevant(OWLEntity c, OWLAxiom a) {
		HashSet<OWLEntity> entities = axiomEntities.get(a);
		if (entities.contains(c))
			return true;
		else
			return false;
	}

}
