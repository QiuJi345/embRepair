package edu.njupt.radon.selefunc;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;


public class ALCSelectionFunction implements SelectionFunction {
	private HashSet<OWLAxiom> allAxioms;
	public HashMap<OWLAxiom,HashSet<OWLEntity>> comparableEntities;
	public HashMap<OWLAxiom,HashSet<OWLEntity>> axiomEntities;
	
	public ALCSelectionFunction(OWLOntology onto) throws Exception {
		this.init();
		allAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());		
		this.initAxiomEntities();	
	}

	public ALCSelectionFunction(HashSet<OWLAxiom> axioms) {
		this.init();
		allAxioms.addAll(axioms);
		initAxiomEntities();
	}
	
	private void init(){
		allAxioms = new HashSet<OWLAxiom>();
		comparableEntities = new HashMap<OWLAxiom,HashSet<OWLEntity>>();
		axiomEntities = new HashMap<OWLAxiom,HashSet<OWLEntity>>();
	}
		
	public void initAxiomEntities(){
		for(OWLAxiom a : allAxioms){
			axiomEntities.put(a, new HashSet<OWLEntity>(a.getSignature()));
			HashSet<OWLEntity> ents = getALCComparableEntities(a);
			if(ents.size()>0){
				comparableEntities.put(a, ents);
			}			
		}	
	}
	
	
	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(OWLEntity entity) {
		Vector<HashSet<OWLAxiom>> allRelated = new Vector<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms_all = new HashSet<OWLAxiom>();
		
		relatedAxioms = getRelatedAxioms(entity);
		
		while(relatedAxioms.size()>0){
			allRelated.add((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms_all.addAll((HashSet<OWLAxiom>)relatedAxioms.clone());
			relatedAxioms = getRelatedAxioms(relatedAxioms_all);
		}
		
		return allRelated;
	}

	public Vector<HashSet<OWLAxiom>> getAllRelatedAxioms(
			HashSet<OWLAxiom> originalAxioms) {
		// TODO Auto-generated method stub
		return null;
	}

	public HashSet<OWLAxiom> getRelatedAxioms(OWLEntity entity) {
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		for(OWLAxiom a : allAxioms){			
			if(isRelevant(entity,a)){
				relatedAxioms.add(a);
			}
		}
		return relatedAxioms;
	}

	public HashSet<OWLAxiom> getRelatedAxioms(HashSet<OWLAxiom> originalAxioms_in) {
		HashSet<OWLAxiom> relatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLEntity> originalEntities = new HashSet<OWLEntity>();
		HashSet<OWLAxiom> originalAxioms = new HashSet<OWLAxiom>(originalAxioms_in);
		
		for(OWLAxiom a : originalAxioms){
			if(axiomEntities.containsKey(a)){
				originalEntities.addAll(axiomEntities.get(a));
			}			
		}
		for(OWLAxiom a : allAxioms){
			if(!originalAxioms.contains(a) && comparableEntities.containsKey(a)){
				HashSet<OWLEntity> leftEnts = comparableEntities.get(a);
				if(!leftEnts.isEmpty()){
					for(OWLEntity ent : leftEnts){
						if(originalEntities.contains(ent)){
							relatedAxioms.add(a);
							break;
						}
					}					
				}					
			}				
		}
		return relatedAxioms;
	}
		

	public HashSet<OWLEntity> getALCComparableEntities(OWLAxiom a) {
		HashSet<OWLEntity> entities = new HashSet<OWLEntity>();
		
		if(a instanceof OWLSubClassOfAxiom) {
			OWLSubClassOfAxiom c = (OWLSubClassOfAxiom)a;
			OWLClassExpression subClassExp = c.getSubClass();
			if(!subClassExp.isAnonymous()){
				entities.add(subClassExp.asOWLClass());
			}
			
		} /*else if(a instanceof OWLEquivalentClassesAxiom){
			for(OWLEntity d : SelectionFunctionUtils.getEntities(a)){
				if(d instanceof OWLClass){
					entities.add((OWLClass)d);
				}
			}
		} else if (a instanceof OWLDisjointClassesAxiom){
			for(OWLEntity d : SelectionFunctionUtils.getEntities(a)){
				if(d instanceof OWLClass){
					entities.add((OWLClass)d);
				}
			}
		}*/ /*else if(a instanceof SubObjectPropertyOf) {
			SubObjectPropertyOf c = (SubObjectPropertyOf)a;
			for(ObjectPropertyExpression op : c.getSubObjectProperties()){
				entities.add((OWLEntity)op);
			}
		} else if(a instanceof SubDataPropertyOf) {
			SubDataPropertyOf c = (SubDataPropertyOf)a;
			entities.add((OWLEntity) c.getSubDataProperty());
		}*/
		return new HashSet<OWLEntity>(entities);
	}	
	

	public boolean isRelevant(OWLAxiom tbcAx, HashSet<OWLAxiom> existingAxsioms){
		boolean flag = false;
		
		for(OWLAxiom at : existingAxsioms){
			if(this.isRelevant(at, tbcAx)){
				flag = true;
				break;
			}
		}
		
		return flag;
	}
	
	public boolean isRelevant(OWLAxiom existingAx, OWLAxiom tbcAx){
		if( axiomEntities.containsKey(existingAx) && 
				comparableEntities.containsKey(tbcAx)){
			HashSet<OWLEntity> ents1 = axiomEntities.get(existingAx);
			HashSet<OWLEntity> ents2 = comparableEntities.get(tbcAx);
			for(OWLEntity ent : ents1){
				if(ents2.contains(ent)){
					return true;
				}
			}
		}		
		return false;
	}
	
	public boolean isRelevant(OWLEntity c, OWLAxiom a){
		if(comparableEntities.containsKey(a)){
			HashSet<OWLEntity> entities = comparableEntities.get(a);
			if(entities.contains(c))
				return true;
			else
				return false;
		} else {
			return false;
		}		
	}

	@Override
	public Vector<HashSet<OWLAxiom>> getAllRelatedLayers(OWLEntity entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiom == null)
			return;		
		if(!axiomEntities.containsKey(axiom)){
			axiomEntities.put(axiom, new HashSet<OWLEntity>(axiom.getSignature()));
		}
		
		this.allAxioms.add(axiom);
	}


	@Override
	public void removeAxiom(OWLAxiom axiom) {
		// TODO Auto-generated method stub
		if(axiomEntities.containsKey(axiom)){
			axiomEntities.remove(axiom);
		}
		allAxioms.remove(axiom);
	}
}
