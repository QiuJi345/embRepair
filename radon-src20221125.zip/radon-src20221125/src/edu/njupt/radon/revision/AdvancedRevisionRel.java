package edu.njupt.radon.revision;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.relative.RelativeDebug;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceParameters;
import edu.njupt.radon.result.RevisionResult;
import edu.njupt.radon.selefunc.SelectionFunction;
import edu.njupt.radon.selefunc.SigBasedSelectionFunction;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.Timer;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * This class needs to be checked later to see its purpose.
 * 
 * @author QiuJi
 * @modified 2018.11.01 Make some minor changes.
 */
public class AdvancedRevisionRel  {
	
	private Vector<OWLAxiom> hs = new Vector<OWLAxiom>();
	HashSet<OWLAxiom> allAxioms;
	HashSet<OWLAxiom> incoAxioms;
	Timer testTimer;	
	Timer checkSatTimer ;	
	SelectionFunction ssf ;	
	HashSet<Vector<OWLAxiom>> hs_onto; //store the hs w.r.t. the entire ontology
	RelativeDebug find;
		
	public AdvancedRevisionRel(HashSet<OWLAxiom> allAxioms_t,
			HashSet<OWLAxiom> incoAxioms){
		this.allAxioms = allAxioms_t;
		this.incoAxioms = incoAxioms;
		testTimer = new Timer();
		checkSatTimer = new Timer();		
		hs_onto = new HashSet<Vector<OWLAxiom>>();	
		find = new RelativeDebug(allAxioms, incoAxioms);
	}
	
	public RevisionResult doRevisionOneByOne(){
		
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		HashSet<HashSet<OWLAxiom>> clMUPS = null;
		Vector<OWLAxiom> diagnose_t = null;
		HashSet<OWLAxiom> diagnose = new HashSet<OWLAxiom>();		
		RevisionResult repairRs = new RevisionResult();	
		long repairTime = 0;
		int i = 0;
		
		if(ReasoningTools.isCoherent(allAxioms, checkSatTimer)){
			repairRs.setCheckTime(checkSatTimer.getTotal());
			repairRs.setCheckTimes(checkSatTimer.getCount());
			repairRs.setTestTime(testTimer.getTotal());
			repairRs.setRepairTime(0);
			return repairRs;
		}
		
		OWLOntology o = OWLTools.createOntology(allAxioms);
		for (OWLClass cl : o.getClassesInSignature()) {
			if (ReasoningTools.isSatisfiable(allAxioms, cl, checkSatTimer)) {
				continue;
			}
			System.out.println((i++)+"> Unsatisfiable concept : "+cl.toString()+" ("+allAxioms.size()+")");
						
			clMUPS = this.getMUPS(cl);
			mups.put(cl, new HashSet<HashSet<OWLAxiom>>(clMUPS));	
			System.out.println("MUPS:");
			CommonTools.printMultiSets(clMUPS, null);

			if(mups==null || mups.size()==0){
				System.out.println("Can not find mups for incoherence.");
				break;
			}
			long s = System.currentTimeMillis();
			if(hs_onto.size()>0){
				diagnose_t = hs_onto.iterator().next();
			}			
			repairTime += System.currentTimeMillis() - s;
			
            //remove one diagnose from rest ontology axioms	
			if(diagnose_t!=null && diagnose_t.size()>0){
				System.out.println("To resolve incoherence, the following axioms are removed from original ontology :");
				CommonTools.printOneSet(diagnose_t, null, null);
				testTimer.start();
				diagnose.addAll(diagnose_t);
				allAxioms.removeAll(diagnose_t);
				incoAxioms.removeAll(diagnose_t);
				diagnose_t.clear();
				testTimer.stop();
				
			}		
		}
		
		repairRs.setMUPS(mups);
		repairRs.setRemovedAxioms(diagnose);
		repairRs.setRepairTime(repairTime);
		repairRs.setCheckTime(checkSatTimer.getTotal()+find.getCheckSatTime());
		repairRs.setCheckTimes(checkSatTimer.getCount()+find.getCheckSatTimes());
		repairRs.setTestTime(testTimer.getTotal()+find.getTestTime());	
		
		return repairRs;		
	}
	
	/**
	 * Compute some MUPS with a hitting set where the axioms in a MUPS
	 * only belong to incAx.
	 * 
	 * @param oc : an unsatisfiable concept
	 * @param allAx : all the axioms to be considered including incAx 
	 * @param incAx : the axioms to be modified to resolve incoherence
	 * @return
	 */
	public HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass oc) {	
		
		HashSet<OWLAxiom> originalAllAx = new HashSet<OWLAxiom>(allAxioms);
		HashSet<OWLAxiom> incAx = new HashSet<OWLAxiom>(incoAxioms);
		HashSet<HashSet<OWLAxiom>> allMUPS = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> layerMUPS = null;
		HashSet<OWLAxiom> allAx = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> incoherentAx = new HashSet<OWLAxiom>();		
		HashSet<OWLAxiom> related = null;
		int layer = 0;	
		
		//Select axioms to be considered from original ontology
		testTimer.start();		
		ssf = new SigBasedSelectionFunction(originalAllAx);	
		related = ssf.getRelatedAxioms(oc);
		//OWLTools.printOneSet(related, null);
		testTimer.stop();
		while(related.size()>0){			
			testTimer.start();
			allAx.addAll(related);
			testTimer.stop();
			
			System.out.println("Layer_"+(layer++)+" : "+related.size()+" ( total = "+allAx.size()+" )");
			

			if(hs_onto.size()>0){					
				testTimer.start();
				hs = new Vector<OWLAxiom>(hs_onto.iterator().next());
				originalAllAx.removeAll(hs);
				testTimer.stop();
				
				if(!ReasoningTools.isSatisfiable(originalAllAx, oc, this.checkSatTimer)){						
					testTimer.start();
					allAx.removeAll(hs);
					incAx.removeAll(hs);
					testTimer.stop();
					
					incoherentAx = CommonTools.getIntersectSet(incAx, allAx);
					find.setAllAxioms(allAx);
					find.setIncoAxioms(incoherentAx);
					layerMUPS = find.getMUPS(oc);
					
					testTimer.start();
					incAx.addAll(hs);
					allAx.addAll(hs);
					
					if(layerMUPS.size()>0){
						allMUPS.addAll(layerMUPS);						
						hs_onto = new HashSet<Vector<OWLAxiom>>(find.getHittingSets());
						hs.addAll(hs_onto.iterator().next());
					} 					
					testTimer.stop();
				} else {
					break;
				}
				testTimer.start();
				originalAllAx.addAll(hs);
				testTimer.stop();
									
				
			} else if(!ReasoningTools.isSatisfiable(allAx, oc, this.checkSatTimer)){
				incoherentAx = CommonTools.getIntersectSet(incAx, allAx);
				find.setAllAxioms(allAx);
				find.setIncoAxioms(incoherentAx);
				layerMUPS = find.getMUPS(oc);

				testTimer.start();	
				allMUPS.addAll(layerMUPS);
				hs_onto.addAll(find.getHittingSets());
				testTimer.stop();
			}
			
		
			
			//Obtain next related axioms
			testTimer.start();
			related = ssf.getRelatedAxioms(allAx);
			testTimer.stop();
		} 	
			
		return allMUPS;
	}
	



		
	/**
	 * Compute some MUPS with a hitting set where the axioms in a MUPS
	 * only belong to incAx.
	 * 
	 * @param oc : an unsatisfiable concept
	 * @param allAx : all the axioms to be considered including incAx 
	 * @param incAx : the axioms to be modified to resolve incoherence
	 * @return
	 */
	public HashSet<HashSet<OWLAxiom>> process2(			 
			OWLClass oc,
			HashSet<OWLAxiom> originalAllAx,
			HashSet<OWLAxiom> incAx){	
		

		HashSet<HashSet<OWLAxiom>> allMUPS = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> layerMUPS = null;
		HashSet<OWLAxiom> allAx = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> incoherentAx = new HashSet<OWLAxiom>();		
		HashSet<OWLAxiom> related = null;
		HashSet<Vector<OWLAxiom>> hs_final = new HashSet<Vector<OWLAxiom>>(); //
		HashSet<Vector<OWLAxiom>> hs_tbc = new HashSet<Vector<OWLAxiom>>() ; //store some branches to be continued
		int layer = 0;	
		
		try {
			//Select axioms to be considered from original ontology
			testTimer.start();			
			ssf = new SigBasedSelectionFunction(originalAllAx);	
			related = ssf.getRelatedAxioms(oc);
			//OWLTools.printOneSet(related, null);
			testTimer.stop();
			while(related.size()>0){			
				testTimer.start();
				allAx.addAll(related);
				testTimer.stop();
				
				System.out.println("Layer_"+(layer++)+" : "+related.size()+" ( total = "+allAx.size()+" )");
				
				if(hs_onto.size()>0){	
					//check each branch to see which branch is already hs
					hs_tbc.clear();
					for(Vector<OWLAxiom> oneHS : hs_onto){
						if(hs_final.contains(oneHS))
							continue;
						testTimer.start();
						originalAllAx.removeAll(oneHS);
						incAx.removeAll(oneHS);
						testTimer.stop();
						try {
							if(!ReasoningTools.isSatisfiable(originalAllAx, oc, this.checkSatTimer)){						
								hs_tbc.add(new Vector<OWLAxiom>(oneHS));
							} else {
								testTimer.start();
								hs_final.add(new Vector<OWLAxiom>(oneHS));
								if(RelevanceParameters.debugStrategy == RelevanceParameters.COMPUTE_ONE_CM_HS_REL){
									testTimer.stop();
									break;
								}
								testTimer.stop();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						testTimer.start();
						originalAllAx.addAll(oneHS);
						incAx.addAll(oneHS);
						testTimer.stop();
					}
					hs_onto = new HashSet<Vector<OWLAxiom>>(hs_final);
					//If some hs exist and we do not compute all justs, or
					//all the branches can not be expanded (i.e. no more justs exist along the branch), 
					//the iteration by adding related axioms can be terminated.  
					if((hs_final.size()>0 && RelevanceParameters.debugStrategy != RelevanceParameters.COMPUTE_ALL_HS_REL) ||
							(hs_tbc.size()==0)){ 
						break;
					} 
					
					//For those branches which are not hs in the entire ontology, continue to expand them.
					for(Vector<OWLAxiom> oneHS : hs_tbc){
						/*System.out.println("Current hs : ");
						OWLTools.printOneSet(oneHS, null, null);*/
						
						testTimer.start();
						allAx.removeAll(oneHS);	
						hs_onto.clear();
						testTimer.stop();
						
						incoherentAx = CommonTools.getIntersectSet(incAx, allAx);
						find.setAllAxioms(allAx);
						find.setIncoAxioms(incoherentAx);
						layerMUPS = find.getMUPS(oc);
						
						testTimer.start();
						if(layerMUPS.size()>0){
							allMUPS.addAll(layerMUPS);
							HashSet<Vector<OWLAxiom>> hst = new HashSet<Vector<OWLAxiom>>(hs_onto);
							/*System.out.println("New hs : ");
							for(Vector<OWLAxiom> hs : hst){
								OWLTools.printOneSet(hs, null, null);
							}	*/
							for(Vector<OWLAxiom> path : hst){
								Vector<OWLAxiom> newPath = new Vector<OWLAxiom>(oneHS);
								newPath.addAll(path);
								hs_onto.add(newPath);	
							}					
						} 
						allAx.addAll(oneHS);
						testTimer.stop();
					}		
					
					
				} else if(!ReasoningTools.isSatisfiable(allAx, oc, this.checkSatTimer)){
					incoherentAx = CommonTools.getIntersectSet(incAx, allAx);
					find.setAllAxioms(allAx);
					find.setIncoAxioms(incoherentAx);
					layerMUPS = find.getMUPS(oc);

					testTimer.start();	
					allMUPS.addAll(layerMUPS);
					hs_onto.addAll(find.getHittingSets());
					testTimer.stop();
					if(RelevanceParameters.debugStrategy == RelevanceParameters.COMPUTE_ONE_CM_HS_REL){
						return allMUPS;
					}
				}
				
				//Obtain next related axioms
				testTimer.start();
				related = ssf.getRelatedAxioms(allAx);
				testTimer.stop();
			} 	
				
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return allMUPS;
	}
	
}
