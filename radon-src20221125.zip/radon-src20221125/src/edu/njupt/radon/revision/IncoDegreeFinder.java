package edu.njupt.radon.revision;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.Timer;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * TODO This class is to find the maximal inconsistency degree. That is to say,
 * if all the axioms with the weights which are larger than this degree, they
 * are consistent. But once the axioms with the weights which are equal to this
 * degree, these axioms will become inconsistent.
 * 
 * @author Qiu Ji
 * @date 30.07.2008
 */
public class IncoDegreeFinder {
	
	Timer testTimer;	
	Timer checkSatTimer;


	public IncoDegreeFinder(Timer testTimer, Timer checkSatTimer){
		this.testTimer = testTimer;
		this.checkSatTimer = checkSatTimer;
	}

    /**
     * Use binary search to find the maximal incoherent degree.
     * 
     * @param begin
     * @param end
     * @return
     * @throws Exception
     */
	public int getIncoherenceDegree(
			HashMap<Double, HashSet<OWLAxiom>> weightAxioms, 
			Vector<Double> sortedWeights,
			HashSet<OWLAxiom> stableAxioms,
			int begin, int end) {
		
		HashSet<OWLAxiom> allAxioms = null;
		int degreeLayer = 0; // The highest layer where the inconsistency occurs			
		int middle = 0;
			
		testTimer.start();
		allAxioms  = new HashSet<OWLAxiom>(stableAxioms);	
		allAxioms.addAll(this.getAxiomsInALayer(weightAxioms, sortedWeights,begin));
		testTimer.stop();
		
		//System.out.println("begin: "+begin);
		//System.out.println("coherent (incD >=begin): "+OWLTools.isCoherent(allAxioms));
		
		try{
			if (!ReasoningTools.isCoherent(allAxioms, checkSatTimer)) { //Check the layer with highest weight
				degreeLayer = begin;
				//System.out.println("d == begin: ");
			} else {
				testTimer.start();
				begin ++; //it is not necessary to check the first layer again
				allAxioms = new HashSet<OWLAxiom>(stableAxioms);
				for(HashSet<OWLAxiom> set : weightAxioms.values()){
					allAxioms.addAll(set);
				}			
				testTimer.stop();
				if(ReasoningTools.isCoherent(allAxioms, checkSatTimer)) { //check all layers
					degreeLayer = -1;
					//System.out.println("d = -1.");
				} else {
					while ((begin < end) ) {
						testTimer.start();
						middle = (end + begin) / 2;
						allAxioms = new HashSet<OWLAxiom>(stableAxioms);
						allAxioms.addAll(this.getAxiomsNLTWeightDsc(weightAxioms, sortedWeights,middle));
						testTimer.stop();
						if (ReasoningTools.isCoherent(allAxioms, checkSatTimer)) {
							if((end-begin)==1){
								return end;
							}
							begin = middle;
							//System.out.println("begin = "+middle);
						} else {
							end = middle;
							//System.out.println("end = "+middle);
						}
					}
					degreeLayer = end;
				}					
			}
		} catch (Exception ex){
			ex.printStackTrace();
		}
		return degreeLayer;
	}
	
	/**
	 * To get all the axioms with weight above a given weight in the case that
	 * Vector weights is in ascendent order.
	 * 
	 * @param weight
	 * @return
	 */
	public HashSet<OWLAxiom> getAxiomsNLTWeightAsc(
			HashMap<Double, HashSet<OWLAxiom>> weightAxioms, 
			Vector<Double> sortedWeights,
			int degreeLayer) {
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		int i = sortedWeights.size() - 1;
		while (i>=degreeLayer) {
			axioms.addAll(weightAxioms.get(sortedWeights.get(i)));
			i--;
			if (i < 0)
				break;
		}
		return axioms;
	}

	public HashSet<OWLAxiom> getAxiomsAboveWeightAsc(
			HashMap<Double, HashSet<OWLAxiom>> weightAxioms, 
			Vector<Double> sortedWeights, 
			int degreeLayer) {
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		int i = sortedWeights.size() - 1;
		while (i > degreeLayer) {
			axioms.addAll(weightAxioms.get(sortedWeights.get(i)));
			i--;
			if (i < 0)
				break;
		}
		return axioms;
	}
	
	public HashSet<OWLAxiom> getAxiomsNLTWeightDsc(
			HashMap<Double, HashSet<OWLAxiom>> weightAxioms, 
			Vector<Double> sortedWeights,
			int bound) {
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		int len = sortedWeights.size();
		int i = 0;
		while (i <= bound) {
			axioms.addAll(weightAxioms.get(sortedWeights.get(i)));
			i++;
			if (i >= len)
				break;
		}
		return axioms;
	}

	public HashSet<OWLAxiom> getAxiomsAboveWeightDsc(
			HashMap<Double, HashSet<OWLAxiom>> weightAxioms, 
			Vector<Double> sortedWeights,
			int lower, int upper) {
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		
		
		if(lower >= upper){
			return axioms;
		}
		int len = sortedWeights.size();
		if(upper > (len-1)){
			upper = len-1;
		}
		if(lower < 0){
			lower = 0;
		}
		
		int i = lower;
		while ((i < upper) && (i>=lower)) {
			axioms.addAll(weightAxioms.get(sortedWeights.get(i)));
			i++;			
		}
		return axioms;
	}
	
	public HashSet<OWLAxiom> getAxiomsInALayer(
			HashMap<Double, HashSet<OWLAxiom>> weightAxioms, 
			Vector<Double> sortedWeights,
			int degreeLayer){
		HashSet<OWLAxiom> ax = new HashSet<OWLAxiom>();
		ax.addAll(weightAxioms.get(sortedWeights.get(degreeLayer)));
		
		return ax;
	}
	
	
	public void outputCheckingProcessForInconDegree(
			HashMap<Double, HashSet<OWLAxiom>> weightAxioms, 
			Vector<Double> sortedWeights,
			int degreeLayer, String ns) throws Exception{

		System.out.println("*********************************************");
		System.out.println(" Look for and check the inconsistency degree ");
		System.out.println("*********************************************");

		HashSet<OWLAxiom> currentAxioms = new HashSet<OWLAxiom>();
		if(degreeLayer!=-1){
			System.out.println(" >>> The inconsistency layer = " + degreeLayer+", weight = "+sortedWeights.get(degreeLayer));	
//			 For test, to check whether the degreeLayer is what we want.			
			currentAxioms = new HashSet<OWLAxiom>(this.getAxiomsNLTWeightAsc(
					weightAxioms, sortedWeights, degreeLayer + 1));
			System.out.println();
			System.out.println(" >>> Check whether the degree obove is the inconsistency degree ... ");
			System.out.println();
			System.out.println(" --> Current axioms with weights >= "
					+ sortedWeights.get(degreeLayer + 1)
					+ ", and layers >= " + (degreeLayer + 1));
			CommonTools.printOneSet(currentAxioms,ns);
			System.out.println(" The ontology including the axioms above is consistent ? " + ReasoningTools.isCoherent(currentAxioms));
			
			currentAxioms = new HashSet<OWLAxiom>(this.getAxiomsNLTWeightAsc(
					weightAxioms, sortedWeights, degreeLayer));	
			System.out.println();
			System.out.println(" --> Current axioms with weights = "
					+ sortedWeights.get(degreeLayer)+" and layer = "+degreeLayer);
			CommonTools.printOneSet(weightAxioms.get(sortedWeights.get(degreeLayer)),ns);
			System.out.println(" --> The ontology including axioms with weights >= "
					+ sortedWeights.get(degreeLayer )
					+ ", and layers >= " + degreeLayer+" is consistent ? " + ReasoningTools.isCoherent(currentAxioms));
			System.out.println();			
		} else {
			System.out.println(" >>> No more inconsistency degree can be found!  ");			
		}
	}

}
