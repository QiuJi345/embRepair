package edu.njupt.radon.revision;

import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.relative.RelativeDebug;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.repair.RepairWithWeight;
import edu.njupt.radon.result.RevisionResult;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.Timer;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * This class is to do revision using an advanced way. That is,
 * (1) Assume the original ontology O_stable is more reliable and the new coming
 * one O_new will cause inconsistency, we compute MUPS in O_new.
 * (2) Repair O_new according to the found MUPS.
 * 
 * @author Qiu Ji
 * @date 2008.07.31
 * @revised 2009.02.13
 * @revised 2018.10.31
 */
public class RelativeRevision implements RadonRevision {
	// The set of axioms of the stable ontology and the new coming one.
	HashSet<OWLAxiom> allAxioms;
	// The set of axioms in the new coming one
	HashSet<OWLAxiom> incoAxioms;
	private boolean useConfidenceValue = false;
	private HashMap<OWLAxiom, Double> weights = null;
	private RelativeDebug find ;
	
	Timer testTimer;	
	Timer checkSatTimer;	
	
	
	public RelativeRevision(HashSet<OWLAxiom> allAxioms,
			HashSet<OWLAxiom> incoAxioms){
		this.allAxioms = allAxioms;
		this.incoAxioms = incoAxioms;
		find = new RelativeDebug(allAxioms, incoAxioms);
			
		testTimer = new Timer();
		checkSatTimer = new Timer();		
	}
	
	
	/**
	 * This method is to revise unsatisfiabilities one by one by.
	 * Alg. 3
	 *  
	 * @param stableAxioms
	 * @param incoAxioms
	 * @return
	 */
	@Override
	public RevisionResult reviseUcs(){
		
		RevisionResult res = new RevisionResult();	
		
		long repairTime = 0;
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		HashSet<HashSet<OWLAxiom>> clMUPS = null;
		HashSet<OWLAxiom> diagnose = new HashSet<OWLAxiom>();			
		HashSet<OWLAxiom> allAxioms_t = new HashSet<OWLAxiom>(allAxioms);
		HashSet<OWLAxiom> incoAxioms_t = new HashSet<OWLAxiom>(incoAxioms);
		
		int i = 0;
		OWLOntology o = OWLTools.createOntology(allAxioms_t);
		for (OWLClass cl : o.getClassesInSignature()) {
			if (ReasoningTools.isSatisfiable(allAxioms_t, cl, checkSatTimer)) {
				continue;
			}
			System.out.println((i++)+"> Unsatisfiable concept : "+cl.toString()+" ("+allAxioms_t.size()+")");
						
			find.setAllAxioms(allAxioms_t);
			find.setIncoAxioms(incoAxioms_t);
			clMUPS = find.getMUPS(cl);
			mups.put(cl, new HashSet<HashSet<OWLAxiom>>(clMUPS));	
			
			System.out.println("MUPS:");
			CommonTools.printMultiSets(clMUPS, null);

			if(mups.isEmpty()){
				System.out.println("Cannot find any mups!");
				break;
			}
			
			HashSet<OWLAxiom> diagnose_t = new HashSet<OWLAxiom>();
			long s = System.currentTimeMillis();				
			if(useConfidenceValue){
				diagnose_t = RepairWithWeight.getOneDiagnoseByHST(
						RepairWithWeight.getLowWeights(clMUPS, weights));
			} else {
				diagnose_t = RepairWithScore.getOneDiagnoseByHST(
						RepairWithScore.getHighScores(clMUPS));
			}
			repairTime += System.currentTimeMillis() - s;
			
            //remove one diagnose from rest ontology axioms	
			if(diagnose_t.size()>0){
				System.out.println("To resolve incoherence, the following axioms are removed from original ontology :");
				CommonTools.printOneSet(diagnose_t, null);
				testTimer.start();
				diagnose.addAll(diagnose_t);
				allAxioms_t.removeAll(diagnose_t);
				incoAxioms_t.removeAll(diagnose_t);
				testTimer.stop();
			}		
		}
		
		res.setTestAxioms(allAxioms_t);
		res.setMUPS(mups);
		res.setRemovedAxioms(diagnose);
		res.setRepairTime(repairTime);
		res.setCheckTime(checkSatTimer.getTotal()+find.getCheckSatTime());
		res.setCheckTimes(checkSatTimer.getCount()+find.getCheckSatTimes());
		res.setTestTime(testTimer.getTotal()+find.getTestTime());	
		
		return res;
	}
	
	/**
	 * This method is to revise unsatisfiabilities one by one by using weights
	 */
	@Override
	public RevisionResult reviseUcsWithWeights(HashMap<OWLAxiom, Double> weights) {
		this.weights = weights;
		this.useConfidenceValue = false;
		return reviseUcs();
	}

	/**
	 * This method compute MIPS first and then choose axioms to be removed. 
	 * Alg. 1 (useConfidenceValue = false)
	 * Alg. 2 (useConfidenceValue = true)
	 */
	@Override
	public RevisionResult reviseOnt(){
		
		RevisionResult res = new RevisionResult();	
		long repairTime = 0;
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		HashSet<HashSet<OWLAxiom>> clMUPS = null;
		HashSet<HashSet<OWLAxiom>> mips = new HashSet<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> diagnose = new HashSet<OWLAxiom>();			
		HashSet<OWLAxiom> allAxioms_t = new HashSet<OWLAxiom>(allAxioms);
		
		// Compute all mups for all usnatisfiable concepts
		int i = 0;
		for (OWLClass cl : ReasoningTools.getUnsatiConcepts(allAxioms_t)) {				
			System.out.println((i++)+"> Unsatisfiable concept : "+cl.toString()+" ("+allAxioms_t.size()+")");
						
			clMUPS = find.getMUPS(cl);
			mups.put(cl, new HashSet<HashSet<OWLAxiom>>(clMUPS));	
			System.out.println("MUPS:");
			CommonTools.printMultiSets(clMUPS, null);

			if(mups==null || mups.size()==0){
				System.out.println("Can not find mups for incoherence.");
				break;
			}				
		}
		
		// Compute mips based on all mups
		mips = find.getMIPS(mups);
		
		// Find axioms to be removed
		long s = System.currentTimeMillis();				
		if(useConfidenceValue){
			diagnose = RepairWithWeight.getOneDiagnoseByHST(
					RepairWithWeight.getLowWeights(mips, weights));
		} else {
			diagnose = RepairWithScore.getOneDiagnoseByHST(
					RepairWithScore.getHighScores(mips));
		}
		repairTime += System.currentTimeMillis() - s;
		
        //remove one diagnose from rest ontology axioms	
		if(diagnose.size()>0){
			System.out.println("To resolve incoherence, the following axioms are removed from original ontology :");
			CommonTools.printOneSet(diagnose, null);
		}		
		
		res.setTestAxioms(allAxioms_t);
		res.setMUPS(mups);
		res.setMIPS(mips);
		res.setRemovedAxioms(diagnose);
		res.setRepairTime(repairTime);
		res.setCheckTime(checkSatTimer.getTotal()+find.getCheckSatTime());
		res.setCheckTimes(checkSatTimer.getCount()+find.getCheckSatTimes());
		res.setTestTime(testTimer.getTotal()+find.getTestTime());	
		
		return res;
	}
	
	/**
	 * This method compute MIPS first and then choose axioms to be removed by using weights. 
	 */
	@Override
	public RevisionResult reviseOntWithWeights(HashMap<OWLAxiom, Double> weights){
		this.weights = weights;
		this.useConfidenceValue = false;
		return reviseOnt();
	}
	
}
