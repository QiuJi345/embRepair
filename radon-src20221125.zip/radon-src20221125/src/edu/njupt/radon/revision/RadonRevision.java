package edu.njupt.radon.revision;

import java.util.HashMap;

import org.semanticweb.owlapi.model.OWLAxiom;

import edu.njupt.radon.result.RevisionResult;

public interface RadonRevision {
	// Revise the unsatisfiability one by one
	public RevisionResult reviseUcs();
	// Revise the unsatisfiability one by one by using weights associated to axioms
	public RevisionResult reviseUcsWithWeights(HashMap<OWLAxiom, Double> weights);
	// Revise all unsatisfiability together by computing MIPS
	public RevisionResult reviseOnt();
	// Revise all unsatisfiability together by computing MIPS and using weights
	public RevisionResult reviseOntWithWeights(HashMap<OWLAxiom, Double> weights);

}
