package edu.njupt.radon.parser;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import edu.njupt.radon.utils.OWLTools;


public class AlignmentParser {
	
	OWLOntology sourceOnto, targetOnto;
	
	public AlignmentParser(OWLOntology sourceOnto, OWLOntology targetOnto){
		this.sourceOnto = sourceOnto;
		this.targetOnto = targetOnto;
	}
		
	public HashMap<OWLAxiom, Double> readMappingsFromFile(String fileName) {		
		String array[][] = {};
		HashMap<OWLAxiom, Double> mappings = new HashMap<OWLAxiom, Double>();
		OWLAxiom ax = null;
		String string = "";
		
		try{
			fileName = fileName.replace("\\", "/");
			FileReader in = new FileReader(fileName);
			BufferedReader filebuf = new BufferedReader(in);
			String oneLine = filebuf.readLine();			
			while (oneLine != null) {
				string = string + oneLine + "\n";
				oneLine = filebuf.readLine();
			}
			in.close();
		} catch (Exception ex){
			System.err.println("Exception occurs when opening a file!");
			ex.printStackTrace();
		}
		
			
		if((string.contains("<entity1"))&&(string.contains("<entity2"))
				&&(string.contains("<relation>"))){ //inria format
			INRIAAlignmentAPI api = new INRIAAlignmentAPI();
			array = api.StringToArray(string);	
		} else if(string.contains("@prefix a: <")&&
				string.contains("ao:elementA a:")&&
				(string.contains("ao:alignmentConfidence"))){ //n3 format
			INRIAAlignmentAPI api = new INRIAAlignmentAPI();
			array = api.LMStringToArray(string);	
		} else if((string.contains(" > ")||(string.contains(" < "))&&(string.contains(" | ")))){
			array = ManheimMappingParser.stringToArray(string);
		} else {
			CSVParser csvParse = new CSVParser();
			array = csvParse.stringToArray(string);		
		}
		
		//Assume the order for each mapping is : 
		//entity1, entity2, similarity (optional), relation (optional)
		if(array.length >0){ 
			//System.out.println("golden standard");
			for (int i = 0; i < (array.length); i++) {
				ax = null;
				double weight = 1.0;
				if(array[i].length==2){
					ax = this.createMappingAxiom(array[i][0], array[i][1], null, null);
				} else if (array[i].length==3){
					weight = Double.valueOf(array[i][2]);
					if(weight>0){
						ax = this.createMappingAxiom(array[i][0], array[i][1], array[i][2], null);
					}					
					
				} else if (array[i].length==4){
					weight = Double.valueOf(array[i][2]);
					if(weight>0){
						ax = this.createMappingAxiom(array[i][0], array[i][1], array[i][2], array[i][3]);
					}					
				}
				if(ax!=null) {
					mappings.put(ax, weight);
				}
			}
		}	
		return mappings;
	}
	
	public OWLAxiom createMappingAxiom(String str1, String str2,
			String sim, String relation) {
		OWLAxiom a = null;
		OWLEntity ent1, ent2;
		
        ent1 = OWLTools.getEntity(sourceOnto, str1);
        ent2 = OWLTools.getEntity(targetOnto, str2);
        
        OWLOntologyManager manager = OWLTools.manager;
        if(manager == null){
        	manager = OWLTools.createOntologyManager();
        }
    	OWLDataFactory factory = manager.getOWLDataFactory();
        if((ent1!=null)&&(ent2!=null)){        	
        	if((ent1 instanceof OWLClass)&&(ent2 instanceof OWLClass)){
        		Vector<OWLClass> ents = new Vector<OWLClass>();
        		ents.add((OWLClass)ent1);
        		ents.add((OWLClass)ent2);            	
            	
            	if((relation!=null)&&(relation.equals("<"))){            		
            		a = factory.getOWLSubClassOfAxiom(ents.get(0), ents.get(1));
            	} else if((relation!=null)&&(relation.equals(">"))){
            		a = factory.getOWLSubClassOfAxiom(ents.get(1), ents.get(0));
            	} else if((relation!=null)&&(relation.equals("<>"))){
            		a = factory.getOWLDisjointClassesAxiom(ents.get(0), ents.get(1));
            	} else {
            		a = factory.getOWLEquivalentClassesAxiom(new HashSet<OWLClass>(ents));
            	}        		
        		
        	} else if((ent1 instanceof OWLObjectProperty)&&
        			(ent2 instanceof OWLObjectProperty)){
        		Vector<OWLObjectPropertyExpression> ents = new Vector<OWLObjectPropertyExpression>();
        		ents.add((OWLObjectPropertyExpression)ent1);
        		ents.add((OWLObjectPropertyExpression)ent2); 
            	if((relation!=null)&&(relation.equals("<"))){
            		a = factory.getOWLSubObjectPropertyOfAxiom(ents.get(0), ents.get(1));
            	} else if((relation!=null)&&(relation.equals(">"))){
            		a = factory.getOWLSubObjectPropertyOfAxiom(ents.get(1), ents.get(0));
            	} else if((relation!=null)&&(relation.equals("<>"))){
            		HashSet<OWLObjectPropertyExpression> entities = new HashSet<OWLObjectPropertyExpression>(ents);
            		a = factory.getOWLDisjointObjectPropertiesAxiom(entities);
            	} else {
            		a = factory.getOWLEquivalentObjectPropertiesAxiom(
            				new HashSet<OWLObjectPropertyExpression>(ents));
            	}  
        		
        	} else if((ent1 instanceof OWLDataPropertyExpression)&&(ent2 instanceof OWLDataPropertyExpression)){
        		Vector<OWLDataPropertyExpression> ents = new Vector<OWLDataPropertyExpression>();
        		ents.add((OWLDataPropertyExpression)ent1);
            	ents.add((OWLDataPropertyExpression)ent2);
            	if((relation!=null)&&(relation.equals("<"))){
            		a = factory.getOWLSubDataPropertyOfAxiom(ents.get(0), ents.get(1));
            	} else if((relation!=null)&&(relation.equals(">"))){
            		a = factory.getOWLSubDataPropertyOfAxiom(ents.get(1), ents.get(0));
            	} else if((relation!=null)&&(relation.equals("<>"))){
            		HashSet<OWLDataPropertyExpression> entities = new HashSet<OWLDataPropertyExpression>(ents);
            		a = factory.getOWLDisjointDataPropertiesAxiom(entities);
            	} else {
            		a = factory.getOWLEquivalentDataPropertiesAxiom(
            				new HashSet<OWLDataPropertyExpression>(ents));
            	}  
        		
        	} else if((ent1 instanceof OWLIndividual)&&(ent2 instanceof OWLIndividual)){        		
            	Vector<OWLIndividual> ents = new Vector<OWLIndividual>();
        		ents.add((OWLIndividual)ent1);
            	ents.add((OWLIndividual)ent2);            	
        		a = factory.getOWLSameIndividualAxiom(new HashSet<OWLIndividual>(ents));
        	}
        }
		
		return a;		
	}	

}
