package edu.njupt.radon.parser;

import java.util.Vector;

public class ManheimMappingParser {
	
	public static String[][] stringToArray(String text) {
		String[][] numbers = {{""}};
        String str = text;
        int index = -1;
		Vector<String[]> vector = new Vector<String[]>();
		String[] mapping = new String[4];
		String sourceNs = "", targetNs = "";
		
		String line = null;
		index = str.indexOf("\n");
		while(index!=-1){
			line = str.substring(0,index);
			str = str.substring(index+1);
			
			if(line.contains("sourceNamespace = ")){
				sourceNs = line.substring(String.valueOf("sourceNamespace = ").length()).trim()+"#";
			} else if(line.contains("targetNamespace = ")){
				targetNs = line.substring(String.valueOf("targetNamespace = ").length()).trim()+"#";
			}
			mapping = new String[4]; 
			mapping[3] = ">";
			int i = line.indexOf(" > ");
			if(i==-1){
				mapping[3] = "<";
				i = line.indexOf(" < ");
			}
			if(i!=-1){
				mapping[0] = sourceNs+line.substring(0,i);	
				line = line.substring(i+3);
				i = line.indexOf(" | ");
				if(i!=-1){
					mapping[1] = targetNs+line.substring(0, i);
					mapping[2] = line.substring(i+3).trim();
				}			
				vector.add(mapping);
			}
			
			index = str.indexOf("\n");
		}		
		
		numbers = new String[vector.size()][4];
		for (int row = 0; row<vector.size(); row++) {
			mapping = (String[]) vector.elementAt(row);
			numbers[row] = mapping;
		}
		
		return numbers;	
	}
	
}
