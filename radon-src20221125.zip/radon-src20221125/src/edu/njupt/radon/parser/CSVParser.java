package edu.njupt.radon.parser;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.StringTokenizer;
import java.util.Vector;

public class CSVParser {

	private String delimiter = ";";
	
	public CSVParser() {
	}
	
	public void changeDelimiter(String delimiterT){
		delimiter = delimiterT;
	}
	
	public String[][] stringToArray(String text) {

		String[][] numbers = {{""}};
        String str = text;
        int index = -1;
		Vector<String> vector = new Vector<String>();
		
		String line = null;
		int maxrow = 0;
		int maxcol = 0;	 
		index = str.indexOf("\n");
		while(index!=-1){
			line = str.substring(0,index);
			str = str.substring(index+1);
			if (maxcol==0) {
				StringTokenizer st = new StringTokenizer(line,delimiter);
				maxcol = st.countTokens();
			}
			vector.add(line);
			index = str.indexOf("\n");
		}
		
		
		maxrow = vector.size();	
		numbers = new String[maxrow][maxcol];
		for (int row = 0; row<maxrow; row++) {
			int col = 0;
			line = (String) vector.elementAt(row);
			StringTokenizer st = new StringTokenizer(line,delimiter);
			while (st.hasMoreTokens())
			{	
				String token = st.nextToken();
				numbers[row][col] = token;
				col++;
			}
		}
		
		return numbers;
	
	}
	
	public String[][] getAllValues(String fileName) {
		String[][] numbers = {{""}};
		try {
		Vector vector = new Vector();
		InputStream inputStream; 
		if (fileName.startsWith("http://")) {
			URL address = new URL(fileName);
		    URLConnection urlConnection = address.openConnection();
		    inputStream = urlConnection.getInputStream();
		} else {
			inputStream = new FileInputStream(fileName);	
		}
		InputStreamReader inputStreamReader = new InputStreamReader(inputStream);	
		BufferedReader bufRdr  = new BufferedReader(inputStreamReader);
		String line = null;
		int maxrow = 0;
		int maxcol = 0;	 
		while((line = bufRdr.readLine()) != null) {
			if (maxcol==0) {
				StringTokenizer st = new StringTokenizer(line,delimiter);
				maxcol = st.countTokens();
			}
			vector.add(line);
		}
		bufRdr.close(); 
		maxrow = vector.size();	
		numbers = new String[maxrow][maxcol];
		for (int row = 0; row<maxrow; row++) {
			int col = 0;
			line = (String) vector.elementAt(row);
			StringTokenizer st = new StringTokenizer(line,delimiter);
			while (st.hasMoreTokens())
			{	
				String token = st.nextToken();
				numbers[row][col] = token;
				col++;
			}
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return numbers;
	}
	
	
}
