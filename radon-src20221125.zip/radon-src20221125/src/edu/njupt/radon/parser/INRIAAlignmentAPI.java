/*
 * Created on 29.12.2004
 *
 */
package edu.njupt.radon.parser;


/**
 * This class transforms the different existing mapping formats into each other.
 */
public class INRIAAlignmentAPI {
	
//	private static final String DIRECTION = "CSVtoINRIA";
	private static final String DIRECTION = "INRIAtoCSV";
//	private static final String DIRECTION = "LMtoCSV";
	private static final String INPUTFILE = "C:/Work/MLcompleteKAON2/eon04/onto304abMap.rdf";
	private static final String OUTPUTFILE ="C:/Work/MLcompleteKAON2/eon04/onto304abMapCSV.txt";
//	private static final String[] OAEINUMBERS = {"103","104","201","202","203","204","205","206","207","208","209","210","221","222","223","224","225","228","230","231","232","236","237","238","239","240","241","246","247","248","249","250","251","252","253","254","257","258","259","260","261","262","265","266","301","302","303","304"};	
	
	/**
	 * Karlsruhe array format to INRIA alignment API format.
	 * @param array
	 * @return
	 */
	public String ArrayToString(String[][] array, String onto1, String onto2) {
		String string = new String();
		if (array!=null) {
		string = string + 
				"<?xml version='1.0' encoding='utf-8' standalone='no'?>\n" +
				"<rdf:RDF xmlns='http://knowledgeweb.semanticweb.org/heterogeneity/alignment'\n" +
				"         xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#'\n" +
				"         xmlns:xsd='http://www.w3.org/2001/XMLSchema#'>\n"+
				"<Alignment>\n" +
				"  <xml>yes</xml>\n" +
				"  <level>0</level>\n" +
				"  <type>11</type>\n";
		if (onto1.equals("")) {
			onto1 = array[0][0];
			int j = onto1.indexOf("#");
			if (j!=-1) {onto1 = onto1.substring(0,j);}
			onto2 = array[0][1];
			j = onto2.indexOf("#");
			if (j!=-1) {onto2 = onto2.substring(0,j);}
			if (onto1.hashCode()<onto2.hashCode()) {
				String onto3 = onto1;
				onto1 = onto2;
				onto2 = onto3;
			}
		}
		string = string +"  <onto1>"+onto1+"</onto1>\n" +
			"  <onto2>"+ onto2 +"</onto2>\n" +
			"  <uri1>"+ onto1 +"</uri1>\n" +
			"  <uri2>"+ onto2 +"</uri2>\n" +
			"  <map>\n";
		for (int i = 0; i<array.length; i++) {
			String value = "1.0";
			if ((array[i].length>=3)&&(array[i][2].length()>1)) value = array[i][2]; 
			if ((array[i][0].startsWith(onto1))&&(array[i][1].startsWith(onto2))) {
				string = string + "    <Cell>\n"+
					"	<entity1 rdf:resource='"+array[i][0]+"'/>\n"+
					"	<entity2 rdf:resource='"+array[i][1]+"'/>\n"+
					"	<measure rdf:datatype='http://www.w3.org/2001/XMLSchema#float'>"+value+"</measure>\n"+
					"	<relation>=</relation>\n"+
					"    </Cell>\n";
			}
		}
		string = string + "  </map>\n"+
			"</Alignment>\n"+
			"</rdf:RDF>\n";		
		}
		return string;
	}
	

	
	/**
	 * INRIA Alignment API format to Karlsruhe array format
	 * @param string
	 * @return
	 */
	public String[][] StringToArray(String string) {
		int size = string.length()/100;
		String array[][] = new String[size][];
		String entity1 = "<entity1 rdf:resource=";
		String entity2 = "<entity2 rdf:resource=";
		String end = "/>";
		int index = 0;
		int pos1 = string.indexOf(entity1);
		while (pos1!=-1) {
			String element[] = new String[4];
			pos1 = pos1+entity1.length()+1;
			int pos2 = string.indexOf(end,pos1);
			element[0] = string.substring(pos1,pos2-1);
			pos1 = string.indexOf(entity2,pos2)+entity2.length()+1;
			pos2 = string.indexOf(end,pos1);
			element[1] = string.substring(pos1,pos2-1);			
			pos1 = string.indexOf("#float",pos2)+8;
			if(pos1 == -1 || pos1 < pos2){
				pos1 = string.indexOf(":float",pos2)+8;
			}
			pos2 = string.indexOf("</measure>",pos1);
			element[2] = string.substring(pos1,pos2);
			pos1 = string.indexOf("<relation>",pos2)+10;
			pos2 = string.indexOf("</relation>",pos1);
			String relation = string.substring(pos1,pos2);
			if(relation.equals("&gt;")){
				relation = ">";
			} else if(relation.equals("&lt;")){
				relation = "<";
			} else if(relation.equals("&lt;&gt;")){
				relation = "<>";
			}
			if (relation.equals("=") || relation.equals(">") 
					|| relation.equals("<") || relation.equals("<>")) {
				element[3] = relation;
				array[index] = element;	
				index++;	
			} 
			pos1 = string.indexOf(entity1,pos2);				
		}
		String array2[][] = new String[index][];
		for (int i = 0; i<index; i++) {
			array2[i]=array[i];
		}
		return array2;
	}

	/**
	 * Lockheed Martin N3 notation to Karlsruhe array format
	 * @param string
	 * @return
	 */
	public String[][] LMStringToArray(String string) {
		int size = string.length()/50;
		String array[][] = new String[size][];
		int index = 0;
		int pos1 = string.indexOf("@prefix a: <")+12;
		int pos2 = string.indexOf(">.",pos1);
		String ns1 = string.substring(pos1,pos2);
		pos1 = string.indexOf("@prefix b: <",pos2)+12;
		pos2 = string.indexOf(">.",pos1);
		String ns2 = string.substring(pos1,pos2);
		pos1 = string.indexOf("ao:elementA a:",pos2);
		while (pos1!=-1) {
			String element[] = new String[3];
			pos1 = pos1+14;
			pos2 = string.indexOf(" ;",pos1);
			element[0] = ns1+string.substring(pos1,pos2);
			pos1 = string.indexOf("ao:elementB b:",pos2)+14;
			pos2 = string.indexOf(" ;",pos1);
			element[1] = ns2+string.substring(pos1,pos2);
			pos1 = string.indexOf("ao:alignmentConfidence ",pos2)+24;
			pos2 = string.indexOf("\".",pos1);
			element[2] = string.substring(pos1,pos2);
			array[index] = element;
			index++;
			pos1 = string.indexOf("ao:elementA a:",pos2);
		}
		String array2[][] = new String[index][];
		for (int i = 0; i<index; i++) {
			array2[i]=array[i];
		}
		return array2;
	}
	

}
