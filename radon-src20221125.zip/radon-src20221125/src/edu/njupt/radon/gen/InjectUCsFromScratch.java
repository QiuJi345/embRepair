package edu.njupt.radon.gen;

import java.io.File;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * 该实现是依据张瑜博士的文章
 * @author QiuJi
 *
 */
public class InjectUCsFromScratch {
	
	int classCounter;
	int opCounter;
	int axCounter;
	OWLDataFactory factory;
	HashSet<OWLAxiom> addedAxioms;
	
	int ucNum;
	int maxMUPSNum;
	int maxMUPSSize;
	HashSet<OWLClass> rootUCs;
	HashSet<OWLClass> derivedUCs;
	
    public static void main(String[] args) throws Exception {
    	
    	int ucNum = 50;
		int maxMUPSNum = 20;
		int maxMUPSSize = 10;
		String injectMethod = "InjectUCsFromScratch"; 
		String newOntoPath = "newOnto/"+injectMethod+"/newOnto-maxSize"+maxMUPSSize+
				"-maxNum"+maxMUPSNum+"-uc"+ucNum+".owl";
		
		InjectUCsFromScratch inject = new InjectUCsFromScratch(ucNum, maxMUPSNum, maxMUPSSize);		
		inject.generateUnsatConcepts();		
		HashSet<OWLAxiom> axioms = inject.getAddedAxioms();		
		OWLOntology onto = OWL.manager.createOntology(axioms);
		// output info
		System.out.println(" __________________________________ ");
		
		System.out.println(" rootUCs: "+inject.getRootUCs().size());
		HashSet<OWLClass> newUCs = ReasoningTools.getUnsatiConcepts(axioms);
		System.out.println(" newUCs2: "+newUCs.size());
		System.out.println(" axioms: "+axioms.size());
		System.out.println(" axioms in onto: "+onto.getAxiomCount());
		// save the new ontology
		File f = new File(newOntoPath);
		OWL.manager.saveOntology(onto, IRI.create(f.toURI()));
		
		// test the correctness of the generation method
/*		int i = 0;
		RadonDebug debug = new BlackboxDebug(axioms);
		for(OWLClass uc : ReasoningTools.getUnsatiConcepts(axioms)) {
			System.out.println((i++)+" UC: "+uc.toString());
			
			debug.getMUPS(uc);
		}	*/	
	}
	
	public InjectUCsFromScratch(int ucNum, int maxMUPSNum, int maxMUPSSize) {
		classCounter = 0;
		opCounter = 0;
		axCounter = 0;
		this.factory = OWL.factory; 
		addedAxioms = new HashSet<>();
		
		this.ucNum = ucNum;
		this.maxMUPSNum = maxMUPSNum;
		this.maxMUPSSize = maxMUPSSize;
		this.rootUCs = new HashSet<>();
		this.derivedUCs = new HashSet<>();
	}
	

	/**
	 * This method mimics the idea given in the paper
	 * "2017-计算机学报-本体推理机求解Mups的性能评测研究"
	 * 
	 * @param onto
	 * @param ucNum
	 * @param maxMUPSNum
	 * @param maxMUPSSize
	 * @return
	 */
	public void generateUnsatConcepts2(){
			
		// Generate maxMUPSNum pure root unsatisfiable concepts
		
		// Generate the first pure root uc
		OWLClass previousUC = generateClass("PureUC1");
		OWLClass disA = generateClass("disA");
		OWLClass disB = generateClass("disB1");
		addedAxioms.add(factory.getOWLSubClassOfAxiom(previousUC, disA));
		addedAxioms.add(factory.getOWLDisjointClassesAxiom(disA, disB));
		addedAxioms.add(factory.getOWLSubClassOfAxiom(previousUC, disB));	
		rootUCs.add(previousUC);
		// Generate root ucs left
		for(int i = 2; i < maxMUPSNum+1; i++) {
			OWLClass uc = generateClass("PureUC"+i);
			disB = generateClass("disB"+i);
			rootUCs.add(uc);
			addedAxioms.add(factory.getOWLDisjointClassesAxiom(disA, disB));
			addedAxioms.add(factory.getOWLSubClassOfAxiom(uc, disB));	
			addedAxioms.add(factory.getOWLSubClassOfAxiom(uc, previousUC));	
			previousUC = uc;
		}
		
		// Add derived ucs to make a MUPS with maximal size
		int size = this.maxMUPSSize - this.maxMUPSNum;
		if(size > 0) {
			for(int i = 1; i <= size; i ++) {
				OWLClass derivedUc = generateClass("DerivedUC"+i);		
				OWLAxiom ax = factory.getOWLSubClassOfAxiom(derivedUc, previousUC);
				System.out.println((axCounter++)+" : "+ax.toString());
				addedAxioms.add(ax);
				derivedUCs.add(derivedUc);
				previousUC = derivedUc;
			}
		}
				
		// Generate more UCs to satisfy ucNum
		int leftUcNum = ucNum - rootUCs.size() - derivedUCs.size();
		System.out.println("leftUcNum: "+leftUcNum);
		if(leftUcNum > 0) {
			rootUCs.addAll(this.generatePureRootUnsatConcepts(leftUcNum));
		}
/*		int i = 0;
		for(OWLClass unsatCon : newUCs) {
			System.out.println((i++)+" UC: "+unsatCon.toString());
		}*/
	}
	
	public void generateUnsatConcepts(){
		
		// Generate maxMUPSNum pure root unsatisfiable concepts
		rootUCs.addAll(this.generatePureRootUnsatConcepts(maxMUPSNum));		
		// Generate the derived UC that has maxMUPSNum MUPS
		OWLClass derivedUc = generateClass("DerivedUC1");
		OWLAxiom ax = factory.getOWLSubClassOfAxiom(derivedUc, factory.getOWLObjectIntersectionOf(this.rootUCs));
		//System.out.println((axCounter++)+" : "+ax.toString());
		addedAxioms.add(ax);
		derivedUCs.add(derivedUc);
		
		// Generate two mutuallyReliedUCs
		HashSet<OWLClass> mrUCs = this.generateMutuallyReliedRootUCs();
		rootUCs.addAll(mrUCs);
		// Generate maxMUPSSize-2 derived UCs
		OWLClass uc = mrUCs.iterator().next();
		for(int i = 2; i < maxMUPSSize; i ++) {
			derivedUc = generateClass("DerivedUC"+i);	
			//InjectIncoHybrid.mipsSizeMap.put(derivedUc, i+1);
			ax = factory.getOWLSubClassOfAxiom(derivedUc, uc);
			//System.out.println((axCounter++)+" : "+ax.toString());
			addedAxioms.add(ax);
			derivedUCs.add(derivedUc);
			uc = derivedUc;
		}
		
		// Generate more UCs to satisfy ucNum
		int leftUcNum = ucNum - rootUCs.size() - derivedUCs.size();
		//System.out.println("leftUcNum: "+leftUcNum);
		if(leftUcNum > 0) {
			rootUCs.addAll(this.generatePureRootUnsatConcepts(leftUcNum));
		}
/*		int i = 0;
		for(OWLClass unsatCon : newUCs) {
			System.out.println((i++)+" UC: "+unsatCon.toString());
		}*/
	}
	/**
	 * 
	 * @param onto
	 * @param ucNum
	 * @return
	 */
	public HashSet<OWLClass> generateDerivedUnsatConcepts(OWLOntology onto, int ucNum){
		
		HashSet<OWLClass> newUCs = new HashSet<>();
		HashSet<OWLClass> candidates = ReasoningTools.getUnsatiConcepts(onto, OWL.manager);
		int counter = 0;
		while(counter < ucNum) {
			OWLClass derivedUc = generateClass("DerivedUC");
			OWLClass uc = candidates.iterator().next();
			OWLAxiom ax = factory.getOWLSubClassOfAxiom(derivedUc, uc);
			System.out.println((axCounter++)+" : "+ax.toString());
			addedAxioms.add(ax);
			candidates.remove(uc);
			candidates.add(derivedUc);
			newUCs.add(derivedUc);
			counter ++;
		}
		return newUCs;
	}
	
	
	private HashSet<OWLClass>  generateMutuallyReliedRootUCs() {
		OWLClass oc1 = generateClass("MutualUC");
		OWLClass oc2 = generateClass("MutualUC");
		InjectIncoHybrid.mipsSizeMap.put(oc1, 2);
		OWLAxiom ax1 = factory.getOWLDisjointClassesAxiom(oc1, oc2);
		OWLAxiom ax2 = factory.getOWLEquivalentClassesAxiom(oc1, oc2);
		//System.out.println((axCounter++)+" : "+ax1.toString());
		//System.out.println((axCounter++)+" : "+ax2.toString());
		//System.out.println("-----------------------------");
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);

		HashSet<OWLClass>  newUCs = new HashSet<>();
		newUCs.add(oc1);
		newUCs.add(oc2);
		return newUCs;
	}
	
	/**
	 * 
	 * @param ucNum : number of pure root unsatisfiable concepts to be generated
	 * @param ucPattern "complementPattern" / "existsAllPattern"
	 * @return
	 */
	public HashSet<OWLClass> generatePureRootUnsatConcepts(int ucNum, String ucPattern){
		HashSet<OWLClass>  newUCs = new HashSet<>();
		for(int i=0; i< ucNum; i++) {
			if(ucPattern.contains("complementPattern")) {
				newUCs.add(generatePureRootUnsatConcept1());
			} else {
				newUCs.add(generatePureRootUnsatConcept2());
			}
		}
		return newUCs;
	}	
	
	/**
	 *  Generate ucNum pure root unsatisfiable concepts containing two patterns 
	 * 
	 * @param ucNum
	 * @return
	 */
	public HashSet<OWLClass> generatePureRootUnsatConcepts(int ucNum){
		HashSet<OWLClass>  newUCs = new HashSet<>();
		int num1 = ucNum / 2;
		int num2 = ucNum - num1;		
		for(int i = 0; i < num1; i++) {
			newUCs.add(this.generatePureRootUnsatConcept1());			
		}
		for(int i = 0; i < num2; i++) {
			newUCs.add(this.generatePureRootUnsatConcept2());
		}	
		return newUCs;
	}
	
	public HashSet<OWLClass> generatePureRootUnsatConcepts2(int ucNum){
		HashSet<OWLClass>  newUCs = new HashSet<>();
		OWLClass previousUC = generateClass("PureUC1");
		OWLClass disA = generateClass("disA");
		OWLClass disB = generateClass("disB1");
		addedAxioms.add(factory.getOWLSubClassOfAxiom(previousUC, disA));
		addedAxioms.add(factory.getOWLDisjointClassesAxiom(disA, disB));
		addedAxioms.add(factory.getOWLSubClassOfAxiom(previousUC, disB));	
		
		for(int i = 2; i < ucNum+1; i++) {
			OWLClass uc = generateClass("PureUC"+i);
			disB = generateClass("disB"+i);
			newUCs.add(uc);
			addedAxioms.add(factory.getOWLDisjointClassesAxiom(disA, disB));
			addedAxioms.add(factory.getOWLSubClassOfAxiom(uc, disB));	
			addedAxioms.add(factory.getOWLSubClassOfAxiom(uc, previousUC));	
			previousUC = uc;
		}
		return newUCs;
	}
	
	private OWLClass generatePureRootUnsatConcept1() {
		OWLClass oc = generateClass("Concept");
		OWLClass newUC = generateClass("PureUC1");
		InjectIncoHybrid.mipsSizeMap.put(newUC, 1);
		OWLAxiom ax = factory.getOWLSubClassOfAxiom(newUC, factory.getOWLObjectIntersectionOf(oc, factory.getOWLObjectComplementOf(oc)));
		//System.out.println((axCounter++)+" : "+ax.toString());
		addedAxioms.add(ax);
		return newUC;
	}
	
	private OWLClass generatePureRootUnsatConcept2() {
		OWLClass oc = generateClass("Concept");
		OWLClass newUC = generateClass("PureUC2");
		InjectIncoHybrid.mipsSizeMap.put(newUC, 1);
		OWLObjectProperty op = generateObjectProperty();
		OWLAxiom ax = factory.getOWLSubClassOfAxiom(newUC, 
				factory.getOWLObjectIntersectionOf(factory.getOWLObjectSomeValuesFrom(op, oc), 
						factory.getOWLObjectAllValuesFrom(op, factory.getOWLObjectComplementOf(oc))));
		//System.out.println((axCounter++)+" : "+ax.toString());
		addedAxioms.add(ax);
		return newUC;
	}
	
	private OWLClass generatePureRootUnsatConcept3(OWLClass oc1, OWLClass oc2) {
		OWLClass newUC = generateClass("PureUC3");
		//System.out.println((axCounter++)+" : "+ax.toString());
		addedAxioms.add(factory.getOWLSubClassOfAxiom(newUC, oc1));
		addedAxioms.add(factory.getOWLSubClassOfAxiom(newUC, oc2));
		return newUC;
	}
	
	private OWLClass generateClass(String prefix) {
		// Use current time as prefix of a new entity to avoid duplicate names
		String classIRI = "http://www.njupt.edu.cn#"+prefix+"_"+System.currentTimeMillis()+classCounter;			
		classCounter ++;
		//System.out.println("new class ["+classCounter+"] "+classIRI);
		return factory.getOWLClass(IRI.create(classIRI));
	}
	

	private OWLObjectProperty generateObjectProperty() {
		// Use current time as prefix of a new entity to avoid duplicate names
		String opIRI = "http://www.njupt.edu.cn#OP"+"_"+System.currentTimeMillis()+opCounter;			
		opCounter ++;
		//System.out.println("new op ["+opCounter+"] "+opIRI);
		return factory.getOWLObjectProperty(IRI.create(opIRI));
	}
	
	public HashSet<OWLAxiom> getAddedAxioms(){
		return addedAxioms;
	}
	
	public HashSet<OWLClass> getRootUCs(){
		return this.rootUCs;
	}
	
	public HashSet<OWLClass> getDerivedUCs(){
		return this.derivedUCs;
	}

}
