package edu.njupt.radon.gen;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parser.AlignmentParser;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.TimeoutException;
import edu.njupt.radon.utils.reasoning.ReasoningTools;


public class MergeOntologies {
	
	static final int m_timeout = 5 * 60 * 1000;

	/**
	 * 需要修改路径的：主函数中String root（37行）
	 * 构造函数中一系列路径（49行）
	 * @param args
	 */
	public static void main(String[] args) {
		// 所有文件所在的根目录
		String injectMethod = "MergeOntologies"; 
		
		String ontoRootPath = "onto/oaei2020/anatomy/";
		String mappingRootPath = "onto/oaei2020/anatomy-alignments/";
		String newOntoPath = "newOnto/"+injectMethod+"/anatomy-merged/";
		
		/*String ontoRootPath = "onto/medical/ontos/";
		String mappingRootPath = "onto/medical/mappings/";
		String mergedOntoPath = "onto/"+injectMethod+"/medical-merged/";*/
		//String root = "onto/liTest/";
		MergeOntologies main = new MergeOntologies();
		// 生成时间测试
		Long tic=System.currentTimeMillis();
		main.mergeMultiOntoPairs(ontoRootPath, mappingRootPath, newOntoPath);
		// 输出生成时间
        Long toc=System.currentTimeMillis();
		System.out.println("The consumption of time is "+(toc-tic) +" ms");
	}


	/**
	 * 拆分conferenceAlignments中各个子文件夹中文件的名字； 
	 * 调用 mergeSingleOntoPair 进一步处理
	 * @param systemFile
	 */
	public void mergeMultiOntoPairs(String ontoRootPath, String mappingRootPath, String mergedOntoPath) {
		File mappingsFile = new File(mappingRootPath);
		/*if (!mappingsFile.isDirectory())
			return;*/
		// 循环遍历 systemFile(某一个系统中)的所有文件，拆分文件名
		for (File mappingFile : mappingsFile.listFiles()) {
			
			// 提取 本体1-本体2 部分 ， 即.rdf 前面的部分
			String fName = mappingFile.getName();
			String o1Name = fName.substring(fName.indexOf("-")+1,fName.lastIndexOf("-"));
			String o2Name = fName.substring(fName.lastIndexOf("-")+1, fName.lastIndexOf("."));
			String o1Path = ontoRootPath +o1Name+".owl";
			String o2Path = ontoRootPath +o2Name+".owl";
			
			HashSet<OWLAxiom> allAxioms = this.mergeOnePairOntos(o1Path, o2Path, mappingFile.getPath());
			System.out.println(" merged onto size : "+allAxioms.size());
			// 保存对齐后的新本体
			try {
				// 测试用
				//System.out.println("开始保存本体");
				this.saveMergedOnto(allAxioms, mergedOntoPath, fName);
			} catch (Exception ex) {
				ex.printStackTrace();
				System.out.println("Exception is thrown when invoking Pellet!");
			}			
		}
	}
	
	public HashSet<OWLAxiom> mergeOnePairOntos(String sourceOntoPath, String targetOntoPath, String mappingPath) {			
		
		System.out.println("Source ontology: "+sourceOntoPath);
		System.out.println("Target ontology: "+targetOntoPath);
		
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	    HashMap<OWLAxiom,Double> weights = null;	    
	    //read two ontologies
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+sourceOntoPath);	
		OWLOntology targetOnto = OWLTools.openOntology("file:"+targetOntoPath);	
		allAxioms.addAll(sourceOnto.getLogicalAxioms());
		allAxioms.addAll(targetOnto.getLogicalAxioms());			
		
		//read mapping
		AlignmentParser align = new AlignmentParser(sourceOnto, targetOnto);
		weights = align.readMappingsFromFile(mappingPath);
		allAxioms.addAll(weights.keySet());	
		
		return allAxioms;
	}
	
	   

	/**
	 * 保存对齐后的新本体
	 * @param allAxioms 两个本体（o1、o2）中的所有公理
	 * @param systemName 映射系统名称
	 * @param mappingName 当前映射文件名称（本体1-本体2）
	 * @throws TimeoutException
	 * @throws OutOfMemoryError
	 * @throws Exception
	 */
	public void saveMergedOnto(final HashSet<OWLAxiom> allAxioms, 
			final String mergedOntoRootPath, final String mappingName)
			throws TimeoutException, OutOfMemoryError, Exception {

		executeAction(new Action() {
			public void run() throws Exception {
				// 保存新本体的路径
				String newOntoPath = mergedOntoRootPath;
				// 判断是否协调、一致
				if (ReasoningTools.isConsistent(allAxioms)) { // 一致的
					int ucNumber = ReasoningTools.getUnsatiConcepts(allAxioms).size();
					System.out.println("[Incoherent] Number of unsatisfiable concepts: " + ucNumber);
					if (ucNumber > 0) { // 不协调的
						newOntoPath = newOntoPath + "incoherent/" + mappingName + ".owl";
					} else { // 协调的
						System.out.println("[Coherent]");
						newOntoPath = newOntoPath + "coherent/" + mappingName + ".owl";
					}
				} else { // 不一致的
					System.out.println("[Inconsistent]");
					newOntoPath = newOntoPath + "inconsistent/" + mappingName + ".owl";
				}
				// 保存本体
				OWLTools.saveOntology(allAxioms, newOntoPath);
				System.out.println("======== end ========");
			}
		});
	}

	/////////////////////////////////////////////////
	@SuppressWarnings("unused")
	protected static void executeAction(final Action action) 
    throws TimeoutException, OutOfMemoryError, Exception {
        final Throwable[] exception=new Throwable[1]; 
        Thread thread=new Thread() {
            public void run() {
                try {
                    action.run();
                }
                catch (Throwable e) {
                    exception[0]=e;
                }
            }
        };
        thread.start();
        if (m_timeout==-1)
            thread.join();
        else
            thread.join(m_timeout);
        if (thread.isAlive()) {
            //stop();
        	thread.interrupt();
            throw new TimeoutException();
        }
        else {
            if (exception[0] instanceof Error)
                throw (Error)exception[0];
            else if (exception[0]!=null)
                throw (Exception)exception[0];
        }
    }
	
	protected static interface Action{
		void run() throws Exception;
	}


}
