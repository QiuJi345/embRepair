package edu.njupt.radon.gen.hybrid;

import java.io.File;
import java.util.HashSet;
import java.util.Random;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * Assume an existing ontology O is incoherent and it is expected to contain n axioms. 
 * If n<= |O|, we do nothing. Otherwise, we increase the size of O while 
 * keeping the original incoherence (i.e. the original MIPS and unsatisfiable concepts
 * are not changed when more axioms are added).  
 * 
 * To implement this idea, we add new sub-concepts to satisfiable concepts.
 * 
 * @author QiuJi
 * 2021.02.07
 */
public class ExtendOntologyTightly {
	
	private int classCounter = 0;

	public static void main(String[] args) throws Exception {
		// 所有文件所在的根目录		
		String injectMethod = "InjectAxiomsWithOnto";
		int ontoSizeToBeExpected = 100;
		String ontoPath = "file:onto/buggyPolicy.owl";
		String newOntoPath = "newOnto/"+injectMethod+"/buggyPolicy-"+ontoSizeToBeExpected+".owl";

		OWLOntology ont = OWL.manager.loadOntology(IRI.create(ontoPath));
		System.out.println("Original onto size : "+ont.getAxiomCount());
		System.out.println("Number of OCs : "+ont.getClassesInSignature().size());
		
		ExtendOntologyTightly main = new ExtendOntologyTightly();
		// 生成时间测试
		Long tic=System.currentTimeMillis();
		HashSet<OWLAxiom> addedAxioms = main.generateAxioms(ont, ontoSizeToBeExpected);
		OWL.manager.addAxioms(ont, addedAxioms);
		
		// save the ontology
		File f  = new File(newOntoPath);
		OWL.manager.saveOntology(ont, IRI.create(f.toURI()));
		// 输出生成时间
        Long toc=System.currentTimeMillis();
		System.out.println("The consumption of time is "+(toc-tic) +" ms");
	}
	
	public HashSet<OWLAxiom> generateAxioms(OWLOntology ont, 
			int ontoSizeToBeExpected) {
		
		HashSet<OWLAxiom> addedAxioms = new HashSet<>();
		
		int num = ontoSizeToBeExpected - ont.getAxiomCount();
		if(num > 0) {
			System.out.println("Number of axioms to be added (expected) : "+num);
			// Obtain all unsatisfiable concepts in the ontology
			HashSet<OWLClass> unsatConcepts= ReasoningTools.getUnsatiConcepts(ont, OWL.manager);
			System.out.println("Number of UCs : "+unsatConcepts.size());
			// Obtain all satisfiable concepts
			HashSet<OWLClass> satConcepts = new HashSet<OWLClass>(ont.getClassesInSignature());
			satConcepts.removeAll(unsatConcepts);
			
			addedAxioms = this.generateAxioms(satConcepts, num);	
			
		}
		System.out.println("Number of added axioms : "+addedAxioms.size());
		return addedAxioms;
	}
	
    public HashSet<OWLAxiom> generateAxioms(
    		HashSet<OWLClass> candidates, int numAdded){
		
		HashSet<OWLAxiom> addedAxioms = new HashSet<>();
		int axCounter = 0;
		OWLClass supClass = candidates.iterator().next();
		if(supClass != null) { // In case all concepts in the input ontology are unsatisfiable.
			supClass = generateClass("Concept");
		}
		while(axCounter < numAdded) {
			// Generate 1-5 new sub-concepts
			HashSet<OWLClass> newSubClasses = this.generateRandomClasses("Concept");
			for(OWLClass newSubClass : newSubClasses) {
				OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(newSubClass, supClass);
				//System.out.println(axCounter+" : "+ax.toString());
				addedAxioms.add(ax);
				candidates.add(newSubClass);
				axCounter ++;
				if(axCounter >= numAdded) {
					break;
				}
			}
			candidates.remove(supClass);
			supClass = candidates.iterator().next();			
		}
		return addedAxioms;
	}
    
    private HashSet<OWLClass> generateRandomClasses(String prefix) {
    	Random r = new Random();
    	int ocNum = r.nextInt(5)+1; // Generate 1-5 concepts randomly
    	HashSet<OWLClass> conceptSet=this.generateClasses(prefix, ocNum);
		return conceptSet;
	}
    
    private HashSet<OWLClass> generateClasses(String prefix, int ocNum) {
    	HashSet<OWLClass> conceptSet=new HashSet<OWLClass>();
		for(int i=0;i<ocNum;i++){
			OWLClass oc = this.generateClass(prefix);
			conceptSet.add(oc);
		}
		return conceptSet;
	}
	
	private OWLClass generateClass(String prefix) {
		// Use current time as prefix of a new entity to avoid duplicate names
		String classIRI = "http://www.njupt.edu.cn#"+prefix+"_"+System.currentTimeMillis()+classCounter;			
		classCounter ++;
		//System.out.println("new class ["+classCounter+"] "+classIRI);
		return OWL.factory.getOWLClass(IRI.create(classIRI));
	}
	
}
