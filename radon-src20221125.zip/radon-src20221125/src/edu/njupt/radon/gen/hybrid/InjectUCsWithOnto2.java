package edu.njupt.radon.gen.hybrid;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Vector;

import org.semanticweb.owlapi.model.AxiomType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * 该方法基于
 * @author QiuJi
 *
 */
public class InjectUCsWithOnto2 {

	int classCounter = 0;

	OWLOntology onto;
	//ArrayList<OWLClass> concepts;
	ArrayList<OWLClass> unconcepts;
	ArrayList<OWLObjectProperty> objectproperties;
	Random r = new Random();

	public static void main(String[] args) throws Exception {
		String injectMethod = "InjectUCsWithOnto";
		// type的可选类型有: "intersection","existing", "union" and "random".
		// By default (i.e. type="random"), randomly choose a type for each new axiom.
		int extOSize = 1000;
		int extUcNum = 60; 
		int extMipsNum = 10;
		String ontoName = "proton"; //proton-Ext1000-Mips10-UC60

		String ontoPath = "file:onto/"+ontoName+".owl";
		String newOntoPath = "newOnto/" + injectMethod + "/" + ontoName +"-Ext"+ extOSize+"-Mips"+extMipsNum;

		OWLOntology onto = OWL.manager.loadOntology(IRI.create(ontoPath));
		
		Long tic2 = System.currentTimeMillis();		
		InjectUCsWithOnto2 injectAxioms = new InjectUCsWithOnto2(onto);		
		HashSet<OWLAxiom> newAxioms = injectAxioms.generateUCs(extOSize, extUcNum, extMipsNum);
		Long toc2 = System.currentTimeMillis();
		System.out.println("The consumption of injecting time is " + (toc2 - tic2) + " ms");
		
			
		OWL.manager.addAxioms(onto, newAxioms);
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto);
		System.out.println(" allAxioms " + onto.getLogicalAxiomCount());
		System.out.println("The number of current UCs is " + ucs.size());
		
		// save the new ontology
		newOntoPath += "-UC"+ extUcNum + ".owl";
		File f = new File(newOntoPath);
		OWL.manager.saveOntology(onto, IRI.create(f.toURI()));
		
		RadonDebug debug = new BlackboxDebug(onto);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
				
	}

	public InjectUCsWithOnto2(OWLOntology onto) {
		this.onto = onto;
		objectproperties = new ArrayList<>(onto.getObjectPropertiesInSignature());
		unconcepts = new ArrayList<>(ReasoningTools.getUnsatiConcepts(onto));
		
		System.out.println("The number of original UCs is " + unconcepts.size());
	}

	public HashSet<OWLAxiom> generateUCs(int extOSize, int extUcNum, int extMipsNum) {
		HashSet<OWLAxiom> newAxioms = new HashSet<>();
		
		int newSatConceptNum = extOSize - extUcNum;
		int newUcNum = extUcNum - extMipsNum;
		
		newAxioms = this.generateSatConcepts(newSatConceptNum);
		newAxioms.addAll(generateUnsatConcepts(newUcNum));
		newAxioms.addAll(generateMips(extMipsNum));
		
		
		//System.out.println("The number of new axioms is " + newAxioms.size());
		return newAxioms;
	}
	
	private HashSet<OWLAxiom> generateMips(int mipsNum) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();		
				
		// obtain subclassof relations between atomic concepts
		Vector<OWLClass> subs = new Vector<OWLClass>();
		Vector<OWLClass> sups = new Vector<OWLClass>();
		for(OWLSubClassOfAxiom ax : onto.getAxioms(AxiomType.SUBCLASS_OF)) {
			OWLClassExpression sube = ax.getSubClass();
			OWLClassExpression supe = ax.getSuperClass();
			if(sube.isAnonymous()) {
				continue;
			}
			OWLClass subc = sube.asOWLClass();
			if(this.unconcepts.contains(subc)) {
				continue;
			}
			if(supe.isAnonymous() && (supe instanceof OWLObjectIntersectionOf)) {
				OWLObjectIntersectionOf inters = (OWLObjectIntersectionOf)supe;
				for(OWLClassExpression oce : inters.getOperands()) {
					if(!oce.isAnonymous()) {
						subs.add(subc);
						sups.add(oce.asOWLClass());
					}
				}
			} else if(!supe.isAnonymous()) {
				subs.add(subc);
				sups.add(supe.asOWLClass());
			}
		}
		
		int len = subs.size();
		if(len <= 0) {
			System.out.println("Fail to find a concept hierarchy!");
		} else {
			while(axCounter < mipsNum) {
				int i = r.nextInt(len);
				OWLClass oc = this.generateClass("rootConcept");
				OWLObjectIntersectionOf oi = OWL.factory.getOWLObjectIntersectionOf(subs.get(i),
						OWL.factory.getOWLObjectComplementOf(sups.get(i)));
				OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(oc, oi);

				newAxioms.add(ax);
				axCounter ++;
			}
		}
		
		
		return newAxioms;
	
	}
	
	public HashSet<OWLAxiom> generateUnsatConcepts(int newUcNum) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();		
		
		while(axCounter < newUcNum) {
			OWLAxiom ax = generateAxiom(this.unconcepts, unconcepts);
			newAxioms.add(ax);
			axCounter ++;
		}
		
		return newAxioms;
	}
	
	public HashSet<OWLAxiom> generateUnsatConcepts(ArrayList<OWLClass> ucs, int newUcNum) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();		
		
		while(axCounter < newUcNum) {
			OWLAxiom ax = generateAxiom(ucs, ucs);
			newAxioms.add(ax);
			axCounter ++;
		}
		
		return newAxioms;
	}
	/*
	*//**
	 * 这个方法假设已有的UC都是根不可满足概念，且最大的MIPS包含n个公理，
	 * 则新增加的派生UC跟根UC之间的层次不超过（level-n）
	 * @param newUcNum
	 * @param level
	 * @return
	 *//*
	public HashSet<OWLAxiom> generateUnsatConcepts(int newUcNum, int level) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();		
		
		while(axCounter < newUcNum) {
			OWLAxiom ax = generateAxiom(this.unconcepts, unconcepts);
			newAxioms.add(ax);
			axCounter ++;
		}
		
		return newAxioms;
	}*/
	
	public HashSet<OWLAxiom> generateSatConcepts(int satConceptNum) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();
		
		ArrayList<OWLClass> allConcepts = new ArrayList<>(onto.getClassesInSignature());
		ArrayList<OWLClass> satConcepts = new ArrayList<>(allConcepts);
		satConcepts.removeAll(unconcepts);
		
		while(axCounter < satConceptNum) {
			OWLAxiom ax = generateAxiom(satConcepts, allConcepts);
			newAxioms.add(ax);
			axCounter ++;
		}
		
		return newAxioms;
	}
	
	private OWLAxiom generateAxiom(ArrayList<OWLClass> conceptSet1, ArrayList<OWLClass> conceptSet2) {
		OWLAxiom ax = null;
		OWLClass con = this.generateClass("concept");		
		int index = r.nextInt(2);
		
		if(index == 1) {			
			OWLClass sup = this.getRandomClass(conceptSet1);			
			ax = OWL.factory.getOWLSubClassOfAxiom(con, sup);
		} else {
			OWLClass sup1 = this.getRandomClass(conceptSet1);
			conceptSet2.remove(sup1);
			OWLClass sup2 = this.getRandomClass(conceptSet2);
			conceptSet2.add(sup1);
			ax = OWL.factory.getOWLSubClassOfAxiom(con, OWL.factory.getOWLObjectUnionOf(sup1,sup2));
		}
		return ax;
	}


		
	private OWLClass getRandomClass(ArrayList<OWLClass> ocs) {
		Random random = new Random();
		int randomSupConceptNum = random.nextInt(ocs.size());
		OWLClass oc = ocs.get(randomSupConceptNum);
		return oc;
	}
	
	
	private OWLClass generateClass(String prefix) {
		// Use current time as prefix of a new entity to avoid duplicate names
		String classIRI = "http://www.njupt.edu.cn#"+prefix+"_"+System.currentTimeMillis()+classCounter;			
		classCounter ++;
		//System.out.println("new class ["+classCounter+"] "+classIRI);
		return OWL.factory.getOWLClass(IRI.create(classIRI));
	}
	

}
