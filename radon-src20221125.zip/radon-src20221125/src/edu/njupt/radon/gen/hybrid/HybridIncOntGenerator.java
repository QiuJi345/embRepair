package edu.njupt.radon.gen.hybrid;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.MyPrinter;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class HybridIncOntGenerator {

	public static void main(String[] args) {
		String method = "hybridIncOntGen";
		// 为了能满足用户给出的所有参数，需要满足这些约束：
		String existingOntPath = null; 
		
		int maxMUPSNum= 100;  // 10, 30, 50, 100
		// （1） maxMUPSSize需>=7，因为mipsRel方法生成的MIPS最多包含3个公理(这个可改)，可能生成派生概念C\subclassof C1 union C2，其中C1和C2为根UC
		int maxMUPSSize = 10;	
		// （2）minRemovalSize >= maxMUPSNum+1
		int minRemovalSize = 110;  // 15, 40, 100, 110
		// （3）mipsNum >= minRemovalSize
		int mipsNum = 150;   // 50, 80， 150, 150
		// （4）expectedUCNum >= (maxMUPSNum+2)+(maxMUPSSize-1)+mipsNum-(maxMUPSNum+1)，实际上就是不小于已经生成的UC数量
		//     简写为expectedUCNum >= mipsNum+maxMUPSSize
		int expectedUCNum = 200;
		// （5）expectedOSize去掉已经生成的公理数量便是需要新添的公理数量，这些公理的添加不影响之前的不协调性
		int expectedOSize = 5000;	
		
		
		String newOntoPath = "newOnto/"+method+"/hybridOnto"+expectedOSize+"-UC"+
	              expectedUCNum+"-mipsNum"+mipsNum+"-minR"+minRemovalSize+".owl";
		
		HybridIncOntGenerator inject = new HybridIncOntGenerator(existingOntPath, 
				expectedOSize, expectedUCNum, mipsNum, maxMUPSNum, maxMUPSSize, minRemovalSize);
		HashSet<OWLAxiom> axioms = inject.generateIncOntoFromScratch();
		

		try {
			//save the generated ontology
			OWLOntology onto = OWL.manager.createOntology(axioms);
			File f = new File(newOntoPath);
			OWL.manager.saveOntology(onto, IRI.create(f.toURI()));
			
			// check  correctness
			System.out.println("***************** Check correctness ********************");
			HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto);	
			
			RadonDebug debug = new BlackboxDebug(onto);
			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
			HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(mups);
			MyPrinter.printMultiSets(mips, null);
			
			//HashSet<OWLAxiom> removal = RepairWithScore.getOneDiagnose(mips);
			HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(mips);
			System.out.println("diagnosis : ");
			CommonTools.printMultiSets(diags, null);
			HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags);
			
			System.out.println("axioms: "+onto.getLogicalAxiomCount());
			System.out.println("uc: "+ucs.size());
			System.out.println("mips: "+mips.size());
			System.out.println("removal: "+minHS.size());
			
			
    	} catch(Exception ex) {
    		System.out.println("Fail to save the generated ontology!");
    	}	

	}
	
	String existingOntPath; 
	int expectedOSize;
	int expectedUCNum;
	int mipsNum;
	int maxMUPSNum;
	int maxMUPSSize;
	int minRemovalSize;
	
	HashSet<OWLClass> rootUCs;
	HashSet<OWLClass> derivedUCs;
	HashSet<OWLAxiom> addedAxioms = new HashSet<OWLAxiom>();
	public static HashMap<OWLClass, Integer> ucMaxMupsSize = new HashMap<OWLClass, Integer>();
	
	public HybridIncOntGenerator(String ontoPath, int expectedOSize, 
			int expectedUCNum, int mipsNum, int maxMUPSNum, 
			int maxMUPSSize, int minRemovalSize) {
		this.existingOntPath = ontoPath;
		this.expectedOSize = expectedOSize;
		this.expectedUCNum = expectedUCNum;
		this.mipsNum = mipsNum;
		this.maxMUPSNum = maxMUPSNum;
		this.maxMUPSSize = maxMUPSSize;
		this.minRemovalSize = minRemovalSize;
	}
	
	
	public HashSet<OWLAxiom> generateIncOntoFromScratch() {
		// Generate an empty ontology
		OWLOntology onto = null;		
        try {
			onto = OWL.manager.createOntology(); 
    	} catch(Exception ex) {
    		System.out.println(" This sentence should not be executed!");
    	}
        
        
        // Step1：根据InjectUCsFromScratch生成ucNum个满足最大MUPS数量和大小约束的不可满足概念        	
		this.generateUcsWithMupsMaxNumSize();	
		OWL.manager.addAxioms(onto, this.addedAxioms);
				
		// Step1中生成了maxMUPSNum+1个MIPS，每个MIPS只包含一条公理，所以最小移除maxMUPSNum+1个公理才能解决不协调性
		// Step2：根据用户设定的参数，生成更多MIPS以满足更多的最小移除数量
		int moreMinRemoval = this.minRemovalSize - maxMUPSNum;
		int moreMIPSNum = this.mipsNum - maxMUPSNum;
		GenerateMips gen = new GenerateMips(true);
		HashSet<OWLAxiom> newAxioms = gen.generateMUPS(moreMIPSNum, moreMinRemoval, maxMUPSSize);
		this.addedAxioms.addAll(newAxioms);
		
		// Step3：如果用户想要的UC数量大于已经生成的UC数量，则调用不增加公理数量的方法增添新的派生UC
		int ucNum = maxMUPSNum +1 +maxMUPSSize;	
		int newUcNum = this.expectedUCNum - ucNum - moreMIPSNum;
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto);
		System.out.println("uc: "+newUcNum+", "+ucs.size());
		ucs.removeAll(this.derivedUCs);
		System.out.println("root ucs: "+ucs.size());
		ArrayList<OWLClass> rootUCs = new ArrayList<>(ucs);
		InjectUCsWithOnto2 injectAxioms = new InjectUCsWithOnto2(onto);		
		newAxioms = injectAxioms.generateUnsatConcepts(rootUCs, newUcNum);
		this.addedAxioms.addAll(newAxioms);
						
		// Step4：如果已经生成的公理数量小于期望的，则添加新的不影响原有不协调性的公理
		if(this.addedAxioms.size()< expectedOSize) {			
			ExtendOntologyTightly ext = new ExtendOntologyTightly();
			newAxioms = ext.generateAxioms(onto, expectedOSize);
			addedAxioms.addAll(newAxioms);
			OWL.manager.addAxioms(onto, newAxioms);
			System.out.println(" axioms in finalonto: "+addedAxioms.size());
		}
		
		return addedAxioms;
	}
	
	/**
	 * Generate an incoherent ontology such that it contains an uc 
	 */
	public void generateUcsWithMupsMaxNumSize(){
		// Generate maxMUPSNum pure root unsatisfiable concepts
		MUPSPatterns pat = new MUPSPatterns();		
		for(int i=0; i< maxMUPSNum; i++) {
			rootUCs.add(pat.generateRootUc(-1));
		}

		// Generate the derived UC that has maxMUPSNum MUPS
		OWLClass derivedUc = GenerateEntitesOrAxioms.generateClass("DerivedUC");		
		OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(derivedUc, OWL.factory.getOWLObjectIntersectionOf(this.rootUCs));
		addedAxioms.add(ax);	
		derivedUCs.add(derivedUc);
		ucMaxMupsSize.put(derivedUc, this.maxMUPSNum);
		
		// Generate derived UCs
		OWLClass uc = derivedUc;
		for(int i = 0; i < maxMUPSSize-(pat.getMipsMaxSize()+1); i ++) {
			derivedUc = GenerateEntitesOrAxioms.generateClass("DerivedUC");		
			ax = OWL.factory.getOWLSubClassOfAxiom(derivedUc, uc);
			//System.out.println((axCounter++)+" : "+ax.toString());
			addedAxioms.add(ax);
			derivedUCs.add(derivedUc);
			uc = derivedUc;
		}		
	
	}

}
