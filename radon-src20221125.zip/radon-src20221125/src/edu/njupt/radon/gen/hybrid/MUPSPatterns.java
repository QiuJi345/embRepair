package edu.njupt.radon.gen.hybrid;

import java.util.HashSet;
import java.util.Random;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLObjectProperty;

import com.clarkparsia.owlapiv3.OWL;

public class MUPSPatterns {

	//HashMap<OWLClass, HashSet<OWLAxiom>> rootExpMap = new HashMap<OWLClass, HashSet<OWLAxiom>>();
	HashSet<OWLAxiom> addedAxioms = new HashSet<OWLAxiom>();
	int mipsMaxSize = -1;
	
	
    public OWLClass generateRootUc(int patternId) {
    	OWLClass uc = null;
    	int pId = patternId;
    	// If the given id is out of scope, we randomly choose a pattern.
    	if(pId > 8 || pId < 1) {
    		Random r = new Random();
    		pId = r.nextInt(8)+1;
    	}

		switch (pId) {
		case 1:
			uc = genRootUcAnotA();
			break; 
		case 2:
			uc = genRootUcExistAllAnotA();
			break; 
		case 3:
			uc = genRootUcIsaDisj();
			break; 
		case 4:
			uc = genRootUcExistAll();
			break; 
		case 5:
			uc = genRootUcExistRange();
			break; 
		case 6:
			uc = genRootUcExistDomain();
			break; 
		case 7:
			uc = genRootUcCardiRange();
			break; 
		case 8:
			uc = genRootUcCardiDomain();
			break; 		
		}
		return uc;
    }

	/**
	 * Pattern1: C isa C1 intersect \not C1
	 */
	private OWLClass genRootUcAnotA() {
		OWLClass oc = GenerateEntitesOrAxioms.generateClass("Concept");
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcAnotA");
		OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(newUC, 
				OWL.factory.getOWLObjectIntersectionOf(oc, OWL.factory.getOWLObjectComplementOf(oc)));
    	addedAxioms.add(ax);
		setMipsMaxSize(1);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 1);
		return newUC;
	}
	
	/**
	 * Pattern2: C isa \exists r. C1 intersect \forall r.\not C1
	 */
	private OWLClass genRootUcExistAllAnotA() {
		OWLClass oc = GenerateEntitesOrAxioms.generateClass("Concept");
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcExistAllAnotA");
		OWLObjectProperty op = GenerateEntitesOrAxioms.generateObjectProperty();
		OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(newUC, 
				OWL.factory.getOWLObjectIntersectionOf(OWL.factory.getOWLObjectSomeValuesFrom(op, oc), 
						OWL.factory.getOWLObjectAllValuesFrom(op, OWL.factory.getOWLObjectComplementOf(oc))));
		addedAxioms.add(ax);
		setMipsMaxSize(1);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 1);
		return newUC;
	}
	
	/**
	 * Pattern3: C isa  C1, C isa C2, C1 isa \not C2
	 */
	private OWLClass genRootUcIsaDisj() {		
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcIsaDisj");
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass("Concept1");
		OWLClass oc2 = GenerateEntitesOrAxioms.generateClass("Concept2");
		OWLAxiom ax1 = OWL.factory.getOWLSubClassOfAxiom(newUC, oc1);
		OWLAxiom ax2 = OWL.factory.getOWLSubClassOfAxiom(newUC, oc2);		
		OWLAxiom ax = OWL.factory.getOWLDisjointClassesAxiom(oc1,oc2);
		addedAxioms.add(ax);
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);
		setMipsMaxSize(3);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 3);
		return newUC;
	}
	
	/**
	 * Pattern4: C isa \exists r. C1, C isa \forall r.C2, C1 isa \not C2
	 */
	private OWLClass genRootUcExistAll() {		
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcExistAll");
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass("Concept1");
		OWLClass oc2 = GenerateEntitesOrAxioms.generateClass("Concept2");
		OWLObjectProperty r = GenerateEntitesOrAxioms.generateObjectProperty();
		OWLAxiom ax1 = OWL.factory.getOWLSubClassOfAxiom(newUC, OWL.factory.getOWLObjectSomeValuesFrom(r, oc1));				
		OWLAxiom ax2 = OWL.factory.getOWLSubClassOfAxiom(newUC, OWL.factory.getOWLObjectAllValuesFrom(r, oc2));		
		OWLAxiom ax3 = OWL.factory.getOWLDisjointClassesAxiom(oc1,oc2);
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);
		addedAxioms.add(ax3);
		setMipsMaxSize(3);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 3);
		return newUC;
	}
	
	/**
	 * Pattern5: C isa \exists r. C1, range(r)=C2, C1 isa \not C2
	 */
	private OWLClass genRootUcExistRange() {		
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcExistRange");
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass("Concept1");
		OWLClass oc2 = GenerateEntitesOrAxioms.generateClass("Concept2");
		OWLObjectProperty r = GenerateEntitesOrAxioms.generateObjectProperty();
		OWLAxiom ax1 = OWL.factory.getOWLSubClassOfAxiom(newUC, OWL.factory.getOWLObjectSomeValuesFrom(r, oc1));				
		OWLAxiom ax2 = OWL.factory.getOWLObjectPropertyRangeAxiom(r, oc2);		
		OWLAxiom ax3 = OWL.factory.getOWLDisjointClassesAxiom(oc1,oc2);
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);
		addedAxioms.add(ax3);
		setMipsMaxSize(3);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 3);
		return newUC;
	}
	
	/**
	 * Pattern6: C isa \exists r. C1, domain(r)=C2,  C isa \not C2
	 */
	private OWLClass genRootUcExistDomain() {		
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcExistDomain");
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass("Concept1");
		OWLClass oc2 = GenerateEntitesOrAxioms.generateClass("Concept2");
		OWLObjectProperty r = GenerateEntitesOrAxioms.generateObjectProperty();
		OWLAxiom ax1 = OWL.factory.getOWLSubClassOfAxiom(newUC, OWL.factory.getOWLObjectSomeValuesFrom(r, oc1));				
		OWLAxiom ax2 = OWL.factory.getOWLObjectPropertyDomainAxiom(r, oc2);	
		OWLAxiom ax3 = OWL.factory.getOWLDisjointClassesAxiom(newUC,oc2);
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);
		addedAxioms.add(ax3);
		setMipsMaxSize(3);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 3);
		return newUC;
	}

	/**
	 * Pattern7: C isa >=n r. C1, range(r)=C2, , C1 isa \not C2
	 */
	private OWLClass genRootUcCardiRange() {	
		Random random = new Random();
		int n = random.nextInt(10)+1;
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcCardiRange");
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass("Concept1");
		OWLClass oc2 = GenerateEntitesOrAxioms.generateClass("Concept2");
		OWLObjectProperty r = GenerateEntitesOrAxioms.generateObjectProperty();
		OWLAxiom ax1 = OWL.factory.getOWLSubClassOfAxiom(newUC, OWL.factory.getOWLObjectMinCardinality(n, r, oc1));				
		OWLAxiom ax2 = OWL.factory.getOWLObjectPropertyRangeAxiom(r, oc2);	
		OWLAxiom ax3 = OWL.factory.getOWLDisjointClassesAxiom(oc1,oc2);
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);
		addedAxioms.add(ax3);
		setMipsMaxSize(3);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 3);
		return newUC;
	}
	
	/**
	 * Pattern7: C isa >=n r. C1, range(r)=C2, , C1 isa \not C2
	 */
	private OWLClass genRootUcCardiRange(int n) {
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcCardiRange");
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass("Concept1");
		OWLClass oc2 = GenerateEntitesOrAxioms.generateClass("Concept2");
		OWLObjectProperty r = GenerateEntitesOrAxioms.generateObjectProperty();
		OWLAxiom ax1 = OWL.factory.getOWLSubClassOfAxiom(newUC, OWL.factory.getOWLObjectMinCardinality(n, r, oc1));				
		OWLAxiom ax2 = OWL.factory.getOWLObjectPropertyRangeAxiom(r, oc2);	
		OWLAxiom ax3 = OWL.factory.getOWLDisjointClassesAxiom(oc1,oc2);
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);
		addedAxioms.add(ax3);
		setMipsMaxSize(3);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 3);
		return newUC;
	}
	
	/**
	 * Pattern8: C isa >=n r, domain(r)=C1, , C isa \not C1
	 */
	private OWLClass genRootUcCardiDomain() {		
		Random random = new Random();
		int n = random.nextInt(10)+1;
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcCardiDomain");
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass("Concept1");
		OWLObjectProperty r = GenerateEntitesOrAxioms.generateObjectProperty();
		OWLAxiom ax1 = OWL.factory.getOWLSubClassOfAxiom(newUC, OWL.factory.getOWLObjectMinCardinality(n, r));				
		OWLAxiom ax2 = OWL.factory.getOWLObjectPropertyDomainAxiom(r, oc1);	
		OWLAxiom ax3 = OWL.factory.getOWLDisjointClassesAxiom(newUC,oc1);
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);
		addedAxioms.add(ax3);
		setMipsMaxSize(3);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 3);
		return newUC;
	}
	
	/**
	 * Pattern8: C isa >=n r, domain(r)=C1, , C isa \not C1
	 */
	private OWLClass genRootUcCardiDomain(int n) {	
		OWLClass newUC = GenerateEntitesOrAxioms.generateClass("PureUcCardiDomain");
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass("Concept1");
		OWLObjectProperty r = GenerateEntitesOrAxioms.generateObjectProperty();
		OWLAxiom ax1 = OWL.factory.getOWLSubClassOfAxiom(newUC, OWL.factory.getOWLObjectMinCardinality(n, r));				
		OWLAxiom ax2 = OWL.factory.getOWLObjectPropertyDomainAxiom(r, oc1);	
		OWLAxiom ax3 = OWL.factory.getOWLDisjointClassesAxiom(newUC,oc1);
		addedAxioms.add(ax1);
		addedAxioms.add(ax2);
		addedAxioms.add(ax3);
		setMipsMaxSize(3);
		setMipsMaxSize(3);
		HybridIncOntGenerator.ucMaxMupsSize.put(newUC, 3);
		return newUC;
	}

	
	public HashSet<OWLAxiom> getAddedAxioms(){
		return addedAxioms;
	}
	
	public int getMipsMaxSize(){
		return mipsMaxSize;
	}
	
	
    private void setMipsMaxSize(int size) {
    	if(mipsMaxSize < size) {
    		mipsMaxSize = size;
    	}
    }
    
	
}
