package edu.njupt.radon.gen.hybrid;

import java.util.HashSet;
import java.util.Random;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import com.clarkparsia.owlapiv3.OWL;

public class GenerateMips {
	
	
	boolean mipsWithRandomSize;
	HashSet<OWLAxiom> addedAxioms = new HashSet<OWLAxiom>();
	
	public GenerateMips(boolean mipsWithRandomSize) {
		this.mipsWithRandomSize = mipsWithRandomSize;
	}
	
	public HashSet<OWLAxiom> generateMUPS(int allMUPSNum, int cardiMin, int axiomNum) {
		int mupsNum1 = (int)(allMUPSNum / cardiMin);
		int times = cardiMin -1;
		int mupsNum2 = allMUPSNum - mupsNum1*times;
		for(int i=0; i<times; i++){
			generateGroupShareOneAxiom(mupsNum1, axiomNum);
		}
		generateGroupShareOneAxiom(mupsNum2, axiomNum);
		return this.addedAxioms;
	}

	
	private void generateGroupShareOneAxiom(int mupsNum, int axiomNum)  {
		// All generated MUPS share the same disjointness axiom.
		OWLClass oc1 = GenerateEntitesOrAxioms.generateClass();
		OWLClass oc2 = GenerateEntitesOrAxioms.generateClass();	
		OWLAxiom ax = OWL.factory.getOWLDisjointClassesAxiom(oc1, oc2);
		this.addedAxioms.add(ax);		
		for(int i = 0; i < mupsNum; i++) {
			System.out.println("Generate new mups ["+i+"]");
			this.generateOneMUPS(oc1, oc2, axiomNum);
		}
	}
	
	
	private void generateOneMUPS(OWLClass oc1, OWLClass oc2, int axiomNum) {
		int mupsSize = axiomNum;
		if(mipsWithRandomSize) {
			Random r = new Random();
			mupsSize = r.nextInt(axiomNum);
		}
		
		OWLClass uc = GenerateEntitesOrAxioms.generateClass("RootUc");
		OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(uc, oc1);
		this.addedAxioms.add(ax);
		if(mupsSize <= 3) {
			ax = OWL.factory.getOWLSubClassOfAxiom(uc, oc2);
			this.addedAxioms.add(ax);
			//System.out.println();
			return;
		}		
		
		OWLClass subOc = null;
		OWLClass supOc = oc2;
		for(int i=0; i< mupsSize-3; i++) {
			subOc = GenerateEntitesOrAxioms.generateClass();
			ax = OWL.factory.getOWLSubClassOfAxiom(subOc, supOc);
			this.addedAxioms.add(ax);
			supOc = subOc;
		}
		ax = OWL.factory.getOWLSubClassOfAxiom(uc, supOc);
		this.addedAxioms.add(ax);
		System.out.println();
	}	
	

}
