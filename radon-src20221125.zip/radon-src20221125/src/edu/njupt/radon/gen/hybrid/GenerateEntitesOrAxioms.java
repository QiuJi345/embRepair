package edu.njupt.radon.gen.hybrid;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLObjectProperty;

import com.clarkparsia.owlapiv3.OWL;

public class GenerateEntitesOrAxioms {
	
	static int classCounter = 0;
	static int opCounter = 0;
	//static int axCounter = 0;
	
	public static OWLClass generateClass() {
		return generateClass("NewConcept");
	}
	
	public static OWLClass generateClass(String prefix) {
		// Use current time as prefix of a new entity to avoid duplicate names
		String classIRI = "http://www.njupt.edu.cn#"+prefix+"_"+System.currentTimeMillis()+classCounter;			
		classCounter ++;
		//System.out.println("new class ["+classCounter+"] "+classIRI);
		return OWL.factory.getOWLClass(IRI.create(classIRI));
	}
	

	public static OWLObjectProperty generateObjectProperty() {
		// Use current time as prefix of a new entity to avoid duplicate names
		String opIRI = "http://www.njupt.edu.cn#OP"+"_"+System.currentTimeMillis()+opCounter;			
		opCounter ++;
		//System.out.println("new op ["+opCounter+"] "+opIRI);
		return OWL.factory.getOWLObjectProperty(IRI.create(opIRI));
	}
	
	private OWLAxiom addSubclassOfAxiom(OWLClass subC, OWLClass supC) {
		OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(subC, supC);
		return ax;
	}
	
	private OWLAxiom addDisjointAxiom(OWLClass oc1, OWLClass oc2) {
		OWLAxiom ax = OWL.factory.getOWLDisjointClassesAxiom(oc1, oc2);
		return ax;
	}

}
