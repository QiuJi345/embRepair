package edu.njupt.radon.gen;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.io.MyPrinter;

/**
 * This class is to generate axioms with a given number and a given type.
 * The ontology containing these axioms is coherent. 
 * This class is used to increase the size of an existing ontology.
 */
public class ExtendOntologyLoosely {

	private int clCounter = 0;
	private int opCounter = 0;
	private int axCounter = 0;
	private HashSet<OWLAxiom> newAxioms = new HashSet<>();
	
	public static void main(String[] args) throws Exception {
		String injectMethod = "InjectAxiomsFromScratch"; 
		// type的可选类型有"random"、"subclassof"、"disjointwith"、"equivalence","intersection","existing"
		String type = "random";
		// 生成的数量
		int injectNum = 20;				
		String newOntoPath = "newOnto/"+injectMethod+"/newOnto-type"+type+"-"+injectNum+".owl";
	

		Long tic2 = System.currentTimeMillis();
		ExtendOntologyLoosely injectAxioms = new ExtendOntologyLoosely();		
		HashSet<OWLAxiom> newAxioms = new HashSet<>();
		if (injectNum <= 0) {
			System.out.println("The number of injected Axioms cannot be negative!");
		} else {
			newAxioms = injectAxioms.generateAxioms(injectNum, type);
		}
		Long toc2 = System.currentTimeMillis();
		
		// 打印输出添加的本体
		System.out.println("The number of new injected axioms is " + newAxioms.size());
		MyPrinter.printAxioms(newAxioms);
		System.out.println("The consumption of injecting time is " + (toc2 - tic2) + " ms");
		
		// save the new ontology
		File f = new File(newOntoPath);
		OWLOntology onto = OWL.manager.createOntology(newAxioms);
		OWL.manager.saveOntology(onto, IRI.create(f.toURI()));		
	}

	/**
	 * This method is to generate axioms with a given number of axioms and type of axioms.
	 * 生成的逻辑方式(即同一层的概念定义不相交关系，可以借助上一层的本体定义包含关系、相交关系、以及存在关系)
	 * 生成的方式以层为单位，生成2的指数概念
	 * 
	 * @param injectNum
	 * @param type
	 * @return
	 */
	public HashSet<OWLAxiom> generateAxioms(int injectNum, String type) {
		
		int level = 1;
		ArrayList<OWLClass> supConcepts = new ArrayList<OWLClass>();
		ArrayList<OWLClass> newconcepts = new ArrayList<OWLClass>();
		// Obtain super-concepts
		OWLClass initialConcept = generateClass();
		supConcepts.add(initialConcept);
		// Judge whether the generated axioms are enough for the given number
		boolean isEnough = false;
		
		while (!isEnough) { 
			// Obtain sub-concepts
			int startIndex = (int) Math.pow(2, level);
			int endIndex = (int) Math.pow(2, level + 1);
			newconcepts = generateClasses(startIndex, endIndex);
			
			if (type.equals("intersection")) {
				isEnough = this.generateAxiomsIntesection(supConcepts, newconcepts, injectNum);
			} else if (type.equals("disjointwith")) {
				isEnough = this.generateAxiomsDisj(newconcepts, injectNum);
			} else if (type.equals("equivalence")) {
				isEnough = this.generateAxiomsEquiv(newconcepts, injectNum);
			} else if (type.equals("existential")) {
				isEnough = this.generateAxiomsExistential(supConcepts, newconcepts, injectNum);
			} else if(type.equals("subclassof")) {
				isEnough = this.generateAxiomsSubsumption(supConcepts, newconcepts, injectNum);
			} else { // By default, we generate axioms with random type
				isEnough = this.generateAxiomsRandomly(supConcepts, newconcepts, injectNum);
			}
			
			// Update super-concepts and sub-concepts
			level++;
			supConcepts.clear(); // 层次增加
			supConcepts.addAll(newconcepts); // 父亲集合更新
			newconcepts.clear();
		}
		
		return newAxioms;
	}
	
	
	private boolean generateAxiomsSubsumption(ArrayList<OWLClass> supConcepts, 
			ArrayList<OWLClass> newconcepts, int injectNum) {

		boolean isEnough = false;
		Random r = new Random();
		int ran1 = r.nextInt(supConcepts.size());
		OWLClass supC = supConcepts.get(ran1);
		for (OWLClass c : newconcepts) {			
			OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(c, supC);
			isEnough = this.addAxiom(a, injectNum);
			if (isEnough) {
				break;
			}
		}	
		return isEnough;
	}
	
	
	
	private boolean generateAxiomsDisj( 
			ArrayList<OWLClass> newconcepts, int injectNum) {

		boolean isEnough = false;
		for (int i = 0; i < newconcepts.size(); i++) {
			for (int j = i + 1; j < newconcepts.size(); j++) {
				OWLAxiom a = OWL.factory.getOWLDisjointClassesAxiom(newconcepts.get(i), newconcepts.get(j));
				isEnough = this.addAxiom(a, injectNum);
				if (isEnough) {
					break;
				}
			}
		}
		return isEnough;
	}
	
	private boolean generateAxiomsEquiv( 
			ArrayList<OWLClass> newconcepts, int injectNum) {

		boolean isEnough = false;
		for (int i = 0; i < newconcepts.size(); i++) {
			for (int j = i + 1; j < newconcepts.size(); j++) {
				OWLAxiom a = OWL.factory.getOWLEquivalentClassesAxiom(newconcepts.get(i), newconcepts.get(j));
				isEnough = this.addAxiom(a, injectNum);
				if (isEnough) {
					break;
				}
			}
		}
		return isEnough;
	}
	
	private boolean generateAxiomsExistential( ArrayList<OWLClass> supConcepts,
			ArrayList<OWLClass> newconcepts, int injectNum) {

		boolean isEnough = false;

		Random r = new Random();
		int ran1 = r.nextInt(supConcepts.size());
		OWLClass supC = supConcepts.get(ran1);
		for (int j = 0; j < newconcepts.size(); j++) {
			OWLObjectProperty ob = this.generateObjectProperty();
			OWLAxiom a =  OWL.factory.getOWLSubClassOfAxiom(newconcepts.get(j), OWL.factory.getOWLObjectSomeValuesFrom(ob, supC));
			isEnough = this.addAxiom(a, injectNum);
			if (isEnough) {
				break;
			}
		}
	
		return isEnough;
	}
	
	private boolean generateAxiomsIntesection( ArrayList<OWLClass> supConcepts,
			ArrayList<OWLClass> newconcepts, int injectNum) {

		boolean isEnough = false;
		Random r = new Random();
		int ran1 = r.nextInt(supConcepts.size());
		OWLClass supC = supConcepts.get(ran1);
		for (int i = 0; i < newconcepts.size(); i++) {
			for (int j = i + 1; j < newconcepts.size(); j++) {
				OWLObjectIntersectionOf oce = OWL.factory.getOWLObjectIntersectionOf(newconcepts.get(j + 1), supC); // 基于不相交的原理进行添加
				OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(newconcepts.get(i), oce);
				isEnough = this.addAxiom(a, injectNum);
				if (isEnough) {
					break;
				}
			}
		}
	
		return isEnough;
	}
	

	private boolean generateAxiomsRandomly(ArrayList<OWLClass> supConcepts, 
			ArrayList<OWLClass> newconcepts, int injectNum) {

		boolean isEnough = false;
		Random random = new Random();
		for (int i = 0; i < newconcepts.size()-1; i++) {
			// Obtain a super concept randomly
			int randomSupConceptNum = random.nextInt(supConcepts.size());
			OWLClass supC = supConcepts.get(randomSupConceptNum);
			OWLAxiom a = this.generateAxiom(supC, newconcepts.get(i), newconcepts.get(i+1));
			isEnough = this.addAxiom(a, injectNum);
			if (isEnough) {
				break;
			}
		}
		
		return isEnough;
	}
	
	private OWLAxiom generateAxiom(OWLClass supC, OWLClass subC1, OWLClass subC2) {
		// Randomly choose a type of an axiom to be generated
		Random random = new Random();
		int randomInt = random.nextInt(10);
		OWLAxiom newAxiom = null;
		if (randomInt == 0 || randomInt == 1 || randomInt == 2 || randomInt == 3 || randomInt == 4) {
			newAxiom = OWL.factory.getOWLSubClassOfAxiom(subC1, supC); // 上层概念
		} else if (randomInt == 5) {
			newAxiom = OWL.factory.getOWLDisjointClassesAxiom(subC1, subC2);
		} else if (randomInt == 6 || randomInt == 7) {
			OWLObjectIntersectionOf oce = OWL.factory.getOWLObjectIntersectionOf(subC2, supC); // 基于合取的原理进行添加
			newAxiom = OWL.factory.getOWLSubClassOfAxiom(subC1, oce);
		} else {
			// Generate a new objectproperty and then define a complex concept with existential operator
			OWLObjectProperty ob = this.generateObjectProperty();
			newAxiom = OWL.factory.getOWLSubClassOfAxiom(subC1, OWL.factory.getOWLObjectSomeValuesFrom(ob, supC));
		}	
		return newAxiom;
	}

	private boolean addAxiom(OWLAxiom a, int injectNum) {
		boolean isEnough =false;
		if(a!=null) { //Just in case 
			newAxioms.add(a);
			axCounter++;	
			if (newAxioms.size() >= injectNum) {
				isEnough = true;				
			}
		}
		return isEnough;
	}

	private ArrayList<OWLClass> generateClasses(int start, int end) {
		ArrayList<OWLClass> conceptSet = new ArrayList<OWLClass>();
		for (int i = start; i < end; i++) {
			OWLClass newConcept = this.generateClass();
			conceptSet.add(newConcept);
		}
		return conceptSet;
	}

	private OWLClass generateClass() {
		String classIRI = "http://www.njupt.edu.cn#concept-" + (System.currentTimeMillis()+(clCounter ++));
		return OWL.manager.getOWLDataFactory().getOWLClass(IRI.create(classIRI));
	}
    
	private OWLObjectProperty generateObjectProperty() {
		// Use current time as prefix of a new entity to avoid duplicate names
		String opIRI = "http://www.njupt.edu.cn#objectproperty-"+(System.currentTimeMillis()+(opCounter ++));
		return OWL.factory.getOWLObjectProperty(IRI.create(opIRI));
	}
	

}
