package edu.njupt.radon.gen;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.gen.mipsRelevance.Pattern2Share1Axiom;
import edu.njupt.radon.gen.mipsRelevance.Pattern3Share1or2Axioms;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.MyPrinter;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * If an existing ontology is given,
 * @author QiuJi
 *
 */
public class InjectIncoHybrid {
	
	// By default, we generate an incoherent ontology from scratch with the given number of expectedUCNum, maxMUPSNum, maxMUPSSize
	String existingOntPath; 
	int expectedOSize;
	int expectedUCNum;
	int mipsNum;
	int maxMUPSNum;
	int maxMUPSSize;
	int minRemovalSize;
	public static HashMap<OWLClass, Integer> mipsSizeMap = new HashMap<OWLClass, Integer>();
	
	public static void main(String[] args) throws Exception {
		
		String method = "InjectIncoHybrid";
		// 为了能满足用户给出的所有参数，需要满足这些约束：
		String existingOntPath = null; 
		
		// （1） maxMUPSSize需>=3，因为mipsRel方法生成的MIPS介于[3,maxMUPSSize]之间
		int maxMUPSSize = 10;	
		int maxMUPSNum= 16;  // 10, 30, 50, 100		
		// （2）minRemovalSize >= maxMUPSNum+1
		int minRemovalSize = 24;  // 15, 40, 100, 110
		// （3）mipsNum >= minRemovalSize
		int mipsNum = 27;   // 50, 80， 150, 150
		// （4）expectedUCNum >= maxMUPSSize+mipsNum
		int expectedUCNum = 42;
		// （5）expectedOSize >= maxMUPSSize*（mipsNum+1）+maxMUPSNum+expectedUCNum+1
		int expectedOSize = 1000;	
				
		String infoPath = "newOnto/"+method+"/";
		FileTools.checkPath(infoPath);
		
		String ontoName = "size"+maxMUPSSize+"-UC"+expectedUCNum+"-mipsNum"+mipsNum+
				"-minR"+minRemovalSize+"-nmax"+maxMUPSNum;
		String newOntoPath = infoPath+ontoName+".owl";
		
		System.setOut((new PrintStreamObject(infoPath+ontoName+"-log.txt")).ps);		
		InjectIncoHybrid inject = new InjectIncoHybrid(existingOntPath, 
				expectedOSize, expectedUCNum, mipsNum, maxMUPSNum, maxMUPSSize, minRemovalSize);
		//InjectIncoHybrid inject = new InjectIncoHybrid(existingOntPath, expectedOSize, expectedUCNum, maxMUPSNum, maxMUPSSize);
		OWLOntology onto = inject.generateOntoFromScratch();
		System.out.println("axioms: "+onto.getLogicalAxiomCount());
		
		File f = new File(newOntoPath);
		OWL.manager.saveOntology(onto, IRI.create(f.toURI()));	
			

		//debug(onto);
	}	
	
	public void iniParameters() {
		if(this.maxMUPSSize < 3){
			this.maxMUPSSize = 3;
		}
		if(this.maxMUPSNum < 1) {
			this.maxMUPSNum = 1;
		}
		int rootucNum = this.maxMUPSNum+1;
		// set value for minRemovalSize
		if(this.minRemovalSize < rootucNum) {
			this.minRemovalSize = rootucNum;
		}
		// set value for number of mips
		if(this.mipsNum < this.minRemovalSize) {
			this.mipsNum = this.minRemovalSize;
		}
		int existUcNum = this.maxMUPSSize+this.mipsNum;
		// set value for number of ucs
		if(this.expectedUCNum < existUcNum) {
			this.expectedUCNum = existUcNum;
		}
		
	}
	
	public OWLOntology generateOntoFromScratch() {
		HashSet<OWLAxiom> newAxioms = new HashSet<>();	
		OWLOntology onto = null;		
        try {
			onto = OWL.manager.createOntology(); 
    	} catch(Exception ex) {
    		System.out.println(" This sentence should not be executed!");
    	}
        
       // System.setOut((new PrintStreamObject( "results/log.txt")).ps);
        // Step1：根据InjectUCsFromScratch生成ucNum个满足最大MUPS数量和大小约束的不可满足概念
        int ucNum = maxMUPSNum +1 +maxMUPSSize;
        InjectUCsFromScratch inject = new InjectUCsFromScratch(ucNum, maxMUPSNum, maxMUPSSize);		
		inject.generateUnsatConcepts();		
		newAxioms=inject.getAddedAxioms();	
		OWL.manager.addAxioms(onto, newAxioms);
		//debug(onto);
						
		// Step1中生成了maxMUPSNum+1个MIPS，每个MIPS只包含一条公理，所以最小移除maxMUPSNum+1个公理才能解决不协调性
		// Step2：根据用户设定的参数，生成更多MIPS以满足更多的最小移除数量
		int moreMinRemoval = this.minRemovalSize - (maxMUPSNum+1);
		int moreMIPSNum = this.mipsNum - (maxMUPSNum+1);
		System.out.println("Generating new MIPS and moreMinR:  "+moreMIPSNum+", "+moreMinRemoval);
		Pattern2Share1Axiom gen = new Pattern2Share1Axiom();
		if(moreMIPSNum!=0 && moreMinRemoval!=0) {
			newAxioms = gen.generateMUPS(moreMIPSNum, this.maxMUPSSize, moreMinRemoval);
			OWL.manager.addAxioms(onto, newAxioms);
		}	
		//debug(onto);
				
		// Step3：如果用户想要的UC数量大于已经生成的UC数量，则调用不增加公理数量的方法增添新的派生UC
		int newUcNum = this.expectedUCNum - ucNum - moreMIPSNum;
		System.out.println("Generating new derived ucs: "+newUcNum);
		if(newUcNum != 0 ) {
			InjectUCsWithOnto2 injectAxioms = new InjectUCsWithOnto2(onto, this.maxMUPSNum, this.maxMUPSSize);		
			newAxioms = injectAxioms.generateUnsatConcepts(newUcNum);
			OWL.manager.addAxioms(onto, newAxioms);
		}
			
		//debug(onto);
						
		// Step4：如果已经生成的公理数量小于期望的，则添加新的不影响原有不协调性的公理
		HashSet<OWLAxiom> axioms = new HashSet<>(onto.getLogicalAxioms());
		if(axioms.size()< expectedOSize) {			
			ExtendOntologyTightly ext = new ExtendOntologyTightly();
			newAxioms = ext.generateAxioms(onto, expectedOSize);
			OWL.manager.addAxioms(onto, newAxioms);
			System.out.println(" axioms in finalonto: "+axioms.size());
		}
		
		return onto;
	}
	
	public static void debug(OWLOntology onto) {		
		// check 
		System.out.println("***************** Check correctness ********************");
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto);	
		System.out.println("uc: "+ucs.size());
		
		RadonDebug debug = new BlackboxDebug(onto);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
		HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(mups);
		System.out.println("mips: "+mips.size());
		MyPrinter.printMultiSets(mips, null);
		
		//HashSet<OWLAxiom> removal = RepairWithScore.getOneDiagnose(mips);
		long st= System.currentTimeMillis();
		HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(mips);
		/*System.out.println("diagnosis : ");
		CommonTools.printMultiSets(diags, null);*/
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags);
		long time = System.currentTimeMillis() - st;
		
		System.out.println("removal: "+minHS.size());
		CommonTools.printAxioms(minHS);
		System.out.println("repair time: "+ time);
	}
	
	public InjectIncoHybrid(String ontoPath, int expectedOSize, 
			int expectedUCNum, int mipsNum, int maxMUPSNum, 
			int maxMUPSSize, int minRemovalSize) {
		this.existingOntPath = ontoPath;
		this.expectedOSize = expectedOSize;
		this.expectedUCNum = expectedUCNum;
		this.mipsNum = mipsNum;
		this.maxMUPSNum = maxMUPSNum;
		this.maxMUPSSize = maxMUPSSize;
		this.minRemovalSize = minRemovalSize;
		this.iniParameters();
	}
	
	
/*	private String getOntoName(String ontoPath) {
		String name = "newOnto";
		if(ontoPath != null) {
			int bIndex = ontoPath.lastIndexOf("/");
			int eIndex = ontoPath.lastIndexOf(".");
			if(bIndex!=-1 && eIndex!=-1) {
				name = ontoPath.substring(bIndex, eIndex);
			}
		}
		return name;
	}*/
	
	public HashSet<OWLAxiom> generateOnto() {
		HashSet<OWLAxiom> axioms = new HashSet<>();		
		OWLOntology onto = null;
        if(existingOntPath != null) {
        	try {
        		onto = OWL.manager.loadOntology(IRI.create(existingOntPath));
        		System.out.println(" axioms in onto: "+onto.getLogicalAxiomCount());
        	} catch(Exception ex) {
        		System.out.println("Fail to load the ontology with path: "+existingOntPath);
        	}	
        	if(onto != null) {
        		axioms = new HashSet<>(onto.getLogicalAxioms());
        		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto);	
        		if(ucs.size()==0) {
        			InjectDisjointAxioms addDisj = new InjectDisjointAxioms(onto);
           		    // By default, we generate no more than 20 disjointClass Axioms.
           		    axioms.addAll(addDisj.generateDisjAxioms(20));
        	        System.out.println(" Disjoint axioms: "+axioms.size());
        	        MyPrinter.printAxioms(axioms);        	        
        	        ucs = ReasoningTools.getUnsatiConcepts(onto);	
        	        System.out.println(" current onto ucs : "+ucs.size());
        		} 
        		// Currently, the ontology is incoherent.
       			int addedUCNum = expectedUCNum - ucs.size();
       			// If it is not enough, then generate new unsatisfiable concepts based on existing ontology
       			if(addedUCNum > 0) {
       				InjectUCsWithOnto2 injectAxioms = new InjectUCsWithOnto2(onto, this.maxMUPSSize, this.maxMUPSSize);
       				axioms = injectAxioms.generateUCs(expectedOSize, addedUCNum, 2);
       				System.out.println(" axioms in newonto: "+axioms.size());
       			}
        	}
        	
		}
		
		
		if(onto == null) {
			// Generate an empty ontology
			try {
				onto = OWL.manager.createOntology(); 
        	} catch(Exception ex) {
        		System.out.println(" This sentence should not be executed!");
        	}
			// Generate an ontology with the given number of unsatisfiable concepts, max MUPS size
			if(minRemovalSize > 0) {
				Pattern3Share1or2Axioms gen = new Pattern3Share1or2Axioms(onto, OWL.manager);
				gen.generateMUPS(expectedUCNum, maxMUPSSize, minRemovalSize);
				axioms = new HashSet<>(onto.getLogicalAxioms());
			} else {				
				InjectUCsFromScratch inject = new InjectUCsFromScratch(expectedUCNum, maxMUPSNum, maxMUPSSize);		
				inject.generateUnsatConcepts();		
				axioms = inject.getAddedAxioms();
			}	
			
		} else {
			// Check whether there are enough unsatisfiable concepts
			axioms = new HashSet<>(onto.getLogicalAxioms());
			HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto);	
			int addedUCNum = expectedUCNum - ucs.size();
			// If it is not enough, then generate new unsatisfiable concepts based on existing ontology
			if(addedUCNum > 0) {
				InjectUCsWithOnto2 injectAxioms = new InjectUCsWithOnto2(onto, this.maxMUPSSize, this.maxMUPSSize);
				//axioms = injectAxioms.generateUCs(addedUCNum);
				System.out.println(" axioms in newonto: "+axioms.size());
			}
			
		}		
		
		// Check whether there are enough axioms in the ontology
		if(axioms.size()< expectedOSize) {
			
			ExtendOntologyTightly main = new ExtendOntologyTightly();
			HashSet<OWLAxiom> newAxioms = main.generateAxioms(onto, expectedOSize);
			axioms.addAll(newAxioms);
			OWL.manager.addAxioms(onto, newAxioms);
			System.out.println(" axioms in finalonto: "+axioms.size());
		}
		
		return axioms;
	}
	
	
	
	public void printOntoInfo(OWLOntology onto) {
		System.out.println("onto size: "+onto.getLogicalAxiomCount());
		System.out.println("classes: "+onto.getClassesInSignature().size());
		System.out.println("ucs: "+ReasoningTools.getUnsatiConcepts(onto).size());
		
	}
	
}
