package edu.njupt.radon.gen;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.ComputeHierarchy;
import edu.njupt.radon.utils.io.MyPrinter;


/**
 * This class is to generate a set of disjoint axioms each of which contains two 
 * atomic concepts that have subsumption relationship. The number of generated
 * disjoint axioms is equal to or no more than the given number.
 * 
 * @author Qiu JI
 * modified: 2019.01.02
 * modified: 2021.02.18
 */
public class InjectDisjointAxioms {
		
	/** The subsumption relations between any two atomic concepts in a given ontology. */
	private HashMap<OWLClass, HashSet<OWLClass>> classHierarchy = 
		new HashMap<OWLClass, HashSet<OWLClass>>();
	
	// These two variables are used to save generated disjoint classes
	private Vector<OWLClass> disjClasses1 = new Vector<>();
	private Vector<OWLClass> disjClasses2 = new Vector<>();
	
	/** The set of disjoint axioms to be generated. */
	HashSet<OWLAxiom> disjAxioms = new HashSet<OWLAxiom>();	
	/** The counter to count the number of generated disjoint axioms. */
	
	
	int counter = 0 ;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String injectMethod = "InjectDisjointAxioms"; 
		String ontoName = "hello";		
		int numberOfAddedDisjAxioms = 100;
		
		String ontoPath = "file:onto/"+ontoName+".owl";
		// Please make sure the folder of "newOnto" exists in the current workspace
		String newOntoPath = "newOnto/"+injectMethod+"/"+ontoName+"-"+numberOfAddedDisjAxioms+".owl";
				
		
		OWLOntology onto = OWL.manager.loadOntology(IRI.create(ontoPath));		
		System.out.println("All axioms: "+onto.getAxiomCount());
        System.out.println("All logical axioms: "+onto.getLogicalAxiomCount());
        //HashSet<OWLAxiom> axs = new HashSet<OWLAxiom>(onto.getAxioms());
        //axs.removeAll(onto.getLogicalAxioms());        
        
        InjectDisjointAxioms addDisj = new InjectDisjointAxioms(onto);
        //addDisj.printAxioms(axs);
        HashSet<OWLAxiom> axioms = addDisj.generateDisjAxioms(numberOfAddedDisjAxioms);
        System.out.println(" Disjoint axioms: "+axioms.size());
        MyPrinter.printAxioms(axioms);
       
        File f  = new File(newOntoPath);
        // Generate a new ontology containing the axioms in the original ontology and those generated axioms
        //axioms.addAll(onto.getLogicalAxioms());
        //System.out.println(ReasoningTools.isCoherent(disjAxioms));
        //addDisj.printUcs(axioms);
        OWL.manager.addAxioms(onto, axioms);
        OWL.manager.saveOntology(onto, IRI.create(f.toURI()));        
	}
	
	
	public InjectDisjointAxioms(OWLOntology onto){
		ComputeHierarchy compute = new ComputeHierarchy();
		classHierarchy = compute.computeHierarchy(onto);
	}
	
	public void ini() {
		this.disjClasses1.clear();
		this.disjClasses2.clear();
		this.disjAxioms.clear();
		this.counter = 0;
	}

	
	/**
	 * This method generates a given number of disjoint axioms.  
	 * Each generated axiom contains two atomic concepts that 
	 * have the direct subsumption relationship.
	 * 
	 * For example, if we have A subclassof B in the original ontology,
	 * we generate A disjointWith B.
	 * 
	 * @param num
	 * @return
	 */
/*	public HashSet<OWLAxiom> getDisjointAxiomsSimple(int num){
		this.ini();
		for(OWLClass oc : classHierarchy.keySet()){
			HashSet<OWLClass> sups = classHierarchy.get(oc);
			Vector<OWLClass> orderedSups = new Vector<OWLClass>(sups);
			orderedSups.add(oc);
			// Create disjointness axioms
			this.generateDisjointAxioms(orderedSups, num);	
			if(counter >= num){
				break;
			}
		}	
		return disjAxioms;
	}*/
	

	
	/**
	 * This method generates a given number of disjoint axioms.  
	 * Each generated axiom contains two atomic concepts that 
	 * have the direct or indirect subsumption relationship.
	 * 
	 * For example, if we have A subclassof B and B subclassof C in the original ontology,
	 * we generate A disjointWith B and A disjointWith C.
	 * 
	 * @param num
	 * @return
	 */
	public HashSet<OWLAxiom> generateDisjAxioms(int num){
		this.ini();

		for(OWLClass oc : classHierarchy.keySet()){			
			HashSet<OWLClass> superClasses = getAllSuperClasses(oc);
			superClasses.add(oc);
			Vector<OWLClass> orderedSups = new Vector<OWLClass>(superClasses);
			// Create disjointness axioms
			this.generateDisjAxioms(orderedSups, num);
			if(counter >= num){
				break;
			}
		}	
		return disjAxioms;
	}
		
	private void generateDisjAxioms(Vector<OWLClass> orderedSups, int num) {	
		System.out.println("oc num = "+orderedSups.size());
		for(int i = 0; i<orderedSups.size(); i++) {
			OWLClass oc1 = orderedSups.get(i);
			System.out.println("oc1= "+oc1.toString()+" : "+i);
			for(int j = i+1; j < orderedSups.size(); j++) {				
				OWLClass oc2 = orderedSups.get(j);
				// This is to avoid adding A disjointWith B and B disjointWith A.
				if(this.isContained(oc1, oc2)) {
					System.out.println("******* continue");
					continue;
				}
				System.out.println("      oc2= "+oc2.toString()+" : "+j);
				OWLAxiom a = OWL.factory.getOWLDisjointClassesAxiom(oc1, oc2);
				disjAxioms.add(a);
				counter = disjAxioms.size();
				System.out.println("     "+counter+" :  "+a.toString());
				if(counter >= num){
					break;
				}
			}
			if(counter >= num){
				break;
			}
		}	
	}

	private boolean isContained(OWLClass oc1, OWLClass oc2) {
		boolean contained = false;
		if(this.disjClasses1.contains(oc1)) {
			int index = disjClasses1.indexOf(oc1);
			if(this.disjClasses2.get(index).equals(oc2)) {
				contained = true;
			}
		} 
		if(!contained && this.disjClasses1.contains(oc2)) {
			int index = disjClasses1.indexOf(oc2);
			if(this.disjClasses2.get(index).equals(oc1)) {
				contained = true;
			}
		}
		return contained;
	}
	
	public HashSet<OWLClass> getAllSuperClasses(OWLClass oc){
		HashSet<OWLClass> superClasses = new HashSet<OWLClass>();
		superClasses.add(oc);
		computeSuperclasses(oc, superClasses);
		return superClasses;
	}
	
	private void computeSuperclasses(
			OWLClass oc,
			HashSet<OWLClass> superClasses){
		
		HashSet<OWLClass> directSuper = classHierarchy.get(oc);
		if(directSuper!=null){			
			for(OWLClass superC : directSuper){
				// Avoid circle
				if(superClasses.contains(superC)){
					continue;
				}
				superClasses.add(superC);
				computeSuperclasses(superC, superClasses);
			}
		}
	}
	


}
