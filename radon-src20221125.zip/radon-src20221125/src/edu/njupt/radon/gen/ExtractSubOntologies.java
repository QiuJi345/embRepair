package edu.njupt.radon.gen;

import java.io.File;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.blackbox.BlackboxForOneMUPS;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * This class is to extract an incoherent sub-ontology with given number of axioms 
 * from an incoherent ontology. The basic idea is to find a MUPS first as a starter
 * ontology and then add more axioms randomly until the given number is reached.
 * 
 * @author QiuJi
 *
 */
public class ExtractSubOntologies {	
	
	HashSet<OWLAxiom> ontoAxioms = new HashSet<>();
	int pruneWindow = 100;
	
	public static void main(String[] args) throws Exception {
		
		String injectMethod = "ExtractSubOntology"; 
		int subOntoSize = 50;
		int subOntNum = 10;
		String ontoName = "ALOD2Vec-cmt-ekaw.rdf";
		String ontoPath = "file:onto/"+ontoName+".owl";	
		String newOntoPath = "newOnto/"+injectMethod+"/"+ontoName+"-";	
		
		
		OWLOntology onto = OWL.manager.loadOntology(IRI.create(ontoPath));

		ExtractSubOntologies ext = new ExtractSubOntologies(onto);
		ext.extractSubIncoOntos(subOntoSize, subOntNum, newOntoPath);
		
	}
	
	public ExtractSubOntologies(OWLOntology onto){		
		if(!ReasoningTools.isConsistent(onto, OWL.manager)) {
			ontoAxioms = OWLTools.getTBox(onto);			
		} else {
			ontoAxioms = new HashSet<>(onto.getLogicalAxioms());
		}			
		//ontoAxioms = OWLTools.getTBox(onto);
		System.out.println(" Original ontology axioms: "+ontoAxioms.size());
	}
	
	public void extractSubIncoOntos(int subOntoSize, int subOntNum, String resultPath) throws Exception{
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(ontoAxioms);
		System.out.println(" original ucs: "+ucs.size());
		OWLClass uc = ucs.iterator().next();
		int currentOntoSize = subOntoSize;
		HashSet<OWLAxiom> subOntAxioms = this.getStarterOnto(ontoAxioms, uc, subOntoSize);				
		while(subOntNum > 0){			
			subOntAxioms = extractSubIncoOnto(subOntAxioms, currentOntoSize);
			// output infor
			ucs = ReasoningTools.getUnsatiConcepts(subOntAxioms);
			System.out.println(" ucs: "+ucs.size());
			// save ontology
			File f = new File(resultPath+subOntAxioms.size()+".owl");
			OWLTools.saveOntology(subOntAxioms, f.getAbsolutePath());	
			// modify counter and the size of next sub-ontology
			subOntNum --;
			currentOntoSize += subOntoSize;
		}
	}
	
	
	public HashSet<OWLAxiom> extractSubIncoOnto(int subOntoSize, String resultPath) throws Exception {		
		
		HashSet<OWLAxiom> starterOnto = this.getStarterOnto(ontoAxioms);
		HashSet<OWLAxiom> subOnto = this.extractSubIncoOnto(starterOnto, subOntoSize);
		// save the axioms to a local ontology
		OWLOntology ont = OWL.manager.createOntology(subOnto);
		File f = new File(resultPath+subOnto.size()+".owl");
		OWL.manager.saveOntology(ont, IRI.create(f.toURI()));	
		
		return subOnto;
	}
	
    public HashSet<OWLAxiom> extractSubIncoOnto(HashSet<OWLAxiom> starterOnto, int subOntoSize)  {		
		
		HashSet<OWLAxiom> subOnto = new HashSet<>(starterOnto);
		int counter = subOnto.size();
		if(counter < subOntoSize) {
			for(OWLAxiom axiom : ontoAxioms){		
				if(starterOnto.contains(axiom)) {
					continue;
				}
				subOnto.add(axiom);
				counter ++;
				if(counter >= subOntoSize) {
					break;
				}
			}
		}		
		System.out.println("subOnto size : "+subOnto.size());		
		
		return subOnto;
	}

	
	private HashSet<OWLAxiom> getStarterOnto(HashSet<OWLAxiom> onto) {
		HashSet<OWLAxiom> oneMUPS = new HashSet<>();
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto);
		if(ucs.size()!=0) {
			OWLClass uc = ucs.iterator().next();			
			BlackboxForOneMUPS computeOneMUPS = new BlackboxForOneMUPS(onto);			
			oneMUPS = computeOneMUPS.getOneMUPS(uc);	
		}		
		System.out.println("starter ontology size is : "+oneMUPS.size());
		return oneMUPS;
	}
	


public HashSet<OWLAxiom> getStarterOnto(HashSet<OWLAxiom> axioms, OWLClass oc, int expSize) {	
	Vector<OWLAxiom> allRelated = new Vector<OWLAxiom>(axioms);
	HashSet<OWLAxiom> prunedOWLAxioms = new HashSet<OWLAxiom>(axioms);
	int size = allRelated.size();
	//System.out.println(OWLTools.isCoherent(new HashSet<OWLAxiom>(prunedOWLAxioms),oc));
	if(size>pruneWindow){
		int parts = size / pruneWindow;
		for (int part = 0; part < parts; part++) {				
			for (int i = part * pruneWindow; i < part * pruneWindow
					+ pruneWindow; i++) {
				prunedOWLAxioms.remove(allRelated.get(i));
			}
							
			if (ReasoningTools.isSatisfiable(new HashSet<OWLAxiom>(prunedOWLAxioms),oc)) {
				System.out.println("  Fast prune: cannot remove"+prunedOWLAxioms.size());
				for (int i = part * pruneWindow; i < part * pruneWindow
						+ pruneWindow; i++) {
					prunedOWLAxioms.add(allRelated.get(i));
					//System.out.println(i+" > "+allRelated.get(i).toString().replace(ns, ""));
				}
			} else {
				System.out.println("  Fast prune: remove"+prunedOWLAxioms.size());
			}
			if(prunedOWLAxioms.size()<=expSize) {								
				break;
			}
		}
	}
	return prunedOWLAxioms;
}
	
	public void generateSubOntos(HashSet<OWLAxiom> origOnto, int stepLength) throws Exception {
		HashSet<OWLAxiom> origOnto_temp = new HashSet<OWLAxiom>(origOnto);				
		HashSet<OWLAxiom> subOnto = new HashSet<OWLAxiom>();
		int counter = 1;
		for(OWLAxiom a : origOnto_temp){			
			subOnto.add(a);
			if(counter > 0 && (counter % stepLength) == 0 ){
				OWLTools.saveOntology(subOnto, "file:///d:/km1500-"+ counter +".owl");
				System.out.println("subonto size: "+subOnto.size());
			} 
			counter ++;
		}
	}
}
