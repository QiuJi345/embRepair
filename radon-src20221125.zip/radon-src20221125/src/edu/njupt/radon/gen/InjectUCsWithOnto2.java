package edu.njupt.radon.gen;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Vector;

import org.semanticweb.owlapi.model.AxiomType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * 该方法基于
 * @author QiuJi
 *
 */
public class InjectUCsWithOnto2 {

	int classCounter = 0;

	OWLOntology onto;
	//ArrayList<OWLClass> concepts;
	ArrayList<OWLClass> unconcepts;
	ArrayList<OWLObjectProperty> objectproperties;
	Random r = new Random();
	int maxMUPSNum;
	int maxMUPSSize;
	ArrayList<OWLClass> existUcs = new ArrayList<>(InjectIncoHybrid.mipsSizeMap.keySet());
	ArrayList<OWLClass> unselectedUcs = new ArrayList<>(InjectIncoHybrid.mipsSizeMap.keySet());

	public static void main(String[] args) throws Exception {
		String injectMethod = "InjectUCsWithOnto";
		// type的可选类型有: "intersection","existing", "union" and "random".
		// By default (i.e. type="random"), randomly choose a type for each new axiom.
		int extOSize = 1000;
		int extUcNum = 60; 
		int extMipsNum = 10;
		int maxMUPSNum = 10;
		int maxMUPSSize = 10;
		String ontoName = "proton"; //proton-Ext1000-Mips10-UC60

		String ontoPath = "file:onto/"+ontoName+".owl";
		String newOntoPath = "newOnto/" + injectMethod + "/" + ontoName +"-Ext"+ extOSize+"-Mips"+extMipsNum;

		OWLOntology onto = OWL.manager.loadOntology(IRI.create(ontoPath));
		
		Long tic2 = System.currentTimeMillis();		
		InjectUCsWithOnto2 injectAxioms = new InjectUCsWithOnto2(onto, maxMUPSNum, maxMUPSSize);		
		HashSet<OWLAxiom> newAxioms = injectAxioms.generateUCs(extOSize, extUcNum, extMipsNum);
		Long toc2 = System.currentTimeMillis();
		System.out.println("The consumption of injecting time is " + (toc2 - tic2) + " ms");
		
			
		OWL.manager.addAxioms(onto, newAxioms);
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto);
		System.out.println(" allAxioms " + onto.getLogicalAxiomCount());
		System.out.println("The number of current UCs is " + ucs.size());
		
		// save the new ontology
		newOntoPath += "-UC"+ extUcNum + ".owl";
		File f = new File(newOntoPath);
		OWL.manager.saveOntology(onto, IRI.create(f.toURI()));
		
		RadonDebug debug = new BlackboxDebug(onto);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
				
	}

	public InjectUCsWithOnto2(OWLOntology onto, int maxMUPSNum, int maxMUPSSize) {
		this.maxMUPSNum = maxMUPSNum;
		this.maxMUPSSize = maxMUPSSize;
		this.onto = onto;
		objectproperties = new ArrayList<>(onto.getObjectPropertiesInSignature());
		unconcepts = new ArrayList<>(ReasoningTools.getUnsatiConcepts(onto));
		
		System.out.println("The number of original UCs is " + unconcepts.size());
	}

	public HashSet<OWLAxiom> generateUCs(int extOSize, int extUcNum, int extMipsNum) {
		HashSet<OWLAxiom> newAxioms = new HashSet<>();
		
		int newSatConceptNum = extOSize - extUcNum;
		int newUcNum = extUcNum - extMipsNum;
		
		newAxioms = this.generateSatConcepts(newSatConceptNum);
		newAxioms.addAll(generateUnsatConcepts(newUcNum));
		newAxioms.addAll(generateMips(extMipsNum));
		
		
		//System.out.println("The number of new axioms is " + newAxioms.size());
		return newAxioms;
	}
	
	private HashSet<OWLAxiom> generateMips(int mipsNum) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();		
				
		// obtain subclassof relations between atomic concepts
		Vector<OWLClass> subs = new Vector<OWLClass>();
		Vector<OWLClass> sups = new Vector<OWLClass>();
		for(OWLSubClassOfAxiom ax : onto.getAxioms(AxiomType.SUBCLASS_OF)) {
			OWLClassExpression sube = ax.getSubClass();
			OWLClassExpression supe = ax.getSuperClass();
			if(sube.isAnonymous()) {
				continue;
			}
			OWLClass subc = sube.asOWLClass();
			if(this.unconcepts.contains(subc)) {
				continue;
			}
			if(supe.isAnonymous() && (supe instanceof OWLObjectIntersectionOf)) {
				OWLObjectIntersectionOf inters = (OWLObjectIntersectionOf)supe;
				for(OWLClassExpression oce : inters.getOperands()) {
					if(!oce.isAnonymous()) {
						subs.add(subc);
						sups.add(oce.asOWLClass());
					}
				}
			} else if(!supe.isAnonymous()) {
				subs.add(subc);
				sups.add(supe.asOWLClass());
			}
		}
		
		int len = subs.size();
		if(len <= 0) {
			System.out.println("Fail to find a concept hierarchy!");
		} else {
			while(axCounter < mipsNum) {
				int i = r.nextInt(len);
				OWLClass oc = this.generateClass("rootConcept");
				OWLObjectIntersectionOf oi = OWL.factory.getOWLObjectIntersectionOf(subs.get(i),
						OWL.factory.getOWLObjectComplementOf(sups.get(i)));
				OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(oc, oi);

				newAxioms.add(ax);
				axCounter ++;
			}
		}
		
		
		return newAxioms;
	
	}
	
/*	public HashSet<OWLAxiom> generateUnsatConcepts(int newUcNum) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();		
		
		while(axCounter < newUcNum) {
			OWLAxiom ax = generateAxiom(this.unconcepts, unconcepts);
			newAxioms.add(ax);
			axCounter ++;
		}		
		return newAxioms;
	}*/
	
	public HashSet<OWLAxiom> generateUnsatConcepts(int newUcNum) {
		HashSet<OWLAxiom> newAxioms = new HashSet<>();	
		int ucTBAnum = newUcNum;		
		
		while(ucTBAnum > 0) {
			OWLClass uc = this.getRandomClass(this.existUcs);
			System.out.println("injectWithOnto: randomly selected uc: "+uc.getIRI().toString());
			int exSize = InjectIncoHybrid.mipsSizeMap.get(uc);				
			// Generate derived ucs with random number under given conditions
			int size1 = this.maxMUPSNum - 1;
			int size2 = this.maxMUPSSize - exSize;
			int size = Math.min(size1, size2);
			
			if(ucTBAnum <= size) {
				// create derived ucs for one root uc
				newAxioms.addAll(this.generateDerivedUCs(uc, ucTBAnum));
				break;
				
			} else {							
				
				int derivedUcNum = r.nextInt(size)+1;
				ucTBAnum -= derivedUcNum;
				newAxioms.addAll(this.generateDerivedUCs(uc, derivedUcNum));				
				
			}			
		}		
				
		return newAxioms;
	}
	
	public HashSet<OWLAxiom> generateUnsatConcepts2(int newUcNum) {
		HashSet<OWLAxiom> newAxioms = new HashSet<>();	
		int ucTBAnum = newUcNum;		
		while(ucTBAnum > 0) {
			OWLClass uc = this.getRandomClass(this.existUcs);
			System.out.println("injectWithOnto: randomly selected uc: "+uc.getIRI().toString());
			int exSize = InjectIncoHybrid.mipsSizeMap.get(uc);				
			// Generate derived ucs with random number under given conditions
			int size1 = this.maxMUPSNum - 1;
			int size2 = this.maxMUPSSize - exSize;
			int size = Math.min(size1, size2);
			
			if(ucTBAnum <= size) {
				// create derived ucs for one root uc
				newAxioms.addAll(this.generateDerivedUCs(uc, ucTBAnum));
				break;
				
			} else {							
				
				int derivedUcNum = r.nextInt(size)+1;
				newAxioms.addAll(this.generateDerivedUCs(uc, derivedUcNum));				
				ucTBAnum -= derivedUcNum;
			}			
		}		
				
		return newAxioms;
	}
	
/*	private void removeUc(OWLClass uc) {
		
		if(uc.getIRI().toString().contains("patternUC")) {
			HashSet<OWLClass> ucs  = new HashSet<OWLClass>(this.unselectedUcs);
			for(OWLClass uc2 : ucs) {
				if(uc2.getIRI().toString().contains("patternUC")) {
					this.unselectedUcs.remove(uc2);
				}
			}
		}
	}*/
	
	public OWLClass selectUc(int length) {		
		OWLClass uc = this.getRandomClass(this.unselectedUcs);
		
		int exSize = InjectIncoHybrid.mipsSizeMap.get(uc);
		// exSize+length 表示一个uc的最大可能MUPS size
		// length+1表示一个uc的可能MUPS数量
		while((exSize+length) > maxMUPSSize || (length+1) > this.maxMUPSNum) {
			uc = this.getRandomClass(unselectedUcs);
			exSize = InjectIncoHybrid.mipsSizeMap.get(uc);
		}
		return uc;
	}
	
	/**
	 * 生成ucNum个派生不可满足概念：
	 * （1）第一个派生uc D1是某个已有uc C1的子概念；
	 * （2）第二个派生uc D2\subclassof D1 \intersection C2，其中C2是不同于C1的已有uc
	 * （3）第n个派生uc Dn\subclassof Dn-1 \intersection Cn，其中Cn是不同于C1..Cn-1的已有uc
	 * 
	 * @param ucNum
	 * @return
	 */
	public HashSet<OWLAxiom> generateDerivedUCs(OWLClass uc1, int ucNum) {
		//
		System.out.println("*******************\n    To generate derived ucs: "+ucNum);
		int length = ucNum;
		Integer mNum = this.maxMUPSNum - 1;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();
		HashSet<OWLAxiom> tmpAxioms = new HashSet<>();
		this.unselectedUcs = new ArrayList<>(this.existUcs);
		this.unselectedUcs.remove(uc1);
		//this.removeUc(uc1);
		
		OWLClass duc = this.generateClass("derivedOntoUC"+length);
		System.out.println("new uc: "+duc.getIRI().toString());
		System.out.println("   selected root1: "+uc1.getIRI().toString());
		OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(duc, uc1);		
		newAxioms.add(ax);
		tmpAxioms = this.generateMoreMUPS(duc, ucNum, mNum);
		newAxioms.addAll(tmpAxioms);
		mNum = mNum - tmpAxioms.size();
		System.out.println("  tmpAxioms: "+tmpAxioms.size());
		System.out.println("  mNum: "+mNum);
		OWLClass previousUc = duc;	
		length --;
		
		while(length>0) {			
			duc = this.generateClass("derivedOntoUC"+length);
			System.out.println("new uc: "+duc.getIRI().toString());
			//OWLClass uc2 = this.selectUc(ucNum);
			//ax = OWL.factory.getOWLSubClassOfAxiom(duc, OWL.factory.getOWLObjectIntersectionOf(previousUc, uc2));
			ax = OWL.factory.getOWLSubClassOfAxiom(duc, previousUc);
			tmpAxioms = this.generateMoreMUPS(duc, ucNum, mNum);
			newAxioms.add(ax);
			System.out.println("  tmpAxioms: "+tmpAxioms.size());
			newAxioms.addAll(tmpAxioms);
			mNum = mNum - tmpAxioms.size();
			System.out.println("  mNum: "+mNum);
			previousUc = duc;	
			length --;
		}
		return newAxioms;
	}
	
	private HashSet<OWLAxiom> generateMoreMUPS(OWLClass uc, int length, int num) {
		OWLAxiom ax = null;
		OWLClass uc2 = null;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();
		if(num-1 > 0) {
			int mupsNum = r.nextInt(num-1)+1;
			for(int i=0; i<mupsNum; i++) {
				uc2 = this.selectUc(length);
				ax = OWL.factory.getOWLSubClassOfAxiom(uc, uc2);
				newAxioms.add(ax);
				System.out.println("   selected root: "+uc2.getIRI().toString());
			}
			System.out.println("    generate new relations: "+mupsNum);
		} else if(num==1) {
			uc2 = this.selectUc(length);
			ax = OWL.factory.getOWLSubClassOfAxiom(uc, uc2);
			newAxioms.add(ax);
			System.out.println("   selected root: "+uc2.getIRI().toString());
			System.out.println("    generate new relations: 1");
		}
		return newAxioms;
		
	}
	
	/*
	*//**
	 * 这个方法假设已有的UC都是根不可满足概念，且最大的MIPS包含n个公理，
	 * 则新增加的派生UC跟根UC之间的层次不超过（level-n）
	 * @param newUcNum
	 * @param level
	 * @return
	 *//*
	public HashSet<OWLAxiom> generateUnsatConcepts(int newUcNum, int level) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();		
		
		while(axCounter < newUcNum) {
			OWLAxiom ax = generateAxiom(this.unconcepts, unconcepts);
			newAxioms.add(ax);
			axCounter ++;
		}
		
		return newAxioms;
	}*/
	
	public HashSet<OWLAxiom> generateSatConcepts(int satConceptNum) {
		int axCounter = 0;
		HashSet<OWLAxiom> newAxioms = new HashSet<>();
		
		ArrayList<OWLClass> allConcepts = new ArrayList<>(onto.getClassesInSignature());
		ArrayList<OWLClass> satConcepts = new ArrayList<>(allConcepts);
		satConcepts.removeAll(unconcepts);
		
		while(axCounter < satConceptNum) {
			OWLAxiom ax = generateAxiom(satConcepts, allConcepts);
			newAxioms.add(ax);
			axCounter ++;
		}
		
		return newAxioms;
	}
	
	private OWLAxiom generateAxiom(ArrayList<OWLClass> conceptSet1, ArrayList<OWLClass> conceptSet2) {
		OWLAxiom ax = null;
		OWLClass con = this.generateClass("concept");	
		
		
		OWLClass sup = this.getRandomClass(conceptSet1);			
		ax = OWL.factory.getOWLSubClassOfAxiom(con, sup);
		
		/*int index = r.nextInt(2);		
		if(index == 1) {			
			OWLClass sup = this.getRandomClass(conceptSet1);			
			ax = OWL.factory.getOWLSubClassOfAxiom(con, sup);
		} else {
			OWLClass sup1 = this.getRandomClass(conceptSet1);
			conceptSet2.remove(sup1);
			OWLClass sup2 = this.getRandomClass(conceptSet2);
			conceptSet2.add(sup1);
			ax = OWL.factory.getOWLSubClassOfAxiom(con, OWL.factory.getOWLObjectUnionOf(sup1,sup2));
		}*/
		return ax;
	}


		
	private OWLClass getRandomClass(ArrayList<OWLClass> ocs) {
		Random random = new Random();
		int randomSupConceptNum = random.nextInt(ocs.size());
		OWLClass oc = ocs.get(randomSupConceptNum);
		return oc;
	}
	
	
	private OWLClass generateClass(String prefix) {
		// Use current time as prefix of a new entity to avoid duplicate names
		String classIRI = "http://www.njupt.edu.cn#"+prefix+"_"+System.currentTimeMillis()+classCounter;			
		classCounter ++;
		//System.out.println("new class ["+classCounter+"] "+classIRI);
		return OWL.factory.getOWLClass(IRI.create(classIRI));
	}
	

}
