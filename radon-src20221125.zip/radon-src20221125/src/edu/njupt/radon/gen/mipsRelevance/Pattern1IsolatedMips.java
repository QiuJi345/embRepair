package edu.njupt.radon.gen.mipsRelevance;

import java.io.File;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.repair.ilp.RepairParameters;
import edu.njupt.radon.utils.OWLTools;

public class Pattern1IsolatedMips {
	
	OWLOntology onto;

	OWLOntologyManager manager;
	
	int classCounter = 1;
	
	
	public Pattern1IsolatedMips(OWLOntology o, OWLOntologyManager m) {
		onto = o;
		this.manager = m;
	}
		
	
	/**
	 * Generate an ontology with mupsNum disconnected MUPS,
	 * each of which contain no more axiomNum axioms.
	 * 
	 * @param mupsNum
	 * @param axiomNum
	 */
	public void generateMUPS(int mupsNum, int axiomNum) {
		for(int i = 0; i < mupsNum; i++) {
			System.out.println("Generate new mups ["+i+"]");
			this.generateOneMUPS(axiomNum);
		}
	}
	
	private void generateOneMUPS(int axiomNum) {
		OWLClass oc1 = generateNewClass();
		OWLClass oc2 = generateNewClass();
		OWLClass uc = generateNewClass();
		
		this.addDisjointAxiom(oc1, oc2);
		this.addSubclassOfAxiom(uc, oc1);
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc2);
			System.out.println();
			return;
		}		
		
		OWLClass subOc = null;
		OWLClass supOc = oc2;
		for(int i=0; i< axiomNum-3; i++) {
			subOc = generateNewClass();
			this.addSubclassOfAxiom(subOc, supOc);
			supOc = subOc;
		}
		this.addSubclassOfAxiom(uc, supOc);
		System.out.println();
	}
	

	private OWLClass generateNewClass() {
		String classIRI = "http://njupt.edu.cn#concept-"+(classCounter++);
		System.out.println("new class : "+classIRI);
		return manager.getOWLDataFactory().getOWLClass(IRI.create(classIRI));
	}
	
	private void addSubclassOfAxiom(OWLClass subC, OWLClass supC) {
		OWLAxiom ax = manager.getOWLDataFactory().getOWLSubClassOfAxiom(subC, supC);
		manager.addAxiom(onto, ax);
		System.out.println(ax.toString());
	}
	
	private void addDisjointAxiom(OWLClass oc1, OWLClass oc2) {
		OWLAxiom ax = manager.getOWLDataFactory().getOWLDisjointClassesAxiom(oc1, oc2);
		manager.addAxiom(onto, ax);
		System.out.println(ax.toString());
	}

}
