package edu.njupt.radon.gen.mipsRelevance;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

/**
 * 
 * @author QiuJi
 * 2021.03.12 Modified: 修复了之前无法处理normal group的大小为1的情况
 */
public class Pattern3Share1or2Axioms {

	OWLOntology onto;

	OWLOntologyManager manager;
	
	int classCounter = 1;
	
	public Pattern3Share1or2Axioms(OWLOntology o, OWLOntologyManager m) {
		onto = o;
		this.manager = m;
	}
	
	public void generateMUPS(int allMUPSNum, int axiomNum, int cardiMin)  {
		// The number of MUPS in each group except the last one
		float num = (float)allMUPSNum / cardiMin;	
		if(num < 1) {
			System.err.println("Fail to construct the ontology since each group only can contain 1 MUPS! \n"
					+ "We cannot generate MUPS sharing two axioms.");
			return;
		}
		// The number of MUPS in each group except the last one
		int mupsNum1 = allMUPSNum / cardiMin;
		// The number of MUPS in the last group
		int reminder = allMUPSNum % cardiMin;
		// The number of normal groups
		int times = cardiMin -1;		
		if(reminder == 0 ) {
			times = cardiMin;			
		}
		// The number of MUPS in the last group (maybe 0)
		int mupsNum2 = allMUPSNum - mupsNum1*times;
		
		int groupCounter = 0;
		if(mupsNum1 == 1) {
			for(int i=0; i<times; i++){
				this.generateOneMUPS(axiomNum);
			}
		} else {
			// Generate 2*n groups of ontologies
			for(int i=0; i<times-1; i=i+2){
				generateMUPSShareTwoAxioms(mupsNum1, axiomNum);
				groupCounter+=2;
			}
			// Generate times-groupCounter groups of ontologies
			for(int i=0; i<times-groupCounter; i++){
				generateMUPSShareOneAxiom(mupsNum1, axiomNum);
			}
		}

		// Generate the last group of ontologies if exists
		if(mupsNum2 != 0) {
			generateMUPSShareOneAxiom(mupsNum2, axiomNum);
		}
		
	}
	
	public void generateOneMUPS(int axiomNum) {
		// Share the disjoint axiom
		OWLClass oc1 = generateNewClass();
		OWLClass oc2 = generateNewClass();		
		//System.out.println("*************************shared:");
		this.addDisjointAxiom(oc1, oc2);
		// Share the subclassof axiom
		OWLClass uc = generateNewClass();
		//System.out.println("*************************shared:");
		this.addSubclassOfAxiom(uc, oc1);
		// Construct the mups sharing two axioms
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc2);
			//System.out.println();
			return;
		} else {
			OWLClass subOc = null;
			OWLClass supOc = oc2;
			for(int i=0; i< axiomNum-3; i++) {
				subOc = generateNewClass();
				this.addSubclassOfAxiom(subOc, supOc);
				supOc = subOc;
			}
			this.addSubclassOfAxiom(uc, supOc);
			//System.out.println();
		}
	}
	
	
	public void generateMUPSShareTwoAxioms(int mupsNum, int axiomNum) {
		// Share the disjoint axiom
		OWLClass oc1 = generateNewClass();
		OWLClass oc2 = generateNewClass();		
		//System.out.println("*************************shared:");
		this.addDisjointAxiom(oc1, oc2);
		// Share the subclassof axiom
		OWLClass uc = generateNewClass();
		//System.out.println("*************************shared:");
		this.addSubclassOfAxiom(uc, oc1);
		// Construct the mups sharing two axioms
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc2);
			//System.out.println();
			return;
		} else {
			OWLClass subOc = null;
			OWLClass supOc = oc2;
			for(int i=0; i< axiomNum-3; i++) {
				subOc = generateNewClass();
				this.addSubclassOfAxiom(subOc, supOc);
				supOc = subOc;
			}
			this.addSubclassOfAxiom(uc, supOc);
			//System.out.println();
		}
		
		// Construct mupsNum mups sharing the disjoint axiom
		for(int i = 0; i < mupsNum; i++) {
			//System.out.println("Generate new mups sharing disjointness axiom ["+i+"]");
			this.generateOneMUPSShareDisjAxiom(oc1, oc2, axiomNum);
		}
		
		// Construct mupsNum-1 mups sharing the first subclass axiom
		for(int i = 0; i < mupsNum-1; i++) {
			//System.out.println("Generate new mups sharing subclass axiom ["+i+"]");
			this.generateOneMUPSShareSubcAxiom(uc, oc1, axiomNum);
		}
		
	}
	
	private void generateMUPSShareOneAxiom(int mupsNum, int axiomNum)  {
		// All generated MUPS share the same disjointness axiom.
		OWLClass oc1 = generateNewClass();
		OWLClass oc2 = generateNewClass();		
		this.addDisjointAxiom(oc1, oc2);
		
		for(int i = 0; i < mupsNum; i++) {
			//System.out.println("Generate new mups ["+i+"]");
			this.generateOneMUPSShareDisjAxiom(oc1, oc2, axiomNum);
		}
	}

	private void generateOneMUPSShareSubcAxiom(OWLClass uc, OWLClass oc1,int axiomNum) {
		// All generated MUPS share the same subclass axiom.
		OWLClass oc2 = generateNewClass();		
		this.addDisjointAxiom(oc1, oc2);
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc2);
			//System.out.println();
			return;
		}		
		
		OWLClass subOc = null;
		OWLClass supOc = oc2;
		for(int i=0; i< axiomNum-3; i++) {
			subOc = generateNewClass();
			this.addSubclassOfAxiom(subOc, supOc);
			supOc = subOc;
		}
		this.addSubclassOfAxiom(uc, supOc);
		//System.out.println();
	}
	
	/**
	 * Generate one MUPS with the given disjointness relation between oc1 and oc2
	 * @param oc1
	 * @param oc2
	 * @param axiomNum
	 */
	private void generateOneMUPSShareDisjAxiom(OWLClass oc1, OWLClass oc2, int axiomNum) {
		OWLClass uc = generateNewClass();
		this.addSubclassOfAxiom(uc, oc1);
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc2);
			//System.out.println();
			return;
		}		
		
		OWLClass subOc = null;
		OWLClass supOc = oc2;
		for(int i=0; i< axiomNum-3; i++) {
			subOc = generateNewClass();
			this.addSubclassOfAxiom(subOc, supOc);
			supOc = subOc;
		}
		this.addSubclassOfAxiom(uc, supOc);
		//System.out.println();
	}
	

	

	private OWLClass generateNewClass() {
		String classIRI = "http://njupt.edu.cn#concept-"+(classCounter++);
		//System.out.println("new class : "+classIRI);
		return manager.getOWLDataFactory().getOWLClass(IRI.create(classIRI));
	}
	
	private void addSubclassOfAxiom(OWLClass subC, OWLClass supC) {
		OWLAxiom ax = manager.getOWLDataFactory().getOWLSubClassOfAxiom(subC, supC);
		manager.addAxiom(onto, ax);
		//System.out.println(ax.toString());
	}
	
	private void addDisjointAxiom(OWLClass oc1, OWLClass oc2) {
		OWLAxiom ax = manager.getOWLDataFactory().getOWLDisjointClassesAxiom(oc1, oc2);
		manager.addAxiom(onto, ax);
		//System.out.println(ax.toString());
	}
}
