package edu.njupt.radon.gen.mipsRelevance;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class Pattern4Share1or2AxiomsComplex {

	OWLOntology onto;

	OWLOntologyManager manager;
	
	int classCounter = 1;
	
	public Pattern4Share1or2AxiomsComplex(OWLOntology o, OWLOntologyManager m) {
		onto = o;
		this.manager = m;
	}
	
	public void generateMUPS(int allMUPSNum, int axiomNum, int cardiMin) {
		// The number of MUPS in each MUPS except the last one
		int mupsNum1 = (int)(allMUPSNum * 0.8);
		mupsNum1 = (int)(mupsNum1/(cardiMin-1));
		if(mupsNum1 <= 3 && cardiMin <= 1) {
			System.err.println("Fail to construct the ontology!  \n"
					+ "It is because  each group only can contain no more than 4 MUPS! ");
			return;
		}		
		int times = cardiMin - 1;		
		int mupsNum2 = allMUPSNum - mupsNum1*times;
		// Construct groups with Pattern2	
		for(int i=0; i<times-1; i++){
			generateMUPSContainOneAxiom(mupsNum1, axiomNum);
		}
		// Generate the last groups of MUPS 
		generateLastTwoGroups(mupsNum1, mupsNum2, axiomNum);
				
	}
	
	
	public void generateLastTwoGroups(int mupsNum1, int mupsNum2, int axiomNum) {
		// Share the disjoint axiom
		OWLClass oc1 = generateNewClass();
		OWLClass oc2 = generateNewClass();		
		System.out.println("*************************shared:");
		this.addDisjointAxiom(oc1, oc2);
		// Share the subclassof axiom
		OWLClass uc = generateNewClass();
		System.out.println("*************************shared:");
		this.addSubclassOfAxiom(uc, oc1);
		
		// Construct two mups sharing the first disjoint axiom and subclass axiom
		for(int k=0; k<2; k++) {
			if(axiomNum <= 3) {
				this.addSubclassOfAxiom(uc, oc2);
				System.out.println();
				return;
			} else {
				OWLClass subOc = null;
				OWLClass supOc = oc2;
				for(int i=0; i< axiomNum-3; i++) {
					subOc = generateNewClass();
					this.addSubclassOfAxiom(subOc, supOc);
					supOc = subOc;
				}
				this.addSubclassOfAxiom(uc, supOc);
				System.out.println();
			}
		}
		
		// Construct a mups sharing the second disjoint axiom and subclass axiom
		OWLClass oc3 = generateNewClass();
		System.out.println("*************************shared:");
		this.addDisjointAxiom(oc1, oc3);
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc3);
			System.out.println();
			return;
		} else {
			OWLClass subOc = null;
			OWLClass supOc = oc3;
			for(int i=0; i< axiomNum-3; i++) {
				subOc = generateNewClass();
				this.addSubclassOfAxiom(subOc, supOc);
				supOc = subOc;
			}
			this.addSubclassOfAxiom(uc, supOc);
			System.out.println();
		}		
				
		// Construct mupsNum1-2 mups sharing the first disjoint axiom
		for(int i = 0; i < mupsNum1-2; i++) {
			System.out.println("Generate new mups sharing disjointness axiom ["+i+"]");
			this.generateOneMUPSContainDisjAxiom(oc1, oc2, axiomNum);
		}
		
		// Construct mupsNum2-2 mups containing both the first subclass axiom and the second disjoint axiom
		for(int i = 0; i < mupsNum2-2; i++) {
			System.out.println("Generate new mups sharing subclass axiom ["+i+"]");
			if(axiomNum <= 3) {
				this.addSubclassOfAxiom(uc, oc3);
				System.out.println();
				return;
			} else {
				OWLClass subOc = null;
				OWLClass supOc = oc3;
				for(int j=0; j< axiomNum-3; j++) {
					subOc = generateNewClass();
					this.addSubclassOfAxiom(subOc, supOc);
					supOc = subOc;
				}
				this.addSubclassOfAxiom(uc, supOc);
				System.out.println();
			}	
		}
		
		// Construct one MUPS containing the second disjoint axiom
		this.generateOneMUPSContainDisjAxiom(oc1, oc3, axiomNum);
	}
	
	
	
	private void generateMUPSContainOneAxiom(int mupsNum, int axiomNum) {
		// All generated MUPS share the same disjointness axiom.
		OWLClass oc1 = generateNewClass();
		OWLClass oc2 = generateNewClass();		
		this.addDisjointAxiom(oc1, oc2);
		
		for(int i = 0; i < mupsNum; i++) {
			System.out.println("Generate new mups ["+i+"]");
			this.generateOneMUPSContainDisjAxiom(oc1, oc2, axiomNum);
		}
	}

	private void generateOneMUPSContainSubcAxiom(OWLClass uc, OWLClass oc1,int axiomNum) {
		// All generated MUPS share the same subclass axiom.
		OWLClass oc2 = generateNewClass();		
		this.addDisjointAxiom(oc1, oc2);
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc2);
			System.out.println();
			return;
		}		
		
		OWLClass subOc = null;
		OWLClass supOc = oc2;
		for(int i=0; i< axiomNum-3; i++) {
			subOc = generateNewClass();
			this.addSubclassOfAxiom(subOc, supOc);
			supOc = subOc;
		}
		this.addSubclassOfAxiom(uc, supOc);
		System.out.println();
	}
	
	/**
	 * Generate one MUPS with the given disjointness relation between oc1 and oc2
	 * @param oc1
	 * @param oc2
	 * @param axiomNum
	 */
	private void generateOneMUPSContainDisjAxiom(OWLClass oc1, OWLClass oc2, int axiomNum) {
		OWLClass uc = generateNewClass();
		this.addSubclassOfAxiom(uc, oc1);
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc2);
			System.out.println();
			return;
		}		
		
		OWLClass subOc = null;
		OWLClass supOc = oc2;
		for(int i=0; i< axiomNum-3; i++) {
			subOc = generateNewClass();
			this.addSubclassOfAxiom(subOc, supOc);
			supOc = subOc;
		}
		this.addSubclassOfAxiom(uc, supOc);
		System.out.println();
	}
	

	

	private OWLClass generateNewClass() {
		String classIRI = "http://njupt.edu.cn#concept-"+(classCounter++);
		System.out.println("new class : "+classIRI);
		return manager.getOWLDataFactory().getOWLClass(IRI.create(classIRI));
	}
	
	private void addSubclassOfAxiom(OWLClass subC, OWLClass supC) {
		OWLAxiom ax = manager.getOWLDataFactory().getOWLSubClassOfAxiom(subC, supC);
		manager.addAxiom(onto, ax);
		System.out.println(ax.toString());
	}
	
	private void addDisjointAxiom(OWLClass oc1, OWLClass oc2) {
		OWLAxiom ax = manager.getOWLDataFactory().getOWLDisjointClassesAxiom(oc1, oc2);
		manager.addAxiom(onto, ax);
		System.out.println(ax.toString());
	}
}
