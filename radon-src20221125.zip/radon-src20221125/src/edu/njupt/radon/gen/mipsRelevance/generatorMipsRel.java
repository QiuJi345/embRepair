package edu.njupt.radon.gen.mipsRelevance;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.repair.RepairWithScore;
import edu.njupt.radon.repair.ilp.RepairParameters;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.inco.MUPSUtils;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class generatorMipsRel {

	public static void main(String[] args) throws Exception {
/*		int mupsNum = RepairParameters.mupsNum;
		int mupsSize = RepairParameters.axiomNum;
		int cardiMin = RepairParameters.cardiMin;*/
		
		int mupsNum = 50;  // 20, 30, 40, 50
		int mupsSize = 5;
		// 需要cardiMin <= mupsNum
		int cardiMin = 12;  // 12, 14, 16
		RepairParameters.expType = RepairParameters.T_Pattern2;
		String newOntoPath = "newOnto/CreatorWithMipsRelevance/mipsRel-UC"+
				mupsNum+"-minR"+cardiMin+".owl";
		
		OWLOntology o = OWLTools.createOntology();
		
		if(RepairParameters.expType.equals(RepairParameters.T_Pattern1)){
			Pattern1IsolatedMips gen = new Pattern1IsolatedMips(o, OWLTools.manager);
			gen.generateMUPS(cardiMin, mupsSize);
			
		} else if(RepairParameters.expType.equals(RepairParameters.T_Pattern2)) {
			Pattern2Share1Axiom gen = new Pattern2Share1Axiom();
			HashSet<OWLAxiom> axioms = gen.generateMUPS(mupsNum, mupsSize, cardiMin);
			OWLTools.manager.addAxioms(o, axioms);
			
		} else if(RepairParameters.expType.equals(RepairParameters.T_Pattern3)) {
			Pattern3Share1or2Axioms gen = new Pattern3Share1or2Axioms(o, OWLTools.manager);
			gen.generateMUPS(mupsNum, mupsSize, cardiMin);
			
		} else if(RepairParameters.expType.equals(RepairParameters.T_Pattern4)) {
			Pattern4Share1or2AxiomsComplex gen = new Pattern4Share1or2AxiomsComplex(o, OWLTools.manager);
			gen.generateMUPS(mupsNum, mupsSize, cardiMin);
		}
		
		File f  = new File(newOntoPath);
		OWLTools.manager.saveOntology(o, IRI.create(f.toURI()));
		
        // Test the correctness of this data generation method
		RadonDebug debug = new BlackboxDebug(o);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
		//MUPSUtils.printAllMUPS(mups);
		
		HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(mups);
		System.out.println("******************** mips : ");
		CommonTools.printMultiSets(mips, null);
		HashSet<HashSet<OWLAxiom>> diags = RepairWithScore.getHighScores(mips);
		System.out.println("******************** diagnosis : ");
		CommonTools.printMultiSets(diags, null);
		
		System.out.println("******************** minimal diagnosis : ");
		HashSet<OWLAxiom> minHS = RepairWithScore.getOneDiagnoseByHST(diags);
		CommonTools.printOneSet(minHS, null);
	}
	

}
