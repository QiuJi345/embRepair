package edu.njupt.radon.gen.mipsRelevance;

import java.util.HashSet;
import java.util.Random;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.gen.InjectIncoHybrid;

public class Pattern2Share1Axiom {
	
	HashSet<OWLAxiom> addedAxioms;
	HashSet<OWLClass> rootUCs;
		
	int classCounter = 1;
	
	
	public Pattern2Share1Axiom() {
		addedAxioms = new HashSet<OWLAxiom>();
		rootUCs = new HashSet<OWLClass>();
	}
		

	public HashSet<OWLAxiom> generateMUPS(int allMUPSNum, int axiomNum, int cardiMin) {
		int mupsNum1 = (int)(allMUPSNum / cardiMin);
		int times = cardiMin -1;
		int mupsNum2 = allMUPSNum - mupsNum1*times;
		for(int i=0; i<times; i++){			
			generateMUPSShareOneAxiom(mupsNum1, axiomNum);
		}
		generateMUPSShareOneAxiom(mupsNum2, axiomNum);
		return this.addedAxioms;
	}
	
		
	public void generateMUPSCardi2R46(int allMUPSNum, int axiomNum) throws Exception {
		int mupsNum1 = (int)(allMUPSNum * 0.4);
		int mupsNum2 = allMUPSNum - mupsNum1;
		generateMUPSShareOneAxiom(mupsNum1, axiomNum);
		generateMUPSShareOneAxiom(mupsNum2, axiomNum);
	}
	
	private void generateMUPSShareOneAxiom(int mupsNum, int axiomNum)  {
		// All generated MUPS share the same disjointness axiom.
		OWLClass oc1 = generateNewClass();
		OWLClass oc2 = generateNewClass();		
		this.addDisjointAxiom(oc1, oc2);
		Random r = new Random();
		OWLClass uc = null;
		int size = 0;
		for(int i = 0; i < mupsNum; i++) {
			//System.out.println("Generate new mups ["+i+"]");
			// 产生一个[3,maxMUPSSize]的随机整数，作为新生MUPS的size
			size = r.nextInt(axiomNum-3)+3;
			//System.out.println("mups size (random): "+size);
			uc = this.generateOneMUPS(oc1, oc2, size);			
		}
		InjectIncoHybrid.mipsSizeMap.put(uc, size);
		System.out.println("pattern2: uc= "+uc.getIRI().toString()+", size = "+size);
		System.out.println("   disj: "+oc1.getIRI().toString()+", oc2 = "+oc2.getIRI().toString());
	}
	
	
	private OWLClass generateOneMUPS(OWLClass oc1, OWLClass oc2, int axiomNum) {
		OWLClass uc = generateNewClass("patternUC");
		this.rootUCs.add(uc);
		
		this.addSubclassOfAxiom(uc, oc1);
		if(axiomNum <= 3) {
			this.addSubclassOfAxiom(uc, oc2);
			//System.out.println();
			return uc;
		}		
		
		OWLClass subOc = null;
		OWLClass supOc = oc2;
		for(int i=0; i< axiomNum-3; i++) {
			subOc = generateNewClass();
			this.addSubclassOfAxiom(subOc, supOc);
			supOc = subOc;
		}
		this.addSubclassOfAxiom(uc, supOc);
		//System.out.println();
		return uc;
	}	
	

	private OWLClass generateNewClass() {
		String classIRI = "http://njupt.edu.cn#concept-"+(classCounter++);
		//System.out.println("new class : "+classIRI);
		return OWL.factory.getOWLClass(IRI.create(classIRI));
	}
	
	private OWLClass generateNewClass(String prefix) {
		String classIRI = "http://njupt.edu.cn#"+prefix+"-"+(classCounter++);
		//System.out.println("new class : "+classIRI);
		return OWL.factory.getOWLClass(IRI.create(classIRI));
	}
	
	private void addSubclassOfAxiom(OWLClass subC, OWLClass supC) {
		OWLAxiom ax = OWL.factory.getOWLSubClassOfAxiom(subC, supC);
		this.addedAxioms.add(ax);
		//System.out.println(ax.toString());
	}
	
	private void addDisjointAxiom(OWLClass oc1, OWLClass oc2) {
		OWLAxiom ax = OWL.factory.getOWLDisjointClassesAxiom(oc1, oc2);
		this.addedAxioms.add(ax);
		//System.out.println(ax.toString());
	}
	
	public HashSet<OWLClass> getRootUcs(){
		return this.rootUCs;
	}

}
