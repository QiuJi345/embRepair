package edu.njupt.radon.gen.patterns;

import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.reasoning.ReasoningTask;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class MUPSPatternThing {
	
	HashSet<OWLClass> topConcepts = new HashSet<OWLClass>();
	HashSet<OWLClass> bottomConcepts = new HashSet<OWLClass>();
	
	public static void main(String[] args) throws Exception {
		String ontPath = "file:onto/CHEM-A.owl";
		
		OWLOntology ont = OWL.manager.loadOntology(IRI.create(ontPath));
		MUPSPatternThing main = new MUPSPatternThing(ont, OWL.manager);
		
	}
	

	public MUPSPatternThing(OWLOntology onto, OWLOntologyManager manager) {
		init(onto, manager);
	}
	
	public void init(OWLOntology onto, OWLOntologyManager manager) {		
		
		ReasoningTask task = new ReasoningTask(onto, manager);	
		OWLDataFactory factory = manager.getOWLDataFactory();
		int i = 0;
		for(OWLClass oc : onto.getClassesInSignature()){
			/*i++;
			if(i<=59) {
				continue;
			}*/
			//System.out.println("class ["+(i)+"]: "+oc.getIRI().toString());
        	if(oc.equals(factory.getOWLNothing())||
        			oc.equals(factory.getOWLThing())){
        		continue;
        	}   	
        	
        	boolean f = task.isSatisfiable(oc);
        	//System.out.println(" is satisfiable: "+f);        	
			if(!f){
				bottomConcepts.add(oc);
				System.out.println(" unsatisfiable: "+oc.getIRI().toString());  
			} else {
				OWLAxiom ent = factory.getOWLEquivalentClassesAxiom(oc, factory.getOWLThing());
				if(task.isEntailed(ent)) {
					topConcepts.add(oc);
					System.out.println(" thing: "+oc.getIRI().toString());  
				}
			}
		}			
	}
}
