package edu.njupt.radon.gen;

/**
 * 这个方法不用于研发投稿的实验中
 */
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.semanticweb.owlapi.model.AxiomType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectUnionOf;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.ComputeHierarchy;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * 这个类本意是想保持本体规模和MIPS不变，可以生成用户指定数量的不可满足概念
 * （实现上还是有问题）
 * @author QiuJi
 *
 */
public class InjectUCsWithOnto {

	private int opCounter = 0;

	OWLOntology onto;
	//ArrayList<OWLClass> concepts;
	ArrayList<OWLClass> unconcepts;
	ArrayList<OWLObjectProperty> objectproperties;

	public static void main(String[] args) throws Exception {
		String injectMethod = "InjectUCsWithOnto";
		// type的可选类型有: "intersection","existing", "union" and "random".
		// By default (i.e. type="random"), randomly choose a type for each new axiom.
		String type = "random";
		// 生成UC的数量（也是修改已有公理的数量）
		int injectUCNum = 20;
		String ontoName = "proton";
		String ontoPath = "file:onto/"+ontoName+".owl";
		String newOntoPath = "newOnto/" + injectMethod + "/" + ontoName + "-"+ type;

		OWLOntology onto = OWL.manager.loadOntology(IRI.create(ontoPath));
		System.out.println("ConceptNum " + onto.getClassesInSignature().size());
		//MyPrinter.printAxioms(new HashSet<OWLAxiom>(onto.getLogicalAxioms()));
		
		
		Long tic2 = System.currentTimeMillis();
		
		if (injectUCNum <= 0) {
			System.out.println("The number of injected Axioms cannot be negative!");
		} else {
			InjectUCsWithOnto injectAxioms = new InjectUCsWithOnto(onto);
			HashSet<OWLAxiom> allAxioms = injectAxioms.generateUCs(injectUCNum, type);
			Long toc2 = System.currentTimeMillis();
			System.out.println("The consumption of injecting time is " + (toc2 - tic2) + " ms");
			
			OWLOntology newOnt = OWL.manager.createOntology(allAxioms);
			System.out.println(" ______________ main_______________ " );
			HashSet<OWLClass> ucs3 = ReasoningTools.getUnsatiConcepts(newOnt);
			System.out.println(" allAxioms " + allAxioms.size());
			System.out.println("The number of current UCs is " + ucs3.size());
			// save the new ontology
			newOntoPath += "-UC"+ ucs3.size() + ".owl";
			File f = new File(newOntoPath);
			OWL.manager.saveOntology(newOnt, IRI.create(f.toURI()));
			//MyPrinter.printAxioms(allAxioms);
		}
				
	}

	public InjectUCsWithOnto(OWLOntology onto) {
		this.onto = onto;
		objectproperties = new ArrayList<>(onto.getObjectPropertiesInSignature());
		unconcepts = new ArrayList<>(ReasoningTools.getUnsatiConcepts(onto));
		
		System.out.println("The number of original UCs is " + unconcepts.size());
	}

	public HashSet<OWLAxiom> generateUCs(int injectNum, String type) {

		HashSet<OWLAxiom> finalAxioms = new HashSet<>(onto.getLogicalAxioms());		
		boolean flag = false;
		ComputeHierarchy com = new ComputeHierarchy();
		HashSet<OWLClass> leaves = com.getLeafConcepts(onto);
		HashSet<OWLClass> nonleaves = new HashSet<>(onto.getClassesInSignature());
		nonleaves.removeAll(leaves);
		nonleaves.removeAll(unconcepts);
		leaves.removeAll(this.unconcepts);
		System.out.println(" leaves: "+leaves.size());
		System.out.println(" nonleaves: "+nonleaves.size());
		System.out.println(" ucs: "+this.unconcepts.size());
		
		while(nonleaves.size()>0) {
			OWLClass subC = nonleaves.iterator().next();
			nonleaves.remove(subC);
			Set<OWLSubClassOfAxiom> subAxioms = onto.getSubClassAxiomsForSubClass(subC);
			if(subAxioms.isEmpty()) {
				System.out.println("  has no super class definition! ");
				continue;
			}
			
			OWLSubClassOfAxiom oriAxiom = subAxioms.iterator().next();
			OWLClassExpression supOce = oriAxiom.getSuperClass();
			OWLAxiom ax = this.generateAxiom(subC, supOce, type);
			System.out.println("    modified:  " + ax.toString());
			
			finalAxioms.remove(oriAxiom);
			finalAxioms.add(ax);			
			HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(finalAxioms);
			System.out.println(" allAxioms " + finalAxioms.size());
			System.out.println("The number of current UCs is " + ucs.size());
			if(ucs.size() > injectNum) {
				//withdraw adding the new modified axiom
				finalAxioms.add(oriAxiom);
				finalAxioms.remove(ax);
				break;
			} else {
				this.unconcepts.addAll(ucs);
				nonleaves.removeAll(ucs);
				leaves.removeAll(ucs);
				if(unconcepts.size() == injectNum) {
					flag = true;
					break;	
				} 
			}
		}
		
		
		// Add ucs slowly using leave concepts
		while(!flag && leaves.size() > 0) {
			OWLClass subC2 = leaves.iterator().next();
			leaves.remove(subC2);
			Set<OWLSubClassOfAxiom> subAxioms2 = onto.getSubClassAxiomsForSubClass(subC2);
			if(subAxioms2.isEmpty()) {
				continue;
			}
			
			OWLSubClassOfAxiom oriAxiom2 = subAxioms2.iterator().next();
			OWLClassExpression supOce2 = oriAxiom2.getSuperClass();
			OWLAxiom ax2 = this.generateAxiom(subC2, supOce2, type);
			System.out.println("    modified:  " + ax2.toString());
			
			finalAxioms.remove(oriAxiom2);
			finalAxioms.add(ax2);			
			HashSet<OWLClass> ucs2 = ReasoningTools.getUnsatiConcepts(finalAxioms);
			this.unconcepts.addAll(ucs2);
			System.out.println("    allAxioms " + finalAxioms.size());
			System.out.println("    slow UCs: " + ucs2.size());
			if(ucs2.size() >= injectNum) {
				flag = true;
				break;
			}
			leaves.removeAll(ucs2);
		}
		
		/*for(OWLClass subC : leaves) {
			Set<OWLSubClassOfAxiom> subAxioms = onto.getSubClassAxiomsForSubClass(subC);
			if(subAxioms.isEmpty()) {
				continue;
			}
			
			OWLSubClassOfAxiom oriAxiom = subAxioms.iterator().next();
			OWLClassExpression supOce = oriAxiom.getSuperClass();
			OWLAxiom ax = this.generateAxiom(subC, supOce, type);
			System.out.println("    modified:  " + ax.toString());
			finalAxioms.remove(oriAxiom);
			finalAxioms.add(ax);
			this.unconcepts.add(subC);
			
			HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(finalAxioms);
			System.out.println(" allAxioms " + finalAxioms.size());
			System.out.println("The number of current UCs is " + ucs.size());
			
			// If the number of UCs is reached (each newAxiom corresponds a new UC), then break.
			if (ucs.size() >= injectNum) {				
				flag = true;
				break;			
			}
		}*/
		/*for(OWLSubClassOfAxiom subAxiom : onto.getAxioms(AxiomType.SUBCLASS_OF)) {
			OWLClassExpression subOce = subAxiom.getSubClass();
			OWLClassExpression supOce = subAxiom.getSuperClass();
			if(subOce.isAnonymous()) {
				continue;
			}
			OWLClass subC = subOce.asOWLClass();
			if(this.unconcepts.contains(subC) || !leaves.contains(subC)) {
				continue;
			}
			//System.out.println("original axiom:  " + subAxiom.toString());
			// We modify a subsumption relation with an atomic concept as sub-concept.
			OWLAxiom ax = this.generateAxiom(subC, supOce, type);
			System.out.println("    modified:  " + ax.toString());
			finalAxioms.remove(subAxiom);
			finalAxioms.add(ax);
			this.unconcepts.add(subC);
			
			HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(finalAxioms);
			System.out.println(" allAxioms " + finalAxioms.size());
			System.out.println("The number of current UCs is " + ucs.size());
			
			// If the number of UCs is reached (each newAxiom corresponds a new UC), then break.
			if (ucs.size() >= injectNum) {
				
				flag = true;
				break;			
			}
		}*/
		//System.out.println(" new axioms: "+newAxioms.size());
		//System.out.println(" modified axioms: "+modifiedAxioms.size());
		//finalAxioms.removeAll(modifiedAxioms);
		//finalAxioms.addAll(newAxioms);
		//System.out.println(" finalAxioms axioms: "+finalAxioms.size());
		
		if (flag) {			
			System.out.println("\nThe number of injected Axioms by ComplexInjector is completed.");
		} else {
			System.out.println("\nThe injected Axioms by ComplexInjector is completed, but it is not enough.");
		}
		//System.out.println("The number of new axioms is " + newAxioms.size());
		return finalAxioms;
	}


	private OWLAxiom generateAxiom(OWLClass subC, OWLClassExpression supOce, String type) {
		OWLAxiom a = null;
		if(type.equals("intersection")) {
			a = this.generateAxiomIntersectionRandomly(subC, supOce);
		} else if(type.equals("union")) {
			a = this.generateAxiomUnionRandomly(subC, supOce);
		} else if(type.equals("existing")) {
			a = this.generateAxiomExistentialRandomly(subC, supOce);
		} else {
			a = this.generateAxiomRandomly(subC, supOce);
		}
		return a;
	}
	
	private OWLAxiom generateAxiomRandomly(OWLClass subC, OWLClassExpression supOce) {		
		OWLAxiom a = null;
		Random random = new Random();
		int randomIndex = random.nextInt(3);
		if(randomIndex == 0) {
			a = this.generateAxiomExistentialRandomly(subC, supOce);
		} else if(randomIndex == 1) {
			a = this.generateAxiomIntersectionRandomly(subC, supOce);
		} else {
			a = this.generateAxiomUnionRandomly(subC, supOce);
		}
		return a;
	}
	
	private OWLAxiom generateAxiomUnionRandomly(OWLClass subC, OWLClassExpression supOce) {			
		OWLClass uc1 = this.getRandomClass(this.unconcepts);	
		ArrayList<OWLClass> tempUcs = new ArrayList<OWLClass>(this.unconcepts);
		tempUcs.remove(uc1);
		OWLClass uc2 = this.getRandomClass(tempUcs);
		OWLAxiom a = generateAxiomUnion(subC, supOce, uc1, uc2);
		return a;
	}
	
	private OWLAxiom generateAxiomUnion(OWLClass subC, OWLClassExpression supOce, OWLClass uc1, OWLClass uc2) {		
		OWLObjectUnionOf oce = OWL.factory.getOWLObjectUnionOf(uc1, uc2);
		OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(subC, OWL.factory.getOWLObjectIntersectionOf(supOce, oce));
		return a;
	}
	
	private OWLAxiom generateAxiomExistentialRandomly(OWLClass subC, OWLClassExpression supOce) {
		OWLObjectProperty op = this.getRandomObjectProperty();
		OWLClass uc = this.getRandomClass(this.unconcepts);		
		OWLAxiom a = this.generateAxiomExistential(subC, supOce, uc, op);
		return a;
	}
	
	private OWLAxiom generateAxiomExistential(OWLClass subC, OWLClassExpression supOce, OWLClass uc, OWLObjectProperty op) {		
		OWLObjectSomeValuesFrom b = OWL.factory.getOWLObjectSomeValuesFrom(op, uc);
		OWLObjectIntersectionOf oce = OWL.factory.getOWLObjectIntersectionOf(supOce, b); 
		OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(subC, oce);
		return a;
	}
	
	private OWLAxiom generateAxiomIntersectionRandomly(OWLClass subC, OWLClassExpression supOce) {
		OWLClass uc = this.getRandomClass(this.unconcepts);		
		OWLAxiom a = this.generateAxiomIntersection(subC, supOce, uc);
		return a;
	}	
	
	private OWLAxiom generateAxiomIntersection(OWLClass subC, OWLClassExpression supOce, OWLClass uc) {		
		OWLObjectIntersectionOf oce = OWL.factory.getOWLObjectIntersectionOf(supOce, uc); 
		OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(subC, oce);
		return a;
	}
		
	private OWLClass getRandomClass(ArrayList<OWLClass> ocs) {
		Random random = new Random();
		int randomSupConceptNum = random.nextInt(ocs.size());
		OWLClass oc = ocs.get(randomSupConceptNum);
		return oc;
	}
	
	private OWLObjectProperty getRandomObjectProperty() {
		OWLObjectProperty op = null;
		if(this.objectproperties.size() <= 0) {
			op = this.generateObjectProperty();
		} else {
			Random random = new Random();
			ArrayList<OWLObjectProperty> ops = new ArrayList<>(this.objectproperties);
			int randomSupConceptNum = random.nextInt(ops.size());
			op = ops.get(randomSupConceptNum);
		}
		return op;
	}

	
	private OWLObjectProperty generateObjectProperty() {
		// The naming method avoids duplicate names
		String opIRI = "http://www.njupt.edu.cn#objectproperty-"+(System.currentTimeMillis()+(opCounter ++));
		return OWL.factory.getOWLObjectProperty(IRI.create(opIRI));
	}
}
