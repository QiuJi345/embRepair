package edu.njupt.radon.tolerant;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class IncoherenceTolarent {
	
	int pruneWindow = 5;
	
	public HashSet<OWLAxiom> getCardiMaxCoherentSubset(
			HashSet<OWLAxiom> tbox) throws Exception {

		if(ReasoningTools.isCoherent(tbox)){
			return null;
		}
		
		
		// Try to find a maximal consistent subontology
		HashSet<OWLAxiom> currentAxioms = this.getMaxCoherentSubset(tbox);

		/*
		 * If the cardinality is greater than 0 and smaller than the size of
		 * the original ontology, we try to find all cardinality-maximal
		 * subontologies.
		 */		
		int cardinality = currentAxioms.size();
		int begin = cardinality;
		int end = tbox.size();
		int middle = 0;

		while (begin < end) {
			int temp = (end + begin) % 2;
			if (temp == 0) {
				middle = (end + begin) / 2;
			} else {
				middle = (end + begin) / 2 + 1;
			}

			HashSet<HashSet<OWLAxiom>> cardiSubsets = CommonTools.getCardiSubSets(
					new HashSet<OWLAxiom>(), tbox, middle);
			boolean existConsistentSubonto = false;
			for (HashSet<OWLAxiom> cardiSubset : cardiSubsets) {
				boolean isConsistent = ReasoningTools.isCoherent(cardiSubset);
				if (isConsistent) {
					existConsistentSubonto = true;					
					break;
				}
			}

			if (!existConsistentSubonto) {
				if ((end - begin)==1) {
					break;
				} else {
					end = middle;
				}				
			} else {
				begin = middle;
			}			
		}
		
		//Compute one consistent subset with a given cardinality
		HashSet<OWLAxiom> cardiMaxSubset = null;
		cardinality = begin;
		if(cardinality == tbox.size()){
			cardiMaxSubset = new HashSet<OWLAxiom>(tbox);
		} else {
			HashSet<HashSet<OWLAxiom>> subsets = CommonTools.getCardiSubSets(
					new HashSet<OWLAxiom>(), tbox, cardinality);
			
			for(HashSet<OWLAxiom> subset : subsets){
				if(ReasoningTools.isCoherent(subset)){
					cardiMaxSubset = new HashSet<OWLAxiom>(subset);
					break;
				}
			}
		}	

		return cardiMaxSubset;
	}

	public HashSet<OWLAxiom> getMaxCoherentSubset(
			HashSet<OWLAxiom> tbox) throws Exception {
		//fast prune
		HashSet<OWLAxiom> slowPruneAxioms = this.fastPrune(new HashSet<OWLAxiom>(), 
				new Vector<OWLAxiom>(tbox));
		//slow prune
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(tbox);
		axioms.removeAll(slowPruneAxioms);
		for (OWLAxiom axiom : slowPruneAxioms) {
			axioms.add(axiom);
			if (!ReasoningTools.isCoherent(axioms)) {
				axioms.remove(axiom);
			}
		}		
		return axioms;
	}
	
	private HashSet<OWLAxiom> fastPrune(
			HashSet<OWLAxiom> unchangedAxioms, 
			Vector<OWLAxiom> toBePrunedAxioms) throws Exception {		
		
		HashSet<OWLAxiom> currentAxioms = new HashSet<OWLAxiom>(unchangedAxioms);
		HashSet<OWLAxiom> slowPruneAxioms = new HashSet<OWLAxiom>();
		int size = toBePrunedAxioms.size();
		//System.out.println(OWLTools.isCoherent(new HashSet<OWLAxiom>(prunedOWLAxioms),oc));
		if(size>pruneWindow){
			int parts = size / pruneWindow;
			for (int part = 0; part < parts; part++) {
				for (int i = part * pruneWindow; i < part * pruneWindow
						+ pruneWindow; i++) {
					currentAxioms.add(toBePrunedAxioms.get(i));
				}					
				
				if (!ReasoningTools.isCoherent(currentAxioms)) {					//System.out.println("Fast prune OWLAxioms");
					for (int i = part * pruneWindow; i < part * pruneWindow
							+ pruneWindow; i++) {
						slowPruneAxioms.add(toBePrunedAxioms.get(i));
						currentAxioms.remove(toBePrunedAxioms.get(i));
						//System.out.println(i+" > "+allRelated.get(i).toString().replace(ns, ""));
					}
				}
			}
			if (size > parts * pruneWindow) {
				// add remaining from list to OWLAxioms
				for (int i = parts * pruneWindow; i < size; i++) {
					slowPruneAxioms.add(toBePrunedAxioms.get(i));
				}
			}
		}
		return slowPruneAxioms;
	}
}
