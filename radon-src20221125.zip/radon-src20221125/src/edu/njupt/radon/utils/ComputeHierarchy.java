package edu.njupt.radon.utils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

public class ComputeHierarchy {
	
	private HashMap<OWLClass, HashSet<OWLClass>> classHierarchy = 
			new HashMap<OWLClass, HashSet<OWLClass>>();
	
	public HashSet<OWLClass> getLeafConcepts(OWLOntology onto) {
		this.computeHierarchy(onto);
		HashSet<OWLClass> values = new HashSet<>();
		for(OWLClass key : classHierarchy.keySet()) {
			values.addAll(classHierarchy.get(key));
		}
		HashSet<OWLClass> ocs = new HashSet<>(onto.getClassesInSignature());
		HashSet<OWLClass> leaves = new HashSet<>();
		for(OWLClass oc : ocs) {
			if(values.contains(oc)) {
				continue;
			}
			leaves.add(oc);
		}
		return leaves;
	}
	/**
	 * Obtain the subsumptions between any two atomic concepts.
	 * 
	 * @param onto
	 */
	public HashMap<OWLClass, HashSet<OWLClass>> computeHierarchy(OWLOntology onto){	
		HashSet<OWLAxiom> axiomsInOnto = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		HashSet<OWLAxiom> refinedAxioms = this.refineAxioms(axiomsInOnto);
		for(OWLAxiom a : refinedAxioms){			
			if(!(a instanceof OWLSubClassOfAxiom)){
				continue;
			}
			OWLSubClassOfAxiom subA = (OWLSubClassOfAxiom)a;
			OWLClassExpression subC = subA.getSubClass();
			OWLClassExpression supC = subA.getSuperClass();				
			// Check whether the signatures are all atomic.
			if(!subC.isAnonymous() && !supC.isAnonymous()){						
				addSubRelation(subC.asOWLClass(), supC.asOWLClass());					
			}
		}
		return classHierarchy;
	}
	
	/**
	 * Transfer A subclassof B intersectionOf C to A subclassof B and A subclassof C.
	 * @param axiomsInOnto
	 * @return
	 */
	private HashSet<OWLAxiom> refineAxioms(HashSet<OWLAxiom> axiomsInOnto){	
		HashSet<OWLAxiom> refinedAxioms = new HashSet<OWLAxiom>();
		for(OWLAxiom a : axiomsInOnto){						
			OWLClassExpression subC = null;
			OWLClassExpression supC = null;
			boolean isIntersectionOf = false;
			// Check whether there is a class expression defined with intersectionOf
			if(a instanceof OWLSubClassOfAxiom){				
				OWLSubClassOfAxiom axiom = (OWLSubClassOfAxiom)a;
				subC = axiom.getSubClass();
				supC = axiom.getSuperClass();
				if(supC instanceof OWLObjectIntersectionOf){
					isIntersectionOf = true;
				} 		
			} else if(a instanceof OWLEquivalentClassesAxiom){
				OWLEquivalentClassesAxiom axiom = (OWLEquivalentClassesAxiom)a;
				Vector<OWLClassExpression> oces = new Vector<OWLClassExpression>(axiom.getClassExpressions());
				OWLClassExpression oc1 = oces.get(0);
				OWLClassExpression oc2 = oces.get(1);	
								
				if(oc1 instanceof OWLObjectIntersectionOf){
					isIntersectionOf = true;
					subC = oc2;
					supC = oc1;
				} else if(oc2 instanceof OWLObjectIntersectionOf){
					isIntersectionOf = true;
					subC = oc1;
					supC = oc2;
				} 						
			} 
			
			// If there is a class expression defined with intersectionOf,
			// then separate the original axiom into its sub-axioms.
			if(isIntersectionOf){							
				OWLObjectIntersectionOf interC = (OWLObjectIntersectionOf)supC;
				for(OWLClassExpression oce : interC.getOperands()){
					OWLAxiom newAxiom = OWL.subClassOf(subC, oce);
					refinedAxioms.add(newAxiom);
				}				
			} else {
				refinedAxioms.add(a);
			}
		}
		return refinedAxioms;
	}
	
	
	
	private void addSubRelation(OWLClass subC, OWLClass supC){
		if(classHierarchy.containsKey(subC)){
			classHierarchy.get(subC).add(supC);
		} else {
			HashSet<OWLClass> superClasses = new HashSet<OWLClass>();
			superClasses.add(supC);
			classHierarchy.put(subC, superClasses);
		}
	}

}
