package edu.njupt.radon.utils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;

/**
 * TODO This class is to stratify the correspondences into different subsets 
 * according to the similarity values associated with each correspondence. 
 * That is, for those correspondences with the same/similar similarities, 
 * they should belong to the same subset.
 * 
 * @author Qiu Ji
 * 24.01.2008
 */
public class StratifyByWeights {
	
	public static void main(String[] args){
		Double[] sims = {0.001, 0.01, 0.002, 0.005, 0.02, 0.3};
		Vector<Double> newSims = new Vector<Double>();
		double preSim = -1;
		double error = 0.005;
		boolean changed = false;
		System.out.println(sims);
		
		for(Double sim : sims){
			double value = (double)((Math.round(sim*100))/100.00);
			System.out.println("value: "+value);
		}	
		System.out.println("new: "+newSims);
	}
	
	public static HashMap<Double, HashSet<OWLAxiom>> stratify(
			HashMap<Double, HashSet<OWLAxiom>> layers){
		return stratify(layers, 0.0);
	}
	
	public static HashMap<Double, HashSet<OWLAxiom>> stratify(
			HashMap<Double, HashSet<OWLAxiom>> layers,
			Double error){
		
		HashMap<Double, HashSet<OWLAxiom>> newLayers = new HashMap<Double, HashSet<OWLAxiom>>();
		/*HashSet<OWLAxiom> oneLayer = new HashSet<OWLAxiom>();
		double preSim = -1;
		boolean changed = false;*/
		
		if(error<=0){
			return layers;
		}
		for(Double sim : layers.keySet()){
			double value = (double)((Math.round(sim*100))/100.00);
			if(newLayers.containsKey(value)){
				newLayers.get(value).addAll(layers.get(sim));
			} else {
				newLayers.put(value, new HashSet<OWLAxiom>(layers.get(sim)));
			}
			/*if(preSim == -1){ //For the first round
				preSim = sim;				
			}			
			if(java.lang.Math.abs(preSim-sim) > error){
				changed = true;
			}
			if(changed){ 
				newLayers.put(preSim, new HashSet<OWLAxiom>(oneLayer));
				oneLayer.clear();
				changed = false;
				preSim = sim;	
			} 
			oneLayer.addAll(layers.get(sim));	*/
		}		
		return newLayers;
	}
	
	

	public static HashMap<Double, HashSet<OWLAxiom>> getLayers(
			HashMap<OWLAxiom,Double> weights){
		
		HashMap<Double, HashSet<OWLAxiom>> weightOWLAxioms = 
			new HashMap<Double, HashSet<OWLAxiom>>();
		for(OWLAxiom a : weights.keySet()){
			Double d = weights.get(a);
			if(weightOWLAxioms.containsKey(d)){
				weightOWLAxioms.get(d).add(a);
			} else {
				HashSet<OWLAxiom> ax = new HashSet<OWLAxiom>();
				ax.add(a);
				weightOWLAxioms.put(d, ax);
			}
		}
		return weightOWLAxioms;
	}
	
	public static HashMap<OWLAxiom,Double> getLayersRound(
			HashMap<OWLAxiom,Double> weights){
		
		HashMap<OWLAxiom,Double> newWeights = new HashMap<OWLAxiom,Double>();
		for(OWLAxiom a : weights.keySet()){
			Double d = weights.get(a);
			int b = (int)Math.round(d * 10);
			Double c = (double)b / 10.00;
			newWeights.put(a, c);
		}
		return newWeights;
	}

	public static void printLayers(HashMap<Double,HashSet<OWLAxiom>> layers,
			Vector<Double> sortedWeights){
		//test
		int i = 0;
		for(Double d : sortedWeights){
			System.out.println("layer_"+(i++)+", w = "+d);
			for(OWLAxiom a : layers.get(d)){
				System.out.println("   "+a);
			}
		}	
	}

}
