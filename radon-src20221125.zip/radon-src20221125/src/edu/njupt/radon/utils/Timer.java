
package edu.njupt.radon.utils;

/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 22.09.2007
 */
public class Timer {
	
	long start = -1;
	long end = -1;
	long total = 0;
	String type = null;
	int count = 0;
	
	public Timer(){
		count = 0;
		total = 0;
	}
	
	public void start(){
		start = System.currentTimeMillis();
	}
	
	public void stop(){
		end = System.currentTimeMillis();
		count++;
		total += (end - start);
		//System.out.println("end-start= "+(end-start)+" , total = "+total);
		start = -1;
		end = -1;	
	}
	
	public long getLastTestTime(){
		long t = end-start;
		return t;
	}
	
	public int getCount(){
		return count;
	}
	
	public long getTotal(){
		return total;
	}

	public boolean isStarted(){
		if(start!=-1)
			return true;
		else 
			return false;
	}
	
	public boolean isStopped(){
		if(end==-1)
			return true;
		else
			return false;
	}
	
}
