package edu.njupt.radon.utils;

public class ThreadUtils {
	
	public static boolean isInterruptedExceptionAccepted = false;
	
	public static boolean isVisited = false;
	
	public static void receiveInterruptedException () throws InterruptedException {
		isVisited = true;
		if(Thread.currentThread().isInterrupted()){
			isInterruptedExceptionAccepted = true;
			// Give the current thread time to deal with the interrupted request
        	Thread.sleep(1);
        }
	}

}
