package edu.njupt.radon.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.HermiT.Configuration;
import org.semanticweb.HermiT.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.AxiomType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyChange;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.RemoveAxiom;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.util.SimpleIRIMapper;

import com.clarkparsia.modularity.ModularityUtils;
import com.clarkparsia.owlapiv3.OWL;
import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

import edu.njupt.radon.parameters.DebuggingParameters;
import uk.ac.manchester.cs.factplusplus.owlapiv3.FaCTPlusPlusReasonerFactory;
import uk.ac.manchester.cs.jfact.JFactFactory;
import uk.ac.manchester.cs.owlapi.modularity.ModuleType;


/**
 * TODO : 
 *
 * @author Qiu Ji 
 * @date 9 Feb 2007
 */
public class OWLTools {
	
	public static OWLOntologyManager manager = null; 
	//public static OWLOntology onto = null; 
	private static int newontoCounter = 0;
	
    public static OWLReasonerFactory getResonerFactory(String reasoner){
		OWLReasonerFactory reasonerFactory = null; 
		if(reasoner.equalsIgnoreCase(DebuggingParameters.factppReasoner)){
			reasonerFactory = new FaCTPlusPlusReasonerFactory(); 
			//System.out.println("Reasoner : "+DebuggingParameters.factppReasoner);
			
		} else if(reasoner.equalsIgnoreCase(DebuggingParameters.hermitReasoner)){
			//reasonerFactory = new Reasoner.ReasonerFactory();
			reasonerFactory = new Reasoner.ReasonerFactory()  {
	            
	            public OWLReasoner createReasoner(OWLOntology ontology, OWLReasonerConfiguration config) {
	                Configuration configuration = new Configuration();
	                configuration.ignoreUnsupportedDatatypes = true;
	                return super.createReasoner(ontology, configuration);
	            }
	        };
			//System.out.println("Reasoner : "+DebuggingParameters.hermitReasoner);
			
		} else if(reasoner.equalsIgnoreCase(DebuggingParameters.jfactReasoner)){
			reasonerFactory = new JFactFactory(); 
			//System.out.println("Reasoner : "+DebuggingParameters.jfactReasoner);
			
		} else {
			reasonerFactory = new PelletReasonerFactory(); 
			//System.out.println("Reasoner : "+DebuggingParameters.pelletReasoner);
		}
		return reasonerFactory;
    }


	public static Set<OWLAxiom> extractModule(OWLOntology onto, OWLClass concept){
		ModuleType moduleType = ModuleType.BOT;
        HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
        sigs.add(concept);
		// Extract the module axioms for the specified signature
		Set<OWLAxiom> moduleAxioms = ModularityUtils.extractModule( onto, sigs, moduleType );
		// Create an ontology for the module axioms  
		return moduleAxioms;
	}
	
	public static Set<OWLAxiom> extractModule(OWLOntology onto, OWLClass subClass, OWLClass supClass){
		ModuleType moduleType = ModuleType.BOT;
        HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
        sigs.add(subClass);
        sigs.add(supClass);
		// Extract the module axioms for the specified signature
		Set<OWLAxiom> moduleAxioms = ModularityUtils.extractModule( onto, sigs, moduleType );
		// Create an ontology for the module axioms  
		return moduleAxioms;
	}
	
	public static Set<OWLAxiom> extractModule(OWLOntology onto, OWLNamedIndividual indi, OWLClass supClass){
		ModuleType moduleType = ModuleType.BOT;
        HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
        sigs.add(indi);
        sigs.add(supClass);
		// Extract the module axioms for the specified signature
		Set<OWLAxiom> moduleAxioms = ModularityUtils.extractModule( onto, sigs, moduleType );
		// Create an ontology for the module axioms  
		return moduleAxioms;
	}
	
	public static Set<OWLAxiom> extractModule(OWLOntology onto, OWLAxiom axiom){
		ModuleType moduleType = ModuleType.TOP;
        HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
        sigs.addAll(axiom.getSignature());
		// Extract the module axioms for the specified signature
		Set<OWLAxiom> moduleAxioms = ModularityUtils.extractModule( onto, sigs, moduleType );
		// Create an ontology for the module axioms  
		return moduleAxioms;
	}
	
	public static OWLOntologyManager createOntologyManager() {
		if(manager==null){
			manager = OWLManager.createOWLOntologyManager();
		}		
		return manager;
	}
	
	public static OWLClass generateClass(String prefix) {
		// Use current time as prefix of a new entity to avoid duplicate names
		String classIRI = "http://www.njupt.edu.cn#"+prefix+"_"+System.currentTimeMillis();	
		return OWL.factory.getOWLClass(IRI.create(classIRI));
	}
	

	public static OWLObjectProperty generateObjectProperty() {
		// Use current time as prefix of a new entity to avoid duplicate names
		String opIRI = "http://www.njupt.edu.cn#OP"+"_"+System.currentTimeMillis();	
		return OWL.factory.getOWLObjectProperty(IRI.create(opIRI));
	}
	
	public static String getEntityURI(OWLEntity oc){		
		String uri = "";
		String ns = oc.toString();
		if(ns.indexOf("#")!=-1){
			uri = ns.substring(0,ns.indexOf("#"));
		}
		return uri;
	}
	
	
	public static Vector<HashSet<OWLAxiom>> getOrderedSets(HashSet<HashSet<OWLAxiom>> sets){
		Vector<HashSet<OWLAxiom>> orderedSets = new Vector<HashSet<OWLAxiom>>();
		for(HashSet<OWLAxiom> set : sets){
			orderedSets.add(set);
		}
		return orderedSets;
	}
	
	public static OWLAxiom getOWLAxiom(OWLOntology onto, String axiomString){
		OWLAxiom axiom = null;
        String[] words = axiomString.split(" ");
		String ent1Name = words[0];
		String ent2Name = words[2];
		String relation = words[1];
		// Initialize the parameters about the debugged entailment
		if(words[0] == null || words[1] == null || words[2] == null){
			return null;
		}
		if(relation.equals("subClassOf")){
			// Obtain the subclass
			OWLClass subClass = OWLTools.getOWLClass(onto, ent1Name, true);
			// Obtain the superclass
			OWLClass superClass = OWLTools.getOWLClass(onto, ent2Name, true);
			// Set the result path
			if(subClass != null && superClass != null){
				axiom = manager.getOWLDataFactory().getOWLSubClassOfAxiom(subClass, superClass);
			}
			
		} else if(relation.equals("types")){
			// Obtain the subclass
			OWLIndividual indi = OWLTools.getIndividual(onto, ent1Name, true);
			// Obtain the superclass
			OWLClass type = OWLTools.getOWLClass(onto, ent2Name, true);
			// Set the result path
			if(indi != null && type != null){
				axiom = manager.getOWLDataFactory().getOWLClassAssertionAxiom(type, indi);
			}			
		}
		return axiom;
	}
/*	
	public static String getOntologyURI(OWLOntology onto){
		String ns = "";		manager.g
		URI uri = onto.;
		if(uri==null)
			ns = "";
		else if(ns.indexOf("#")==-1)
			ns = ns + "#";
		return ns;
	}*/
	


	
	
    //This method has the same functionality as getEntityURI (qiji)
	public static String getNamespace(OWLEntity ent){
		String ns = null;
		if(ent!=null){
			String ts = ent.toString();
			int index = ts.lastIndexOf("#");
			if(index==-1){
				index = ts.lastIndexOf("/");
				if(index==-1){
					ns = ts;
				} else {
					ns = ts.substring(0,index);
				}
			} else {
				ns = ts.substring(0,index);
			}
		}
		
		return ns;
	}
	
	public static HashSet<OWLEntity> getEntities(OWLAxiom a){
		HashSet<OWLEntity> ents = new HashSet<OWLEntity>(
				a.getSignature());
		return ents;
	}
	
	public static HashSet<OWLEntity> getEntities(HashSet<OWLAxiom> axioms){
		HashSet<OWLEntity> ents = new HashSet<OWLEntity>();
		for(OWLAxiom a : axioms){
			ents.addAll(getEntities(a));
		}

		return ents;
	}
	
	public static HashMap<OWLAxiom, HashSet<OWLEntity>> getAxiomEntityMap(Set<OWLAxiom> axioms){
		HashMap<OWLAxiom, HashSet<OWLEntity>> map = new HashMap<OWLAxiom, HashSet<OWLEntity>>();
		for(OWLAxiom a : axioms){
			HashSet<OWLEntity> ents = getEntities(a);
			if(ents!=null){
				map.put(a, ents);
			}
		}
		return map;
	}
	
	
	
	public static String getLocalName(OWLOntology o){
		String name = null;
		createOntologyManager();
		IRI uri = manager.getOntologyDocumentIRI(o);
		if(uri!=null){
			name = getLocalName(uri.toString());
		}		
		return name;
	}
	
	public static String getFileName(OWLEntity ent){
		String name = ent.getIRI().toString();
		String localName = "";
		int ind1 = name.lastIndexOf("#");
		int ind2 = name.indexOf("http://");
		if(ind1 != -1){
			if(ind2 != -1){
				int length = String.valueOf("http://").length();
				String substring = name.substring(ind2+length, ind1);
				// Check whether a prefix of a local name is needed
				if(substring.indexOf(".")==-1 && substring.indexOf("/")==-1){
					localName = name.substring(ind2+length);
				} else {
					localName = name.substring(ind1+1);
				}
			}
			if(localName.length() == 0){
				localName = name.substring(ind1+1);
			}
		} else {			
			ind1 = name.lastIndexOf("/");
			if(ind1 != -1){
				localName = name.substring(ind1+1);
			} else {
				localName = name;
			}
		}		
		return localName;
	}
	
	public static String getLocalName(OWLEntity ent){
		String name = ent.getIRI().toString();
		String localName = "";
		int ind1 = name.lastIndexOf("#");		
		if(ind1 != -1){
			localName = name.substring(ind1+1);			
		} else {
			ind1 = name.lastIndexOf("/");
			if(ind1 != -1){
				localName = name.substring(ind1+1);
			} else {
				localName = name;
			}
		}		
		return localName;
	}
	
	public static String getOAEIUCName(OWLEntity uc){			
		String ucIRI = uc.getIRI().toString();
		int i = ucIRI.indexOf("http://");
		if(i != -1){
			ucIRI = ucIRI.substring(7);
		}		
		return ucIRI;
	}
	
	public static String getLocalName(String ts){
		String name = ts;
		int index = ts.lastIndexOf("#");
		if(index != -1){
			name = ts.substring(index+1);
		} else {
			int ind1 = ts.lastIndexOf("/");
			if(ind1 != -1){
				name = ts.substring(ind1+1);
			} else {
				ind1 = ts.lastIndexOf(":");
				if(ind1==-1){
					name = ts;
				} else {
					int ind2 = ts.lastIndexOf('.');
					if(ind2>ind1){
						name = ts.substring(ind1+1, ind2);
					} 
				}
			}			
		}		
		
		return name;
	}	
	
	public static String hasRelation(OWLClass A, OWLClass B, OWLOntology onto, boolean useReasoner){
		String relation = "norelation";
		if(!useReasoner){
			Set<OWLClassExpression> sets = A.getSuperClasses(onto);
			if(sets.contains(B)){
				relation = "subclassof";
			}
			sets = A.getSubClasses(onto);
			if(sets.contains(B)){
				relation = "superclassof";
			}
		} else {
			
		}
		return relation;
	}
	
	public static OWLOntology openOntology(String ontoPath){		
		createOntologyManager();
		String path = checkOntoPath(ontoPath);
		IRI physicalURI = IRI.create(path);
		OWLOntology ontology = null;
		try{
			ontology = manager.loadOntology(physicalURI);  
		} catch (OWLOntologyCreationException ex){
			ex.printStackTrace();
		}   
       	return ontology;
	}
	
	
	public static OWLOntology openOntology(String ontoPath, 
			OWLOntologyManager conn) {
		String path = checkOntoPath(ontoPath);
		IRI physicalURI = IRI.create(path);
        OWLOntology ontology = null; 
        try{
        	ontology = conn.loadOntology(physicalURI); 
		} catch (OWLOntologyCreationException ex){
			ex.printStackTrace();
		}   
       	return ontology;
	}


	public static String checkOntoPath(String ontoPath) {
		String path = ontoPath;
		if (!ontoPath.startsWith("http:"))
	        if (!ontoPath.startsWith("https:"))
		        if (!ontoPath.startsWith("ftp:"))
		        	if (!ontoPath.startsWith("file:"))
		        		path =  "file:" + ontoPath;
		return path;
	}
	
	public static void clearOntology(OWLOntology o, 
			OWLOntologyManager manager) throws Exception {
		List<OWLOntologyChange> list = new ArrayList<OWLOntologyChange>();
		for(OWLAxiom a : o.getAxioms()){
			RemoveAxiom removeAxiom = new RemoveAxiom(o, a);
			list.add(removeAxiom);
		}
		if(list.size()>0){
			manager.applyChanges(list);
		}			
	}
	
	public static void addAxioms(
			OWLOntology o,
			OWLOntologyManager conn, 
			HashSet<OWLAxiom> axioms) {
		
		List<OWLOntologyChange> list = new ArrayList<OWLOntologyChange>();
		for (OWLAxiom axiom : axioms) {
			if(axiom==null){
				continue;
			}
			AddAxiom addAxiom = new AddAxiom(o, axiom);
			list.add(addAxiom);
		}
		if(list.size()>0){
			conn.applyChanges(list);  
		}		
	}
		
	public static void addAxioms(
			OWLOntology onto, 
			OWLOntology newOnto,
			OWLOntologyManager manager) throws Exception {
		
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(getAxioms(newOnto, null));		
		addAxioms(onto,manager, axioms);
	}
	
	public static void addAxiom(
			OWLOntology onto, 
			OWLAxiom a) throws Exception{	
		
		createOntologyManager();
		AddAxiom axiom = new AddAxiom(onto, a);
		manager.applyChange(axiom);	
	}
	
	public static void removeAxioms(
			OWLOntology onto, 
			HashSet<OWLAxiom> axioms) throws Exception {
		
		createOntologyManager();
		List<OWLOntologyChange> list = new ArrayList<OWLOntologyChange>();
		for (OWLAxiom a : axioms) {
			RemoveAxiom axiom = new RemoveAxiom(onto, a);
			list.add(axiom);
		}
		if(list.size()>0){
			manager.applyChanges(list);  
		}	
	}

	public static void removeAxiom(
			OWLOntology onto, 
			OWLAxiom a) throws Exception {	
		
		createOntologyManager();
		RemoveAxiom axiom = new RemoveAxiom(onto, a);
		manager.applyChange(axiom);	
	}	
	
	//*********************************************
	//Create an ontology with or without some axioms
	//*********************************************
	
	public static OWLOntology createOntology() throws Exception {
		return createOntology(null, new HashSet<OWLAxiom>(), null, null);
	}	
	
	public static OWLOntology createOntology(String logicalUrl) throws Exception {
		return createOntology(null, new HashSet<OWLAxiom>(), logicalUrl, null);
	}
	
	public static OWLOntology createOntology(String logicalUrl,
			String physicalUrl) throws Exception {		
		return createOntology(null, new HashSet<OWLAxiom>(), logicalUrl, physicalUrl);		
	}	

	public static OWLOntology createOntology(
			HashSet<OWLAxiom> axioms) {
		return createOntology(null, axioms, null, null);
	}
	
	public static OWLOntology createOntology(
			HashSet<OWLAxiom> axioms, 
			String physicalPath, 
			String logicalPath) throws Exception  {
		return createOntology(null, axioms, logicalPath, physicalPath);
	}
	
    public static OWLOntology createOntology(
    		HashSet<OWLAxiom> axioms, 
    		String logicalUrl) throws Exception {				
		return createOntology(null, axioms, logicalUrl, null);
	}
    
	public static OWLOntology createOntology(
			OWLOntologyManager conn, 
			HashSet<OWLAxiom> axioms){		
		return createOntology(conn, axioms, null, null);
	}
	
	public static OWLOntology createOntology(
			OWLOntologyManager conn_p, 
			HashSet<OWLAxiom> axioms_p,
			String logicalUrl_p, 
			String physicalUrl_p) {
		if(manager == null)
		    manager = OWLManager.createOWLOntologyManager();
		OWLOntology ont = null;
		try {
			ont = manager.createOntology(axioms_p);
			
		} catch (Exception ex) {
			System.out.println("******* fail to create an ontology");
			//ont = OWL.manager.createOntology(axioms_p);
		}
		return ont;
	}
	public static OWLOntology createOntology2(
			OWLOntologyManager conn_p, 
			HashSet<OWLAxiom> axioms_p,
			String logicalUrl_p, 
			String physicalUrl_p) {
		
		/*if(onto!=null) {
			manager.addAxioms(onto, axioms_p);
			return onto;
		}*/
		String logicalUrl = logicalUrl_p;
		String physicalUrl = physicalUrl_p;
		long id = System.currentTimeMillis();
		if(logicalUrl==null){
			logicalUrl = "http://radon.ontoware.org/example"+id+"-"+(newontoCounter++);			
		}
		if(physicalUrl==null){
			physicalUrl = "file:newOnto-"+ id;
		} else {
			checkOntoPath(physicalUrl);
		}
		
		IRI ontologyURI = IRI.create(logicalUrl);
		IRI physicalURI = IRI.create(physicalUrl);
        SimpleIRIMapper mapper = new SimpleIRIMapper(ontologyURI, physicalURI);
        OWLOntology o = null;
        try{
        	manager = OWLManager.createOWLOntologyManager();
			//createOntologyManager();
			manager.addIRIMapper(mapper);
	        o = manager.createOntology(ontologyURI);
	        addAxioms(o, manager, axioms_p);
        	/*if(conn_p==null){
    			manager = OWLManager.createOWLOntologyManager();
    			//createOntologyManager();
    			manager.addIRIMapper(mapper);
    	        onto = manager.createOntology(ontologyURI);
    	        addAxioms(onto, manager, axioms_p);
    		} else {
    			conn_p.addIRIMapper(mapper);
    			onto = conn_p.createOntology(ontologyURI);
    	        addAxioms(onto, conn_p, axioms_p);
    		}   */
        } catch(OWLOntologyCreationException ex){
        	ex.printStackTrace();
        }		     
		return o;	
	}
	
	public static HashSet<OWLAxiom> getAxioms(OWLOntology o, AxiomType type)  {
		return getAxioms(o,type,false);
	}
	
	public static HashSet<OWLAxiom> getAxioms(
			OWLOntology o, 
			AxiomType type, 
			boolean withAnnotationAxioms) {
		HashSet<OWLAxiom> all = new HashSet<OWLAxiom>();
		if(type==null){			
			if(!withAnnotationAxioms){
				all.addAll(o.getLogicalAxioms());
			} else {
				all.addAll(o.getAxioms());
			}
		} else {
			all.addAll(o.getAxioms(type));
		}	
		return (HashSet<OWLAxiom>)all.clone();
	}
		
	public static OWLClass createOWLClass(
			OWLOntology onto, 
			String entityURI) {
		
		createOntologyManager();
		OWLDataFactory factory = manager.getOWLDataFactory();
		OWLClass ent = factory.getOWLClass(IRI.create(entityURI));
		
		return ent;
	}
	
	
	public static OWLClass getOWLClass(
			OWLOntology onto, 
			String classString,
			boolean considerImportOntos) {
		OWLClass ent = getOWLClass(onto, classString);		
		if(considerImportOntos && ent == null){				
			Set<OWLOntology> impOntos = onto.getImports();
			if(impOntos !=null){
				for(OWLOntology o :impOntos){
					ent = getOWLClass(o, classString);
					if(ent != null){
						break;
					}
				}
			}
		}	
		return ent;
	}
	
	public static OWLClass getOWLClass(
			OWLOntology onto, 
			String classString) {
		OWLClass uc = null;
		if(classString.equals("Nothing") || classString.equals("http://www.w3.org/2002/07/owl#Nothing")){
			return OWL.factory.getOWLNothing();
		} else if(classString.equals("Thing") || classString.equals("http://www.w3.org/2002/07/owl#Thing")){
			return OWL.factory.getOWLThing();
		}
		if(classString.indexOf("http:")!=-1){
			uc = getOWLClassWithURI(onto, classString);
		} else if (classString.indexOf("#")!=-1){
			uc = getOWLClass(onto, "http://"+classString);
			if(uc == null){
				classString = classString.substring(classString.indexOf("#")+1);
			} else {
				return uc;
			}
		} 

		if(uc == null){
			uc = getOWLClassWithLocalName(onto, classString);
		}
		return uc;
	}
		
	public static OWLClass getOWLClassWithURI(
			OWLOntology onto, 
			String entityURI) {
		
		OWLClass ent = null;
		IRI uri = IRI.create(entityURI);
		createOntologyManager();
		OWLDataFactory factory = manager.getOWLDataFactory();		
		if(onto.containsClassInSignature(uri)){
			ent = factory.getOWLClass(uri);
		} 	
		return ent;
	}
	
	public static OWLEntity getEntity(
			OWLOntology onto, 
			String entityURI) {
		OWLEntity ent = null;
		IRI uri = IRI.create(entityURI);
		createOntologyManager();
		OWLDataFactory factory = manager.getOWLDataFactory();
		if(onto.containsClassInSignature(uri)){
			ent = factory.getOWLClass(uri);
		} else if(onto.containsObjectPropertyInSignature(uri)){
			ent = factory.getOWLObjectProperty(uri);
		} else if(onto.containsDataPropertyInSignature(uri)){
			ent = factory.getOWLDataProperty(uri);
		} else if(onto.containsIndividualInSignature(uri)){
			ent = factory.getOWLNamedIndividual(uri);
		} else if(onto.containsDatatypeInSignature(uri)){
			ent = factory.getOWLDatatype(uri);
		}		
		return ent;
	}
	
	public static OWLEntity getEntityWithLocalName(
			OWLOntology onto, 
			String localName) {
		OWLEntity ent = null;
		for(OWLEntity entity : onto.getSignature()){
			String name = getLocalName(entity);
			if(name!=null && name.equals(localName)){
				ent = (OWLEntity)entity;
				break;
			}
		}
		return ent;
	}
		
	public static OWLClass getOWLClassWithLocalName(
			OWLOntology onto, 
			String localName) {
		OWLClass ent = null;
		for(OWLClass entity : onto.getClassesInSignature(true)){
			String entLocalName = getLocalName(entity);
			if(entLocalName.equals(localName)){
				return entity;
			}
			/*String entIri = entity.getIRI().toString();
			if(entIri.indexOf("#")!=-1){
				if(entity.getIRI().toString().endsWith("#"+localName) ||
						entity.getIRI().toString().endsWith(localName)){
					ent = entity;
					break;
				} 
			} else if(entIri.indexOf("/")!=-1){
				if(entity.getIRI().toString().endsWith("/"+localName)){
					ent = entity;
					break;
				}
			} else if(entIri.equals(localName)){
				ent = entity;
				break;
			}*/
		}
		return ent;
	}
	
	public static OWLObjectProperty getOWLObjectPropertyWithLocalName(
			OWLOntology onto, 
			String localName) {
		OWLObjectProperty correspondingProperty = null;
		for(OWLObjectProperty entity : onto.getObjectPropertiesInSignature()){
			String entIri = entity.getIRI().toString();
			if(entIri.indexOf("#")!=-1){
				if(entity.getIRI().toString().endsWith("#"+localName)){
					correspondingProperty = entity;
					break;
				}
			} else if(entIri.indexOf("/")!=-1){
				if(entity.getIRI().toString().endsWith("/"+localName)){
					correspondingProperty = entity;
					break;
				}
			} else if(entIri.equals(localName)){
				correspondingProperty = entity;
				break;
			}
		}
		return correspondingProperty;
	}
	
	public static OWLNamedIndividual getIndividual(
			OWLOntology onto, 
			String name, boolean considerImportOntos) {
		if(name.startsWith("http:")){
			return getIndividualWithIRI(onto, name);
		} else {
			int index = name.indexOf("#");
			if(index != - 1 && index > 0){
				// In such case, the name is an entity name from OAEI
				return getIndividualWithIRI(onto, "http://"+name);
			}
			return getIndividualWithLocalName(onto, name);
		}
	}
	
	public static OWLNamedIndividual getIndividualWithLocalName(
			OWLOntology onto, 
			String localName, boolean considerImportOntos) {
		
		OWLNamedIndividual ent = getIndividualWithLocalName(onto, localName);	
		if(considerImportOntos){				
			if(ent == null){
				Set<OWLOntology> impOntos = onto.getImports();
				if(impOntos !=null){
					for(OWLOntology o :impOntos){
						ent = getIndividualWithLocalName(o, localName);
						if(ent != null){
							break;
						}
					}
				}
			}
		}		
		return ent;
	}
	
	public static OWLNamedIndividual getIndividualWithLocalName(
			OWLOntology onto, 
			String localName) {
		OWLNamedIndividual indi = null;
		String oID = onto.getOntologyID().getOntologyIRI().toString();		
		for(OWLNamedIndividual entity : onto.getIndividualsInSignature(true)){
			if(entity.getIRI().toString().equalsIgnoreCase(oID+localName)){
				indi = entity;
				break;
			}
			String name = getLocalName(entity);
			if(name!=null && name.equals(localName)){
				indi = entity;
				break;
			}
		}
		return indi;
	}
	
	public static OWLNamedIndividual getIndividualWithIRI(
			OWLOntology onto, 
			String iri) {
		OWLNamedIndividual ent = null;
		
		for(OWLNamedIndividual entity : onto.getIndividualsInSignature()){
			if(entity.getIRI().toString().equals(iri)){
				ent = entity;
				break;
			}
		}
		return ent;
	}
	
	public static Set<OWLAxiom> getFunctionalProperties(
			OWLOntology o)  {
		Set allFunc = new HashSet();
		Set<OWLObjectProperty> all = o.getObjectPropertiesInSignature();
		for(OWLObjectProperty op : all){			
			if(op.isFunctional(o)){
				allFunc.add(op);
			}
		}
		Set<OWLDataProperty> alldp = o.getDataPropertiesInSignature();
		for(OWLDataProperty op : alldp){			
			if(op.isFunctional(o)){
				allFunc.add(op);
			}
		}
		return allFunc;
	}	
	
	public static HashSet getIntersect( HashSet A_in, HashSet B_in ){
		if(A_in == null || B_in == null){
			System.out.println("Can't obtain Intersection of  null Sets");
		}
		HashSet A = (HashSet)A_in.clone();		
		A.retainAll(B_in);
		return A;
	}


	public static HashSet<OWLAxiom> getTBox(OWLOntology ontology){
		HashSet<OWLAxiom> allAxioms = getAxioms(ontology,null,false);
		HashSet<OWLAxiom> aBox = getABox(ontology);
		allAxioms.removeAll(aBox);			 
		return allAxioms;
	}
	
	public static HashMap<String,HashSet<OWLAxiom>> getTBoxABox(
			OWLOntology ontology, boolean considerImports){
		HashMap<String,HashSet<OWLAxiom>> map = new HashMap<String, HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> tbox = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> abox = new HashSet<OWLAxiom>();
		Set<OWLOntology> importedOntos = ontology.getImportsClosure();
		if(!considerImports || importedOntos == null || (importedOntos!=null && importedOntos.size()==0)){
			tbox = getAxioms(ontology,null,false);
			abox = getABox(ontology);			
		} else {
			HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
			for(OWLOntology importOnto : importedOntos){
				abox.addAll(getABox(importOnto));
				tbox.addAll(getAxioms(importOnto,null,false));
				allAxioms.addAll(importOnto.getLogicalAxioms());
			}
			//System.out.println("all : "+allAxioms.size());
		}
		tbox.removeAll(abox);	
		map.put("tbox", tbox);
		map.put("abox", abox);
		return map;
	}
	

	public static boolean isSigIntersectant(HashSet<OWLAxiom> set1, HashSet<OWLAxiom> set2) {
		HashSet<OWLEntity> sigs1 = getSignatures(set1);
		HashSet<OWLEntity> sigs2 = getSignatures(set2);
		if(sigs1.size() < sigs2.size()){
			for(OWLEntity ent : sigs1){
				if(sigs2.contains(ent))
					return true;
			}
		} else {
			for(OWLEntity ent : sigs2){
				if(sigs1.contains(ent))
					return true;
			}
		}
		return false;
	}
	
	public static HashSet<OWLEntity> getSignatures(HashSet<OWLAxiom> axioms){
		HashSet<OWLEntity> sigs = new HashSet<OWLEntity>();
		for(OWLAxiom a : axioms){
			sigs.addAll(a.getSignature());
		}
		return sigs;
	}
	
	public static HashSet<OWLAxiom> getRBox(OWLOntology ontology) throws Exception{
		Set tempAxioms = new HashSet<OWLAxiom>();

		//Obtain all the axioms except annotation axioms
		HashSet axioms = getAxioms(ontology,null,false);
		
		//Remove abox
		tempAxioms = getABox(ontology);
		axioms.removeAll(tempAxioms);
		
		//Remove pure TBox
		tempAxioms = getPureTBox(ontology);
		axioms.removeAll(tempAxioms);
		
		return (HashSet<OWLAxiom>) axioms.clone();
	}
	
	public static HashSet<OWLAxiom> getPureTBox(OWLOntology ontology) throws Exception{
		HashSet axioms = getAxioms(ontology,AxiomType.SUBCLASS_OF);
		axioms.addAll(getAxioms(ontology,AxiomType.EQUIVALENT_CLASSES));
		axioms.addAll(getAxioms(ontology,AxiomType.DISJOINT_CLASSES));	
		return axioms;
	}
	
	public static HashSet<OWLAxiom> getABox(OWLOntology ontology) {		
		HashSet axioms = getAxioms(ontology,AxiomType.CLASS_ASSERTION);		
		axioms.addAll(getAxioms(ontology,AxiomType.OBJECT_PROPERTY_ASSERTION));
		axioms.addAll(getAxioms(ontology,AxiomType.DATA_PROPERTY_ASSERTION));
		axioms.addAll(getAxioms(ontology,AxiomType.DIFFERENT_INDIVIDUALS));
		axioms.addAll(getAxioms(ontology,AxiomType.NEGATIVE_DATA_PROPERTY_ASSERTION));
		axioms.addAll(getAxioms(ontology,AxiomType.NEGATIVE_OBJECT_PROPERTY_ASSERTION));
		axioms.addAll(getAxioms(ontology,AxiomType.SAME_INDIVIDUAL));
		return axioms;
	}
	
	public static void saveOntology(OWLOntology onto)
	throws Exception{			
		manager.saveOntology(onto);	
		/*OWLOntologyFormat format = new OWLOntologyFormat();
		format.setParameter(null, null);*/
	}	

	public static void saveOntology(HashSet<OWLAxiom> set, String physicalPath)
	throws Exception{	
		OWLOntology onto = createOntology(set, physicalPath, null);
		File f  = new File(physicalPath);
		manager.saveOntology(onto, IRI.create(f.toURI()));
	}	
	

	public static HashSet<HashSet<OWLAxiom>> transferStringsToAxioms(
			HashSet<HashSet<String>> confStr, 
			HashSet<OWLAxiom> axioms){
		HashMap<String, OWLAxiom> mapping = new HashMap<String, OWLAxiom>();
		for(OWLAxiom axiom : axioms){
			mapping.put(axiom.toString(), axiom);
		}
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<String> oneConfStr : confStr){
			HashSet<OWLAxiom> conflict = new HashSet<OWLAxiom>();
			for(String axiomString : oneConfStr){
				OWLAxiom axiom = mapping.get(axiomString);
				conflict.add(axiom);
			}
			conflicts.add(conflict);			
		}
		return conflicts;
	}
}
