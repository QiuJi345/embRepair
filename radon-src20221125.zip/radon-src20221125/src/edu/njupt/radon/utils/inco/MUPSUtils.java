package edu.njupt.radon.utils.inco;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.io.MyPrinter;

public class MUPSUtils {
	
	public static HashSet<HashSet<OWLAxiom>> getMUPS(OWLOntology onto, String mupsPath){
		HashSet<HashSet<String>> allMUPSString = MUPSUtils.getFoundJusts(mupsPath);
		/*int mupsCounter = 0;
		for(HashSet<String> set : allMUPSString){
			System.out.println("<"+(mupsCounter++)+">");
			int axiomCounter = 0;
			for(String str : set){
				System.out.println(axiomCounter++ + "] "+str);
			}
		}*/
		HashMap<String, OWLAxiom> axiomStringMap = new HashMap<String, OWLAxiom>();
		for(OWLAxiom axiom : onto.getLogicalAxioms()){
			axiomStringMap.put(axiom.toString(), axiom);
		}
		HashSet<HashSet<OWLAxiom>> allMUPS = MUPSUtils.getSetsOfOWLAxioms(allMUPSString, axiomStringMap);
		return allMUPS;
	}
	
	public static HashSet<HashSet<OWLAxiom>> getJusts(HashSet<OWLAxiom> axioms, String mupsPath){
		HashSet<HashSet<String>> allMUPSString = MUPSUtils.getFoundJusts(mupsPath);
		
		HashSet<HashSet<OWLAxiom>> allMUPS = translate(axioms, allMUPSString);
		return allMUPS;
	}
	
	public static HashSet<HashSet<OWLAxiom>> translate(HashSet<OWLAxiom> axioms, 
			HashSet<HashSet<String>> axiomStrings){
		
		HashMap<String, OWLAxiom> axiomStringMap = new HashMap<String, OWLAxiom>();
		for(OWLAxiom axiom : axioms){
			axiomStringMap.put(axiom.toString(), axiom);
		}
		HashSet<HashSet<OWLAxiom>> allMUPS = MUPSUtils.getSetsOfOWLAxioms(axiomStrings, axiomStringMap);
		return allMUPS;
	}

	public static HashSet<HashSet<String>> getFoundJusts(String logPath, String debugMethod) {
		HashSet<HashSet<String>> allMUPSString = new HashSet<HashSet<String>>();
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isAllMUPSBegin = false;
		boolean isOneMUPSBegin = false;
				
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {	
				if(debugMethod.equals("pattern") && oneLine.contains("Correctness Checking")){
					isAllMUPSBegin = true;
				}
				if(debugMethod.equals("pattern") && !isAllMUPSBegin){
					continue;
				}
				if(oneLine.indexOf("Found a new MUPS") != -1 || 
						oneLine.indexOf("Explanation") != -1){
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS has been finished.
					if(oneLine.trim().length() == 0 && oneMUPSString.size()>0){
						// Add the found MUPS to the collection of MUPS
						allMUPSString.add(new HashSet<String>(oneMUPSString));
						// Set the start
						isOneMUPSBegin = false;
					} else {
						int index1 = oneLine.indexOf("]");
						if(index1 != -1){
							// Get the string after ]
							String axiomString = oneLine.substring(index1+1).trim();
							// Remove the first blank space if exists
							if(axiomString.indexOf(" ")==0){
								axiomString = axiomString.substring(1);
							}
							// Add the axiom string to the the collection of axiom strings.
							oneMUPSString.add(axiomString);							
						} 
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		return allMUPSString;
	}
	
	public static HashSet<HashSet<String>> getFoundMUPS2(String logPath) {
		HashSet<HashSet<String>> allMUPSString = new HashSet<HashSet<String>>();
		HashSet<String> oneMUPSString = new HashSet<String>();
		String prefix = "	";
		int prefixLen = prefix.length();
		boolean isOneMUPSBegin = false;
				
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {	
				
				if(oneLine.indexOf("Explanation <") != -1){
					isOneMUPSBegin = true;
					oneMUPSString.clear();      
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS has been finished.
					if(oneLine.trim().length() == 0 && oneMUPSString.size()>0){
						// Add the found MUPS to the collection of MUPS
						allMUPSString.add(new HashSet<String>(oneMUPSString));
						// Set the start
						isOneMUPSBegin = false;
					} else {
						// Get the string after ]
						String axiomString = oneLine.substring(prefixLen).trim();
						// Add the axiom string to the the collection of axiom strings.
						oneMUPSString.add(axiomString);	
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		return allMUPSString;
	}
	
	
	public static HashSet<HashSet<String>> getFoundJusts(String logPath) {
		HashSet<HashSet<String>> allMUPSString = new HashSet<HashSet<String>>();
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneMUPSBegin = false;
				
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {	
				
				if(oneLine.indexOf("conflict <") != -1 
						|| oneLine.indexOf("Explanation <") != -1 
						|| oneLine.indexOf("Found explanation") != -1 
						|| oneLine.startsWith("<")){
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS has been finished.
					if(oneLine.trim().length() == 0 && oneMUPSString.size()>0){
						// Add the found MUPS to the collection of MUPS
						allMUPSString.add(new HashSet<String>(oneMUPSString));
						// Set the start
						isOneMUPSBegin = false;
					} else {
						int index1 = oneLine.indexOf("]");
						if(index1 != -1){
							// Get the string after ]
							String axiomString = oneLine.substring(index1+1).trim();
							// Remove the first blank space if exists
							if(axiomString.indexOf(" ")==0){
								axiomString = axiomString.substring(1);
							}
							// Add the axiom string to the the collection of axiom strings.
							oneMUPSString.add(axiomString);							
						} 
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		return allMUPSString;
	}
	
	public static HashSet<HashSet<OWLAxiom>> getSetsOfOWLAxioms(
			HashSet<HashSet<String>> stringSets,
			OWLOntology ontology){
		HashSet<HashSet<OWLAxiom>> axiomSets = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<String> stringSet : stringSets){
			HashSet<OWLAxiom> axiomSet = getOWLAxioms(stringSet, ontology);
			axiomSets.add(axiomSet);
		}
		return axiomSets;
	}
	
	public static HashSet<HashSet<OWLAxiom>> getSetsOfOWLAxioms(
			HashSet<HashSet<String>> stringSets,
			HashMap<String, OWLAxiom> axiomStringMap){
		HashSet<HashSet<OWLAxiom>> axiomSets = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<String> stringSet : stringSets){
			HashSet<OWLAxiom> axiomSet = getOWLAxioms(stringSet, axiomStringMap);
			axiomSets.add(axiomSet);
		}
		return axiomSets;
	}
	
	public static HashSet<OWLAxiom> getOWLAxioms(
			HashSet<String> strings,
			OWLOntology ontology){
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		for(String string : strings){
			OWLAxiom axiom = getOWLAxiom(string, ontology);
			if(axiom != null){
				axioms.add(axiom);
			}
		}
		return axioms;
	}
	
	
	public static HashSet<OWLAxiom> getOWLAxioms(
			HashSet<String> strings,
			HashMap<String, OWLAxiom> axiomStringMap){
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		for(String string : strings){
			OWLAxiom axiom = axiomStringMap.get(string);
			if(axiom != null){
				axioms.add(axiom);
			} else {
				System.err.println("Fail to translate a string <"+string+"> to an owl axiom!");
			}
		}
		return axioms;
	}
	
	public static OWLAxiom getOWLAxiom(String string, OWLOntology ontology){
		for(OWLAxiom axiom : ontology.getLogicalAxioms()){
			String axiomString = axiom.toString();
			if(axiomString.equals(string)){
				return axiom;
			}
		}
		return null;
	}

	public static void printAllMUPS(HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS){
		
		int ucCounter = 1;
		for(OWLClass uc : allMUPS.keySet()) {
			System.out.println("UC <"+(ucCounter++)+"> "+uc.toString());
			MyPrinter.printMultiSets(allMUPS.get(uc), null);
		}
		
	}
	
	public static void printAllMUPS(HashSet<HashSet<String>> allMUPSString){
		int mupsCounter = 0;
		for(HashSet<String> oneMUPSString : allMUPSString){
			mupsCounter ++;
			System.out.println("MUPS "+mupsCounter);
			
			int axiomCounter = 0;
			for(String oneString : oneMUPSString){
				System.out.println((axiomCounter++)+"> "+oneString);
			}
			System.out.println();
		}
	}
	

}
