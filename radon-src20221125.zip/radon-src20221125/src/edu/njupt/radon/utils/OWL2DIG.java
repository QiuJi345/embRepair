package edu.njupt.radon.utils;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataHasValue;
import org.semanticweb.owlapi.model.OWLDataPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLDataPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLDataPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLDataRange;
import org.semanticweb.owlapi.model.OWLDatatype;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentDataPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLFunctionalDataPropertyAxiom;
import org.semanticweb.owlapi.model.OWLFunctionalObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLInverseFunctionalObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLInverseObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectCardinalityRestriction;
import org.semanticweb.owlapi.model.OWLObjectComplementOf;
import org.semanticweb.owlapi.model.OWLObjectExactCardinality;
import org.semanticweb.owlapi.model.OWLObjectHasValue;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectMaxCardinality;
import org.semanticweb.owlapi.model.OWLObjectMinCardinality;
import org.semanticweb.owlapi.model.OWLObjectOneOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectUnionOf;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyID;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.model.OWLSubDataPropertyOfAxiom;
import org.semanticweb.owlapi.model.OWLSubObjectPropertyOfAxiom;
import org.semanticweb.owlapi.model.OWLSymmetricObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLTransitiveObjectPropertyAxiom;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class OWL2DIG {
		
	private OWLOntology  ontology;
	private Document digFile;
	private String kburi;
	private Node root;
	
	public static void main(String[] args) {
		String ontoName = "University"; //km1500-4000 proton_100_all
		String dataset = "real";
		String ontoRoot = "d:/Data/debugging/journal-paper-data/incoherent/"+dataset+"/";
		String ontoPath = "file:"+ontoRoot+ontoName+".owl";
		String digfilePath = "d:/"+ontoName+"-dig.xml";
		
		
		//System.out.println(ontology.getPhysicalURI());
		
		//System.out.println(ontology.createAxiomRequest().getAll().size());
		//System.out.println(OWLTools.getAxioms(ontology, null).size());
		//OWLTools.printAxioms(ontology);
		if(ontoName == null){
			File f = new File(ontoRoot);
			for(File ontoF : f.listFiles()){
				ontoName = ontoF.getName();
				ontoPath = "file:"+ontoRoot+ontoName; 
				System.out.println(ontoPath);
				
				OWLOntology ontology = OWLTools.openOntology(ontoPath);
				OWL2DIG owl2dig = new OWL2DIG(ontology);
				owl2dig.owl2dig();		
				
				digfilePath = "d:/"+ontoName.substring(0, ontoName.indexOf("."))+"-dig.xml";
				owl2dig.outputDoc(digfilePath);
				
			}
		} else {
			OWLOntology ontology = OWLTools.openOntology(ontoPath);
			System.out.println(ontoPath);
			OWL2DIG owl2dig = new OWL2DIG(ontology);
			owl2dig.owl2dig();		
			owl2dig.outputDoc(digfilePath);
		}
	}
	
	public OWL2DIG(OWLOntology onto){
		this.ontology = onto;
		this.iniOntologyIRI();		
		this.iniDIGDocument();	
	}

	private void iniOntologyIRI(){
		OWLOntologyID iri = ontology.getOntologyID();
		if(iri != null){
			kburi = iri.getOntologyIRI().toString();
		} else {
			kburi = null;
		}
	}
	
	private void iniDIGDocument(){
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		factory.setValidating(true);
		try{
			DocumentBuilder builder = factory.newDocumentBuilder();
			digFile = builder.newDocument();
		} catch(Exception ex){
			ex.printStackTrace();
		}	
	    //  Create the root node of a DIG file
		root = createRoot("tells");
	}
	
	private Element createRoot(String roottag) {	
		// Create a node
		Element root = digFile.createElement(roottag);
		root.setAttribute("xmlns", "http://dl.kr.org/dig/2003/02/lang");
		// Set the value for "uri" attribute
		if (kburi != null) {
			root.setAttribute("uri", kburi);
		}
		// Add the root node to the DIG file
		digFile.appendChild(root);
		// Return the created node
		return root;
	}
	
	public void owl2dig() { 
		int i = 0;
		for(OWLAxiom axiom : ontology.getLogicalAxioms()){
			System.out.println("axiom "+(i++)+" : "+axiom.toString().replace("http://protege.stanford.edu/plugins/owl/owl-library/koala.owl#", ""));
			if(axiom.toString().contains("#Koala")){
				System.out.println("stop");
			}
			translateAxiom(axiom);
		}
	}
	
	public void translateAxiom(OWLAxiom axiom) {	
		// Axioms in TBox		
		if(axiom instanceof OWLSubClassOfAxiom) {
			OWLSubClassOfAxiom subClAxiom = (OWLSubClassOfAxiom)axiom;
			translateAxiom(subClAxiom.getSubClass(), subClAxiom.getSuperClass(), "impliesc");
							
		} else if(axiom instanceof OWLDisjointClassesAxiom) {
			OWLDisjointClassesAxiom disjAxiom = (OWLDisjointClassesAxiom)axiom;
			List<OWLClassExpression> exps = disjAxiom.getClassExpressionsAsList();
			translateAxiom(exps.get(0), exps.get(1), "disjoint");	
			
		} else if(axiom instanceof OWLEquivalentClassesAxiom) {
			OWLEquivalentClassesAxiom equAxiom = (OWLEquivalentClassesAxiom)axiom;
			List<OWLClassExpression> exps = equAxiom.getClassExpressionsAsList();
			translateAxiom(exps.get(0), exps.get(1), "equalc");
			
		// Axioms about object-properties in RBox
		} else if(axiom instanceof OWLEquivalentObjectPropertiesAxiom){
			OWLEquivalentObjectPropertiesAxiom equivalentOPAxiom = (OWLEquivalentObjectPropertiesAxiom)axiom;
			Vector<OWLObjectPropertyExpression> opes = new Vector<OWLObjectPropertyExpression>(equivalentOPAxiom.getProperties());
			translateAxiom(opes.get(0), opes.get(1), "equalr");					
			
		} else if(axiom instanceof OWLSubObjectPropertyOfAxiom) {
			OWLSubObjectPropertyOfAxiom subAxiom = (OWLSubObjectPropertyOfAxiom)axiom;
			translateAxiom(subAxiom.getSubProperty(), subAxiom.getSuperProperty(), "impliesr");		
			
		}  else if(axiom instanceof OWLObjectPropertyDomainAxiom){
			OWLObjectPropertyDomainAxiom domainAxiom = (OWLObjectPropertyDomainAxiom)axiom;
			translateAxiom(domainAxiom.getProperty(), domainAxiom.getDomain(), "domain");
			
		} else if (axiom instanceof OWLObjectPropertyRangeAxiom){
			OWLObjectPropertyRangeAxiom rangeAxiom = (OWLObjectPropertyRangeAxiom)axiom;
			translateAxiom(rangeAxiom.getProperty(), rangeAxiom.getRange(), "range");
			
		} else if (axiom instanceof OWLInverseObjectPropertiesAxiom){
			OWLInverseObjectPropertiesAxiom newAxiom = (OWLInverseObjectPropertiesAxiom)axiom;
			translateAxiom(newAxiom.getFirstProperty(), newAxiom.getSecondProperty(), "inverse");
						
		} else if (axiom instanceof OWLFunctionalObjectPropertyAxiom){
			OWLFunctionalObjectPropertyAxiom newAxiom = (OWLFunctionalObjectPropertyAxiom)axiom;
			translateAxiom(newAxiom.getProperty(), null, "functional");
			
		} else if (axiom instanceof OWLInverseFunctionalObjectPropertyAxiom){
			OWLInverseFunctionalObjectPropertyAxiom newAxiom = (OWLInverseFunctionalObjectPropertyAxiom)axiom;
			Element subElement = digFile.createElement("functional");	
			translateAxiom(subElement, newAxiom.getProperty(), null, "inverse");
						
		} else if (axiom instanceof OWLTransitiveObjectPropertyAxiom){
			OWLTransitiveObjectPropertyAxiom newAxiom = (OWLTransitiveObjectPropertyAxiom)axiom;
			translateAxiom(newAxiom.getProperty(), null, "transitive");
			
		} else if (axiom instanceof OWLSymmetricObjectPropertyAxiom){
			OWLSymmetricObjectPropertyAxiom newAxiom = (OWLSymmetricObjectPropertyAxiom)axiom;
			translateAxiom(newAxiom.getProperty(), null, "transitive");
			Element subElement = digFile.createElement("equalr");
			translateObjectProperty(subElement, newAxiom.getProperty());
			translateAxiom(subElement, newAxiom.getProperty(), null, "inverse");
			
		// Axioms about data-properties in RBox
		} else if (axiom instanceof OWLSubDataPropertyOfAxiom){
			OWLSubDataPropertyOfAxiom newAxiom = (OWLSubDataPropertyOfAxiom)axiom;
			translateAxiom(newAxiom.getSubProperty(), newAxiom.getSuperProperty(), "impliesr");
			
		} else if (axiom instanceof OWLEquivalentDataPropertiesAxiom){
			OWLEquivalentDataPropertiesAxiom newAxiom = (OWLEquivalentDataPropertiesAxiom)axiom;
			Vector<OWLDataPropertyExpression> dpes = new Vector<OWLDataPropertyExpression>(newAxiom.getProperties());
			translateAxiom(dpes.get(0), dpes.get(1), "equalr");	
			
		} else if (axiom instanceof OWLDataPropertyDomainAxiom){
			OWLDataPropertyDomainAxiom newAxiom = (OWLDataPropertyDomainAxiom)axiom;
			translateAxiom(newAxiom.getProperty(), newAxiom.getDomain(), "domain");
			
		} else if (axiom instanceof OWLDataPropertyRangeAxiom){
			OWLDataPropertyRangeAxiom newAxiom = (OWLDataPropertyRangeAxiom)axiom;
			OWLDataRange range = newAxiom.getRange();
			if(range.isDatatype()){
				OWLDatatype datatype = range.asOWLDatatype();
				if(datatype.isInteger()){
					translateAxiom(newAxiom.getProperty(), null, "rangeint");
				} else {
					translateAxiom(newAxiom.getProperty(), null, "rangestring");
				}
			}
			
		} else if (axiom instanceof OWLFunctionalDataPropertyAxiom){
			OWLFunctionalDataPropertyAxiom newAxiom = (OWLFunctionalDataPropertyAxiom)axiom;
			translateAxiom(newAxiom.getProperty(), null, "functional");
			
		// Axioms in ABox
		} else if(axiom instanceof OWLClassAssertionAxiom){
			OWLClassAssertionAxiom newAxiom = (OWLClassAssertionAxiom)axiom;
			translateAxiom(newAxiom.getIndividual(), newAxiom.getClassExpression(), "instanceof");
			
		} else if(axiom instanceof OWLObjectPropertyAssertionAxiom){
			OWLObjectPropertyAssertionAxiom newAxiom = (OWLObjectPropertyAssertionAxiom)axiom;
			translateAxiom(newAxiom.getSubject(), newAxiom.getProperty(), newAxiom.getObject(), "related");
			
		} else if(axiom instanceof OWLDataPropertyAssertionAxiom){
			OWLDataPropertyAssertionAxiom newAxiom = (OWLDataPropertyAssertionAxiom)axiom;
			translateAxiom(newAxiom.getSubject(), newAxiom.getProperty(), newAxiom.getObject(), "value");
			
		} else {
			printUnableInfo(axiom, "axiom");
		}
	}
	
	private void translateAxiom(			
			Object entity1,
			Object entity2,
			String operator) {
		this.translateAxiom(null, entity1, entity2, null, operator);
	}
	
	private void translateAxiom(			
			Object entity1,
			Object entity2,
			Object entity3,
			String operator) {
		this.translateAxiom(null, entity1, entity2, entity3, operator);
	}
	
	private void translateAxiom(		
			Element superElement,
			Object entity1,
			Object entity2,
			String operator) {
		translateAxiom(superElement, entity1, entity2, null, operator);
	}
	
	private void translateAxiom(		
			Element superElement,
			Object entity1,
			Object entity2,
			Object entity3,
			String operator) {
		Element element = digFile.createElement(operator);
		appendEntityElement(element, entity1);
        appendEntityElement(element, entity2);
        appendEntityElement(element, entity3);
        if(superElement == null){
			root.appendChild(element);
		} else {
			superElement.appendChild(element);
		}	
	}
	private void appendEntityElement(Element element, Object entity){		
		if(entity instanceof OWLClassExpression){
			translateClass(element, (OWLClassExpression)entity);			
		} else if(entity instanceof OWLObjectPropertyExpression){
			translateObjectProperty(element, (OWLObjectPropertyExpression)entity);
		} else if(entity instanceof OWLDataPropertyExpression){
			translateDataProperty(element, (OWLDataPropertyExpression)entity);
		} else if(entity instanceof OWLIndividual){
			translateIndividual(element, (OWLIndividual)entity);
		}
	}
		
	private void translateClass(Element superElement, OWLClassExpression classExpression) {
		if(!classExpression.isAnonymous()){
			OWLClass cl = classExpression.asOWLClass();
			Element element = digFile.createElement("catom");
			element.setAttribute("name", cl.getIRI().toString());	
			superElement.appendChild(element);
			
		} else if(classExpression instanceof OWLObjectUnionOf){
			OWLObjectUnionOf ax = (OWLObjectUnionOf)classExpression;
			this.translateMultiClasses(superElement, ax.getOperands(), "or");
			
		} else if(classExpression instanceof OWLObjectIntersectionOf){
			OWLObjectIntersectionOf ax = (OWLObjectIntersectionOf)classExpression;
			this.translateMultiClasses(superElement, ax.getOperands(), "and");
			
		} else if(classExpression instanceof OWLObjectComplementOf){
			OWLObjectComplementOf ax = (OWLObjectComplementOf)classExpression;
			Element element = digFile.createElement("not");
			translateClass(element, ax.getOperand());
			superElement.appendChild(element);
			
		} else if(classExpression instanceof OWLObjectOneOf){
			OWLObjectOneOf ax = (OWLObjectOneOf)classExpression;
			Element element = digFile.createElement("iset");
			for(OWLIndividual indi : ax.getIndividuals()){
				translateIndividual(element, indi);
			}
			appendElement(superElement, element);
			
		} else if(classExpression instanceof OWLObjectAllValuesFrom){
			OWLObjectAllValuesFrom ax = (OWLObjectAllValuesFrom)classExpression;				
			Element element = digFile.createElement("all");
			translateObjectProperty(element, ax.getProperty());
			translateClass(element, ax.getFiller());	
			appendElement(superElement, element);
			
		} else if(classExpression instanceof OWLObjectSomeValuesFrom){
			OWLObjectSomeValuesFrom ax = (OWLObjectSomeValuesFrom)classExpression;
			Element element = digFile.createElement("some");
			translateObjectProperty(element, ax.getProperty());
			translateClass(element, ax.getFiller());	
			appendElement(superElement, element);
			
		} else if(classExpression instanceof OWLObjectHasValue){
			OWLObjectHasValue ax = (OWLObjectHasValue)classExpression;				
			Element element = digFile.createElement("value");
			translateObjectProperty(element, ax.getProperty());
			translateIndividual(element, ax.getValue());
			appendElement(superElement, element);
			
		} else if(classExpression instanceof OWLObjectMaxCardinality){
			OWLObjectMaxCardinality ax = (OWLObjectMaxCardinality)classExpression;
			translateNumberCardinality(superElement, ax.getProperty(), ax.getFiller(),
					ax.getCardinality(), "max");
			
		} else if(classExpression instanceof OWLObjectMinCardinality){
			OWLObjectMinCardinality ax = (OWLObjectMinCardinality)classExpression;
			translateNumberCardinality(superElement, ax.getProperty(), ax.getFiller(),
					ax.getCardinality(), "min");
			
		} else if((classExpression instanceof OWLObjectExactCardinality) || (classExpression instanceof OWLObjectCardinalityRestriction)){
			OWLObjectCardinalityRestriction ax = (OWLObjectCardinalityRestriction)classExpression;
			Element element = digFile.createElement("and");
			translateNumberCardinality(element, ax.getProperty(), ax.getFiller(),
					ax.getCardinality(), "min");
			translateNumberCardinality(element, ax.getProperty(), ax.getFiller(),
					ax.getCardinality(), "max");
			appendElement(superElement, element);
			
		} else if(classExpression instanceof OWLDataHasValue){
			OWLDataHasValue ax = (OWLDataHasValue)classExpression;				
			
			OWLLiteral literal = ax.getValue();
			if(literal.isInteger()){
				Element element = digFile.createElement("intequals");
				element.setAttribute("val", literal.getLiteral().toString());
				translateDataProperty(element, ax.getProperty());
				appendElement(superElement, element);
			} else {
				Element element = digFile.createElement("stringequals");
				element.setAttribute("val", literal.getLiteral().toString());
				translateDataProperty(element, ax.getProperty());
				appendElement(superElement, element);
			}
			
		} else {
			System.out.println("Cannot translate class : "+classExpression.toString());			
		}
	}
	
	
	private void translateMultiClasses(
			Element superElement,
			Set<OWLClassExpression> concepts,
			String operator) {
		
		Element element = digFile.createElement(operator);
		for(OWLClassExpression concept : concepts) {
			this.appendEntityElement(element, concept);
		}
		if(superElement == null){
			root.appendChild(element);
		} else {
			superElement.appendChild(element);
		}
	}
	
	private void translateObjectProperty(
			Element superElement,
			OWLObjectPropertyExpression ope) {
		
		Element element = null;
		if(!ope.isAnonymous()){
			element = digFile.createElement("ratom");
			OWLObjectProperty op =  ope.asOWLObjectProperty();
			element.setAttribute("name", op.getIRI().toString());
			if(superElement!=null){
				superElement.appendChild(element);
			}
		} else {
			printUnableInfo(ope, "op");
		}
		//return element;
	}
	
	private void translateDataProperty(
			Element superElement,
			OWLDataPropertyExpression dpe) {
		
		if(dpe.isAnonymous()){
			return;
		}
		Element element = digFile.createElement("attribute");
		element.setAttribute("name", dpe.asOWLDataProperty().getIRI().toString());
		appendElement(superElement, element);		
	}
		
	private void translateNumberCardinality(
			Element superElement,
			OWLObjectPropertyExpression property,
			OWLClassExpression classExpression,
			int cardinalityNumber,
			String cardiType) {
		
		Element element = null;
		if (cardiType.equalsIgnoreCase("min")) {
			element = digFile.createElement("atleast");
		} else if(cardiType.equalsIgnoreCase("max")){
			element = digFile.createElement("atmost");
		} 
				
		element.setAttribute("num", cardinalityNumber + "");
		translateObjectProperty(element, property);
		if(classExpression != null){
			translateClass(element, classExpression);
		} else {
			element.appendChild(digFile.createElement("top"));
		}		
		superElement.appendChild(element);
	}
	
	
	private void translateIndividual(Element superElement, OWLIndividual indi) {
		Element element = digFile.createElement("individual");
		element.setAttribute("name", indi.asOWLNamedIndividual().getIRI().toString());
		appendElement(superElement, element);
	}
	
	private void translateOWLLiteral(Element superElement, OWLLiteral literal) {
		
		if(literal.isInteger()){
			Element element = digFile.createElement("intequals");
			element.setAttribute("i", literal.getLiteral().toString());
			superElement.appendChild(element);
		} else {
			Element element = digFile.createElement("stringequals");
			element.setAttribute("s", literal.getLiteral().toString());
			superElement.appendChild(element);
		}
	}
	
	private void appendElement(Element superElement, Element element){
		if(superElement == null){
			root.appendChild(element);
		} else {
			superElement.appendChild(element);
		}
	}
		
	public void outputDoc(String digfilePath){
		try {
            Source source = new DOMSource(digFile);
            StreamResult result = new StreamResult(digfilePath);
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");


            transformer.transform(source, result);
           
            //System.out.println(stringWriter.getBuffer().toString());
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        }
	}
	
	public void printUnableInfo(Object ent, String string){
		if(ent != null)
		    System.out.println("Cannot translate "+string+" : "+ent.toString());
	}

}
