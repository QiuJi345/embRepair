package edu.njupt.radon.utils;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

public class CommonTools {
	

	public static boolean exists(String path){
		File file = new File(path);
		return file.exists();
	}
	
	
	
	public static boolean hasIntersection(HashSet set1, HashSet set2) {
		if(set1.size() > set2.size()){
			for(Object axiom : set2){
				if(set1.contains(axiom)){
					return true;
				}
			}
		} else {
			for(Object axiom : set1){
				if(set2.contains(axiom)){
					return true;
				}
			}
		}
	    return false;
	}
	
	public static boolean hasIntersection(HashSet<OWLAxiom> set1, Vector<OWLAxiom> set2) {
		if(set1.size() > set2.size()){
			for(OWLAxiom axiom : set2){
				if(set1.contains(axiom)){
					return true;
				}
			}
		} else {
			for(OWLAxiom axiom : set1){
				if(set2.contains(axiom)){
					return true;
				}
			}
		}
	    return false;
	}
	
	public static boolean containsAll(Vector<OWLAxiom> set1, Vector<OWLAxiom> set2) {
		if(set1.size() < set2.size()){
			return false;
		} 
		for(OWLAxiom axiom : set2){
			if(set1.contains(axiom)){
				return true;
			}
		}
	    return false;
	}
	
	public static boolean compare(Vector<OWLAxiom> set1, Vector<OWLAxiom> set2) {	
		boolean flag = true;
		long st = System.currentTimeMillis();
		flag = containsAllElementsInSmallSet(set1, set2);
		long time = System.currentTimeMillis() - st;
		System.out.println("Time for comparison of axioms: "+time);
		
		Vector<String> str1 = getStrings(set1);
		Vector<String> str2 = getStrings(set2);
		st = System.currentTimeMillis();
		containsAll1(str1, str2);
		time = System.currentTimeMillis() - st;
		System.out.println("Time for comparison of strings: "+time);
		
	    return flag;
	}
	
	public static boolean containsAllElementsInSmallSet(Vector<OWLAxiom> set1, Vector<OWLAxiom> set2) {	
		for(OWLAxiom axiom : set2){
			if(!set1.contains(axiom)){
				return  false;
			}
		}		
	    return true;
	}
	
	public static boolean containsAll1(Vector<String> set1, Vector<String> set2) {	
		for(String axiom : set2){
			if(!set1.contains(axiom)){
				return  false;
			}
		}		
	    return true;
	}

	public static Vector<String> getStrings(Vector<OWLAxiom> set){
		Vector<String> strings = new Vector<String>();
		for(OWLAxiom axiom : set){
			strings.add(axiom.toString());
		}
		return strings;
	}
	
	public static void deleteFile(String path){
		File f = new File(path);
		if(f.exists()){
			f.delete();
		}
	}
	/*
	 * Obtain all the objects in both S2 and S1.
	 */
	public static HashSet<OWLAxiom> getIntersectSet(
			HashSet<OWLAxiom> s1, 
			HashSet<OWLAxiom> s2){
		
		HashSet<OWLAxiom> s = new HashSet<OWLAxiom>();
		if(s1.size()>=s2.size()){			
			for(OWLAxiom ob : s2){
				if(s1.contains(ob)){
					s.add(ob);
				}
			}
		} else {
			for(OWLAxiom ob : s1){
				if(s2.contains(ob)){
					s.add(ob);
				}
			}
		}
		
		return s;
	}

	public static Set getIntersectSet(
			Set s1, 
			Set s2){
		
		HashSet s = new HashSet();
		if(s1.size()> s2.size()){			
			for(Object ob : s2){
				if(s1.contains(ob)){
					s.add(ob);
				}
			}
		} else {
			for(Object ob : s1){
				if(s2.contains(ob)){
					s.add(ob);
				}
			}
		}
		
		return s;
	}
	
	/**
	 * Combine two sets and do not influence the source sets
	 * 
	 * @param DSet
	 * @param PSet
	 * @return
	 */
    public static HashSet<OWLAxiom> getUnion(HashSet<OWLAxiom> DSet, HashSet<OWLAxiom> PSet) {
		if(DSet == null || PSet == null){
			System.out.println("Can't Union null Sets");
		}

		HashSet<OWLAxiom> DPSet = new HashSet<OWLAxiom>();
		DPSet.addAll(DSet);
		DPSet.addAll(PSet);
		return DPSet;
	}
    
	// Reorder the values by descending order
	public static double[] reorderDSC(double[] d){		
		double temp;
		for(int i=0;i<d.length-1;i++){
			for(int j=i+1;j<d.length;j++){
				if(d[i]<d[j]){
					temp=d[i];
					d[i]=d[j];
					d[j]=temp;
				}
			}
		}
		return d;
	}
	
	// Reorder the values by descending order
	public static Vector<Integer> reorderASC(Set<Integer> d){		
		int temp;
		Vector<Integer> orderedASC = new Vector<Integer>(d);
		for(int i=0;i<orderedASC.size()-1;i++){
			for(int j=i+1;j<orderedASC.size();j++){
				if(orderedASC.get(i)>orderedASC.get(j)){
					temp=orderedASC.get(i);
					orderedASC.set(i, orderedASC.get(j));
					orderedASC.set(j, temp);
				}
			}
		}
		return orderedASC;
	}
    
    /**
     * Get all subsets given a set
     * 
     * @param set The given set
     * @return All the subsets of the given set
     */
    public static HashSet<HashSet<OWLAxiom>> allSubsets(HashSet<OWLAxiom> set){
    	HashSet<HashSet<OWLAxiom>> subsets = new HashSet<HashSet<OWLAxiom>>();    	
    	subsets.add(new HashSet<OWLAxiom>());   //Put an empty set into map
    	for(OWLAxiom a : set){   		
    		HashSet<HashSet<OWLAxiom>> subsetsTemp = (HashSet<HashSet<OWLAxiom>>)subsets.clone();	
    		for(HashSet<OWLAxiom> existingSubset : subsetsTemp){
    			HashSet<OWLAxiom> subset = (HashSet<OWLAxiom>)existingSubset.clone();
    			subset.add(a);
    			subsets.add(subset);
    		}
    	}
    	
    	return subsets;
    }
    

    
    /**
     * Find all subsets of a set and the cardinality of these subsets satisfy a given number
     * 
     * @param set We will find some subsets from this set.
     * @param cardi The given number for cardinality of the subsets
     * @return All the subsets satisfying a given cardinality
     */
    public static HashSet<HashSet<OWLAxiom>> getCardiSubSets(HashSet<OWLAxiom> set, int cardi){
    	HashSet<HashSet<OWLAxiom>> cardiSubsets = new HashSet<HashSet<OWLAxiom>>(); 
    	HashSet<HashSet<OWLAxiom>> allSubsets = allSubsets(set); 
    	
    	for(HashSet<OWLAxiom> existingSubset : allSubsets){			
			if(existingSubset.size()==cardi){
				cardiSubsets.add((HashSet<OWLAxiom>)existingSubset.clone());
			}
		}    	
    	return cardiSubsets;
    }
    
 
    
    public static HashSet<HashSet<OWLAxiom>> getCardiSubSets(
    		HashSet<OWLAxiom> axUnchanged,
    		HashSet<OWLAxiom> ax, int cardi){
    	
    	HashSet<HashSet<OWLAxiom>> cardiSubsets = new HashSet<HashSet<OWLAxiom>>(); 

        if(cardi == axUnchanged.size()+ax.size()){
        	HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>(axUnchanged);
        	subset.addAll(ax);
        	cardiSubsets.add(subset);
    	} else if(cardi == axUnchanged.size()){
    		cardiSubsets.add(new HashSet<OWLAxiom>(axUnchanged));
    	} else if((cardi > (axUnchanged.size()+ax.size()))||(cardi < axUnchanged.size())){
    		cardiSubsets.add(new HashSet<OWLAxiom>());
    	} else {
    		HashSet<HashSet<OWLAxiom>> allSubsets = allSubsets(ax);         	
        	for(HashSet<OWLAxiom> existingSubset : allSubsets){	
        		HashSet<OWLAxiom> tax = new HashSet<OWLAxiom>(axUnchanged);
    			tax.addAll(existingSubset);
    			if(tax.size()==cardi){
    				cardiSubsets.add((HashSet<OWLAxiom>)tax.clone());
    			}
    		} 
    	}    	   	
    	return cardiSubsets;
    }
    

    /**
     * Get axioms from the second set which are not included in the first set
     * 
     * @param srcAxioms
     * @param addedAxioms
     * @return
     */
	public static HashSet<OWLAxiom> getDiffAxioms(Set<OWLAxiom> srcAxioms, Set<OWLAxiom> addedAxioms){
		HashSet<OWLAxiom> diffAxioms = new HashSet<OWLAxiom>();
		for(OWLAxiom a : addedAxioms){
			if(!srcAxioms.contains(a)){
				diffAxioms.add(a);
			}
		}
		return diffAxioms;
	}
	
	public static HashSet<OWLAxiom> getUnion(HashSet<HashSet<OWLAxiom>> Sets) {
		HashSet<OWLAxiom> USet = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> aSet : Sets) {
			USet.addAll(aSet);
		}
		return USet;
	}
	
	/**
	 * prints a short excuse after not understandable input
	 */
	public static void printUsageError() {
		System.out.println("Sorry, didn't understand the command line parameters. Please try entering:");		
	}	
	
	
    public static HashSet<HashSet> powerSet(Set set) {
        HashSet powSet = new HashSet();
        HashSet powNewElements = new HashSet();
        HashSet element = new HashSet();
        HashSet temp = new HashSet();
        
        /* The power set has to contain the empty set */
        powSet.add((HashSet)element.clone());
        
        for (Iterator iterThisSet = set.iterator(); iterThisSet.hasNext(); ) {
            element.clear();
            powNewElements.clear();
            
            element.add(iterThisSet.next());
            
            for (Iterator iterPowerSet = powSet.iterator(); iterPowerSet.hasNext(); ) {
                temp = (HashSet)element.clone();
                temp.addAll((HashSet)iterPowerSet.next());
                powNewElements.add(temp);
            }
            powSet.addAll(powNewElements);
        }
        
        return powSet;
    }

    
	/**
	 * Reorder the values in descendent order
	 * @param vec
	 * @return
	 */
	public static Vector<Double> insertionSortDsc(Vector<Double> vec) {
		Double temp = 0.0;
		for (int k = 0; k < 1000000; k++) {
			for (int i = 1; i < vec.size(); i++) {
				int j = i;
				while (vec.get(j - 1) < vec.get(i)) {
					j--;
					if (j <= 0) {
						break;
					}
				}
				temp = vec.get(i);
				vec.set(i, vec.get(j));
				vec.set(j, temp);
			}
		}
		return vec;
	}
	
	public static void printAxioms(HashSet<OWLAxiom> axioms){
		int i = 0;
		for(OWLAxiom axiom : axioms){
			System.out.println("["+(i++)+"] "+axiom.toString());;
		}
		System.out.println();
	}
	
	public static void printAxioms(Vector<OWLAxiom> axioms){
		printAxioms(new HashSet<OWLAxiom>(axioms));
	}
	
	
	/**
	 * Print all the axioms in an ontology
	 * @param onto
	 */
	public static void printAxioms(OWLOntology onto){
		System.out.println();		
		int i = 0;
		for(OWLAxiom axiom : OWLTools.getAxioms(onto, null)){
			System.out.println("["+(i++)+"] "+axiom.toString());;
		}
		System.out.println();		
	}	
	
	public static void printMultiVectors(
			Vector<Vector<OWLAxiom>> sets, 
			String ns){
		if(ns==null)
			ns = "";
		int i = 0;
		if(sets!=null){
			for(Vector<OWLAxiom> one : sets){
				System.out.println("<"+(i++)+">");
				printOneSet(one,ns,null);
			}
		}
	}
	
	
	public static void printMultiSets(
			HashSet<HashSet<OWLAxiom>> sets, 
			String ns){
		
		if(ns==null)
			ns = "";
		int i = 1;
		if(sets!=null){
			for(HashSet<OWLAxiom> one : sets){
				System.out.println("Explanation <"+(i++)+">");
				printOneSet(one,ns);
			}
		}
	}
	
	public static void printMultiSets(
			Vector<HashSet<OWLAxiom>> sets, 
			String ns,
			HashMap<OWLAxiom,Double> confvalues){
		
		if(ns==null)
			ns = "";
		int i = 0;
		if(sets!=null){
			for(HashSet<OWLAxiom> one : sets){
				System.out.println("<"+(i++)+">");
				printOneSet(new Vector<OWLAxiom>(one),ns, confvalues);
			}
		}
	}
	
	public static void printMultiSets(
			HashSet<HashSet<OWLAxiom>> sets, 
			String ns,
			HashMap<OWLAxiom,Double> confvalues){
		
		if(ns==null)
			ns = "";
		int i = 0;
		if(sets!=null){
			for(HashSet<OWLAxiom> one : sets){
				System.out.println("<"+(i++)+">");
				printOneSet(new Vector<OWLAxiom>(one),ns, confvalues);
			}
		}
	}
	
	public static void printOneSet(
			Vector<OWLAxiom> set,
			String ns,
			HashMap<OWLAxiom,Double> confvalues){	
		
		int i = 1;
		if(set!=null){
			Double value = null;
			for(OWLAxiom a : set){
				if(confvalues!=null){
					value = confvalues.get(a);
					if(value==null)
						value = new Double(1.0);
					if(ns!=null)
					    System.out.println("  ["+(i++)+"] "+a.toString().replace(ns, "")+" : "+value);
					else 
						System.out.println("  ["+(i++)+"] "+a.toString()+" : "+value);
				} else {
					if(ns!=null)
					    System.out.println("  ["+(i++)+"] "+a.toString().replace(ns, ""));
					else 
						System.out.println("  ["+(i++)+"] "+a.toString());
				}				
			}
			System.out.println();
		}
	}
		
	
	public static void printOneSet(
			HashSet<OWLAxiom> set,
			String ns){
		
		Vector<OWLAxiom> set_c = new Vector<OWLAxiom>(set);
	    printOneSet(set_c,ns,null);		
	}


	public static void mkdirs(String path){		
		File file = new File(path);
		if(!file.exists()){
			file.mkdirs();
		}
	}
}
