
package edu.njupt.radon.utils.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 04.08.2007
 */
public class PrintStreamObject {
	
	static String path = null;
	
	public PrintStreamObject(String p){
		path = p;
		int index = path.lastIndexOf('/');
		if(index!=-1){
			if(!(index==path.length()-1)){
				path += "/";
			}
		}
	}
	
	/* redirect anything sent to System.out to log file */
    public static PrintStream ps = new PrintStream(System.out){
	
	public void println(String x){
		FileOutputStream appendedFile;
		try {
			appendedFile = new FileOutputStream(path, true);
			PrintStream p = new PrintStream(appendedFile);				
			p.println(x);
			p.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void print(String x){
		FileOutputStream appendedFile;
		try {
			appendedFile = new FileOutputStream(path, true);
			PrintStream p = new PrintStream(appendedFile);
			p.print(x);
			p.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void println(){
		FileOutputStream appendedFile;
		try {
			appendedFile = new FileOutputStream(path, true);
			PrintStream p = new PrintStream(appendedFile);
			p.println();
			p.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}
	
};

}
