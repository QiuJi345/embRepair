package edu.njupt.radon.utils.io;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OntologyUtils;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ReadMUPSMain {

	public static String ontoName = "AROMA-cmt-cocus"; //km1500-4000 proton_100_all
	public static String ontoPath = "file:///F:/Data/debugging/journal-paper-data/incoherent/oaei2012/"+ontoName+".owl";
	public static String mupsPath = "data/mups.txt";
	public static String newOntoPath = "data/mups.owl";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
				
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		HashMap<String, OWLAxiom> strAxiomMap = new HashMap<String, OWLAxiom>();
		for(OWLAxiom axiom : onto.getLogicalAxioms()){
			strAxiomMap.put(axiom.toString(), axiom);
		}
		
		HashSet<OWLAxiom> mups = getOneMUPS(mupsPath, strAxiomMap);
		CommonTools.printAxioms(mups);
		System.out.println(ReasoningTools.isCoherent(mups));
		System.out.println(ReasoningTools.getUnsatiConcepts(mups));
		OWLOntology o = OntologyUtils.getOntologyFromAxioms(mups);
		OntologyUtils.save(o, newOntoPath);
		
		readOnto("file:"+newOntoPath);
	}
	
	public static void readOnto(String ontoPath){
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		CommonTools.printAxioms(axioms);
	}
	
	public static HashSet<OWLAxiom> getOneMUPS(String filePath, HashMap<String, OWLAxiom> strAxiomMap) {
		HashSet<OWLAxiom> mups = new HashSet<OWLAxiom>();
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(filePath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {		
				String axiomStr = null;
				int index = strLine.indexOf("] ");
				if(index == -1){
					index = strLine.indexOf("]");
					axiomStr = strLine.substring(index+1);
				} else {
					axiomStr = strLine.substring(index+2);
				}
				if(strAxiomMap.containsKey(axiomStr)){
					OWLAxiom axiom = strAxiomMap.get(axiomStr);
					mups.add(axiom);
				} else {
					System.err.println("Cannot tranfer the string <"+axiomStr+"> to an owlAxiom!");
				}
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
		return mups;
	}
	
	public static HashSet<OWLAxiom> getMultiMUPS(String filePath, HashMap<String, OWLAxiom> strAxiomMap) {
		HashSet<OWLAxiom> mups = new HashSet<OWLAxiom>();
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(filePath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {		
				String axiomStr = null;
				int index = strLine.indexOf("] ");
				if(index == -1){
					index = strLine.indexOf("]");
					axiomStr = strLine.substring(index+1);
				} else {
					axiomStr = strLine.substring(index+2);
				}
				if(strAxiomMap.containsKey(axiomStr)){
					OWLAxiom axiom = strAxiomMap.get(axiomStr);
					mups.add(axiom);
				} else {
					System.err.println("Cannot tranfer the string <"+axiomStr+"> to an owlAxiom!");
				}
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
		return mups;
	}

}
