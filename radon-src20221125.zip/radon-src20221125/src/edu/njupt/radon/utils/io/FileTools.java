package edu.njupt.radon.utils.io;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Vector;

public class FileTools {
	
	
	public static void checkPath(String path){
		// Check the path to store results
		File file = new File(path);
		if(!file.exists()){
			file.mkdirs();
		} 
		System.setOut((new PrintStreamObject(path+"log.txt")).ps);
	}
	
	public static boolean fileExists(String path){
		// Check the path to store results
		boolean exists = false;
		File file = new File(path);
		if(!file.exists()){
			file.mkdirs();
		} else {
			exists = true;
		}
		return exists;
	}

	public static boolean createNewFile(String path){
		File f = new File(path);
		if(!f.exists()){
			return f.mkdirs();
		}
		return false;
	}
	
	public static void deleteFile(String path){
		File f = new File(path);
		if(f.exists()){
			f.delete();
		}
	}
	
	
	public static boolean isLogFileExists(String path){
		File f = new File(path);
		return f.exists();		
	}
	
	public static String getString(String filePath) {
		String text = "";
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(filePath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {				
				text += strLine + "\n";
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
		return text;
	}
	
	public static Vector<String> getStringVector(String filePath) {
		Vector<String> text = new Vector<String>();
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(filePath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {	
				if(strLine.trim().length()==0){
					continue;
				}
				text.add(strLine);
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			//System.err.println("Error: " + e.getMessage());
		}
		return text;
	}
	
}
