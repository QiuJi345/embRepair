package edu.njupt.radon.utils.io;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;

public class MyPrinter {
	
	/**
	 * prints a short excuse after not understandable input
	 */
	public static void printUsageError() {
		System.out.println("Sorry, didn't understand the command line parameters. Please try entering:");		
	}
	
	public static void printMultiSets(
			HashSet<HashSet<OWLAxiom>> sets, 
			String ns){
		
		if(ns==null)
			ns = "";
		int i = 0;
		if(sets!=null){
			for(HashSet<OWLAxiom> one : sets){
				System.out.println("Found explanation <"+(i++)+">");
				printOneSet(one,ns);
			}
		}
	}
	
	public static void printMultiSets(
			HashSet<HashSet<OWLAxiom>> sets, 
			String ns,
			HashMap<OWLAxiom,Double> confvalues){
		
		if(ns==null)
			ns = "";
		int i = 0;
		if(sets!=null){
			for(HashSet<OWLAxiom> one : sets){
				System.out.println("<"+(i++)+">");
				printOneSet(new Vector<OWLAxiom>(one),ns, confvalues);
			}
		}
	}
	
	public static void printOneSet(
			Vector<OWLAxiom> set,
			String ns,
			HashMap<OWLAxiom,Double> confvalues){	
		
		int i = 0;
		if(set!=null){
			Double value = null;
			for(OWLAxiom a : set){
				if(confvalues!=null){
					value = confvalues.get(a);
					if(value==null)
						value = new Double(1.0);
					if(ns!=null)
					    System.out.println("  ["+(i++)+"] "+a.toString().replace(ns, "")+" : "+value);
					else 
						System.out.println("  ["+(i++)+"] "+a.toString()+" : "+value);
				} else {
					if(ns!=null)
					    System.out.println("  ["+(i++)+"] "+a.toString().replace(ns, ""));
					else 
						System.out.println("  ["+(i++)+"] "+a.toString());
				}				
			}
			System.out.println();
		}
	}
		
	
	public static void printOneSet(
			HashSet<OWLAxiom> set,
			String ns){
		
		Vector<OWLAxiom> set_c = new Vector<OWLAxiom>(set);
	    printOneSet(set_c,ns,null);		
	}
	
	public static void printAxioms(Set<OWLAxiom> axioms){
		System.out.println();
		int i = 0;
		for(OWLAxiom axiom : axioms){
			System.out.println("["+(i++)+"] "+axiom.toString());;
		}
		System.out.println();
	}
	
	public static void printAxioms(HashSet<OWLAxiom> axioms){
		System.out.println();
		int i = 0;
		for(OWLAxiom axiom : axioms){
			System.out.println("["+(i++)+"] "+axiom.toString());;
		}
		System.out.println();
	}
		
	public static void printMultiVectors(
			Vector<Vector<OWLAxiom>> sets, 
			String ns){
		if(ns==null)
			ns = "";
		int i = 0;
		if(sets!=null){
			for(Vector<OWLAxiom> one : sets){
				System.out.println("<"+(i++)+">");
				printOneSet(one,ns,null);
			}
		}
	}

}
