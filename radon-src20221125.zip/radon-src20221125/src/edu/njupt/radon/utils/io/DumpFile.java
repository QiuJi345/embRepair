
package edu.njupt.radon.utils.io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;



/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 22.07.2007
 */
public class DumpFile {
	
	
	public static void dumpObject(String dumpFile,
			Object ob) {
		try {

			FileOutputStream objfile = new FileOutputStream(dumpFile);
			ObjectOutputStream p = new ObjectOutputStream(objfile);
			p.writeObject(ob);
			p.flush();
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void dumpMUPS(String dumpFile,
			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups) {
		try {

			FileOutputStream objfile = new FileOutputStream(dumpFile);
			ObjectOutputStream p = new ObjectOutputStream(objfile);
			p.writeObject(mups);
			p.flush();
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void dumpMips(String dumpFile,
			HashSet<HashSet<OWLAxiom>> mips) {
		try {

			FileOutputStream objfile = new FileOutputStream(dumpFile);
			ObjectOutputStream p = new ObjectOutputStream(objfile);
			p.writeObject(mips);
			p.flush();
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void dumpAxiomSets(String dumpFile,
			HashSet<HashSet<OWLAxiom>> axiomSets) {
		try {

			FileOutputStream objfile = new FileOutputStream(dumpFile);
			ObjectOutputStream p = new ObjectOutputStream(objfile);
			HashSet<HashSet<String>> stringSets = new HashSet<HashSet<String>>();
			for(HashSet<OWLAxiom> axiomSet : axiomSets){
				HashSet<String> stringSet = new HashSet<String>();
				for(OWLAxiom axiom : axiomSet){
					stringSet.add(axiom.toString());
				}
				stringSets.add(stringSet);
			}
			p.writeObject(stringSets);
			p.flush();
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void dumpAxioms(String dumpFile,
			HashSet<OWLAxiom> currentAxioms) {
		try {

			FileOutputStream objfile = new FileOutputStream(dumpFile);
			ObjectOutputStream p = new ObjectOutputStream(objfile);
			p.writeObject(currentAxioms);
			p.flush();
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void dumpMap(String dumpFile,
			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> map) {
		try {

			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> m = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();

			for (OWLClass c : map.keySet()) {
				HashSet<HashSet<OWLAxiom>> mm = new HashSet<HashSet<OWLAxiom>>();
				for (HashSet<OWLAxiom> mups : map.get(c)) {
					HashSet<OWLAxiom> ms = new HashSet<OWLAxiom>();
					for (OWLAxiom ma : mups) {
						ms.add(ma);
					}
					mm.add(ms);
				}
				m.put(c, mm);
			}

			FileOutputStream objfile = new FileOutputStream(dumpFile);
			ObjectOutputStream p = new ObjectOutputStream(objfile);
			p.writeObject(m);
			p.flush();
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Object getObject (String dumpFile){
		Object ob = null;
		try {
			
			FileInputStream objfile = new FileInputStream(dumpFile);
			ObjectInputStream p = new ObjectInputStream(objfile);
			ob = p.readObject();			
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return ob;
	}

	public static HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPSFromFile(String dumpFile){
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = null;
		try {
			
			FileInputStream objfile = new FileInputStream(dumpFile);
			ObjectInputStream p = new ObjectInputStream(objfile);
			mups = (HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>)p.readObject();			
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mups;
	}
	
	public static HashSet<HashSet<OWLAxiom>> getMIPSFromFile(String dumpFile){
		HashSet<HashSet<OWLAxiom>> mips = null;
		try {
			
			FileInputStream objfile = new FileInputStream(dumpFile);
			ObjectInputStream p = new ObjectInputStream(objfile);
			mips = (HashSet<HashSet<OWLAxiom>>)p.readObject();			
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mips;
	}
	
	public static HashSet<OWLAxiom> getAxiomsFromFile(String dumpFile){
		HashSet<OWLAxiom> as = null;
		try {
			
			FileInputStream objfile = new FileInputStream(dumpFile);
			ObjectInputStream p = new ObjectInputStream(objfile);
			as = (HashSet<OWLAxiom>)p.readObject();			
			objfile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return as;
	}

}
