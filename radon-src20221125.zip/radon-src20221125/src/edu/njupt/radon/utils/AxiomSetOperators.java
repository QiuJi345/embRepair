package edu.njupt.radon.utils;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAxiom;

public class AxiomSetOperators {

	/*
	 * Obtain all the objects in both S2 and S1.
	 */
	public static HashSet<OWLAxiom> getIntersectSet(
			HashSet<OWLAxiom> s1, 
			HashSet<OWLAxiom> s2){
		
		HashSet<OWLAxiom> s = new HashSet<OWLAxiom>();
		if(s1.size()>=s2.size()){			
			for(OWLAxiom ob : s2){
				if(s1.contains(ob)){
					s.add(ob);
				}
			}
		} else {
			for(OWLAxiom ob : s1){
				if(s2.contains(ob)){
					s.add(ob);
				}
			}
		}
		
		return s;
	}

	
	/**
	 * Combine two sets and do not influence the source sets
	 * 
	 * @param DSet
	 * @param PSet
	 * @return
	 */
    public static HashSet<OWLAxiom> getUnion(HashSet<OWLAxiom> DSet, HashSet<OWLAxiom> PSet) {
		if(DSet == null || PSet == null){
			System.out.println("Can't Union null Sets");
		}

		HashSet<OWLAxiom> DPSet = new HashSet<OWLAxiom>();
		DPSet.addAll(DSet);
		DPSet.addAll(PSet);
		return DPSet;
	}
    
    /**
     * Get all subsets given a set
     * 
     * @param set The given set
     * @return All the subsets of the given set
     */
    public static HashSet<HashSet<OWLAxiom>> allSubsets(HashSet<OWLAxiom> set){
    	HashSet<HashSet<OWLAxiom>> subsets = new HashSet<HashSet<OWLAxiom>>();    	
    	subsets.add(new HashSet<OWLAxiom>());   //Put an empty set into map
    	for(OWLAxiom a : set){   		
    		HashSet<HashSet<OWLAxiom>> subsetsTemp = (HashSet<HashSet<OWLAxiom>>)subsets.clone();	
    		for(HashSet<OWLAxiom> existingSubset : subsetsTemp){
    			HashSet<OWLAxiom> subset = (HashSet<OWLAxiom>)existingSubset.clone();
    			subset.add(a);
    			subsets.add(subset);
    		}
    	}
    	
    	return subsets;
    }
    
    public static HashSet<HashSet> powerSet(Set set) {
        HashSet powSet = new HashSet();
        HashSet powNewElements = new HashSet();
        HashSet element = new HashSet();
        HashSet temp = new HashSet();
        
        /* The power set has to contain the empty set */
        powSet.add((HashSet)element.clone());
        
        for (Iterator iterThisSet = set.iterator(); iterThisSet.hasNext(); ) {
            element.clear();
            powNewElements.clear();
            
            element.add(iterThisSet.next());
            
            for (Iterator iterPowerSet = powSet.iterator(); iterPowerSet.hasNext(); ) {
                temp = (HashSet)element.clone();
                temp.addAll((HashSet)iterPowerSet.next());
                powNewElements.add(temp);
            }
            powSet.addAll(powNewElements);
        }
        
        return powSet;
    }


	public static boolean isIntersectant(HashSet set1, HashSet set2) {
		boolean flag = false;
		for (Object ob : set1) {
			if (set2.contains(ob)) {
				flag = true;
				break;
			}
		}
		return flag;
	}

    
    /**
     * Find all subsets of a set and the cardinality of these subsets satisfy a given number
     * 
     * @param set We will find some subsets from this set.
     * @param cardi The given number for cardinality of the subsets
     * @return All the subsets satisfying a given cardinality
     */
    public static HashSet<HashSet<OWLAxiom>> cardiSubSets(HashSet<OWLAxiom> set, int cardi){
    	HashSet<HashSet<OWLAxiom>> cardiSubsets = new HashSet<HashSet<OWLAxiom>>(); 
    	HashSet<HashSet<OWLAxiom>> allSubsets = allSubsets(set); 
    	
    	for(HashSet<OWLAxiom> existingSubset : allSubsets){			
			if(existingSubset.size()==cardi){
				cardiSubsets.add((HashSet<OWLAxiom>)existingSubset.clone());
			}
		}    	
    	return cardiSubsets;
    }
    

    
    public static HashSet<HashSet<OWLAxiom>> cardiSubSets(HashSet<OWLAxiom> axUnchanged,
    		HashSet<OWLAxiom> ax, int cardi){
    	
    	HashSet<HashSet<OWLAxiom>> cardiSubsets = new HashSet<HashSet<OWLAxiom>>(); 
    	HashSet<HashSet<OWLAxiom>> allSubsets = allSubsets(ax); 
    	
    	for(HashSet<OWLAxiom> existingSubset : allSubsets){	
    		HashSet<OWLAxiom> tax = new HashSet<OWLAxiom>(axUnchanged);
			tax.addAll(existingSubset);
			if(tax.size()==cardi){
				cardiSubsets.add((HashSet<OWLAxiom>)tax.clone());
			}
		}    	
    	return cardiSubsets;
    }
    

    /**
     * Get axioms from the second set which are not included in the first set
     * 
     * @param srcAxioms
     * @param addedAxioms
     * @return
     */
	public static HashSet<OWLAxiom> getDiffAxioms(Set<OWLAxiom> srcAxioms, Set<OWLAxiom> addedAxioms){
		HashSet<OWLAxiom> diffAxioms = new HashSet<OWLAxiom>();
		for(OWLAxiom a : addedAxioms){
			if(!srcAxioms.contains(a)){
				diffAxioms.add(a);
			}
		}
		return diffAxioms;
	}
	
	public static HashSet<OWLAxiom> getUnion(HashSet<HashSet<OWLAxiom>> Sets) {
		HashSet<OWLAxiom> USet = new HashSet<OWLAxiom>();
		for (HashSet<OWLAxiom> aSet : Sets) {
			USet.addAll(aSet);
		}
		return USet;
	}
	
}
