package edu.njupt.radon.utils.weights;

import java.util.HashMap;
import java.util.regex.Matcher;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLTools;

public class SubclassOfRelationParser extends GeneralParser {

	@Override
	public HashMap<OWLAxiom, Double> parseNextInstance(Matcher matcher) {
		
		HashMap<OWLAxiom, Double> result = new HashMap<OWLAxiom, Double>();

		// TODO Auto-generated method stub
		String subClsStr = matcher.group(1).replace(" ", "_")+"_c";
		String superClsStr = matcher.group(2).replace(" ", "_")+"_c";

		Double valueDouble = Double.parseDouble(matcher.group(3));

		OWLClass subClass = OWLTools.getOWLClassWithLocalName(ontology, subClsStr);
		OWLClass superClass = OWLTools.getOWLClassWithLocalName(ontology, superClsStr);		
		if (subClass != null && superClass != null) {
			OWLSubClassOfAxiom newSubClassOf = OWL.factory.getOWLSubClassOfAxiom(subClass, superClass);			
			result.put(newSubClassOf, valueDouble);
		} else {
			System.out.println("[Warning] Fail to translate string <"+matcher.group()+"> to an OWL axiom");
		}
		return result;
	}

	@Override
	String genPatternString() {
		//str to match: subclass-of( frog, vertebrate )=1.0
		String patternStr = "subclass-of\\(\\s?(.*?)\\s?,\\s?(.*?)\\s?\\)=([0-1]\\.[0-9]+),";
		return patternStr;
		
	}

}
