package edu.njupt.radon.utils.weights;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

public abstract class GeneralParser {
	OWLOntology ontology;
	String sText;

	
	/** the patternStr corresponds to the string pattern for matching a type of axiom
	 * it must be override by each sub-class */
	abstract String genPatternString();

	public GeneralParser(){

	}
	
	
	public void  init(String sTextIn, OWLOntology ontologyIn){
		sText = sTextIn;
		ontology = ontologyIn;
	}
	
	public HashMap<OWLAxiom, Double> parse() {
		HashMap<OWLAxiom, Double> hmAxiom2Value = new HashMap<OWLAxiom, Double>();
		
		//str to match: instance-of( florida, coast )=0.8840761072811479
		String patternStr = genPatternString();
		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(sText);

		boolean matchFound = matcher.find();
		while (matchFound) {
			// add next axiom, value pair 
			HashMap<OWLAxiom, Double> nextInstance = parseNextInstance(matcher);
			if (nextInstance != null){
				hmAxiom2Value.putAll(parseNextInstance(matcher));
			}
			
			
			if (matcher.end() + 1 <= sText.length()) {
				matchFound = matcher.find(matcher.end());
			} else {
				break;
			}
		}
		
	
		return hmAxiom2Value;
	}
	
	
	/** define how to construct axiom from the string got from pattern
	 *  must be overriden by each sub-class
	 * @param matcher
	 * @return
	 */
	abstract public HashMap<OWLAxiom, Double> parseNextInstance(Matcher matcher);


	
}
