package edu.njupt.radon.utils.weights;

import java.util.HashMap;
import java.util.regex.Matcher;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyRangeAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLTools;

public class RelationParser extends GeneralParser {


	@Override
	public HashMap<OWLAxiom, Double> parseNextInstance(Matcher matcher) {
		
		HashMap<OWLAxiom, Double> result = new HashMap<OWLAxiom, Double>();

		// TODO Auto-generated method stub
		String objectPropertyStr = matcher.group(1)+"_r";
		String domainStr = matcher.group(2).replace(" ", "_")+"_c";
		String rangeStr = matcher.group(3).replace(" ", "_")+"_c";

		Double valueDouble = Double.parseDouble(matcher.group(4));
		
		OWLObjectProperty op = OWLTools.getOWLObjectPropertyWithLocalName(ontology, objectPropertyStr);
		OWLClass domainCls = OWLTools.getOWLClassWithLocalName(ontology, domainStr);
		OWLClass rangeCls = OWLTools.getOWLClassWithLocalName(ontology, rangeStr);
		if (domainCls != null && rangeCls != null && op != null) {
			OWLObjectPropertyDomainAxiom  opd = OWL.factory.getOWLObjectPropertyDomainAxiom(op, domainCls);
			OWLObjectPropertyRangeAxiom opr = OWL.factory.getOWLObjectPropertyRangeAxiom(op,rangeCls);

			result.put(opd, valueDouble);
			result.put(opr, valueDouble);
		} else {
			System.out.println("[Warning] Fail to translate string <"+matcher.group()+"> to an OWL axiom");
		}		
		return result;
	}

	@Override
	String genPatternString() {
		//str to match: grow_in( eduli, association )=1.0
		String patternStr = "\\s?(.*?)\\(\\s?(.*?)\\s?,\\s?(.*?)\\s?\\)=([0-1]\\.[0-9]+),";
		return patternStr;
	}

}
