package edu.njupt.radon.utils.weights;

import java.util.HashMap;
import java.util.regex.Matcher;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLIndividual;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLTools;

public class InstanceOfRelationParser extends GeneralParser {
	

	@Override
	public HashMap<OWLAxiom, Double> parseNextInstance(Matcher matcher) {
		
		HashMap<OWLAxiom, Double> result = new HashMap<OWLAxiom, Double>();

		String indStr = matcher.group(1);
		String clsStr = matcher.group(2);

		Double valueDouble = Double.parseDouble(matcher.group(3));
		OWLClass cls = OWLTools.getOWLClassWithLocalName(ontology, clsStr);
		OWLIndividual ind = OWLTools.getIndividualWithLocalName(ontology, indStr);
		if (cls != null && ind != null) {
			OWLClassAssertionAxiom newClassMember = OWL.factory.getOWLClassAssertionAxiom(cls, ind);
			result.put(newClassMember, valueDouble);
		}
		return result;
	}


	@Override
	String genPatternString() {
		String patternStr = "instance-of\\(\\s?(.*?)\\s?,\\s?(.*?)\\s?\\)=([0-1]\\.[0-9]+)";
		return patternStr;
	}

}
