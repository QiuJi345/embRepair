package edu.njupt.radon.utils.weights;

import java.util.HashMap;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

public class TopParser {
	GeneralParser parser;
	StringBuffer sbText;
	OWLOntology ontology;

	
	public void init( OWLOntology ontology ){
		this.ontology = ontology;
	}
	
	
	final static  String[] axiomTag = {
		//"org.ontoware.text2onto.pom.POMInstanceOfRelation",
		"org.ontoware.text2onto.pom.POMDisjointClasses",
		"org.ontoware.text2onto.pom.POMSubclassOfRelation",
		"org.ontoware.text2onto.pom.POMRelation"
	};
	
	final static String[] parser4axiomTag = {
		//"InstanceOfRelationParser",
		"DisjointClassesParser",
		"SubclassOfRelationParser",
		"RelationParser"
	};
	
	
	public HashMap<OWLAxiom, Double> parseAll(String sText){
		sbText = new StringBuffer(sText);
		HashMap<OWLAxiom, Double> hmAxiom2Value = new HashMap<OWLAxiom, Double>();
	    
		do {
	   	
	    	int intClassBegin = sbText.indexOf("class org");	    	
	    	int nextClassBeginIndex = -1;	    	
	    	if (intClassBegin == -1){
	    		break;
	    	}
	    	sbText = new StringBuffer( sbText.substring(intClassBegin + "class ".length()) );

	    	
	        if (sbText.equals("")){
	        	break;
	        }
	        
	        for ( int index = 0 ; index < axiomTag.length; index ++){
	        	if (sbText.toString().startsWith(axiomTag[index])){
	        		nextClassBeginIndex = sbText.indexOf("class org");
	        		
	        		// skip the head
	        		StringBuffer subText = new StringBuffer(sbText.substring(axiomTag[index].length() + 2));
		        		
	        		if (intClassBegin < nextClassBeginIndex){
	        			subText = new StringBuffer(subText.substring(0,nextClassBeginIndex));
	        		}
	        		
	        		String packageName = this.getClass().getPackage().getName().toString();
	    			
	        		String parserStr =  packageName + "." + parser4axiomTag[index];
	    			
	        		try {
	    				parser = (GeneralParser)Class.forName(parserStr).newInstance();
	    			} catch (InstantiationException e) {
	    				e.printStackTrace();
	    			} catch (IllegalAccessException e) {
	    				e.printStackTrace();
	    			} catch (ClassNotFoundException e) {
	    				e.printStackTrace();
	    			}
	    			
	    			parser.init(subText.toString(), ontology);
	    			
	    			try{
	    			    hmAxiom2Value.putAll(parser.parse());
	    			}catch(Exception e){
	    				// when parser returns null, do nothing
	    			}        		
	        		
	    			break;
	        	}
	        }
	    
	
		}while(true);
		
		return hmAxiom2Value;
		
	}
	
}
