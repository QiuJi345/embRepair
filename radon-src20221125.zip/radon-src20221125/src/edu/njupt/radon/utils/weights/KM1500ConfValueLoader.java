package edu.njupt.radon.utils.weights;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.DumpFile;


public class KM1500ConfValueLoader {
	final static String root = "D:/Programming/debug/partialConflict/data/";
	final static String srcOntologyURL = "file:"+root+"km1500/km1500_i500.owl";

	static String txtFile = root+"km1500/axiomConf.txt";
	
	static String dumpPath = root+"km1500/";
	
	public static void main(String[] args) throws Exception {
		
        
        OWLOntology ontology = OWLTools.openOntology(srcOntologyURL);
		
		
		File file = new File(txtFile);
		String sText = getText(file);
		
		TopParser parser = new TopParser();
		parser.init(ontology);
		HashMap<OWLAxiom,Double> hmAxiom2Value = parser.parseAll(sText);

		file = new File(dumpPath);
		if(!file.exists())
			file.mkdirs();
		DumpFile.dumpObject(dumpPath+"km1500_i500.dump", hmAxiom2Value);
		for (OWLAxiom a : hmAxiom2Value.keySet()){
			System.out.println(a.toString() + " " + hmAxiom2Value.get(a));
		}		
	}

	public static String getText(File file) {
		StringBuffer sbText = new StringBuffer();
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(file));
			String sLine = null;
			while ((sLine = reader.readLine()) != null) {
				sbText.append(sLine.trim() + "\n");
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return sbText.toString();
	}
	

}
