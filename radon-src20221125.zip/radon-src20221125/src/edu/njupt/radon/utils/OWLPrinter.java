package edu.njupt.radon.utils;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;

public class OWLPrinter {
	
	public static void printClasses(OWLOntology onto){
		System.out.println("\n**** Classes *******\n");
		int i = 0;
		for(OWLClass oc : onto.getClassesInSignature()){
			System.out.println("<"+(i++)+"> "+oc.toString());
		}
	}
	
	public static void printClasses(OWLOntology onto, String s_filler){
		System.out.println("\n**** Classes *******\n");
		int i = 0;
		for(OWLClass oc : onto.getClassesInSignature()){
			String s_oc = oc.getIRI().toString();
			if(s_filler != null && s_oc.startsWith(s_filler)){
				System.out.println("<"+(i++)+"> "+oc.toString());
			}			
		}
	}
	
	public static void printClasses(Set<OWLClass> ocs){
		int i = 0;
		for(OWLClass oc : ocs){
			System.out.println("<"+(i++)+"> "+oc.toString());
		}
	}
	
	public static void printObjectProperty(OWLOntology onto){
		System.out.println("\n**** Object Properties *******\n");
		int i = 0;
		for(OWLObjectProperty op : onto.getObjectPropertiesInSignature()){
			System.out.println("<"+(i++)+"> "+op.toString());
		}
	}
	
	public static void printObjectProperty(OWLOntology onto, String s_filler){
		System.out.println("\n**** Object Properties *******\n");
		int i = 0;
		for(OWLObjectProperty op : onto.getObjectPropertiesInSignature()){
			String s_op = op.getIRI().toString();
			if(s_filler != null && s_op.startsWith(s_filler)){
				System.out.println("<"+(i++)+"> "+op.toString());
			}	
		}
	}
	
	public static void printDataProperty(OWLOntology onto){
		System.out.println("\n**** Data Properties *******\n");
		int i = 0;
		for(OWLDataProperty dp : onto.getDataPropertiesInSignature()){
			System.out.println("<"+(i++)+"> "+dp.toString());
		}
	}
	
	public static void printDataProperty(OWLOntology onto, String s_filler){
		System.out.println("\n**** Data Properties *******\n");
		int i = 0;
		for(OWLDataProperty dp : onto.getDataPropertiesInSignature()){
			String s_dp = dp.getIRI().toString();
			if(s_filler != null && s_dp.startsWith(s_filler)){
				System.out.println("<"+(i++)+"> "+dp.toString());
			}
		}
	}
	
	public static void printIndividuals(OWLOntology onto){
		System.out.println("**** Individuals *******");
		int i = 0;
		for(OWLNamedIndividual indi : onto.getIndividualsInSignature()){
			System.out.println("<"+(i++)+"> "+indi.toString());
		}
	}
	
	
	public static void printLogicAxioms(OWLOntology onto){
		System.out.println("**** Logic Axioms *******");
		int i = 0;
		for(OWLAxiom a : onto.getLogicalAxioms()){
			System.out.println("<"+(i++)+"> "+a.toString());
		}
	}
	
	public static void printAxioms(OWLOntology onto){
		System.out.println("**** Axioms *******");
		int i = 0;
		for(OWLAxiom a : onto.getAxioms()){
			System.out.println("<"+(i++)+"> "+a.toString());
		}
	}
	
	public static void printAxiomSets(HashSet<HashSet<OWLAxiom>> sets, String message){
		int counter = 0;
		for(HashSet<OWLAxiom> set : sets){
			counter ++;
			System.out.println(message + " "+counter);			
			printAxiomSet(set);
		}
	}
	
	public static void printAxiomSet(HashSet<OWLAxiom> set){
		int axiomCounter = 0;
		for(OWLAxiom axiom : set){
			System.out.println((axiomCounter++)+"> "+axiom);
		}
		System.out.println();
	}

}
