
package edu.njupt.radon.utils;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

/**
 * TODO Provide some useful tools.s
 *
 * @author Qiu Ji 
 * @date 21.11.2007
 */
public class OrderingTools {	

	// Reorder the values by descending order
	public static double[] reorder(double[] d){		
		double temp;
		for(int i=0;i<d.length-1;i++){
			for(int j=i+1;j<d.length;j++){
				if(d[i]<d[j]){
					temp=d[i];
					d[i]=d[j];
					d[j]=temp;
				}
			}
		}
		return d;
	}
	
	public static Vector getRandomOrder(HashSet set){
		Vector<Object> originalSet = new Vector<Object>(set);
		Vector<Object> newSet = new Vector<Object>();
		Random r = new Random();
		while(originalSet.size()>0){
			int index = r.nextInt(originalSet.size());
			newSet.add(originalSet.get(index));
			originalSet.remove(index);
		}
		return newSet;
	}
	
//	 Reorder the values by descending order
	public static Vector<Double> reorderDesending(Vector<Double> v){				
		int num=v.size();
		for(int i=0;i<num-1;i++){ 
			for(int j=i+1;j<num;j++){
				Double vi=v.get(i);
				Double vj=v.get(j);
				if(vi<vj){					
					v.set(i, vj);
					v.set(j, vi);
				}
			}
		}
		return v;
	}
	
//	 Reorder the values by ascending order
	public static Vector<Double> reorderAscending(Vector<Double> v){				
		int num=v.size();
		for(int i=0;i<num-1;i++){ 
			for(int j=i+1;j<num;j++){
				Double vi=v.get(i);
				Double vj=v.get(j);
				if(vi>vj){					
					v.set(i, vj);
					v.set(j, vi);
				}
			}
		}
		return v;
	}
	
//	 Reorder the values by descending order
	public static Vector<Double> halfSearch(int begin, int length, 
			Vector<Double> v, double d){	
		
		int pos = (length-begin)/2;
				
		if(v.size()==0)
			v.add(d);
		else{
			if(d==v.get(pos))
				v.insertElementAt(d, pos);				
			else if((pos==0)&&(d>v.get(begin)))
				v.insertElementAt(d, begin);
			else if((pos==0)&&(d<v.get(begin)))
				v.insertElementAt(d, begin+1);
			else if(((length-begin)==2)&&(d<v.get(pos)))
				v.insertElementAt(d, length);
			else if((d>v.get(pos))&&(pos>0))
				halfSearch(begin, pos-1, v,d);			
			else if((d<v.get(pos))&&(pos>0))
				halfSearch(pos+1, length-1, v, d);	
		}	
				
		return v;
	}
	
	/**
	 * Sort the values in ascendent order
	 * 
	 * @param vec
	 *            The values to be ordered
	 * @return : The ordered values in ascendent order
	 */
	public static Vector<Double> insertionSortAsc(Vector<Double> vec) {
		Double temp = 0.0;
		for (int k = 0; k < 1000000; k++) {
			for (int i = 1; i < vec.size(); i++) {
				int j = i;
				while (vec.get(j - 1) > vec.get(i)) {
					j--;
					if (j <= 0) {
						break;
					}
				}
				temp = vec.get(i);
				vec.set(i, vec.get(j));
				vec.set(j, temp);
			}
		}
		return vec;
	}

	

	
	
	

	/**
	 * Reorder the values in descendent order
	 * @param vec
	 * @return
	 */
	public static Vector<Double> insertionSortDsc(Vector<Double> vec) {
		Double temp = 0.0;
		for (int k = 0; k < 1000000; k++) {
			for (int i = 1; i < vec.size(); i++) {
				int j = i;
				while (vec.get(j - 1) < vec.get(i)) {
					j--;
					if (j <= 0) {
						break;
					}
				}
				temp = vec.get(i);
				vec.set(i, vec.get(j));
				vec.set(j, temp);
			}
		}
		return vec;
	}
	

	
	




}
