package edu.njupt.radon.utils;

import java.io.File;
import java.util.Vector;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class BatchFileGenerator {
	
	static String libraries = ".;radon.jar;"+DebuggingParameters.libraries;
		
	static String fixedPara = "";
	/**
	 * @param args
	 */
	public static void main(String[] args) {	
		String reasoner = "factpp";
		generateAllBatchFile(reasoner);
	}
	
	public static void generateAllBatchFile(String reasoner){
		String batchFilePath = "results/" + "radonExplain-" + reasoner+".bat";	
		System.setOut((new PrintStreamObject(batchFilePath)).ps);		
		
		generateAllBatchFile("consistent-tbox", reasoner);
		generateAllBatchFile("incoherent", reasoner);
	    //generateAllBatchFile("inconsistent", reasoner);
	}
	
	public static void generateAllBatchFile(String debugTask, String reasoner){	
        fixedPara = "-to 1000000 -re "+reasoner+" -or data/ -rr results/"+reasoner+"/ -dm radonRelAll -dt "+debugTask+" -on ";
		if(debugTask.equalsIgnoreCase("inconsistent")){
			generateBatchForInconsistency();
		} else {
			generateBatchForEntailments(debugTask);
		}
	}
	
	public static void generateBatchForInconsistency(){				
		String prefix = DebuggingParameters.preFixedPara + libraries +
				"edu.seu.cse.radon.debug.main.explanation.RaDONMIS "+ fixedPara;      
		
		String path = DebuggingParameters.ontoRoot + "inconsistent/";
		File file = new File(path);
		for(File ontoFile : file.listFiles()){
			if(ontoFile.isDirectory()){
				continue;
			}
			String name = ontoFile.getName();
			name = name.substring(0, name.lastIndexOf("."));
			if(!name.equalsIgnoreCase("nifstd")){
				continue;
			}
			String commandLine = prefix + name;
			System.out.println(commandLine);
			System.out.println();			
		}
		
	}
	
	public static void generateBatchForEntailments(String debugTask){	
		DebuggingParameters.debugTask = debugTask;
		boolean dealWithIncoherence = false;
		if(DebuggingParameters.debugTask.contains("incoherent")){
			dealWithIncoherence = true;
		}
				
		String prefix = "";
		if(dealWithIncoherence){
			prefix = DebuggingParameters.preFixedPara + libraries +
			        "edu.seu.cse.radon.debug.main.explanation.RaDONMUPS " + fixedPara;      
		} else {
			prefix = DebuggingParameters.preFixedPara + libraries +
			        "edu.seu.cse.radon.debug.main.explanation.RaDONJusts " + fixedPara;      
		}
		
		String path = DebuggingParameters.ontoRoot + debugTask + "/";
		File file = new File(path);
		for(File ontoFile : file.listFiles()){
			if(ontoFile.isDirectory()){
				continue;
			}

			String name = ontoFile.getName();
			name = name.substring(0, name.lastIndexOf("."));
			if(!name.equalsIgnoreCase("km1500-5000")){
				continue;
			}
			
			String entailmentsFile = DebuggingParameters.ontoRoot +DebuggingParameters.debugTask+ 
					"/inferred/"+ name + ".txt";
			
			String specificPrefix = prefix + name;
			Vector<String> selectedEntailmentStrings = FileTools.getStringVector(entailmentsFile);
			for(String entailmentStr : selectedEntailmentStrings){	
				if(entailmentStr.contains(" types ")){
					entailmentStr = entailmentStr.replace(" types ", "-types-");
				} else if(entailmentStr.contains(" subClassOf ")){
					entailmentStr = entailmentStr.replace(" subClassOf ", "-subClassOf-");
				} 
				if(dealWithIncoherence){
					String commandLine = specificPrefix + " -un "+entailmentStr;
					System.out.println(commandLine);	
				} else {
					String commandLine = specificPrefix + " -en "+entailmentStr;
					System.out.println(commandLine);
				}				
				System.out.println();
			}
		}
		
	
	}
}
