package edu.njupt.radon.utils.mapping;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owl.align.Cell;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import edu.njupt.radon.utils.OWLTools;
import fr.inrialpes.exmo.align.impl.BasicAlignment;
import fr.inrialpes.exmo.align.parser.AlignmentParser;


public class MappingUtils {
	//public static variables
	public static int numberOfDecimal = 10; //10^n indicates n decimal.
	
	// 
	public static double threshold = 0.2;

	//private static variables

	//public variables

	//private variables
	public static HashSet<Vector<String>> getCorrespondences(String mappingPath) {
		HashSet<Vector<String>> corres = new HashSet<Vector<String>>();
		Vector<String> corr = new Vector<String>();
		
		AlignmentParser p = new AlignmentParser(0);
		try{
			BasicAlignment align = (BasicAlignment)p.parse(mappingPath);
			for(Cell cell : align.getArrayElements()){
				String ent1Str = cell.getObject1AsURI().toString();
				String ent2Str = cell.getObject2AsURI().toString();
				String relation = cell.getRelation().getRelation();
				String sim = String.valueOf(cell.getStrength());
				Double d = Double.valueOf(sim);
				if(d < threshold){
					continue;
				}
				d = (double)(Math.round(d*numberOfDecimal)/(double)numberOfDecimal);
	            sim = String.valueOf(d);
				corr = new Vector<String>();
				corr.add(ent1Str);
				corr.add(ent2Str);
				corr.add(relation);
				corr.add(sim);
				corres.add(new Vector<String>(corr));
			}
		} catch (Exception ex){
			ex.printStackTrace();
		}
		
		return corres;
	}
	
	public static HashMap<OWLAxiom, Double> transfer(
			OWLOntology sourceOnto, 
			OWLOntology targetOnto,
			HashSet<Vector<String>> corres) {
		HashMap<OWLAxiom, Double> mapping = new HashMap<OWLAxiom, Double>();
		//System.out.println("========== begin =========");
		for(Vector<String> corr : corres){						
			OWLAxiom axiom = createMappingAxiom(sourceOnto, targetOnto, 
					corr.get(0), corr.get(1), corr.get(2));
			if(axiom == null){
				System.out.println("Ingnore this correspondence: "+corr.get(0)+", "+corr.get(1)+": "+corr.get(2));
				continue;
			}
			mapping.put(axiom, Double.valueOf(corr.get(3)));
		}
		//System.out.println("========== end =========");
		return mapping;
	}
	
	public static HashMap<OWLAxiom, Double> transfer(OWLOntology sourceOnto, OWLOntology targetOnto,
			String path) throws Exception {
		HashMap<OWLAxiom, Double> mapping = new HashMap<OWLAxiom, Double>();
		HashSet<Vector<String>> corres = getCorrespondences(path);
		for(Vector<String> corr : corres){						
			OWLAxiom axiom = createMappingAxiom(sourceOnto, targetOnto, 
					corr.get(0), corr.get(1), corr.get(2));
			if(axiom == null){
				continue;
			}
			mapping.put(axiom, Double.valueOf(corr.get(3)));
		}
		return mapping;
	}

	public static OWLAxiom createMappingAxiom(
			OWLOntology sourceOnto, OWLOntology targetOnto, 
			String str1, String str2,
			String relation) {
		OWLAxiom corrAxiom = null;
		OWLEntity ent1, ent2;
		
        ent1 = OWLTools.getEntity(sourceOnto, str1);
        ent2 = OWLTools.getEntity(targetOnto, str2);
        
        OWLOntologyManager manager = OWLTools.manager;
        if(manager == null){
        	manager = OWLTools.createOntologyManager();
        }
    	OWLDataFactory factory = manager.getOWLDataFactory();
        if((ent1!=null)&&(ent2!=null)){        	
        	if((ent1 instanceof OWLClass)&&(ent2 instanceof OWLClass)){
        		Vector<OWLClass> ents = new Vector<OWLClass>();
        		ents.add((OWLClass)ent1);
        		ents.add((OWLClass)ent2);            	
            	
            	if((relation!=null)&&(relation.equals("<"))){            		
            		corrAxiom = factory.getOWLSubClassOfAxiom(ents.get(0), ents.get(1));
            	} else if((relation!=null)&&(relation.equals(">"))){
            		corrAxiom = factory.getOWLSubClassOfAxiom(ents.get(1), ents.get(0));
            	} else if((relation!=null)&&(relation.equals("<>"))){
            		corrAxiom = factory.getOWLDisjointClassesAxiom(ents.get(0), ents.get(1));
            	} else {
            		corrAxiom = factory.getOWLEquivalentClassesAxiom(new HashSet<OWLClass>(ents));
            	}        		
        		
        	} else if((ent1 instanceof OWLObjectProperty)&&
        			(ent2 instanceof OWLObjectProperty)){
        		Vector<OWLObjectPropertyExpression> ents = new Vector<OWLObjectPropertyExpression>();
        		ents.add((OWLObjectPropertyExpression)ent1);
        		ents.add((OWLObjectPropertyExpression)ent2); 
            	if((relation!=null)&&(relation.equals("<"))){
            		corrAxiom = factory.getOWLSubObjectPropertyOfAxiom(ents.get(0), ents.get(1));
            	} else if((relation!=null)&&(relation.equals(">"))){
            		corrAxiom = factory.getOWLSubObjectPropertyOfAxiom(ents.get(1), ents.get(0));
            	} else if((relation!=null)&&(relation.equals("<>"))){
            		HashSet<OWLObjectPropertyExpression> entities = new HashSet<OWLObjectPropertyExpression>(ents);
            		corrAxiom = factory.getOWLDisjointObjectPropertiesAxiom(entities);
            	} else {
            		corrAxiom = factory.getOWLEquivalentObjectPropertiesAxiom(
            				new HashSet<OWLObjectPropertyExpression>(ents));
            	}  
        		
        	} else if((ent1 instanceof OWLDataPropertyExpression)&&(ent2 instanceof OWLDataPropertyExpression)){
        		Vector<OWLDataPropertyExpression> ents = new Vector<OWLDataPropertyExpression>();
        		ents.add((OWLDataPropertyExpression)ent1);
            	ents.add((OWLDataPropertyExpression)ent2);
            	if((relation!=null)&&(relation.equals("<"))){
            		corrAxiom = factory.getOWLSubDataPropertyOfAxiom(ents.get(0), ents.get(1));
            	} else if((relation!=null)&&(relation.equals(">"))){
            		corrAxiom = factory.getOWLSubDataPropertyOfAxiom(ents.get(1), ents.get(0));
            	} else if((relation!=null)&&(relation.equals("<>"))){
            		HashSet<OWLDataPropertyExpression> entities = new HashSet<OWLDataPropertyExpression>(ents);
            		corrAxiom = factory.getOWLDisjointDataPropertiesAxiom(entities);
            	} else {
            		corrAxiom = factory.getOWLEquivalentDataPropertiesAxiom(
            				new HashSet<OWLDataPropertyExpression>(ents));
            	}  
        		
        	} else if((ent1 instanceof OWLIndividual)&&(ent2 instanceof OWLIndividual)){        		
            	Vector<OWLIndividual> ents = new Vector<OWLIndividual>();
        		ents.add((OWLIndividual)ent1);
            	ents.add((OWLIndividual)ent2);            	
        		corrAxiom = factory.getOWLSameIndividualAxiom(new HashSet<OWLIndividual>(ents));
        	} else {
        		System.err.println("The correspondence cannot be transferred to an axiom.");
        		System.err.println(ent1.toString()+" "+relation+" "+ent2.toString()+"\n");
        	}
        }
		
		return corrAxiom;		
	}	

	public static HashMap<OWLAxiom, Double> cutAlignment(
			HashMap<OWLAxiom, Double> alignment,
			double threshold){
		HashMap<OWLAxiom, Double> alignment_new = new HashMap<OWLAxiom, Double>();
		for(OWLAxiom axiom : alignment.keySet()){
			double sim = alignment.get(axiom);
			if(sim>=threshold){
				alignment_new.put(axiom, sim);
			}
		}
		return alignment_new;
	}
	
	public static HashSet<Vector<String>> cutAlignment(
			HashSet<Vector<String>> alignment,
			double threshold){
		HashSet<Vector<String>> alignment_new = new HashSet<Vector<String>>();
		for(Vector<String> corr : alignment){			
			double sim = Double.valueOf(corr.get(3));
			if(sim>=threshold){
				alignment_new.add(new Vector<String>(corr));
			}
		}
		return alignment_new;
	}
	
	public static HashMap<Double, HashSet<OWLAxiom>> getLayers(
			HashSet<OWLAxiom> axioms,
			HashMap<OWLAxiom, Double> axiomWeightMap){
		HashMap<Double, HashSet<OWLAxiom>> weightAxiomsMap = new HashMap<Double, HashSet<OWLAxiom>>();
		for(OWLAxiom axiom : axioms){
			double weight = 1.0;
			if(axiomWeightMap.containsKey(axiom)){
				weight = axiomWeightMap.get(axiom);
			}
			if(weightAxiomsMap.containsKey(weight)){
				weightAxiomsMap.get(weight).add(axiom);
			} else {
				HashSet<OWLAxiom> set = new HashSet<OWLAxiom>();
				set.add(axiom);
				weightAxiomsMap.put(weight, set);
			}
		}
		return weightAxiomsMap;
	}
}
