package edu.njupt.radon.utils;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class IncoherencePrinter {
	
	public static void printAllUnsatConcepts(OWLOntology onto, OWLOntologyManager manager){
		HashSet<OWLClass> unsatConcepts = ReasoningTools.getUnsatiConcepts(onto, manager);
		printUnsatConcepts(unsatConcepts);
	}
	
	public static void printAllUnsatConcepts(HashSet<OWLAxiom> axioms){
		HashSet<OWLClass> unsatConcepts = ReasoningTools.getUnsatiConcepts(axioms);
		printUnsatConcepts(unsatConcepts);
	}
	
	public static void printUnsatConcepts(HashSet<OWLClass> unsatConcepts){
		int counter = 1;
		for(OWLClass unsatConcept : unsatConcepts){
			System.out.println(" UC <"+(counter++)+"> "+unsatConcept.getIRI().toString());
		}
	}

}
