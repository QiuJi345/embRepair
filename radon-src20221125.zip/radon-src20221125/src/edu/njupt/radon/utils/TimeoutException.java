
package edu.njupt.radon.utils;

@SuppressWarnings("serial")
public class TimeoutException extends Exception {
}
