package edu.njupt.radon.utils;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Random;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class EvenSampling {
		
	static int samplingNumber = 3;
	
	static int samplingTimes = 5;

	static int inferredAxiomsNum = 0;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//System.out.println("Ontology : "+DebuggingParameters.ontoName);
		
		String resultsPath = DebuggingParameters.ontoRoot + "consistent/inferredAxioms/"+DebuggingParameters.ontoName+".txt";
		resultsPath = "g:/Data/sel.txt";
		// String dataSet = "tbox-realWorld";
		//String ontoPath = "file:"+ontoRoot+dataSet+"/"+ontoName+".owl";
		//Vector<String> originalStrings = getUCString(ontoPath);
		
		String axiomsPath = DebuggingParameters.ontoRoot + "consistent/inferredAxioms/allentailments/"+DebuggingParameters.ontoName+".txt";
		axiomsPath = "G:/Data/inf.txt";
		Vector<String> originalStrings = getAxiomStrings(axiomsPath);
		
		//String axiomOntoPath = DebuggingParameters.ontoRoot + "consistent/bio/"+DebuggingParameters.ontoName+"/selectedentailments.xml";
		//Vector<String> originalStrings = getSelectedStrings(axiomOntoPath);
			
		
		HashSet<String> selectedStrings = getSelectedStrings(originalStrings);		
		saveResultsToFile(selectedStrings, resultsPath);
	}
	
	public static Vector<String> getSelectedStrings(String entailmentsPath){
		OWLOntology onto = OWLTools.openOntology(entailmentsPath);
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		inferredAxiomsNum = axioms.size();
		Vector<String> axiomStrings = new Vector<String>();
		for(OWLAxiom axiom : axioms){
			// We only consider the cases that each line contains three words.
			if(axiom instanceof OWLSubClassOfAxiom){
				OWLSubClassOfAxiom subAxiom = (OWLSubClassOfAxiom)axiom;
				String subString = subAxiom.getSubClass().asOWLClass().getIRI().toString();
				String supString = subAxiom.getSuperClass().asOWLClass().getIRI().toString();
				axiomStrings.add(subString+" subClassOf "+supString);
			} else if(axiom instanceof OWLClassAssertionAxiom){
				OWLClassAssertionAxiom assertion = (OWLClassAssertionAxiom)axiom;
				String type = assertion.getClassExpression().asOWLClass().getIRI().toString();
				String indiString = assertion.getIndividual().asOWLNamedIndividual().getIRI().toString();
				axiomStrings.add(indiString+" types "+type);
			}
		}
		return axiomStrings;
	}
	
	public static HashSet<String> getSelectedStrings(Vector<String> originalStrings){
		
		System.out.println("*******************************************");		
		System.out.println("Inferred axioms: "+inferredAxiomsNum);
		System.out.println();
		
		HashSet<String> allSelectedStrings = new HashSet<String>();		
		if(inferredAxiomsNum <= 15){
			allSelectedStrings.addAll(originalStrings);
		} else {
			for(int i =0; i < samplingTimes; i++){
				System.out.println("[Info] Sampling <"+i+">");
				Vector<String> selectedStrings = sampling(originalStrings);
				System.out.println();
				allSelectedStrings.addAll(selectedStrings);
			}			
		}
		
		
		System.out.println("All selected concepts or entailments ("+allSelectedStrings.size()+")");
		// Output all selected Strings		
		for(String s : allSelectedStrings){
			System.out.println(s);
		}
		return allSelectedStrings;
		
	}
	
	public static void saveResultsToFile(HashSet<String> allSelectedStrings, String resultsPath){
		System.setOut((new PrintStreamObject(resultsPath)).ps);
		// Output all selected Strings		
		for(String s : allSelectedStrings){
			System.out.println(s);
		}
	}
	
	public static Vector<String> getAxiomStrings(String axiomStringsPath){
		Vector<String> axiomStrings = new Vector<String>();
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(axiomStringsPath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {					
				// If the last word in this line is "Thing", we will ignore this line.
				if(strLine.indexOf(" Thing") != -1 || 
						strLine.indexOf(" http://www.w3.org/2002/07/owl#Thing") != -1){
					continue;
				}
				inferredAxiomsNum ++;
				// We only consider the cases that each line contains three words.
				String[] strArray = strLine.split(" ");
				if(strArray.length == 3){
					axiomStrings.add(strLine);
				}				
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
		return axiomStrings;
	}
	
	public static Vector<String> getUCStrings(String ontoPath){
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto, OWLTools.manager);
		Vector<String> strs = new Vector<String>();
		for(OWLClass uc : ucs){
			strs.add(uc.getIRI().toString());
		}
		return strs;
	}

	public static Vector<String> sampling(Vector<String> inputStrings){
		Vector<String> randomSelectedStrings = new Vector<String>();
		int length = inputStrings.size();
		Random random = new Random();
		if(length > 5){
			for(int counter = 0; counter < samplingNumber; counter++){
				int randomValue = random.nextInt(length);
				String selectedString = inputStrings.get(randomValue);
				randomSelectedStrings.add(selectedString);
				System.out.println(selectedString);
			}
			return randomSelectedStrings;
		} else {
			return inputStrings;
		}
	}
	
}
