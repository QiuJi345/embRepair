package edu.njupt.radon.utils.reasoning;

import static edu.njupt.radon.utils.reasoning.InconsistencyTools.checkMISCorrectness;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLTools;

public class InconsistencyTools {
	
	
	public static HashSet<HashSet<OWLAxiom>> getMUPS(HashSet<HashSet<OWLAxiom>> confs, 
			OWLClass oc)  {
		HashSet<HashSet<OWLAxiom>> mups = new HashSet<HashSet<OWLAxiom>>();
		int i = 0;
		for(HashSet<OWLAxiom> conf : confs){
			HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(conf);
			HashSet<OWLAxiom> oneMUPS = new HashSet<OWLAxiom>(conf);
			if(ucs.contains(oc)){			
				for(OWLAxiom a : conf){
					oneMUPS.remove(a);
					HashSet<OWLClass> ucs2 = ReasoningTools.getUnsatiConcepts(oneMUPS);					
					if(!ucs2.contains(oc)){
						oneMUPS.add(a);
					} else {
						System.out.println("This set is not a minimal");
					}
				}
				mups.add(new HashSet<OWLAxiom>(oneMUPS));
			} else {
				printOneMUPS(conf, i++);
				System.out.println("This set is not a super set of a MUPS w.r.t. "+oc.toString());
			}	
		}		
		return mups;
	}

	public static void checkMISCorrectness(HashSet<HashSet<OWLAxiom>> allMIS){
		if(allMIS != null && allMIS.size()>0){
			int i = 0;
			for(HashSet<OWLAxiom> oneMIS : allMIS){
				printOneMUPS(oneMIS, i++);
				checkOneMISCorrectness(oneMIS);	
				System.out.println("--------------------------");
			}		
		}
	}
	
	public static boolean checkOneMISCorrectness(HashSet<OWLAxiom> mis) {		
		if(!ReasoningTools.isConsistent(mis)){		
			HashSet<OWLAxiom > mis_copy = new HashSet<OWLAxiom>(mis);
			for(OWLAxiom axiomInMIS : mis){
				mis_copy.remove(axiomInMIS);
				if(!ReasoningTools.isConsistent(mis_copy)){
					mis_copy.add(axiomInMIS);
					System.out.println("[Info] This mis is not minimal.");
					System.out.println("[Info] This axiom is redundant: "+axiomInMIS.toString());
					return false;					
				}
				mis_copy.add(axiomInMIS);
			}
			System.out.println("[Info] Is it a real MIS? true");			
			return true;
		} else {
			System.out.println("[Info] This mis is consistent!");
			return false;
		}
	}
	
	
	public static void checkMUPSCorrectness(HashSet<HashSet<OWLAxiom>> mups, OWLClass oc){
		if(mups != null && mups.size()>0){
			int i = 0;
			for(HashSet<OWLAxiom> oneMUPS : mups){
				printOneMUPS(oneMUPS, i++);
				checkOneMUPSCorrectness(oneMUPS, oc);	
				System.out.println("--------------------------");
			}		
		}
	}
	
	
	
	public static void checkEntailments(HashSet<OWLAxiom> mups, OWLClass oc) {	
		OWLClass class2 = OWL.factory.getOWLClass(IRI.create("http://cocus#Person"));
		OWLAxiom axiom = OWL.factory.getOWLSubClassOfAxiom(oc, class2);
		axiom = OWL.factory.getOWLEquivalentClassesAxiom(class2,OWL.factory.getOWLThing());
		System.out.println(ReasoningTools.canBeEntailed(mups, axiom));
	}
	
	/*public static boolean checkOneMUPSCorrectness(HashSet<OWLAxiom> mups, OWLClass oc) {	
		boolean isReal = true;
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(mups);
		HashSet<OWLAxiom> oneMUPS = new HashSet<OWLAxiom>(mups);
		if(ucs.contains(oc)){			
			for(OWLAxiom a : mups){
				oneMUPS.remove(a);
				HashSet<OWLClass> ucs2 = ReasoningTools.getUnsatiConcepts(oneMUPS);					
				if(ucs2.contains(oc)){
					System.out.println("[Info] Is it a real MUPS w.r.t. concept <"+oc.toString()+"> ? false");	
					//System.out.println("[Info] This mups is not minimal.");
					System.out.println("[Info] This axiom is redundant: "+a.getAxiomWithoutAnnotations().toString());
					//OWLTools.saveOntology(mups, "file:///e:/data/temp/mups_"+(n++)+".owl");
					isReal = false;			
				} else {
					oneMUPS.add(a);
				}
			}			
		} else {
			System.out.println("[Info] Is it a real MUPS w.r.t. concept <"+oc.toString()+"> ? false");	
			System.out.println("[Info] This mups is coherent w.r.t. "+oc.toString());
			isReal = false;
		}
		if(isReal){
			System.out.println("[Info] Is it a real MUPS w.r.t. concept <"+oc.toString()+"> ? true");
		}
		return isReal;
	}
	*/
	
	public static boolean checkOneMUPSCorrectness(HashSet<OWLAxiom> mups, OWLClass oc) {	
		boolean isReal = true;
		HashSet<OWLAxiom> oneMUPS = new HashSet<OWLAxiom>(mups);
		if(ReasoningTools.isSatisfiable(mups, oc)){
			System.out.println("[Info] Is it a real MUPS w.r.t. concept <"+oc.toString()+"> ? false");	
			System.out.println("[Info] This mups is coherent w.r.t. "+oc.toString());
			isReal = false;
		}
		
		for(OWLAxiom a : mups){
			//System.out.println("h: "+ReasoningTools.isSatisfiable(mups, oc));
			oneMUPS.remove(a);				
			if(!ReasoningTools.isSatisfiable(oneMUPS, oc)){
				System.out.println("[Info] Is it a real MUPS w.r.t. concept <"+oc.toString()+"> ? false");	
				//System.out.println("[Info] This mups is not minimal.");
				System.out.println("[Info] This axiom is redundant: "+a.getAxiomWithoutAnnotations().toString());
				//OWLTools.saveOntology(mups, "file:///e:/data/temp/mups_"+(n++)+".owl");
				isReal = false;			
			} else {
				oneMUPS.add(a);
			}
		}			
		
		if(isReal){
			System.out.println("[Info] Is it a real MUPS w.r.t. concept <"+oc.toString()+"> ? true");
		}
		return isReal;
	}
	
				
	public static void mupsAnalysis(Set<Set<OWLAxiom>> mups, OWLClass oc){
		if(mups != null && mups.size()>0){
			int totalSize = 0;
			int minSize = 1000;
			int maxSize = 0;
			for(Set<OWLAxiom> one : mups){
				int size = one.size();
				totalSize += size;
				if(minSize > size){
					minSize = size;
				}
				if(maxSize < size){
					maxSize = size;
				}
			}		
			System.out.println(" Total size of the found MUPS: "+totalSize);
			System.out.println(" Minimal size of the found MUPS: "+minSize);
			System.out.println(" Maximal size of the found MUPS: "+maxSize);
		}
	}
	
	public static void mupsAnalysis(HashSet<HashSet<OWLAxiom>> mups, OWLClass oc){
		if(mups != null && mups.size()>0){
			int totalSize = 0;
			int minSize = 1000;
			int maxSize = 0;
			for(Set<OWLAxiom> one : mups){
				int size = one.size();
				totalSize += size;
				if(minSize > size){
					minSize = size;
				}
				if(maxSize < size){
					maxSize = size;
				}
			}		
			System.out.println(" Total size of the found MUPS: "+totalSize);
			System.out.println(" Minimal size of the found MUPS: "+minSize);
			System.out.println(" Maximal size of the found MUPS: "+maxSize);
		}
	}
	
	public void printMultipleMUPS(HashSet<HashSet<OWLAxiom>> multipleMUPS){		
		printMultipleMUPS(multipleMUPS, null);
	}
	
	public void printMultipleMUPS(HashSet<HashSet<OWLAxiom>> multipleMUPS, OWLClass unsatConcept){		
		int i = 0;
		for(HashSet<OWLAxiom> oneMUPS : multipleMUPS){
			printOneMUPS(oneMUPS, ++i, unsatConcept);
		}
	}
	
    public static void printOneMUPS(HashSet<OWLAxiom> mups, int n){
    	printOneMUPS(mups, n, null);
	}
    
    private static int ontoNumber = 1;
    public static void printOneMUPS(HashSet<OWLAxiom> mups, int mupsID, OWLClass unsatConcept){    	
    	System.out.println("Found a new Set <"+mupsID+">");
    	// An counter of axioms in a mups
    	int axiomCounter = 0;
    	boolean needToSave = false;
    	for(OWLAxiom a : mups){
    		if(unsatConcept == null){
    			System.out.println("    ["+(axiomCounter++)+"] "+a.getAxiomWithoutAnnotations().toString());
        	} else {
        		System.out.println("    ["+(axiomCounter++)+"] "+a.getAxiomWithoutAnnotations().toString()+ 
        				" for concept <"+unsatConcept.getIRI().toString()+">");        		
        	}
    		if(a.toString().contains("ObjectAllValuesFrom")){
    			needToSave = true;
    		}
		}
    	if(needToSave){
    		try{
				OWLTools.saveOntology(mups, "file:///d:/temp/just"+mups.size()+"-"+(ontoNumber++));
			} catch (Exception ex){
				ex.printStackTrace();
			}
    	}
    	System.out.println();
	}
    	

	

    public static void printAxiomSet(HashSet<OWLAxiom> axiomSet, int setID, String setInfo){    	
    	System.out.println("Found a new " +setInfo+" <"+setID+">");
    	// An counter of axioms in the set
    	int axiomCounter = 0;
    	// Iterate all axioms in the set
    	for(OWLAxiom axiom : axiomSet){
    		// Output an axim
    		System.out.println("    ["+(axiomCounter++)+"] "+axiom.toString());		
		}
    	// Output a blank line
    	System.out.println();
	}
 
}
