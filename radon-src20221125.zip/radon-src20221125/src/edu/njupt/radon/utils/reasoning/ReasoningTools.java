package edu.njupt.radon.utils.reasoning;

import java.util.HashSet;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.Timer;


/**
 * In this class, we provide the functionalities to check 
 * satisfiable, consistent, coherent. Specifically:
 * 
 * 1) Satisfiable: We consider a concept in one ontology
 * as satisfiable if it is not semantically equal to owl:Nothing.  
 * 
 * 2) Coherent: We consider an ontology is incoherent if this
 * ontology has at least on unsatisifiable concept.
 * 
 * 3) Consistent: We consider an ontology is inconsistent if there
 * is no model in the ontology.
 * 
 * @author Qiu Ji
 *
 */
public class ReasoningTools {
	
	public static void setReasoner(String reasoner){
		ReasoningTask.reasoner = reasoner;
	}
	
	public static boolean canBeEntailed(
			HashSet<OWLAxiom> o,
			HashSet<OWLAxiom> unwantedAxioms) {
				
		for(OWLAxiom unwantedAxiom : unwantedAxioms){
			if(canBeEntailed(o, unwantedAxiom)){				
				return true;
			}
		}
		return false;
	}
	
	public static boolean canBeEntailed(HashSet<OWLAxiom> axioms, OWLAxiom axiom){
				
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		boolean canBeEntailedoriginal = false;
		boolean canBeEntailedmodified = false;
		try{
			OWLOntology onto = manager.createOntology( axioms );
			ReasoningTask task = new ReasoningTask(onto, manager);
			canBeEntailedoriginal = task.isEntailed(axiom);
					
			for(OWLClass oc : axiom.getClassesInSignature()){
				if(!onto.containsClassInSignature(oc.getIRI())){	
					System.out.println("    A signature <"+oc.getIRI().toString()+"> is not contained in the set of axioms.");
					OWLDataFactory factory = manager.getOWLDataFactory();
					OWLClass dumyClass = factory.getOWLClass(IRI.create("http://radon.org#"+System.currentTimeMillis()));
					OWLAxiom dumyAxiom = factory.getOWLSubClassOfAxiom(oc, dumyClass);
					manager.addAxiom(onto, dumyAxiom);
					//System.out.println(onto.containsClassInSignature(oc.getIRI()));
					//manager.removeAxiom(onto, dumyAxiom);
					//System.out.println(onto.containsClassInSignature(oc.getIRI()));
				}
			}
			task = new ReasoningTask(onto, manager);
			canBeEntailedmodified = task.isEntailed(axiom);
			//CommonTools.printAxioms(onto);
			System.out.println("   Can be entailed in origninal and modified set? "+canBeEntailedoriginal
					+", "+canBeEntailedmodified+", size="+onto.getLogicalAxiomCount());
			System.out.println("--------------------------------");
			
		} catch (OWLOntologyCreationException ex){
			ex.printStackTrace();
		}	
		return canBeEntailedoriginal;
	}
	
	public static boolean isIntersectant(HashSet<OWLEntity> set1, HashSet<OWLEntity> set2) {
		boolean flag = false;
		for (OWLEntity ob : set1) {
			if (set2.contains(ob)) {
				flag = true;
				break;
			}
		}
		return flag;
	}
	
	public static HashSet<OWLEntity> getSignatures(HashSet<OWLAxiom> axioms){
		// Obtain all signatures in the set of axioms in unwantedAxioms
		HashSet<OWLEntity> ents = new HashSet<OWLEntity>();
		for(OWLAxiom a : axioms){
			ents.addAll(a.getSignature());
		}
		return ents;
	}
    /**
     * Check whether a MUPS w.r.t. an unsatisfiable concept is real or not
     * according to the definition of a MUPS. That is, a MUPS is a minimal
     * unsatisfiability-preserving subset.
     * 
     * @param mups
     * @param oc
     * @param onto
     * @return
     */
    public static boolean checkMUPS(
    		HashSet<OWLAxiom> mups, 
    		OWLClass oc, 
    		OWLOntology onto){ 
    	
    	HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(mups);    	
    	boolean flag = true;    	
    	for(OWLAxiom a : mups){
    		System.out.println("removed axiom : "+a.toString());
    		allAxioms.remove(a);
    		if(!isSatisfiable(allAxioms, oc, null)){
    			flag = false;
    			break;
    		}
    		allAxioms.add(a);
    	}
    	return flag;	
    }
    
    
    //************************************************
	// Check whether an ontology is consistent or not
    //************************************************
    
	
	public static boolean isConsistent(
			OWLOntologyManager conn, 
			HashSet<OWLAxiom> ax,
			Timer checkSat) {
		
		boolean isConsistent = true;
		OWLOntology o = OWLTools.createOntology(conn,ax);		
		isConsistent = isConsistent(o, OWLTools.manager, checkSat);
		return isConsistent;
	}
	
	public static boolean isConsistent(
			OWLOntology onto,
			OWLOntologyManager manager,
			Timer checkSat){
		
		boolean flag = true;
		ReasoningTask task = new ReasoningTask(onto, manager);
		if(checkSat!=null){
			checkSat.start();
		}
		flag = task.isConsistent();
		if(checkSat!=null){
			checkSat.stop();
		}
		return flag;
	}
	
	public static boolean isConsistent(
			HashSet<OWLAxiom> axs,
			Timer checkSat) {
		return isConsistent(null, axs, checkSat);
	}	
	
	public static boolean isConsistent(
			OWLOntology onto,
			OWLOntologyManager manager) {	
		return isConsistent(onto, manager, null);
	}
	
	public static boolean isConsistent(HashSet<OWLAxiom> axs)  {
		return isConsistent(axs, null);
	}
	


	
    //************************************************
	// Check whether a concept is satisfiable or not
    //************************************************	
	
	public static boolean isSatisfiable(
			OWLOntology onto, 
			OWLOntologyManager manager,
			OWLClass ent,
			Timer checkSat) {

		boolean flag = true;
		ReasoningTask task = new ReasoningTask(onto, manager);
		flag = task.isSatisfiable(ent);		
		return flag;
	}
	
	public static boolean isSatisfiable(
			OWLOntology onto, 
			OWLOntologyManager manager,
			OWLClass ent) {		
		return isSatisfiable(onto, manager, ent, null);
	}
	
	
	public static boolean isSatisfiable(OWLOntologyManager conn, 
			HashSet<OWLAxiom> ax, 
			OWLClass ent, 
			Timer checkSat) {
		
		OWLOntology o = OWLTools.createOntology(ax);		
		return isSatisfiable(o, OWLTools.manager, ent, checkSat);
	}		
	
	public static boolean isSatisfiable(
			HashSet<OWLAxiom> axioms, 
			OWLClass ent, 
			Timer checkSat) {	
		if(checkSat!=null){
			checkSat.start();
		}
		boolean isSatisfiable = true;
		//System.out.println("Before creating a new ontology: "+axioms.size());
		//OWLOntology ontology = OWLTools.createOntology(axioms);
		OWLOntology onto = OWLTools.createOntology(axioms);
		//System.out.println("  In the new ontology: "+OWLTools.onto.getLogicalAxiomCount());
		//CommonTools.printAxioms(ontology);
		isSatisfiable = isSatisfiable(onto, OWLTools.manager, ent, checkSat);
		OWLTools.manager.removeOntology(onto);
		//SOWLTools.managerystem.out.println("  after removing ontology: "+OWLTools.onto.getLogicalAxiomCount());
		
		//System.out.println("The concept <"+ent.toString()+"> is satisfiable? "+f);
		if(checkSat!=null && checkSat.isStarted()){
			checkSat.stop();
		}
		return isSatisfiable;
	}

	public static boolean isSatisfiable(
			HashSet<OWLAxiom> AxiomSet, 
			OWLClass ent) {		
		return isSatisfiable(AxiomSet, ent, null);
	}
	
	public static boolean isSatisfiable(
			HashSet<OWLAxiom> axioms,
			HashSet<OWLClassExpression> unwantedUnsatClasses) {			
		return isSatisfiable(axioms, new HashSet<OWLAxiom>(), unwantedUnsatClasses);
	}
	
	public static boolean isSatisfiable(
			HashSet<OWLAxiom> stableAxioms,
			HashSet<OWLAxiom> unstableAxioms,
			HashSet<OWLClassExpression> unwantedUnsatClasses) {
				
		boolean isSatisfiable = true;
		try{
			// Get all axioms
			HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(stableAxioms);
			allAxioms.addAll(unstableAxioms);
			// Create an ontology for these axioms
			OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
			OWLOntology onto = manager.createOntology( allAxioms );
			// Check whether a considered class is unsatisfiable  
			ReasoningTask task = new ReasoningTask(onto, manager);
			for(OWLClassExpression unsatClass : unwantedUnsatClasses){
				if(!task.isSatisfiable(unsatClass)){				
					isSatisfiable = false;
					break;
				}
			}		
			
		} catch (OWLOntologyCreationException ex){
			ex.printStackTrace();
		}	
		
		return isSatisfiable;
	}
		
    //************************************************
	// Check whether an ontology is coherent or not.
	// That is check whether the ontology contains an unsatisfiable concept
    //************************************************
		
	public static boolean isCoherent(
			OWLOntologyManager conn, 
			HashSet<OWLAxiom> ax, 
			Timer checkSat) {
		
		boolean flag = true;
		OWLOntology onto = OWLTools.createOntology(ax);		
		OWLOntologyManager manager = conn;
		if(manager == null){
			manager = OWLTools.manager;
		}
		ReasoningTask task = new ReasoningTask(onto, manager);		
		OWLDataFactory factory = manager.getOWLDataFactory();
		for(OWLClass oc : onto.getClassesInSignature()){
        	if(oc.equals(factory.getOWLNothing())||
        			oc.equals(factory.getOWLThing())){
        		continue;
        	}
			if(!task.isSatisfiable(oc)){
				flag = false;
				break;
			}					
		}			
		return flag;
	}
	
	
	public static boolean isCoherent(
			HashSet<OWLAxiom> ax, 
			HashSet<OWLClass> ucs) {
		
		boolean flag = true;
		OWLOntology onto = OWLTools.createOntology(ax);		
		OWLOntologyManager manager = OWLTools.manager;
		
		ReasoningTask task = new ReasoningTask(onto, manager);		
		OWLDataFactory factory = manager.getOWLDataFactory();
		for(OWLClass oc : ucs){
        	if(oc.equals(factory.getOWLNothing())||
        			oc.equals(factory.getOWLThing())){
        		continue;
        	}
			if(!task.isSatisfiable(oc)){
				flag = false;
				break;
			}					
		}			
		return flag;
	}
	
	public static boolean isCoherent(HashSet<OWLAxiom> ax, 
			Timer checkSat) {
		return isCoherent(null, ax, checkSat);
	}
	
	public static boolean isCoherent(HashSet<OWLAxiom> ax) {
		return isCoherent(null, ax, null);
	}
	
	public static boolean isCoherent(
			OWLOntology onto, 
			OWLOntologyManager manager,
			Timer checkSat) {
		
		boolean flag = true;
		ReasoningTask task = new ReasoningTask(onto, manager);		
		OWLDataFactory factory = manager.getOWLDataFactory();
		for(OWLClass oc : onto.getClassesInSignature()){
        	if(oc.equals(factory.getOWLNothing())||
        			oc.equals(factory.getOWLThing())){
        		continue;
        	}
			if(!task.isSatisfiable(oc)){
				flag = false;
				break;
			}					
		}			
		return flag;
	}
	
	public static boolean isCoherent(
			OWLOntology onto,
			OWLOntologyManager manager)  {		
		return isCoherent(onto, manager, null);
	}
	
	
    //************************************************
	// Compute unsatisfiable concept(s)
    //************************************************
		
	public static HashSet<OWLClass> getUnsatiConcepts(
			OWLOntology onto, 
			OWLOntologyManager manager,
			Timer checkTimer) {		
		HashSet<OWLClass> uncon = new HashSet<OWLClass>();		
		ReasoningTask task = new ReasoningTask(onto, manager);	
		OWLDataFactory factory = manager.getOWLDataFactory();
		int i = 0;
		for(OWLClass oc : onto.getClassesInSignature()){
			/*i++;
			if(i<=59) {
				continue;
			}*/
			//System.out.println("class ["+(i)+"]: "+oc.getIRI().toString());
        	if(oc.equals(factory.getOWLNothing())||
        			oc.equals(factory.getOWLThing())){
        		continue;
        	}
        	if(checkTimer!=null){
        		checkTimer.start();
        	}        	
        	boolean f = task.isSatisfiable(oc);
        	//System.out.println(" is satisfiable: "+f);
        	if(checkTimer!=null){
        		checkTimer.stop();
        	}
			if(!f){
				uncon.add(oc);
			}					
		}				
		return uncon;
	}
	
	public static HashSet<OWLClass> getUnsatiConcepts(
			HashSet<OWLAxiom> ax, 
			Timer checkTimer) {		
		HashSet<OWLClass> uncon = new HashSet<OWLClass>();
		OWLOntology onto = OWLTools.createOntology(ax);		
		uncon = getUnsatiConcepts(onto, OWLTools.manager, checkTimer);
		OWLTools.manager.removeOntology(onto);
		return uncon;
	}
	
	public static HashSet<OWLClass> getUnsatiConcepts(OWLOntology onto) {		
		return getUnsatiConcepts(onto, OWL.manager, null);
	}
	
	public static HashSet<OWLClass> getUnsatiConcepts(
			OWLOntology onto,
			OWLOntologyManager manager) {		
		return getUnsatiConcepts(onto, manager, null);
	}
	
	public static HashSet<OWLClass> getUnsatiConcepts(HashSet<OWLAxiom> ax){		
		return getUnsatiConcepts(ax, null);
	}	

}
