package edu.njupt.radon.utils.reasoning;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;
import org.semanticweb.owlapi.util.InferredAxiomGenerator;
import org.semanticweb.owlapi.util.InferredClassAssertionAxiomGenerator;
import org.semanticweb.owlapi.util.InferredOntologyGenerator;
import org.semanticweb.owlapi.util.InferredSubClassAxiomGenerator;

import com.clarkparsia.owlapiv3.OWL;
import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class InferredAxioms {
	public static OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		DebuggingParameters.ontoName = "resist";
		computeEntailments2();
/*
        String selectedEntailmentsPath = ontoRoot + "inferredAxioms/"+ontoName+".txt";		
		HashSet<String> selectedStrings = EvenSampling.getSelectedStrings(allEntailmentsPath, ontoName);
		EvenSampling.saveResultsToFile(selectedStrings, selectedEntailmentsPath);*/

	}
	
	public static void computeEntailments1() throws Exception {
		//String inferredOntoPath = "file:"+DebuggingParameters.ontoRoot+"bio-inferred/"+ DebuggingParameters.ontoName+".owl";
		String inferredOntoPath = "file:"+DebuggingParameters.ontoRoot+"consistent-abox/inferred/inferredOntos/"+ 
		          DebuggingParameters.ontoName+"-inferred.owl";	
		inferredOntoPath = "file:///G:/Data/campaign/oaei2012/conf/ekaw-subsumptions.owl";
		String resultsPath = DebuggingParameters.ontoRoot+"consistent-abox/inferred/"+ 
		          DebuggingParameters.ontoName+"-nontrivial.txt";
		
		String ontoPath = "file:G:/Data/2014-kbs/data/consistent-abox/mouse.owl";
		OWLOntology origOnto = OWL.manager.loadOntology( IRI.create( ontoPath ) );
		OWLOntology inferredOnto = OWL.manager.loadOntology( IRI.create( inferredOntoPath ) );
		System.out.println(inferredOnto.getLogicalAxiomCount());
		System.out.println(origOnto.getClassesInSignature().size());
		int i =0;
		for(OWLAxiom a : inferredOnto.getLogicalAxioms()){
			System.out.println(a.getAxiomWithoutAnnotations().toString());
		}
		
		//System.setOut((new PrintStreamObject(resultsPath)).ps);
		HashSet<OWLAxiom> nonTrivialEntailments = InferredAxioms.getNonTrivialEntailments(origOnto, inferredOnto);
		System.out.println(nonTrivialEntailments.size());
	}
	
	public static void computeEntailments2() throws Exception  {
		String entailmentType = "assertion"; // subsumption, assertion, both
		String allEntailmentsPath = DebuggingParameters.ontoRoot + 
		       "coherent/inferredAxioms/allentailments/"+DebuggingParameters.ontoName+".txt";
		allEntailmentsPath = "G:/Data/inf.txt";
		String ontoPath = "file:G:/Data/campaign/oaei2012/anomy/swrc_v0.3.owl";
		System.setOut((new PrintStreamObject(allEntailmentsPath)).ps);
		printInferredAxioms(ontoPath, entailmentType);
	}
	
	public static HashSet<OWLAxiom> getNonTrivialEntailments(OWLOntology origOnto, OWLOntology inferredOnto) throws Exception {	
		HashSet<OWLAxiom> nonTrivialEntailments = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> allAxiomsInOrigOnto = new HashSet<OWLAxiom>();	
		for(OWLAxiom ax : origOnto.getLogicalAxioms()){
			allAxiomsInOrigOnto.add(ax.getAxiomWithoutAnnotations());	
		}
		for(OWLOntology o : origOnto.getImports()){
			for(OWLAxiom ax : o.getLogicalAxioms()){
				allAxiomsInOrigOnto.add(ax.getAxiomWithoutAnnotations());	
			}
		}
		
		for(OWLAxiom ax : inferredOnto.getLogicalAxioms()){
			// Ignore the entailments that are explicitly defined in the original ontology	
			if(allAxiomsInOrigOnto.contains(ax)){
				continue;
			}
			// Ignore those non-interesting entailments 
			if(ax.toString().contains("http://www.w3.org/2002/07/owl#Thing") 
					|| ax.toString().contains("owl:Thing")){
				continue;
			}
			if(ax instanceof OWLSubClassOfAxiom){
				OWLSubClassOfAxiom subAxiom = (OWLSubClassOfAxiom)ax;
				OWLClass oc  = subAxiom.getSubClass().asOWLClass();
				if(oc.getSuperClasses(origOnto).contains(oc)){
					continue;
				}
			} else if(ax instanceof OWLClassAssertionAxiom){
				OWLClassAssertionAxiom assertion = (OWLClassAssertionAxiom)ax;
				OWLIndividual indi  = assertion.getIndividual();
				OWLClassExpression type = assertion.getClassExpression();
				// Ignore those assertions 
				if(indi.getTypes(origOnto).contains(type)){
					continue;
				}
			}
			
			nonTrivialEntailments.add(ax);
			printEntailment(ax);
		
		}
		
		return nonTrivialEntailments;
	}
	
	public static boolean isNonTrivialEntailment(HashSet<OWLAxiom> allAxioms, OWLAxiom entailment) throws Exception{
		boolean isNonTrivial = false;
		
		allAxioms.remove(entailment);		
		OWLOntology o = OWL.manager.createOntology(allAxioms);
		OWLReasoner reasoner = reasonerFactory.createReasoner(o);
		if(reasoner.isEntailed(entailment)){
			isNonTrivial = true;
		}
		reasoner.dispose();
		allAxioms.add(entailment);
		
		return isNonTrivial;
	}
	
	public static void printAxioms(HashSet<OWLAxiom> axioms){
		for(OWLAxiom axiom : axioms){
			System.out.println(axiom.toString());
		}
	}

	public static void printEntailment(OWLAxiom axiom){
		//System.out.println(axiom.toString());
		if(axiom instanceof OWLSubClassOfAxiom){
			OWLSubClassOfAxiom subAxiom = (OWLSubClassOfAxiom)axiom;
			System.out.println(subAxiom.getSubClass().asOWLClass().getIRI().toString()+
					" subClassOf "+subAxiom.getSuperClass().asOWLClass().getIRI().toString());
		} else if(axiom instanceof OWLClassAssertionAxiom){
			OWLClassAssertionAxiom assertion = (OWLClassAssertionAxiom)axiom;
			System.out.println(assertion.getIndividual().asOWLNamedIndividual().getIRI().toString()+
					" types "+assertion.getClassExpression().asOWLClass().getIRI().toString());
		}
		//System.out.println();
	}
	
	
    public static void printInferredAxioms(String ontoIRI, String entailmentType) throws OWLOntologyCreationException,
    Exception {
        // Create a reasoner factory. In this case, we will use pellet, but we
        // could also use FaCT++ using the FaCTPlusPlusReasonerFactory. Pellet
        // requires the Pellet libraries (pellet.jar, aterm-java-x.x.jar) and
        // the XSD libraries that are bundled with pellet: xsdlib.jar and
        // relaxngDatatype.jar make sure these jars are on the classpath
        OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
        // Uncomment the line below reasonerFactory = new
        // PelletReasonerFactory(); Load an example ontology - for the purposes
        // of the example, we will just load the pizza ontology.
        OWLOntologyManager man = OWLManager.createOWLOntologyManager();
        OWLOntology ont = man.loadOntologyFromOntologyDocument(IRI.create(ontoIRI));
        // Create the reasoner and classify the ontology
        OWLReasoner reasoner = reasonerFactory.createNonBufferingReasoner(ont);
               
        // To generate an inferred ontology we use implementations of inferred
        // axiom generators to generate the parts of the ontology we want (e.g.
        // subclass axioms, equivalent classes axioms, class assertion axiom
        // etc. - see the org.semanticweb.owlapi.util package for more
        // implementations). Set up our list of inferred axiom generators
        List<InferredAxiomGenerator<? extends OWLAxiom>> gens = new ArrayList<InferredAxiomGenerator<? extends OWLAxiom>>();
        if(entailmentType.equals("subsumption")){
        	reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
        	gens.add(new InferredSubClassAxiomGenerator());
        } else if(entailmentType.equals("assertion")){
        	reasoner.precomputeInferences(InferenceType.CLASS_ASSERTIONS);
        	gens.add(new InferredClassAssertionAxiomGenerator());
        } else {
        	reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
        	gens.add(new InferredSubClassAxiomGenerator());
        	reasoner.precomputeInferences(InferenceType.CLASS_ASSERTIONS);
        	gens.add(new InferredClassAssertionAxiomGenerator());
        }
        
        // Put the inferred axioms into a fresh empty ontology - note that there
        // is nothing stopping us stuffing them back into the original asserted
        // ontology if we wanted to do this.
        OWLOntology infOnt = man.createOntology();
        // Now get the inferred ontology generator to generate some inferred
        // axioms for us (into our fresh ontology). We specify the reasoner that
        // we want to use and the inferred axiom generators that we want to use.
        InferredOntologyGenerator iog = new InferredOntologyGenerator(reasoner, gens);
        iog.fillOntology(man, infOnt);
        // Save the inferred ontology. (Replace the URI with one that is
        // appropriate for your setup)
        //man.saveOntology(infOnt, new StringDocumentTarget());
        printAxioms(infOnt.getAxioms(), ont);
    }
    
    public static void printAxioms(Set<OWLAxiom> entailments, OWLOntology ont) throws Exception {
    	System.out.println(entailments.size());
    	HashSet<OWLAxiom> axiomsInOrigOnt = new HashSet<OWLAxiom>(ont.getLogicalAxioms());
    	int selectedEntailmentsCounter = 0;
    	int containedEntailmentsCounter = 0;
    	for(OWLAxiom entailment : entailments){
    		if(axiomsInOrigOnt.contains(entailment)){
    			containedEntailmentsCounter ++;
    			continue;
    		}
    		printAxiom(entailment);
			selectedEntailmentsCounter ++;    		
    	}
    	System.out.println(containedEntailmentsCounter);
    	System.out.println(selectedEntailmentsCounter);
    }
    

    public static void printAxiom(OWLAxiom axiom){
    	if(axiom instanceof OWLSubClassOfAxiom){
    		OWLSubClassOfAxiom subClassOfAxiom = (OWLSubClassOfAxiom)axiom;
    		OWLClass subClass = subClassOfAxiom.getSubClass().asOWLClass();
    		OWLClass superClass = subClassOfAxiom.getSuperClass().asOWLClass();
    		System.out.println(OWLTools.getLocalName(subClass)+" subClassOf "+
    				OWLTools.getLocalName(superClass));
    	} else if(axiom instanceof OWLClassAssertionAxiom){
    		OWLClassAssertionAxiom asserAxiom = (OWLClassAssertionAxiom)axiom;
    		OWLNamedIndividual indi = asserAxiom.getIndividual().asOWLNamedIndividual();
    		OWLClass type = asserAxiom.getClassExpression().asOWLClass();
    		System.out.println(OWLTools.getLocalName(indi)+" types "+
    				OWLTools.getLocalName(type));
    	}
    }



}
