
package edu.njupt.radon.utils.reasoning;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.Timer;


/**
 * TODO
 *
 * @author Qiu Ji 
 * @date 22.07.2007
 */
public class DebugTools {
	

	/** 
	 * This method cannot ensure the found ucs are roots.
	 * We only found those ucs that have
	 */
	public static HashSet<OWLClass> getRootUcs(HashSet<OWLClass> ucs, OWLOntology o) {
		System.out.println("original ucs: "+ucs.size());
		HashSet<OWLClass> roots = new HashSet<>();
		int i = 0;
		for(OWLClass uc : ucs) {
			System.out.println((i++)+">  current uc is : "+uc.toStringID());
			boolean isRoot = true;
			Set<OWLSubClassOfAxiom> axioms = o.getSubClassAxiomsForSubClass(uc);
			for(OWLSubClassOfAxiom axiom : axioms) {
				OWLClassExpression oce = axiom.getSuperClass();
				if(!oce.isAnonymous()) {
					OWLClass sup = oce.asOWLClass();
					if(ucs.contains(sup)) {
						System.out.println("   ** not root because: "+axiom.toString());
						isRoot = false;
					}
				} else {
					if(oce instanceof OWLObjectIntersectionOf) {
						OWLObjectIntersectionOf oce2 = (OWLObjectIntersectionOf)oce;
						for(OWLClassExpression sup2 : oce2.getOperands()) {
							if(!sup2.isAnonymous()) {
								OWLClass sup = sup2.asOWLClass();
								if(ucs.contains(sup)) {
									isRoot = false;
									System.out.println("   not root because: "+axiom.toString());
									break;
								}								
							}
						}
					}
				}
				if(!isRoot) {
					break;
				}				
			} // end for
			
			if(isRoot) {
				System.out.println("   is root ");
				roots.add(uc);
			}
		}
		System.out.println("root ucs: "+roots.size());
		return roots;
	}
	

	
	public static boolean hasEnoughMUPS(
			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups, 
			OWLOntology o, HashSet<OWLAxiom> removedAx,
			Timer testTimer, Timer checkSatTimer) {	
		
		HashSet<OWLAxiom> ax = new HashSet<OWLAxiom>();
		boolean flag = true;
		
		try{
			ax.addAll(o.getAxioms());
			flag = hasEnoughMUPS(mups, ax, removedAx,
					testTimer, checkSatTimer);
		} catch (Exception e){
			e.printStackTrace();
		}		
		
		return flag;
	}
	
	public static boolean hasEnoughMUPS(
			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups, 
			HashSet<OWLAxiom> tbox, HashSet<OWLAxiom> removedAx,
			Timer testTimer, Timer checkSatTimer) {	
		
		boolean flag = true;
		for(OWLClass oc : mups.keySet()){	
			HashSet<HashSet<OWLAxiom>> ocMUPS = mups.get(oc);
			flag = hasEnoughMUPS(oc, ocMUPS, tbox, removedAx,
					testTimer, checkSatTimer);
			if(!flag)
				return false;
		}	
		return flag;
	}
	
    public static boolean hasEnoughMUPS(OWLClass oc, 
    		HashSet<HashSet<OWLAxiom>> ocMUPS, 
    		HashSet<OWLAxiom> allAx, HashSet<OWLAxiom> removedAx,
    		Timer testTimer, Timer checkSatTimer) {
		
		boolean unsatiResolved = true;
		
		testTimer.start();
		removedAx.clear();
		for(HashSet<OWLAxiom> one : ocMUPS){	
			for(OWLAxiom a : one){
				if(connected(a, oc)){
					removedAx.add(a);
					break;
				}
			}
		}
		allAx.removeAll(removedAx);
		testTimer.stop();
		try{
			unsatiResolved = ReasoningTools.isSatisfiable(allAx, 
					oc, checkSatTimer);
		} catch (Exception e){
			e.printStackTrace();
			return false;
		}		
				
		return unsatiResolved;
	}
    
    
    public static boolean connected(OWLAxiom a , OWLClass oc){
    	boolean flag = false;
    	if(a.toString().contains(oc.toString())){
    		flag = true;
    	}
    	return flag;
    }
	
	public static HashSet<OWLAxiom> getMUPSUnion(HashMap<OWLClass,HashSet<HashSet<OWLAxiom>>> mups){
		HashSet<OWLAxiom> union = new HashSet<OWLAxiom>();
		for(OWLClass oc : mups.keySet()){
			for(HashSet<OWLAxiom> one : mups.get(oc)){
				union.addAll(one);
			}			
		}
		return (HashSet<OWLAxiom>)union.clone();
	}
	
	public static HashSet<HashSet<OWLAxiom>> getAllMUPS(HashMap<OWLClass,HashSet<HashSet<OWLAxiom>>> mups){
		HashSet<HashSet<OWLAxiom>> union = new HashSet<HashSet<OWLAxiom>>();
		for(OWLClass oc : mups.keySet()){
			union.addAll(mups.get(oc));			
		}
		return (HashSet<HashSet<OWLAxiom>>)union.clone();
	}
	
	public HashSet<OWLAxiom> getOneRealMIPS(HashSet<OWLAxiom> oneMIPS) {
		HashSet<OWLAxiom> mips_t = (HashSet<OWLAxiom>) oneMIPS.clone();
		HashSet<OWLAxiom> current = new HashSet<OWLAxiom>(mips_t);
		for (OWLAxiom a : mips_t) {
			current.remove(a);
			try{
				if (ReasoningTools.isCoherent(current)) {
					current.add(a);
				}
			} catch (Exception ex){
				ex.printStackTrace();
			}
			
		}

		return current;
	}
		
	public static void printMUPS(HashMap<OWLClass,HashSet<HashSet<OWLAxiom>>> mups,String ns){
		if(ns==null)
			ns = "";
		int i = 0;
		for(OWLClass oc : mups.keySet()){			
			System.out.println("<"+(i++)+">"+oc.toString().replace(ns, ""));	
			CommonTools.printMultiSets(mups.get(oc), ns);
		}
	}
	
	public static boolean checkMUPS(HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups) {	
		
		boolean flag = true;
		for(OWLClass oc : mups.keySet()){	
			HashSet<HashSet<OWLAxiom>> ocMUPS = mups.get(oc);
			flag = checkOneUnsatiConcept(oc, ocMUPS);
			if(!flag)
				return false;
		}	
		return flag;
	}
	

    
    public static boolean checkOneUnsatiConcept(OWLClass oc, 
    		HashSet<HashSet<OWLAxiom>> ocMUPS) {
		
		boolean unsatiResolved = true;		
		for(HashSet<OWLAxiom> one : ocMUPS){
			unsatiResolved = checkOneMUPS(oc, one);
			if(!unsatiResolved)
				return false;
		}
						
		return unsatiResolved;
	}
	
	 /*
	 * Check whether a MUPS @mups of an unsatisfiable concept @oc is true
	 * by removing the axiom one by one. 
	 */
	public static boolean checkOneMUPS(OWLClass oc, HashSet<OWLAxiom> oneMUPS) {
		
		boolean isRealMUP = true;
		
		HashSet<OWLAxiom> current = (HashSet<OWLAxiom>)oneMUPS.clone();
		try{
			if(ReasoningTools.isSatisfiable(oneMUPS, oc)){
				System.out.println("The U is coherent in this MUPS. ");
				return false;
			}
			for(OWLAxiom a : oneMUPS){
				current.remove(a);				
				if(!ReasoningTools.isSatisfiable(current, oc)){
					isRealMUP = false;
					break;
				} else {
					current.add(a);
				}				
			}
			
		} catch (Exception e){
			System.out.println(e);
		}
		
		return isRealMUP;
	}
	
	public static boolean checkOneMIPS(HashSet<OWLAxiom> oneMIPS) {
		
		boolean isRealMUP = true;
		
		HashSet<OWLAxiom> current = (HashSet<OWLAxiom>)oneMIPS.clone();
		try{
			for(OWLAxiom a : oneMIPS){
				current.remove(a);
				
				if(!ReasoningTools.isCoherent(current)){
					isRealMUP = false;
					break;
				} else {
					current.add(a);
				}				
			}
			
		} catch (Exception e){
			System.out.println(e);
		}
		
		return isRealMUP;
	}
	
	public static boolean checkMIPS(HashSet<OWLAxiom> allAxioms, HashSet<HashSet<OWLAxiom>> mips){
		boolean flag = true;
		HashSet<HashSet<OWLAxiom>> mips_t = (HashSet<HashSet<OWLAxiom>>)mips.clone();
		HashSet<OWLAxiom> allAxioms_t = (HashSet<OWLAxiom>)allAxioms.clone();
		HashSet<OWLAxiom> removedAxioms = new HashSet<OWLAxiom>();
		//Check each MIPS is right or not
		for(HashSet<OWLAxiom> one : mips_t){
			flag = checkOneMIPS(one);
			removedAxioms.add(one.iterator().next());
			if(!flag){
				return false;
			}
		}
		//Check whether the incoherence is resolved by removing one axiom from each MIPS
		allAxioms_t.removeAll(removedAxioms);
		try{
			if(!ReasoningTools.isCoherent(allAxioms_t)){
				flag = false;				
			} 
		} catch (Exception ex){
			ex.printStackTrace();
		}		
		return flag;
	}
 
    
}
