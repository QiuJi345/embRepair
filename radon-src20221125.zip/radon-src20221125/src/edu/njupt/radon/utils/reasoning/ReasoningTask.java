package edu.njupt.radon.utils.reasoning;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.HermiT.Reasoner;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import com.clarkparsia.owlapi.explanation.util.OntologyUtils;
import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

import uk.ac.manchester.cs.factplusplus.owlapiv3.FaCTPlusPlusReasonerFactory;
import uk.ac.manchester.cs.jfact.JFactFactory;

public class ReasoningTask {
	
	
	
    public final static String PELLET = "pellet";
	
	public final static String FACTPP = "factpp";
	
	public final static String HERMIT = "hermit";
	
	public final static String jfact = "jfact";
	
	public static String reasoner = PELLET;
	
	OWLOntology onto;
	OWLReasoner owlReasoner;
		
	public ReasoningTask(
			OWLOntology onto,
			OWLOntologyManager manager) {
		this.onto = onto;	
		Set<OWLOntology> ontos = new HashSet<OWLOntology>();
		ontos.add(onto);
		if(reasoner.equalsIgnoreCase(FACTPP)){
			OWLReasonerFactory reasonerFactory = new FaCTPlusPlusReasonerFactory();
			owlReasoner = reasonerFactory.createReasoner(onto);
			//System.out.println("reasoner: "+FACTPP);
		} else if(reasoner.equalsIgnoreCase(HERMIT)){
			OWLReasonerFactory reasonerFactory = new Reasoner.ReasonerFactory();
			owlReasoner = reasonerFactory.createReasoner(onto);
			//System.out.println("reasoner: "+HERMIT);
		} else if(reasoner.equalsIgnoreCase(jfact)){
			OWLReasonerFactory reasonerFactory = new JFactFactory();
			owlReasoner = reasonerFactory.createReasoner(onto);
			//System.out.println("reasoner: "+HERMIT);
		} else {			
			OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
			if(onto==null) {
				System.out.println("*********** onto is null");
			}
			owlReasoner = reasonerFactory.createReasoner(onto);/*
			Set<OWLOntology> importsClosure = manager.getImportsClosure(onto);
			owlReasoner.loadOntologies(importsClosure);
			owlReasoner.classify();*/
		}	
	}
	
	public boolean isConsistent() {
		try{
			boolean isConsistent = owlReasoner.isConsistent();
			return isConsistent;
		} catch (Exception ex){
			ex.printStackTrace();
		}
		
		return false;
	}

	public boolean isSatisfiable(OWLClass concept) {
		boolean f = true;
		if(onto.containsClassInSignature(concept.getIRI())){
			f = owlReasoner.isSatisfiable(concept);
		}
		//owlReasoner.dispose();
		return f;
	}
	
	public boolean isSatisfiable(OWLClassExpression unsatClass) {
		if(OntologyUtils.containsUnreferencedEntity(onto, unsatClass)){
			return true;
		}
		return owlReasoner.isSatisfiable(unsatClass);
	}
	
	public boolean isEntailed(OWLAxiom a) {
		return owlReasoner.isEntailed(a);
	}
	
	public HashSet<OWLClass> getDescendants(OWLClass oc) {
		HashSet<OWLClass> descendants = new HashSet<OWLClass>();
		Set<OWLClass> ns = owlReasoner.getSubClasses(oc, false).getFlattened();
		
		
		for(OWLClass n : ns) {
			if(!n.isOWLNothing() && !n.isOWLThing()) {
				descendants.add(n);
				//System.out.println("    "+n.toString());
			}			
		}
		System.out.println("descendants of class "+oc.toString()+": "+descendants.size());
		return descendants;
	}
	
	/**
	 * For a given class, obtain all superclasses excluding i
	 * @param oc
	 * @return
	 */
	public HashSet<OWLClass> getAncestors(OWLClass oc) {
		HashSet<OWLClass> ancestors = new HashSet<OWLClass>();
		Set<OWLClass> ns = owlReasoner.getSuperClasses(oc, false).getFlattened();		
		
		for(OWLClass n : ns) {
			if(!n.isOWLNothing() && !n.isOWLThing()) {
				ancestors.add(n);
				//System.out.println("    "+n.toString());
			}			
		}
		System.out.println("ancestors of class "+oc.toString()+": "+ancestors.size());
		return ancestors;
	}
	
	

}
