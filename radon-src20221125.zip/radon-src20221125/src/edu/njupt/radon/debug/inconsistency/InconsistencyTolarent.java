package edu.njupt.radon.debug.inconsistency;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class InconsistencyTolarent {
	
	int pruneWindow = 5;
	
	public static void main(String[] args) throws Exception {
		String ontoPath = "data/buggyPolicy.owl";
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);		
		HashSet<OWLAxiom> abox = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		abox.removeAll(tbox);
		System.out.println(" \n tbox:");
		CommonTools.printAxioms(tbox);
		System.out.println(" \n abox: ");
		CommonTools.printAxioms(abox);
		
		InconsistencyTolarent ct = new InconsistencyTolarent();
		HashSet<OWLAxiom> subset = ct.getMaxConsistentSubset(tbox, abox);
		if(subset!=null){
			System.out.println(" \n subset: ");
			CommonTools.printAxioms(subset);
		}
		
	}
	
	/**
	 * Assume the ontology includes a tbox and an abox, where the tbox is consistent.
	 * 
	 * @param tbox
	 * @param abox
	 * @return a cardinality-maximal consistent subset of the ontology
	 */
	public HashSet<OWLAxiom> getCardiMaxConsistentSubset(
			HashSet<OWLAxiom> tbox,
			HashSet<OWLAxiom> abox) {

		if(!this.isConsistent(tbox)){
			return null;
		}
		
		// Try to find a maximal consistent subontology
		HashSet<OWLAxiom> currentAxioms = this.getMaxConsistentSubset(tbox, abox);

		/*
		 * If the cardinality is greater than 0 and smaller than the size of
		 * the original ontology, we try to find all cardinality-maximal
		 * subontologies.
		 */		
		int cardinality = currentAxioms.size();
		int begin = cardinality;
		int end = tbox.size()+ abox.size();
		int middle = 0;

		while (begin < end) {
			int temp = (end + begin) % 2;
			if (temp == 0) {
				middle = (end + begin) / 2;
			} else {
				middle = (end + begin) / 2 + 1;
			}

			HashSet<HashSet<OWLAxiom>> cardiSubsets = CommonTools.getCardiSubSets(tbox, abox, middle);
			boolean existConsistentSubonto = false;
			for (HashSet<OWLAxiom> cardiSubset : cardiSubsets) {
				boolean isConsistent = this.isConsistent(cardiSubset);
				if (isConsistent) {
					existConsistentSubonto = true;					
					break;
				}
			}

			if (!existConsistentSubonto) {
				if ((end - begin)==1) {
					break;
				} else {
					end = middle;
				}				
			} else {
				begin = middle;
			}			
		}
		
		//Compute one consistent subset with a given cardinality
		HashSet<OWLAxiom> cardiMaxSubset = null;
		cardinality = begin;
		if(cardinality == tbox.size()){
			cardiMaxSubset = new HashSet<OWLAxiom>(tbox);
		} else {
			HashSet<HashSet<OWLAxiom>> subsets = CommonTools.getCardiSubSets(tbox, abox, cardinality);
			
			for(HashSet<OWLAxiom> subset : subsets){
				if(this.isConsistent(subset)){
					cardiMaxSubset = new HashSet<OWLAxiom>(subset);
					break;
				}
			}
		}	

		return cardiMaxSubset;
	}
	
	/**
	 * Assume the ontology includes a tbox and an abox, where the tbox is consistent.
	 * 
	 * @param tbox
	 * @param abox
	 * @return A maximal consistent subset of the ontology.
	 */
	public HashSet<OWLAxiom> getMaxConsistentSubset(
			HashSet<OWLAxiom> tbox,
			HashSet<OWLAxiom> abox) {
		//fast prune
		HashSet<OWLAxiom> slowPruneAxioms = this.fastPrune(tbox, new Vector<OWLAxiom>(abox));
		//slow prune
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(tbox);
		axioms.addAll(abox);
		axioms.removeAll(slowPruneAxioms);
		for (OWLAxiom axiom : slowPruneAxioms) {
			axioms.add(axiom);
			if (!this.isConsistent(axioms)) {
				axioms.remove(axiom);
			}
		}		
		return axioms;
	}
	
	public HashSet<OWLAxiom> fastPrune(
			HashSet<OWLAxiom> unchangedAxioms, 
			Vector<OWLAxiom> toBePrunedAxioms){		
		
		HashSet<OWLAxiom> currentAxioms = new HashSet<OWLAxiom>(unchangedAxioms);
		HashSet<OWLAxiom> slowPruneAxioms = new HashSet<OWLAxiom>();
		int size = toBePrunedAxioms.size();
		//System.out.println(OWLTools.isCoherent(new HashSet<OWLAxiom>(prunedOWLAxioms),oc));
		if(size>pruneWindow){
			int parts = size / pruneWindow;
			for (int part = 0; part < parts; part++) {
				for (int i = part * pruneWindow; i < part * pruneWindow
						+ pruneWindow; i++) {
					currentAxioms.add(toBePrunedAxioms.get(i));
				}					
				
				if (!this.isConsistent(currentAxioms)) {
					//System.out.println("Fast prune OWLAxioms");
					for (int i = part * pruneWindow; i < part * pruneWindow
							+ pruneWindow; i++) {
						slowPruneAxioms.add(toBePrunedAxioms.get(i));
						currentAxioms.remove(toBePrunedAxioms.get(i));
						//System.out.println(i+" > "+allRelated.get(i).toString().replace(ns, ""));
					}
				}
			}
			if (size > parts * pruneWindow) {
				// add remaining from list to OWLAxioms
				for (int i = parts * pruneWindow; i < size; i++) {
					slowPruneAxioms.add(toBePrunedAxioms.get(i));
				}
			}
		}
		return slowPruneAxioms;
	}
	
	private boolean isConsistent(HashSet<OWLAxiom> axioms){
		boolean consistent = true;
		try{
			consistent = ReasoningTools.isConsistent(axioms);
		} catch (Exception e) {
			consistent = false;
		}
		return consistent;
	}
}
