package edu.njupt.radon.debug.inconsistency;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Iterator;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;


public class AfterSelectVerifyMCS {
    public static void main(String[] args) throws Exception {

        String ontoPath = "data/buggyPolicy-inc.owl";
        OWLOntology onto = OWLTools.openOntology(ontoPath);
        HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);
        HashSet<OWLAxiom> abox = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
        abox.removeAll(tbox);
        InconsistencyTolarent ct = new InconsistencyTolarent();
        HashSet<OWLAxiom> subset = ct.getMaxConsistentSubset(tbox, abox);
        if (subset != null) {
            System.out.println(" \n subset: ");
            CommonTools.printAxioms(subset);
        }
        System.out.println("原来的subset的大小：");
        System.out.println(subset.size());
        System.out.println("selectAxiomsSet:");
        CommonTools.printAxioms(AxiomsMatching(abox));
        System.out.println("在加入selectAxiomset之前，判断公理a 是否属于subse");
        for(OWLAxiom a:AxiomsMatching(abox)) {
            if (subset.contains(a)) {
                System.out.println("a ∈ subset");
            } else {
                System.out.println("a 不属于 subset ");
            }
        }
        System.out.println("在加入selectAxiomset之后，判断公理a 是否属于subset");
        for(OWLAxiom a:AxiomsMatching(abox)){
          subset.add(a);
          if(subset.contains(a)){
              System.out.println("a ∈ subset");
          }
          else {
              System.out.println("a 不属于 subset ");
          }

//            if(ReasoningTools.isConsistent(subset))
//            {
//                System.out.println("subset is  CS");
//            }
        }
        System.out.println("加入electAxiomsSet后subset的大小：");
        System.out.println(subset.size());
        //CommonTools.printAxioms(subset);
    }
    public static HashSet<OWLAxiom>  AxiomsMatching(HashSet<OWLAxiom> axioms) throws IOException {
        int i = 0;
        int n = 0;
        Iterator var3 = axioms.iterator();
        HashSet<OWLAxiom> selectAxioms = new HashSet<>();
        String txtpath = "data2/buggyPolicy-incSelectionAxiomsIndex.txt";
        String encoding = "GBK";//设置编码格式
        File file = new File(txtpath);
        if (file.isFile() && file.exists()) {
            InputStreamReader read = new InputStreamReader(new FileInputStream(file), encoding);//考虑到编码格式
            BufferedReader bufferedReader = new BufferedReader(read);
            String linetext = null;
            while ((linetext = bufferedReader.readLine()) != null) {
                n = Integer.parseInt(linetext);
                while (var3.hasNext()) {
                    OWLAxiom axiom = (OWLAxiom) var3.next();
                    //System.out.println("[" + i++ + "] " + axiom.toString());
                    i++;
                    if (i == n) {
                        selectAxioms.add(axiom);

                        break;
                    } else {
                        continue;
                    }

                }
            }
            read.close();
            //System.out.println(selectAxioms.size());
        }
        return selectAxioms;

    }
}
