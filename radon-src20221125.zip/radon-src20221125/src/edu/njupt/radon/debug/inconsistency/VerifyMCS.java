package edu.njupt.radon.debug.inconsistency;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class VerifyMCS {
    public static void main(String[] args) throws Exception {
        String ontoPath = "onto/inconsistent/miniTambis-inc.owl";
        OWLOntology onto = OWLTools.openOntology(ontoPath);
        HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);
        HashSet<OWLAxiom> abox = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
        InconsistencyTolarent ct = new InconsistencyTolarent();
        HashSet<OWLAxiom> subset = ct.getMaxConsistentSubset(tbox, abox);
        if(subset!=null){
            System.out.println(" \n subset: ");
            CommonTools.printAxioms(subset);
        }
        System.out.println("\n Allaxioms");
        HashSet<OWLAxiom> AllAxioms= new HashSet<OWLAxiom>(onto.getLogicalAxioms());
        CommonTools.printAxioms(AllAxioms);
        //Difference=Allaxioms-subset
        System.out.println("\n DifferenceSet");
        AllAxioms.removeAll(subset);
        HashSet<OWLAxiom> DifferenceSet = AllAxioms;
        CommonTools.printAxioms(DifferenceSet);
        
        System.out.println("subset: "+subset.size());
        OWLAxiom ax = subset.iterator().next();
        subset.remove(ax);
        DifferenceSet.add(ax);
        System.out.println("ax1: "+ax.toString());
        System.out.println("subset: "+subset.size());
        
        boolean isCorrect = true;
        for(OWLAxiom a: DifferenceSet) {
        	System.out.println("ax : "+a.toString());
            subset.add(a);
            
            if(ReasoningTools.isConsistent(subset))   {
                System.out.println("subset is not MCS");
                isCorrect = false;
                break;
            } 
        }

        System.out.println("subset is MCS? "+isCorrect);


    }
}
