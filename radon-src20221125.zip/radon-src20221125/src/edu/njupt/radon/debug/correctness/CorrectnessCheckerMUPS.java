package edu.njupt.radon.debug.correctness;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.inco.MUPSUtils;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.InconsistencyTools;

public class CorrectnessCheckerMUPS {
		
	public static void main(String[] args) throws Exception {		
		// Deal with the input parameters
		//ArgumentsProcessing process = new ArgumentsProcessing();
		//process.processArguments(args, "RaDONJustifications");
		
		System.setOut((new PrintStreamObject("d:/log.txt")).ps);
		
		String ucName = "miniTambis#Proteosis";
		String ontoName = "miniTambis"; 
		String debugTask = "incoherent";
		String ontoRoot = "g:/Experiments/2014-KBS-evaluation/systems/pellet/data/";	
		String ontoPath = "file:"+ontoRoot + debugTask+"/"+ontoName+".owl";
		String resultPath = "g:/Experiments/2014-KBS-evaluation/results/log.txt";
		
		OWLOntology onto = OWLTools.openOntology(ontoPath);		
		OWLClass unsatConcept = OWLTools.getOWLClass(onto, ucName);
		
		//System.setOut((new PrintStreamObject("d:/log.txt")).ps);
		System.out.println("****************> "+DebuggingParameters.ontoName+", uc: "+ucName);
				
		HashSet<HashSet<String>> allMUPSString = MUPSUtils.getFoundJusts(resultPath);
		//ReadMUPSLog.printAllMUPS(allMUPSString);
		
		HashSet<HashSet<OWLAxiom>> allMUPS = MUPSUtils.getSetsOfOWLAxioms(allMUPSString, onto);
		/*HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		for(HashSet<OWLAxiom> ax : allMUPS){
			axioms.addAll(ax);
		}
		//OWLTools.saveOntology(axioms, "file:///d:/"+DebuggingParameters.ontoName+"-new.owl");
		
		System.out.println();
		for(OWLAxiom ax : axioms){
			System.out.println(ax.toString());
		}*/		
		InconsistencyTools.checkMUPSCorrectness(allMUPS, unsatConcept);
	}
	
}
