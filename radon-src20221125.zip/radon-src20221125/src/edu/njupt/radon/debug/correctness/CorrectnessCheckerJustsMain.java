package edu.njupt.radon.debug.correctness;

import java.io.File;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.result.JustsReader;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.inco.MUPSUtils;
import edu.njupt.radon.utils.reasoning.ReasoningTask;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class CorrectnessCheckerJustsMain {
		
	
	OWLOntology currentOnto = null;
	
	static OWLAxiom entailment = null;
	
	public static void main(String[] args) throws Exception {	
		String reasonerName = "hermit";
		String debugTask = "consistent-abox";
		String ontoRoot = "g:/Experiments/2014-KBS-evaluation/systems/pellet/data/";
		DebuggingParameters.ontoRoot = ontoRoot + debugTask + "/"; //
		
		// Deal with the input parameters		
		String resultRoot = "g:/Experiments/2014-KBS-evaluation/results/";
		if(args.length == 1){
			resultRoot = args[0];
		} else if(args.length == 2){
			resultRoot = args[0];
			reasonerName = args[1];
		} else if(args.length == 3){
			resultRoot = args[0];
			reasonerName = args[1];
			debugTask = args[2];
		}
		String resultPath = resultRoot + reasonerName +"/" + debugTask + "/"  ;
		
		CorrectnessCheckerJustsMain corr = new CorrectnessCheckerJustsMain();
		corr.process(resultPath);
	}
	
	
	public void process(String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			String ontoName = subFile.getName();
			if(!ontoName.equals("lubm_1")){
				continue;
			}
			String ontoPath = DebuggingParameters.ontoRoot + ontoName + ".owl";
			currentOnto = OWLTools.openOntology(ontoPath);	
			if(currentOnto == null){
				continue;
			}
			//System.out.println("[ontoName] "+ontoName+" path = "+resultPath);
			String path = resultPath + ontoName + "/";
			listDebugMethods(path);			
		}
	}
	
	public void listDebugMethods(String resultPath){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			String debugMethod = subFile.getName();
			if(!debugMethod.startsWith("ProtegeBl")){
				continue;
			}
			String path = resultPath + debugMethod + "/";
			listEntailments(path, debugMethod);
		}
	}
	
	public void listEntailments(String resultPath, String debugMethod){
		File file = new File(resultPath);
		for(File subFile : file.listFiles()){
			String entailmentString = subFile.getName();
			if(!entailmentString.equalsIgnoreCase("AssistantProfessor8++Employee")){
				continue;
			}
			String logPath = resultPath + entailmentString;
			
			String checkResultPath = logPath.replace("/results/", "/correctness/");
			this.checkPath(checkResultPath);
			
			OWLClassExpression unsatConcept = null; //getOWLClassExpression(currentOnto, entailmentString);
			System.out.println("[Info] Path : "+ subFile.getPath());
			
			JustsReader reader = new JustsReader(logPath+"/log.txt", debugMethod);
			HashSet<HashSet<String>> allMUPSString = reader.getJusts();	
			//ReadMUPSLog.printAllMUPS(allMUPSString);
			System.out.println("Found justs : "+allMUPSString.size());
			
			HashSet<HashSet<OWLAxiom>> allMUPS = MUPSUtils.getSetsOfOWLAxioms(allMUPSString, currentOnto);
			
			ReasoningTask.reasoner = "pellet";
			HashSet<OWLAxiom> entailed = new HashSet<OWLAxiom>();
			entailed.add(entailment);
			System.out.println("ent: "+entailment.toString());
			int i = 1;
			for(HashSet<OWLAxiom> mups : allMUPS){
				HashSet<OWLAxiom> mups2 = new HashSet<OWLAxiom>();
				for(OWLAxiom axiom : mups){
					System.out.println(axiom.getAxiomWithoutAnnotations());
					mups2.add(axiom.getAxiomWithoutAnnotations());
					System.out.println(ReasoningTools.canBeEntailed(mups, axiom));
				}
				try{
					OWLTools.saveOntology(mups, "file:///e:/mups"+(i++)+".owl");
				} catch (Exception ex){
					ex.printStackTrace();
				}
				
				System.out.println(ReasoningTools.canBeEntailed(mups2, entailed));
			}
			//JustCorrectnessChecker.checkJustsCorrectness(allMUPS, unsatConcept);
		}
	}
	
	
	private void checkPath(String path){
		// Check the path to store results
		File file = new File(path);
		if(!file.exists()){
			file.mkdirs();
		} else {
			file = new File(path+"/log.txt");
			if(file.exists()){
				file.delete();
			}
		}
		//System.setOut((new PrintStreamObject(path+"/log.txt")).ps);			
	}
	
/*	public OWLClassExpression getOWLClassExpression(OWLOntology ontology, String entailmentStr){
		OWLClassExpression oce = null;
		if(entailmentStr.indexOf("++")!=-1){
			String str = entailmentStr.replace("++", " ");
			String[] strings = str.split(" ");
			OWLNamedIndividual indi = OWLTools.getIndividual(ontology, strings[0], true);
			OWLClass type = OWLTools.getOWLClass(ontology, strings[1]);
	    	//type = OWLTools.getOWLClass(ontology, "http://www.geneontology.org/formats/oboInOwl#Subset");
	    	entailment = OWL.factory.getOWLClassAssertionAxiom(type, indi);
	    	oce = OWL.factory.getOWLObjectIntersectionOf(OWL.factory.getOWLObjectComplementOf(type), OWL.factory.getOWLObjectOneOf(indi));
	    	
		} else if(entailmentStr.indexOf("top+bot") != -1){
			oce = OWL.factory.getOWLThing();
			
		} else if(entailmentStr.indexOf("+") != -1){
			String str = entailmentStr.replace("+", " ");
			String[] strings = str.split(" ");
			OWLClass subClass = OWLTools.getOWLClass(ontology, strings[0]);
	    	OWLClass supClass = OWLTools.getOWLClass(ontology, strings[1]);
	    	oce = OWL.factory.getOWLObjectIntersectionOf(subClass, OWL.factory.getOWLObjectComplementOf(supClass));
	    				
		} else {
			oce = OWLTools.getOWLClass(ontology, entailmentStr);
		}
		return oce;
	} */
		
}
