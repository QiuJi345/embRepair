package edu.njupt.radon.debug.correctness;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapi.explanation.SatisfiabilityConverter;
import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLPrinter;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.InconsistencyTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class CorrectnessCheckerJustsLong {
	
	OWLOntology onto;
	OWLClass unsatConcept;
	OWLAxiom entailment = null;
	
	public static void main(String[] args) throws Exception {		
		/*String entailmentStr = "http://lsi.ugr.es/joseluisgs/videojuegos.owl#Motor_Fisico subClassOf " +
				"http://lsi.ugr.es/joseluisgs/videojuegos.owl#Interactividad-Experiencia";*/
		
		String entailmentStr = "UndergraduateStudent83++Student";
		String ontoName = "lubm_1"; 
		String debugTask = "consistent-abox";
		String ontoRoot = "g:/Experiments/2014-KBS-evaluation/systems/pellet/data/";	
		String ontoPath = "file:"+ontoRoot + debugTask+"/"+ontoName+".owl";
		String resultPath = "g:/Experiments/2014-KBS-evaluation/results/log.txt";
		
		System.setOut((new PrintStreamObject("d:/log.txt")).ps);
		
		OWLOntology onto = OWLTools.openOntology(ontoPath);		
		CorrectnessCheckerJustsLong cl = new CorrectnessCheckerJustsLong(onto, entailmentStr);
		
		cl.checkCorrectness(resultPath);		
	}
	
	/**
	 * Initialize the required parameters
	 * 
	 * @param ontology
	 * @param entailmentString
	 */
	public CorrectnessCheckerJustsLong(OWLOntology ontology, String entailmentString){
		this.onto = ontology;
		this.iniDebuggedEntailment(entailmentString);
	}
	
	/**
	 * Obtain the entailment to be explained
	 * @param entailmentString
	 */
	private void iniDebuggedEntailment(String entailmentString){
		String[] elements = entailmentString.split(" ");		
		if(elements[1].equals("subClassOf")){
			// Obtain the subclass
			//subClass = OWLTools.getOWLClass(onto, strArray[0], true);
			OWLClass subClass = OWLTools.getOWLClass(onto, elements[0], true);
			// Obtain the superclass
			//superClass = OWLTools.getOWLClass(onto, strArray[2], true);
			OWLClass superClass = OWLTools.getOWLClass(onto, elements[2],true);
			entailment = OWL.factory.getOWLSubClassOfAxiom(subClass, superClass);
			
		} else if(elements[1].equals("types")){
			// Obtain an individual in OWLAPI
			OWLIndividual individual = OWLTools.getIndividual(onto, elements[0], true);
			// Obtain a class in OWLAPI
			OWLClass indiType = OWLTools.getOWLClass(onto, elements[2], true);
			entailment = OWL.factory.getOWLClassAssertionAxiom(indiType, individual);
		} else {
			entailment = null;
		}
	}
	
	/**
	 * Check where a justification S of an entailment ax is correct or not by 
	 * checking whether ax can be entailed by S directly.
	 * 
	 * @throws Exception
	 */
	public void checkCorrectness(String logPath) throws Exception {
		System.out.println("Read mups string ... ");
		HashSet<HashSet<String>> allMUPSString = this.getFoundMUPS(logPath);
		System.out.println("Transfer a string to an owlaxiom ... ");
		HashSet<HashSet<OWLAxiom>> allJusts = this.getSetsOfOWLAxioms(onto, allMUPSString);
		//CompareUtil.printAllMUPS(allJusts);
		//InconsistencyTools.ch
		
		System.out.println("Check correctness ... ");
		int i = 1;		
		for(HashSet<OWLAxiom> just : allJusts){
			//OWLTools.saveOntology(just, "file:///d:/test.owl");
			
			boolean isJustCorrect = true;
			InconsistencyTools.printOneMUPS(just, i++);
			if(ReasoningTools.canBeEntailed(just, entailment)){
				HashSet<OWLAxiom> just_copy = new HashSet<OWLAxiom>(just);
				for(OWLAxiom axiom : just){
					just_copy.remove(axiom);
					if(ReasoningTools.canBeEntailed(just_copy, entailment)){
						System.out.println("[Info] Is it a real Just w.r.t. entailment <"
								+entailment.getAxiomWithoutAnnotations().toString()+"> ? false");	
						//System.out.println("[Info] This mups is not minimal.");
						System.out.println("[Info] This axiom is redundant: "+axiom.getAxiomWithoutAnnotations().toString());
						//OWLTools.saveOntology(mups, "file:///e:/data/temp/mups_"+(n++)+".owl");
						isJustCorrect = false;	
					} else {
						just_copy.add(axiom);
					}
				}		
			} else {
				System.out.println("[Info] The entailment cannot be entailed.");
				isJustCorrect = false;
			}
			System.out.println("Is this just correct? "+isJustCorrect);
			System.out.println("------------------------------------");
		}
		
	}
	
	/**
	 *  Check where a justification S of an entailment ax is correct or not by 
	 *  transferring a justification to a MUPS. Specifically, we convert ax to 
	 *  a complex unsatisfiable concept C_complex first and then add a new axiom ax2
	 *  C_new=C_complex to S. Then we check the correctness of S union {ax2} for 
	 *  concept C_new.
	 */
	public void checkCorrectnessByTransfer(){		
		SatisfiabilityConverter converter = new SatisfiabilityConverter( OWL.factory );;
		OWLClassExpression unsatConcept = converter.convert( entailment );
		OWLClass newConcept = OWL.factory.getOWLClass(IRI.create("http://www.radon.cn#newC"));
		OWLAxiom newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(newConcept,unsatConcept);
		
		String logPath2 = "onto/log.txt";
		System.out.println("Read mups string ... ");
		HashSet<HashSet<String>> allMUPSString = this.getFoundMUPS(logPath2);
		
		
		System.out.println("Transfer a string to an owlaxiom ... ");
		HashSet<HashSet<OWLAxiom>> allMUPS = this.getSetsOfOWLAxioms(this.onto, allMUPSString);
		OWLPrinter.printAxiomSets(allMUPS, "MUPS");
		
		System.out.println("Add new axiom to each MUPS ... ");
		for(HashSet<OWLAxiom> mups : allMUPS){
			mups.add(newAxiom);
		}
		System.out.println("Check correctness ... ");
		InconsistencyTools.checkMUPSCorrectness(allMUPS, newConcept);
	}
	
	public HashSet<HashSet<String>> getFoundMUPS(String logPath) {
		HashSet<HashSet<String>> allMUPSString = new HashSet<HashSet<String>>();
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneMUPSBegin = false;
				
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {	
				
				int radonStartIndex = oneLine.indexOf("Found a new");
				int pelletStartIndex = oneLine.indexOf("Explanation");
				if(radonStartIndex != -1 || pelletStartIndex != -1){
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS has been finished.
					if(oneLine.trim().length() == 0 && oneMUPSString.size()>0){
						// Add the found MUPS to the collection of MUPS
						allMUPSString.add(new HashSet<String>(oneMUPSString));
						// Set the start
						isOneMUPSBegin = false;
					} else {
						int index1 = oneLine.indexOf("]");
						if(index1 != -1){
							// Get the string after ]
							String axiomString = oneLine.substring(index1+1).trim();
							// Remove the first blank space if exists
							if(axiomString.indexOf(" ")==0){
								axiomString = axiomString.substring(1);
							}
							// Add the axiom string to the the collection of axiom strings.
							if(!axiomString.contains("http://radon.org#")){
								oneMUPSString.add(axiomString);	
							}													
						} 
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		return allMUPSString;
	}
	
	public HashSet<HashSet<OWLAxiom>> getSetsOfOWLAxioms(
			OWLOntology onto, 
			HashSet<HashSet<String>> stringSets){
		HashSet<HashSet<OWLAxiom>> axiomSets = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<String> stringSet : stringSets){
			HashSet<OWLAxiom> axiomSet = getOWLAxioms(onto, stringSet);
			axiomSets.add(axiomSet);
		}
		return axiomSets;
	}

	public HashSet<OWLAxiom> getOWLAxioms(OWLOntology onto, HashSet<String> strings){
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		for(String string : strings){
			OWLAxiom axiom = getOWLAxiom(onto, string);
			if(axiom != null){
				axioms.add(axiom);
			}
		}
		return axioms;
	}
	
	public static OWLAxiom getOWLAxiom(OWLOntology onto, String string){
		for(OWLAxiom axiom : onto.getLogicalAxioms()){
			if(axiom.toString().equals(string) || axiom.getAxiomWithoutAnnotations().toString().equals(string)){
				return axiom.getAxiomWithoutAnnotations();
			}
		}
		return null;
	}
}
