package edu.njupt.radon.debug.correctness;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.inco.MUPSUtils;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.InconsistencyTools;

public class CorrectnessCheckerMUPSProtege {
		
	public static void main(String[] args) throws Exception {		
		// Deal with the input parameters		
		String systemName = "ProtegeBl";
		String debugTask = "incoherent";
		String reasonerName = "pellet";
		String ontoPath = "g:/Experiments/2014-KBS-evaluation/systems/protege/data/" + debugTask + "/";
		String resultPath = "g:/Experiments/2014-KBS-evaluation/results/"  + reasonerName +"/" + debugTask + "/"+ systemName + "/";
		resultPath = "g:/log.txt";
		System.setOut((new PrintStreamObject("d:/log.txt")).ps);
		
		
		
		
		
		File ontosFile = new File(resultPath);
		for(File ontoFile : ontosFile.listFiles()){
			String ontoName = ontoFile.getName();
			ontoPath += ontoName + ".owl";
			if(!ontoName.equals("MaasMatch-cmt-sigkdd")){
				continue;
			}
			OWLOntology onto = OWLTools.openOntology(ontoPath);		
			System.out.println("[Info] ontology name : "+ontoName);
			
			
			String ucsPath = resultPath+ontoName + "/"+ systemName + "/";
			File entsFile = new File(ucsPath);
			for(File entFile : entsFile.listFiles()){
				String ucName = entFile.getName();
				if(!ucName.equals("cmt#Administrator")){
					continue;
				}			
				OWLClass unsatConcept = OWLTools.getOWLClass(onto, ucName);
				System.out.println("[Info] uc name : "+ ucName);
				HashSet<HashSet<String>> allMUPSString = getFoundMUPS(ucsPath+
						ucName+"/log.txt");
				//ReadMUPSLog.printAllMUPS(allMUPSString);
				System.out.println("Found mups : "+allMUPSString.size());
				
				HashSet<HashSet<OWLAxiom>> allMUPS = MUPSUtils.getSetsOfOWLAxioms(allMUPSString, onto);
				InconsistencyTools.checkMUPSCorrectness(allMUPS, unsatConcept);
			}
		}
	}
	
	
	public static HashSet<HashSet<String>> getFoundMUPS(String logPath) {
		HashSet<HashSet<String>> allMUPSString = new HashSet<HashSet<String>>();
		HashSet<String> oneMUPSString = new HashSet<String>();
		int explanationStringNumber = 0;
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {		
				if(oneLine.startsWith("Found ")){
					continue;
				}
				if(explanationStringNumber <= 1 && oneLine.startsWith("Explanation <")){
					explanationStringNumber ++;
					// Add the found MUPS to the collection of MUPS 
					if(explanationStringNumber == 2){
						// Add the found MUPS to the collection of MUPS
						allMUPSString.add(new HashSet<String>(oneMUPSString));
						// Set the start
						explanationStringNumber = 1;
						oneMUPSString.clear();
					} 					
					continue;
				} 
				
				if(explanationStringNumber >= 1){
					// Add the axiom string to the the collection of axiom strings.
					oneMUPSString.add(oneLine.trim());	
				}
			}
			
			// Add the last found mups to the collection of mups
			if(explanationStringNumber == 1 && oneMUPSString.size() > 0){
				// Add the found MUPS to the collection of MUPS
				allMUPSString.add(new HashSet<String>(oneMUPSString));
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		return allMUPSString;
	}
	
}
