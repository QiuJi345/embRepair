package edu.njupt.radon.debug.correctness;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import edu.njupt.radon.utils.io.FileTools;

public class CorrectnessCheckerJustsSWOOP {
	
	String subclassof = "\u8838?";
	String exists = "\u8707?";
	String equiv = "\'a1\'d4";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String filePath = "D:/data/debugging/odbm/swoop-gl/incoherent/LogMapLt-cocus-crs_dr/cocus#Email.rtf";
		
		CorrectnessCheckerJustsSWOOP corr = new CorrectnessCheckerJustsSWOOP();
		corr.readJusts(filePath);

	}
	
	public void readJusts(String filePath){
		String text = "";
		String justStartString = "Axioms causing the problem: ";
		int length = justStartString.length();
		try {
			// Open the file that is the first command line parameter
			FileInputStream fstream = new FileInputStream(filePath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {				
				text += strLine + "\n";
				int index = strLine.indexOf(justStartString);
				if(index != -1){
					strLine = strLine.substring(index+length);
					System.out.println(strLine);
					getJust(strLine);					
				}				
			}
			// Close the input stream
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
	
	private void getJust(String line){
		int counter = 1;
		int nextAxiomIndex = line.indexOf(counter+")");
		while(true){
			line = line.substring(line.indexOf("("));
					
			counter ++;
			nextAxiomIndex = line.indexOf(counter+")");
			if(nextAxiomIndex != -1){
				String axiomStr = line.substring(0, nextAxiomIndex).trim();
				System.out.println(axiomStr);
			} else {
				int reasonIndex = line.indexOf("Reason");
				String axiomStr = line;
				if(reasonIndex != -1){
					axiomStr = line.substring(0, reasonIndex);
				}
				System.out.println(axiomStr);
				break;
			}
			line = line.substring(nextAxiomIndex);
		}
	}

}
