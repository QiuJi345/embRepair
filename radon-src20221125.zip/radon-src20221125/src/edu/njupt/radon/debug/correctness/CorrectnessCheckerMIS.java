package edu.njupt.radon.debug.correctness;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.InconsistencyTools;

public class CorrectnessCheckerMIS {
	
	OWLOntology ontology;
	
	public static void main(String[] args) throws Exception {
		// Make the outputs be saved to a given file
		System.setOut((new PrintStreamObject("d:/log.txt")).ps);
       		
		String ontoName = "miniTambis"; 
		String debugTask = "incoherent";
		String ontoRoot = "g:/Experiments/2014-KBS-evaluation/systems/pellet/data/";	
		String ontoPath = "file:"+ontoRoot + debugTask+"/"+ontoName+".owl";
		// Load an OWL ontology
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		
		CorrectnessCheckerMIS correctness = new CorrectnessCheckerMIS(onto);
		HashSet<HashSet<String>> allMISString = correctness.getFoundMUPS("g:/Experiments/2014-KBS-evaluation/results/log.txt");
		//correctness.printAllMUPS(allMISString);
		
		HashSet<HashSet<OWLAxiom>> allMIS = correctness.getSetsOfOWLAxioms(allMISString);
		InconsistencyTools.checkMISCorrectness(allMIS);
	}
	
	public CorrectnessCheckerMIS(OWLOntology ontology){
		this.ontology = ontology;
	}
		
	private HashSet<HashSet<OWLAxiom>> getSetsOfOWLAxioms(HashSet<HashSet<String>> stringSets){
		HashSet<HashSet<OWLAxiom>> axiomSets = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<String> stringSet : stringSets){
			HashSet<OWLAxiom> axiomSet = this.getOWLAxioms(stringSet);
			axiomSets.add(axiomSet);
		}
		return axiomSets;
	}
	
	private HashSet<OWLAxiom> getOWLAxioms(HashSet<String> strings){
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		for(String string : strings){
			OWLAxiom axiom = this.getOWLAxiom(string);
			if(axiom != null){
				axioms.add(axiom);
			} else {
				System.out.println(" Error to transfer a string to an owlaxiom!");
			}
		}
		return axioms;
	}
	
	private OWLAxiom getOWLAxiom(String string){
		for(OWLAxiom axiom : ontology.getLogicalAxioms()){
			String axiomString = axiom.toString();
			if(axiomString.equals(string)){
				return axiom;
			}
		}
		return null;
	}
	
	private void printAllMUPS(HashSet<HashSet<String>> allMUPSString){
		int mupsCounter = 0;
		for(HashSet<String> oneMUPSString : allMUPSString){
			mupsCounter ++;
			System.out.println("MIS "+mupsCounter);
			
			int axiomCounter = 0;
			for(String oneString : oneMUPSString){
				System.out.println((axiomCounter++)+"> "+oneString);
			}
			System.out.println();
		}
	}
	
	public HashSet<HashSet<String>> getFoundMUPS(String logPath) {
		HashSet<HashSet<String>> allMUPSString = new HashSet<HashSet<String>>();
		HashSet<String> oneMUPSString = new HashSet<String>();
		boolean isOneMUPSBegin = false;
				
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fileStream = new FileInputStream(logPath);
			// Get the object of DataInputStream
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataStream));
			
			String oneLine;	
			// Read File Line By Line			
			while ((oneLine = bufferedReader.readLine()) != null) {					
				int radonStartIndex = oneLine.indexOf("Found explanation <");
				int pelletStartIndex = oneLine.indexOf("Explanation");
				if(radonStartIndex != -1 || pelletStartIndex != -1){
					isOneMUPSBegin = true;
					oneMUPSString.clear();
					continue;
				} 
				
				if(isOneMUPSBegin){
					// In this case, the output of one MUPS has been finished.
					if(oneLine.trim().length() == 0 && oneMUPSString.size()>0){
						// Add the found MUPS to the collection of MUPS
						allMUPSString.add(new HashSet<String>(oneMUPSString));
						// Set the start
						isOneMUPSBegin = false;
					} else {
						int index1 = oneLine.indexOf("]");
						if(index1 != -1){
							// Get the string after ]
							String axiomString = oneLine.substring(index1+1).trim();
							// Remove the first blank space if exists
							if(axiomString.indexOf(" ")==0){
								axiomString = axiomString.substring(1);
							}
							// Add the axiom string to the the collection of axiom strings.
							oneMUPSString.add(axiomString);							
						} 
					}
				}
			}
			// Close the input stream
			dataStream.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} 
		return allMUPSString;
	}

}
