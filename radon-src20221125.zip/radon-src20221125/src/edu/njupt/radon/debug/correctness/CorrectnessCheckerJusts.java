package edu.njupt.radon.debug.correctness;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class CorrectnessCheckerJusts {
		
	public static void checkJustsCorrectness(HashSet<HashSet<OWLAxiom>> justs, OWLClass oce){
		int justCounter = 1;
		for(HashSet<OWLAxiom> just : justs){
			System.out.println("Justification <"+(justCounter++)+">");
			checkJustCorrectness(just, oce);
		}
	}
	
	public static boolean checkJustCorrectness(
			HashSet<OWLAxiom> just, OWLClass oce) {	
		
		// output the justification
   	    CommonTools.printOneSet(new HashSet<OWLAxiom>(just), null); 
    	 
		if(ReasoningTools.isSatisfiable(just, oce)){
			System.out.println("[Wrong] This justification cannot be used to explain the concept <"+oce.toString()+">");
			return false;
		}
		
		HashSet<OWLAxiom> subset = new HashSet<OWLAxiom>(just);
		for(OWLAxiom axiom : just){
			subset.remove(axiom);
			if(ReasoningTools.isSatisfiable(subset, oce)){
				subset.add(axiom);
			} else {
				System.out.println("[Redundant] "+axiom.toString());
			    return false;
			}
		}
		System.out.println("[Correct] This justification is correct.");
		System.out.println();
		return true;
	}
		

}
