package edu.njupt.radon.debug.completeness;

import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.inco.MUPSUtils;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class MUPSCompletenessCheck {
	
	private HashSet<Vector<OWLAxiom>> allHS = new HashSet<Vector<OWLAxiom>>();
	
	private OWLClass unsatConcept; 
	private HashSet<OWLAxiom> debuggingAxioms;
	private HashSet<HashSet<OWLAxiom>> allMUPS;
		
	private boolean isComplete = true;
	
	public static void main(String[] args){
		String logPath = DebuggingParameters.resultPath+DebuggingParameters.ucName+"/log.txt";
		
		OWLOntology onto = OWLTools.openOntology(DebuggingParameters.ontoPath);
		OWLClass unsatConcept = OWLTools.getOWLClass(onto, DebuggingParameters.ucName);
		
		HashSet<HashSet<String>> allMUPSString = MUPSUtils.getFoundJusts(logPath);
		HashSet<HashSet<OWLAxiom>> allMUPS = MUPSUtils.getSetsOfOWLAxioms(allMUPSString, onto);
		System.out.println("[Onto] "+DebuggingParameters.ontoName);
		System.out.println("[UC] "+DebuggingParameters.ucName);
		System.out.println("Number of all MUPS: "+allMUPS.size());
		
		Set<OWLAxiom> module = OWLTools.extractModule(onto, unsatConcept);
		System.out.println("Module size : "+module.size());
		MUPSCompletenessCheck check = new MUPSCompletenessCheck(unsatConcept, new HashSet<OWLAxiom>(module), allMUPS);
		long startTime = System.currentTimeMillis();
		System.out.println(check.isComplete());
		System.out.println("Time (ms) : "+(System.currentTimeMillis()-startTime));
		
	}
	
	public MUPSCompletenessCheck(OWLClass unsatConcept, 
			HashSet<OWLAxiom> debuggingAxioms,
			HashSet<HashSet<OWLAxiom>> allMUPS){
		this.unsatConcept = unsatConcept;
		this.debuggingAxioms = debuggingAxioms;
		this.allMUPS = allMUPS;
	}
	
	public MUPSCompletenessCheck(OWLClass unsatConcept, 
			OWLOntology onto,
			HashSet<HashSet<OWLAxiom>> allMUPS){
		this.unsatConcept = unsatConcept;
		this.debuggingAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		this.allMUPS = allMUPS;
	}
		
	public boolean isComplete() {
		if (allMUPS == null || allMUPS.size() == 0) {
			return false;
		} 
		getUnionOfMUPS(allMUPS);
		//HashSet<OWLAxiom> firstJust = getOneMUPS(allMUPS);
		HashSet<OWLAxiom> firstJust = allMUPS.iterator().next();
		System.out.println("The size of the first just: " + firstJust.size());
		// If no MUPS can be reused, then compute one MUPS.
		if(firstJust == null || firstJust.size() == 0){
			return false;	
		} else {
			//List<OWLAxiom> orderedMUPS = getOrderedMUPS(new ArrayList<OWLAxiom>(firstJust), allMUPS);			
			for (OWLAxiom axiomInEdge : firstJust) {
				Vector<OWLAxiom> path = new Vector<OWLAxiom>();
				debuggingAxioms.remove(axiomInEdge);
				depthFirstSearchHST(debuggingAxioms, axiomInEdge, path);				
				debuggingAxioms.add(axiomInEdge);
			}
		}		
		System.out.println("Number of All HS : "+allHS.size());
		return isComplete;
	}
	
	private void depthFirstSearchHST( 
			HashSet<OWLAxiom> currentDebuggingAxioms, 
			OWLAxiom axiomInEdge,
			Vector<OWLAxiom> path) {
				
		HashSet<OWLAxiom> currentDebuggingAxioms_c = new HashSet<OWLAxiom>(currentDebuggingAxioms);		
		Vector<OWLAxiom> newPath = new Vector<OWLAxiom>(path);
		newPath.add(axiomInEdge);
		
		// Reuse existing MUPS	
		HashSet<OWLAxiom>  newJust = getNonIntersectingMUPS(newPath);
		if(newJust == null || newJust.size() == 0){
			// Early path termination
			if(!canBeTerminated(newPath)){
				if(ReasoningTools.isSatisfiable(currentDebuggingAxioms,unsatConcept, null)){
					allHS.add(new Vector<OWLAxiom>(newPath));
					//System.out.println("Find a hitting set!");
				} else {
					isComplete = false;			
					System.out.println("Not complete!");
				}
			}
		} else if(isComplete){		
			for (OWLAxiom newBranchAxiom : newJust) {
				currentDebuggingAxioms_c.remove(newBranchAxiom);
				depthFirstSearchHST(currentDebuggingAxioms_c, newBranchAxiom, newPath); 
				currentDebuggingAxioms_c.add(newBranchAxiom);
			}
		} 		  		
	}
	
	
        
    private HashSet<OWLAxiom> getUnionOfMUPS(HashSet<HashSet<OWLAxiom>> mupsSet){
    	HashSet<OWLAxiom> unionOfMUPS = new HashSet<OWLAxiom>();
    	for(HashSet<OWLAxiom> mups : mupsSet){
    		unionOfMUPS.addAll(mups);
    	}
    	System.out.println("The size of the union of MUPS: "+unionOfMUPS.size());
    	return unionOfMUPS;
    }
    
	private boolean canBeTerminated(Vector<OWLAxiom> path){
		for(Vector<OWLAxiom> hittingSet : allHS){
			if(path.containsAll(hittingSet)){
				return true;
			}
		}
		return false;
	}

	private HashSet<OWLAxiom> getNonIntersectingMUPS(Vector<OWLAxiom> path){
		//Justification reuse
		for (HashSet<OWLAxiom> oneMUPS : allMUPS ){
			if (!CommonTools.hasIntersection(oneMUPS, path)){
				return oneMUPS;
			}
		}
		return null;
	}
}


