package edu.njupt.radon.debug.completeness;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.bfs.HittingSetTree;
import edu.njupt.radon.debug.incoherence.bfs.Node;
import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.inco.MUPSUtils;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class CompletenessCheck {
	
	private HashSet<Vector<OWLAxiom>> allHS = new HashSet<Vector<OWLAxiom>>();
	
	private OWLClass unsatConcept; 
	private HashSet<OWLAxiom> debuggingAxioms;
	private HashSet<HashSet<OWLAxiom>> allMUPS;
	
	private boolean isComplete = true;
	
	public static void main(String[] args){
		String logPath = DebuggingParameters.resultPath+DebuggingParameters.ucName+"/log.txt";
		
		OWLOntology onto = OWLTools.openOntology(DebuggingParameters.ontoPath);
		OWLClass unsatConcept = OWLTools.getOWLClass(onto, DebuggingParameters.ucName);
		
		HashSet<HashSet<String>> allMUPSString = MUPSUtils.getFoundJusts(logPath);
		HashSet<HashSet<OWLAxiom>> allMUPS = MUPSUtils.getSetsOfOWLAxioms(allMUPSString, onto);
		System.out.println("[Onto] "+DebuggingParameters.ontoName);
		System.out.println("[UC] "+DebuggingParameters.ucName);
		System.out.println("Number of all MUPS: "+allMUPS.size());
		
		Set<OWLAxiom> module = OWLTools.extractModule(onto, unsatConcept);
		System.out.println("Module size : "+module.size());
		CompletenessCheck check = new CompletenessCheck(unsatConcept, new HashSet<OWLAxiom>(module), allMUPS);
		long startTime = System.currentTimeMillis();
		System.out.println(check.isComplete());
		System.out.println("Time (ms) : "+(System.currentTimeMillis()-startTime));
		
	}
	
	public CompletenessCheck(OWLClass unsatConcept, 
			HashSet<OWLAxiom> debuggingAxioms,
			HashSet<HashSet<OWLAxiom>> allMUPS){
		this.unsatConcept = unsatConcept;
		this.debuggingAxioms = debuggingAxioms;
		this.allMUPS = allMUPS;
	}
	
	public CompletenessCheck(OWLClass unsatConcept, 
			OWLOntology onto,
			HashSet<HashSet<OWLAxiom>> allMUPS){
		this.unsatConcept = unsatConcept;
		this.debuggingAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		this.allMUPS = allMUPS;
	}
		
	public boolean isComplete() {
		if (allMUPS == null || allMUPS.size() == 0) {
			return false;
		} 
		//HashSet<OWLAxiom> firstJust = getOneMUPS(allMUPS);
		HashSet<OWLAxiom> firstJust = allMUPS.iterator().next();
		System.out.println("The size of the first just: " + firstJust.size());
		// If no MUPS can be reused, then compute one MUPS.
		if(firstJust == null || firstJust.size() == 0){
			return false;	
		} else {
			//List<OWLAxiom> orderedMUPS = getOrderedMUPS(new ArrayList<OWLAxiom>(firstJust), allMUPS);			
			for (OWLAxiom axiomInEdge : firstJust) {
				Vector<OWLAxiom> path = new Vector<OWLAxiom>();
				debuggingAxioms.remove(axiomInEdge);
				depthFirstSearchHST(debuggingAxioms, axiomInEdge, path);				
				debuggingAxioms.add(axiomInEdge);
			}
		}		
		
		return isComplete;
	}
	
	private void depthFirstSearchHST( 
			HashSet<OWLAxiom> currentDebuggingAxioms, 
			OWLAxiom axiomInEdge,
			Vector<OWLAxiom> path) {
				
		HashSet<OWLAxiom> currentDebuggingAxioms_c = new HashSet<OWLAxiom>(currentDebuggingAxioms);		
		Vector<OWLAxiom> newPath = new Vector<OWLAxiom>(path);
		newPath.add(axiomInEdge);
		
		// Reuse existing MUPS	
		HashSet<OWLAxiom>  newJust = getNonIntersectingMUPS(newPath);
		if(newJust == null || newJust.size() == 0){
			// Early path termination
			if(!canBeTerminated(newPath)){
				allHS.add(new Vector<OWLAxiom>(newPath));
				/*if(ReasoningTools.isSatisfiable(currentDebuggingAxioms,unsatConcept, null)){
					allHS.add(new Vector<OWLAxiom>(newPath));
					//System.out.println("Find a hitting set!");
				} else {
					isComplete = false;			
					System.out.println("Not complete!");
				}*/
			}
		} else {	
			for (OWLAxiom newBranchAxiom : newJust) {
				currentDebuggingAxioms_c.remove(newBranchAxiom);
				depthFirstSearchHST(currentDebuggingAxioms_c, newBranchAxiom, newPath); 
				currentDebuggingAxioms_c.add(newBranchAxiom);
			}
		} 		  		
	}
	
	private boolean isCompleteBFS() {
		
		//HashSet<Vector<OWLAxiom>> exploredPaths = new HashSet<Vector<OWLAxiom>>();
		HashSet<OWLAxiom> singleJust = null;
		HittingSetTree hst = new HittingSetTree();
		
		// Reuse the existing MUPS
		if (allMUPS.size()>0) {	
			singleJust = allMUPS.iterator().next();
		}
		
		// If no MUPS can be reused, then compute one MUPS.
		if(singleJust==null){
			singleJust = allMUPS.iterator().next();	
		}
		
		// Create the root node
		Node rootnode = new Node(singleJust);
		Queue<Node> queue = new LinkedList<Node>();
		queue.add(rootnode);
		// Iterate on the nodes in the queue
		while(!queue.isEmpty()){
			// Obtain the node on the top of the queue
			Node node = (Node)queue.remove();
			// Iterate on the axioms in the node
			for(OWLAxiom axiom : node.data){
				// Get the path from the current node to the root node
				Vector<OWLAxiom> path = hst.getPathToRoot(node);
				// Expand the current path
                path.add(axiom);
                // Early path termination
        		if(canBeTerminated(path)){
        			continue;
        		}
        		
        		// Reuse existing MUPS
				HashSet<OWLAxiom> newMUPS = getNonIntersectingMUPS(path);
				// If no MUPS can be reused, then compute a new one
				if(newMUPS == null || newMUPS.size() == 0){
					debuggingAxioms.removeAll(path);
					if(ReasoningTools.isSatisfiable(debuggingAxioms,unsatConcept, null)){
						allHS.add(new Vector<OWLAxiom>(path));
						//System.out.println("Find a hitting set!");
						debuggingAxioms.addAll(path);
						continue;
					} else {
						isComplete = false;			
						System.out.println("Not complete!");
						debuggingAxioms.addAll(path);
						break;
					}
				}
				// Create a new node for the MUPS that are newly discovered.
				Node newNode = new Node(newMUPS);
				queue.add(newNode);	
				// Add a MUPS to the set of all MUPS
				allMUPS.add(newMUPS);
				// expand the hitting set tree
				hst.addEdge(node, newNode, axiom);
			}
		}
		return isComplete;
	}
	
	private void depthFirstSearchHSTAdvanced( 
			HashSet<OWLAxiom> currentDebuggingAxioms, 
			OWLAxiom axiomInEdge,
			Vector<OWLAxiom> path) {
				
		HashSet<OWLAxiom> currentDebuggingAxioms_c = new HashSet<OWLAxiom>(currentDebuggingAxioms);		
		Vector<OWLAxiom> newPath = new Vector<OWLAxiom>(path);
		newPath.add(axiomInEdge);
		
		// Reuse existing MUPS		
		//HashSet<OWLAxiom>  newJust = getOneMUPS(nonIntersectingMUPS);
		HashSet<OWLAxiom>  newJust = getNonIntersectingMUPS(newPath);
		//System.out.println("Nonintersecting mups number : "+nonIntersectingMUPS.size());
		if(newJust == null || newJust.size() == 0){
			// Early path termination
			if(!canBeTerminated(newPath)){
				if(ReasoningTools.isSatisfiable(currentDebuggingAxioms,unsatConcept, null)){
					allHS.add(new Vector<OWLAxiom>(newPath));
					//System.out.println("Find a hitting set!");
				} else {
					isComplete = false;			
					System.out.println("Not complete!");
				}
			}
		} else if(isComplete){	
			HashSet<HashSet<OWLAxiom>> nonIntersectingMUPS = getAllNonIntersectingMUPS(newPath);
			List<OWLAxiom> orderedMUPS = getOrderedMUPS(new ArrayList<OWLAxiom>(newJust), nonIntersectingMUPS);
			for (OWLAxiom newBranchAxiom : orderedMUPS) {
				currentDebuggingAxioms_c.remove(newBranchAxiom);
				depthFirstSearchHST(currentDebuggingAxioms_c, newBranchAxiom, newPath); 
				currentDebuggingAxioms_c.add(newBranchAxiom);
			}
		} 		  		
	}
	
	  /**
     * Orders the axioms in a single MUPS by the frequency of which they appear
     * in all MUPS.
     * @param mups The MUPS containing the axioms to be ordered
     * @param allMups The set of all MUPS which is used to calculate the ordering
     */
    private static List<OWLAxiom> getOrderedMUPS(List<OWLAxiom> mups, 
    		final HashSet<HashSet<OWLAxiom>> allMups) {
        Comparator<OWLAxiom> mupsComparator = new Comparator<OWLAxiom>() {
            public int compare(OWLAxiom axiom1, OWLAxiom axiom2) {
                // The axiom that appears in most MUPS has the lowest index
                // in the list
                int occ1 = getOccurrences(axiom1, allMups);
                int occ2 = getOccurrences(axiom2, allMups);
                return -occ1 + occ2;
            }
        };
        Collections.sort(mups, mupsComparator);
        return mups;
    }
    
    private HashSet<OWLAxiom> getOneMUPS(HashSet<HashSet<OWLAxiom>> mupsSet){
    	HashMap<OWLAxiom, Integer> axiomOccurrences = getAxiomOccurrences(mupsSet);
    	HashSet<OWLAxiom> mupsWithMaxAvgOccurrence = new HashSet<OWLAxiom>();
    	double maxAvgOccurrence = 0;
    	
    	for(HashSet<OWLAxiom> oneMUPS : mupsSet){
    		double averageOccurrence = 0;
    		for(OWLAxiom axiom : oneMUPS){
    			averageOccurrence += axiomOccurrences.get(axiom);
    		}
    		averageOccurrence = (double)averageOccurrence / oneMUPS.size();
    		if(averageOccurrence > maxAvgOccurrence){
    			maxAvgOccurrence = averageOccurrence;
    			mupsWithMaxAvgOccurrence = new HashSet<OWLAxiom>(oneMUPS);
    		}
    	}
    	return mupsWithMaxAvgOccurrence;
    }
    
    private HashMap<OWLAxiom, Integer> getAxiomOccurrences(HashSet<HashSet<OWLAxiom>> mupsSet){
    	HashMap<OWLAxiom, Integer> axiomOccurrences = new HashMap<OWLAxiom, Integer>();
    	HashSet<OWLAxiom> unionOfMUPS = this.getUnionOfMUPS(mupsSet);
    	for(OWLAxiom axiom : unionOfMUPS){
    		int occurrence = getOccurrences(axiom, mupsSet);
    		axiomOccurrences.put(axiom, occurrence);
    	}
    	return axiomOccurrences;
    }
    
    /**
     * Given an axiom and a set of axioms this method determines how many sets
     * contain the axiom.
     * @param ax The axiom that will be counted.
     * @param axiomSets The sets to count from
     */
    private static int getOccurrences(OWLAxiom ax, HashSet<HashSet<OWLAxiom>> axiomSets) {
        int count = 0;
        for (Set<OWLAxiom> axioms : axiomSets) {
            if (axioms.contains(ax)) {
                count++;
            }
        }
        return count;
    }
    
        
    private HashSet<OWLAxiom> getUnionOfMUPS(HashSet<HashSet<OWLAxiom>> mupsSet){
    	HashSet<OWLAxiom> unionOfMUPS = new HashSet<OWLAxiom>();
    	for(HashSet<OWLAxiom> mups : mupsSet){
    		unionOfMUPS.addAll(mups);
    	}
    	//System.out.println("The size of the union of MUPS: "+unionOfMUPS.size());
    	return unionOfMUPS;
    }
    
	private boolean canBeTerminated(Vector<OWLAxiom> path){
		for(Vector<OWLAxiom> hittingSet : allHS){
			if(path.containsAll(hittingSet)){
				return true;
			}
		}
		return false;
	}

	private HashSet<OWLAxiom> getNonIntersectingMUPS(Vector<OWLAxiom> path){
		//Justification reuse
		for (HashSet<OWLAxiom> oneMUPS : allMUPS ){
			if (!CommonTools.hasIntersection(oneMUPS, path)){
				return oneMUPS;
			}
		}
		return null;
	}
	
	private HashSet<HashSet<OWLAxiom>> getAllNonIntersectingMUPS(Vector<OWLAxiom> path){
		HashSet<HashSet<OWLAxiom>> mupsSet = new HashSet<HashSet<OWLAxiom>>();
		for (HashSet<OWLAxiom> oneMUPS : allMUPS ){
			if (!CommonTools.hasIntersection(oneMUPS, path)){
				mupsSet.add(new HashSet<OWLAxiom>(oneMUPS));
			}
		}
		return mupsSet;
	}
	
}


