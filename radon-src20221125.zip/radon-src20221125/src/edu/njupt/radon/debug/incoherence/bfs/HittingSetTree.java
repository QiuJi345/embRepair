package edu.njupt.radon.debug.incoherence.bfs;

import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;

public class HittingSetTree {
	
	Vector<Node> firstNodes = new Vector<Node>();
	Vector<Node> secondNodes = new Vector<Node>();
	Vector<OWLAxiom> axiomsInEdge = new Vector<OWLAxiom>();
	Vector<Boolean> isHittingSet = new Vector<Boolean>();
	
	public void addEdge(Node firstNode, Node secondNode, OWLAxiom axiomInEdge){
		addEdge(firstNode, secondNode, axiomInEdge, false);
	}
	
	public void addEdge(Node firstNode, Node secondNode, OWLAxiom axiomInEdge, Boolean isHS){
		firstNodes.add(firstNode);
		secondNodes.add(secondNode);
		axiomsInEdge.add(axiomInEdge);
		isHittingSet.add(isHS);
	}
	
	public Vector<OWLAxiom> getPathToRoot(Node currentNode){
		Vector<OWLAxiom> path = new Vector<OWLAxiom>();
		if(!secondNodes.contains(currentNode)){
			return path;
		}
		int indexInSecondNodeList = secondNodes.indexOf(currentNode);
		while(indexInSecondNodeList != -1){
			Node firstNode = firstNodes.get(indexInSecondNodeList);
			path.add(axiomsInEdge.get(indexInSecondNodeList));
			indexInSecondNodeList = secondNodes.indexOf(firstNode);
		}
		return path;
	}

}



