package edu.njupt.radon.debug.incoherence.heuristic;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLEntity;

import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindPath;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.InconsistencyTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class PatternUtils {	
	public static void check(HashSet<HashSet<OWLAxiom>> conflicts, OWLClass uc){
		// Output a conflict set
		System.out.println("      [Number] Found conflict sets: "+conflicts.size());
		InconsistencyTools.checkMUPSCorrectness(conflicts, uc);
		
	}
	
	public static HashSet<HashSet<OWLAxiom>> combinePartialJusts(			 
			HashSet<HashSet<OWLAxiom>> partialJusts1,
			HashSet<HashSet<OWLAxiom>> partialJusts2){
		
		HashSet<HashSet<OWLAxiom>> completeJusts = new HashSet<HashSet<OWLAxiom>>();
		
		// Combine two partial sets.
		if(partialJusts1 != null && partialJusts1.size() > 0 
				&& partialJusts2 != null && partialJusts2.size() > 0){			
			for(HashSet<OWLAxiom> set1 : partialJusts1){
				for(HashSet<OWLAxiom> set2 : partialJusts2){
					HashSet<OWLAxiom> set = new HashSet<OWLAxiom>();
					set.addAll(set1);
					set.addAll(set2);
					completeJusts.add(new HashSet<OWLAxiom>(set));
				}
			}	
			//completeJusts = getMinimalConflicts(completeJusts);
		} else if(partialJusts1 != null && partialJusts1.size() >0 &&
				(partialJusts2 == null || partialJusts2.size() == 0)){
			completeJusts = partialJusts1;
		} else if(partialJusts2 != null && partialJusts2.size() >0 &&
				(partialJusts1 == null || partialJusts1.size() == 0)){
			completeJusts = partialJusts2;
		}
		// Return the found set of justifications.
		return completeJusts;
	}
	
	public static HashSet<HashSet<Vector<OWLClassExpression>>> combinePartialPaths(			 
			HashSet<HashSet<Vector<OWLClassExpression>>> partialJusts1,
			HashSet<HashSet<Vector<OWLClassExpression>>> partialJusts2){
		
		HashSet<HashSet<Vector<OWLClassExpression>>> completeJusts = new HashSet<HashSet<Vector<OWLClassExpression>>>();
		
		// Combine two partial sets.
		if(partialJusts1 != null && partialJusts1.size() > 0 
				&& partialJusts2 != null && partialJusts2.size() > 0){			
			for(HashSet<Vector<OWLClassExpression>> set1 : partialJusts1){
				for(HashSet<Vector<OWLClassExpression>> set2 : partialJusts2){
					HashSet<Vector<OWLClassExpression>> set = new HashSet<Vector<OWLClassExpression>>();
					set.addAll(set1);
					set.addAll(set2);
					completeJusts.add(new HashSet<Vector<OWLClassExpression>>(set));
				}
			}	
			//completeJusts = getMinimalConflicts(completeJusts);
		} else if(partialJusts1 != null && partialJusts1.size() >0 &&
				(partialJusts2 == null || partialJusts2.size() == 0)){
			completeJusts = partialJusts1;
		} else if(partialJusts2 != null && partialJusts2.size() >0 &&
				(partialJusts1 == null || partialJusts1.size() == 0)){
			completeJusts = partialJusts2;
		}
		// Return the found set of justifications.
		return completeJusts;
	}
	
	/**
	 * For each set in conflicts, remove those axioms 
	 * which do not influence the unsatisfiability of a concept uc.
	 * 
	 * @param conflicts
	 * @param uc
	 * @return
	 */
	public static HashSet<HashSet<OWLAxiom>> getMUPS(
			HashSet<HashSet<OWLAxiom>> currConflicts, OWLClass uc){
        
		System.out.println("[Info] Newly found conflict sets: "+currConflicts.size() +" for concept <"+uc.getIRI().toString()+">");
		HashSet<HashSet<OWLAxiom>> mups = new HashSet<HashSet<OWLAxiom>>();
		if(currConflicts != null && currConflicts.size()>0){	
			// Minimize each found conflict set such that the set is a MUPS
			for(HashSet<OWLAxiom> conflict : currConflicts){
				HashSet<OWLAxiom> onto = new HashSet<OWLAxiom>(conflict);
				for(OWLAxiom a : conflict){
					onto.remove(a);
					if(ReasoningTools.isSatisfiable(onto, uc)){
						onto.add(a);
					}
				}
				mups.add(new HashSet<OWLAxiom>(onto));
			}
			// Output all MUPS
			System.out.println("[Info] Newly found MUPS: "+mups.size());	
			//CommonTools.printMultiSets(mups, null);	
			//System.out.println("------------------");	
			
		} else {
			System.out.println("    [Info] No MUPS can be found!");
		}
		
		// Return all MUPS
		return mups;
	}
	
	/**
	 * 
	 * @param conflicts
	 * @return
	 */
	public static HashSet<HashSet<Vector<OWLClass>>> getMinimalPaths(
			HashSet<HashSet<Vector<OWLClass>>> conflicts){
		
		if(conflicts.size() <= 1){
			return conflicts;
		}
		HashMap<Integer, HashSet<HashSet<Vector<OWLClass>>>> orderedConflicts = stratifyPaths(conflicts);
		HashSet<HashSet<Vector<OWLClass>>> minConflicts = getMinimalPaths(orderedConflicts);
		
		return minConflicts;
	}
	
	public static HashMap<Integer, HashSet<HashSet<Vector<OWLClass>>>> stratifyPaths(
			HashSet<HashSet<Vector<OWLClass>>> conflicts){
		HashMap<Integer, HashSet<HashSet<Vector<OWLClass>>>> orderedConfs = new 
		HashMap<Integer, HashSet<HashSet<Vector<OWLClass>>>>();
		for(HashSet<Vector<OWLClass>> conf : conflicts){
			int size = conf.size();
			if(orderedConfs.containsKey(size)){
				orderedConfs.get(size).add(conf);
			} else {
				HashSet<HashSet<Vector<OWLClass>>> confSet = new HashSet<HashSet<Vector<OWLClass>>>();
				confSet.add(conf);
				orderedConfs.put(size, confSet);
			}
		}
		return orderedConfs;
	}
	
	public static HashSet<HashSet<Vector<OWLClass>>> getMinimalPaths(
			HashMap<Integer, HashSet<HashSet<Vector<OWLClass>>>> orderedConflicts){
		
		HashSet<HashSet<Vector<OWLClass>>> minConflicts = new HashSet<HashSet<Vector<OWLClass>>>();
				
		Vector<Integer> orderedSize = CommonTools.reorderASC(new HashSet<Integer>(orderedConflicts.keySet()));
		// Those conflicts with minimal number of axioms are minimal conflicts.
		minConflicts.addAll(orderedConflicts.get(orderedSize.get(0)));		
		for(int i = 1; i < orderedSize.size(); i ++){
			int size = orderedSize.get(i);
			
			HashSet<HashSet<Vector<OWLClass>>> newMinConflicts = new HashSet<HashSet<Vector<OWLClass>>>();
			for(HashSet<Vector<OWLClass>> conf1 : orderedConflicts.get(size)){
				boolean contains = false;
				for(HashSet<Vector<OWLClass>> conf2 : minConflicts){
					if(conf1.containsAll(conf2)){
						contains = true;
						break;
					}
				}
				if(!contains){
					newMinConflicts.add(conf1);
				}
			}
			if(newMinConflicts.size()>0){
				minConflicts.addAll(newMinConflicts);
			}
		}
		return minConflicts;
	}
	
	/**
	 * Remove those sets of axioms which contain another set of axioms
	 * 
	 * @param sets
	 * @return
	 */
	public static HashSet<HashSet<OWLAxiom>> getMinimalSets(
			HashSet<HashSet<OWLAxiom>> sets){
		
		if(sets.size() <= 1){
			return sets;
		}
		HashMap<Integer, HashSet<HashSet<OWLAxiom>>> orderedConflicts = stratifyConflicts(sets);
		HashSet<HashSet<OWLAxiom>> minConflicts = getMinimalSets(orderedConflicts);
		
		return minConflicts;
	}
	

	/**
	 * Remove those sets of axioms which contain another set of axioms
	 * 
	 * @param orderedConflicts
	 * @return
	 */
	public static HashSet<HashSet<OWLAxiom>> getMinimalSets(
			HashMap<Integer, HashSet<HashSet<OWLAxiom>>> orderedConflicts){
		
		HashSet<HashSet<OWLAxiom>> minConflicts = new HashSet<HashSet<OWLAxiom>>();
				
		Vector<Integer> orderedSize = CommonTools.reorderASC(new HashSet<Integer>(orderedConflicts.keySet()));
		// Those conflicts with minimal number of axioms are minimal conflicts.
		minConflicts.addAll(orderedConflicts.get(orderedSize.get(0)));		
		for(int i = 1; i < orderedSize.size(); i ++){
			int size = orderedSize.get(i);
			
			HashSet<HashSet<OWLAxiom>> newMinConflicts = new HashSet<HashSet<OWLAxiom>>();
			for(HashSet<OWLAxiom> conf1 : orderedConflicts.get(size)){
				boolean contains = false;
				for(HashSet<OWLAxiom> conf2 : minConflicts){
					if(conf1.containsAll(conf2)){
						contains = true;
						break;
					}
				}
				if(!contains){
					newMinConflicts.add(conf1);
				}
			}
			if(newMinConflicts.size()>0){
				minConflicts.addAll(newMinConflicts);
			}
		}
		return minConflicts;
	}
	
	public static HashMap<Integer, HashSet<HashSet<OWLAxiom>>> stratifyConflicts(
			HashSet<HashSet<OWLAxiom>> conflicts){
		HashMap<Integer, HashSet<HashSet<OWLAxiom>>> orderedConfs = new 
		HashMap<Integer, HashSet<HashSet<OWLAxiom>>>();
		for(HashSet<OWLAxiom> conf : conflicts){
			int size = conf.size();
			if(orderedConfs.containsKey(size)){
				orderedConfs.get(size).add(conf);
			} else {
				HashSet<HashSet<OWLAxiom>> confSet = new HashSet<HashSet<OWLAxiom>>();
				confSet.add(conf);
				orderedConfs.put(size, confSet);
			}
		}
		return orderedConfs;
	}
		
	public static HashSet<HashSet<OWLAxiom>> transferConflicts(
			HashSet<HashSet<Vector<OWLClass>>> completeConflicts,
			OWLDisjointClassesAxiom disjAxiom,
			HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>> inferredJusts,
			HashMap<Vector<OWLClassExpression>, OWLAxiom> axiomMap){
		
		// Transfer pairs to logical axioms.
		HashSet<HashSet<OWLAxiom>> logicConflicts = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<Vector<OWLClass>> conflict : completeConflicts){
			// Transfer an informal conflict to some logical conflicts.
			HashSet<HashSet<OWLAxiom>> someConflicts = new HashSet<HashSet<OWLAxiom>>();			
			for(Vector<OWLClass> pair : conflict){
				if(inferredJusts.containsKey(pair)){
					if(someConflicts.size() == 0){
						someConflicts.addAll(inferredJusts.get(pair));
					} else {
						// Combine partial conflicts.
						HashSet<HashSet<OWLAxiom>> tempConflicts = new HashSet<HashSet<OWLAxiom>>();
						for(HashSet<OWLAxiom> partialJust1 : someConflicts){							
							for(HashSet<OWLAxiom> partialJust2 : inferredJusts.get(pair)){
								HashSet<OWLAxiom> oneLogicConf = new HashSet<OWLAxiom>();
								oneLogicConf.addAll(partialJust1);
								oneLogicConf.addAll(partialJust2);
								tempConflicts.add(new HashSet<OWLAxiom>(oneLogicConf));
							}
						}
						someConflicts = new HashSet<HashSet<OWLAxiom>>(tempConflicts);
					}
					
				} else if(axiomMap.containsKey(pair)){
					if(someConflicts.size() == 0){
						HashSet<OWLAxiom> oneLogicConf = new HashSet<OWLAxiom>();
						oneLogicConf.add(axiomMap.get(pair));
						someConflicts.add(new HashSet<OWLAxiom>(oneLogicConf));
					} else {
						for(HashSet<OWLAxiom> just : someConflicts){
							just.add(axiomMap.get(pair));
						}
					}
					
				} else {
					System.err.println("Pair: "+pair.get(0).toString()+", "+pair.get(1).toString());
					System.err.println("Error to transfer the pair to owlaxiom.");
				}
			}
			for(HashSet<OWLAxiom> partialJust1 : someConflicts){					
				partialJust1.add(disjAxiom);
			}
			logicConflicts.addAll(new HashSet<HashSet<OWLAxiom>>(someConflicts));
		}
		return logicConflicts;
	}
	

	public static void getDisjointAxioms(
			HashSet<HashSet<Vector<OWLClassExpression>>> completeConflicts,
			OntologyInfo myOnto){
		for(HashSet<Vector<OWLClassExpression>> conflict : completeConflicts){
			HashSet<HashSet<OWLAxiom>> someConflicts = new HashSet<HashSet<OWLAxiom>>();	
			for(Vector<OWLClassExpression> pair : conflict){	
				if(myOnto.getDisjointAxiomsMap().containsKey(pair)){
					if(someConflicts.size() == 0){
						HashSet<OWLAxiom> oneLogicConf = new HashSet<OWLAxiom>();
						oneLogicConf.add(myOnto.getDisjointAxiomsMap().get(pair));
						someConflicts.add(new HashSet<OWLAxiom>(oneLogicConf));
					} else {
						HashSet<HashSet<OWLAxiom>> set_temp = new HashSet<HashSet<OWLAxiom>>();	
						for(HashSet<OWLAxiom> just : someConflicts){
							HashSet<OWLAxiom> newJust = new HashSet<OWLAxiom>();
							newJust.addAll(just);							
							newJust.add(myOnto.getDisjointAxiomsMap().get(pair));
							set_temp.add(newJust);
						}
						someConflicts = new HashSet<HashSet<OWLAxiom>>(set_temp);
					}
				}
			}
		}		
	}
	
	public static HashSet<HashSet<OWLAxiom>> transferConflicts(
			HashSet<HashSet<Vector<OWLClassExpression>>> completeConflicts,
			ClassHierarchy classhier,
			OntologyInfo myOnto){
		
		HashSet<HashSet<OWLAxiom>> logicConflicts = new HashSet<HashSet<OWLAxiom>>();
				
		for(HashSet<Vector<OWLClassExpression>> conflict : completeConflicts){
			HashSet<OWLAxiom> axiomSetConflict = new HashSet<OWLAxiom>();	
			for(Vector<OWLClassExpression> pair : conflict){				
				HashSet<OWLAxiom> axiomSubset = getAxioms(classhier, myOnto, pair);
				axiomSetConflict.addAll(axiomSubset);
			}
			logicConflicts.add(axiomSetConflict);
		}
		return logicConflicts;
	}
	
	private static HashSet<OWLAxiom> getAxioms(
			ClassHierarchy hier, OntologyInfo myOnto, 
			Vector<OWLClassExpression> conceptPair) {
		
		HashSet<OWLAxiom> axiomSet = getAxioms(myOnto, conceptPair);
		if(!axiomSet.isEmpty()) {
			return axiomSet;
		}
		
		if(hier.getInferredRelationJusts().containsKey(conceptPair)){
			HashSet<HashSet<OWLAxiom>> hierJust = hier.getInferredRelationJusts().get(conceptPair);
			for(HashSet<OWLAxiom> pairInJust : hierJust) {
				axiomSet.addAll(pairInJust);			
			}	
			
		} else {	
			axiomSet = 	getInferredAxioms(myOnto, hier, conceptPair);	
		}
		return axiomSet;
	}
	
	private static HashSet<OWLAxiom> getAxioms(OntologyInfo myOnto, 
			Vector<OWLClassExpression> conceptPair) {
		
		HashSet<OWLAxiom> axiomSet = new HashSet<OWLAxiom>();	
		if(myOnto.getPairAxiomMap().containsKey(conceptPair)){
			OWLAxiom correspondingAxiom = myOnto.getPairAxiomMap().get(conceptPair);
			axiomSet.add(correspondingAxiom);
			
		} else if(myOnto.getDisjointAxiomsMap().containsKey(conceptPair)){
			OWLAxiom correspondingAxiom = myOnto.getDisjointAxiomsMap().get(conceptPair);
			axiomSet.add(correspondingAxiom);			
		} 

		return axiomSet;
	}
	

	/** to be continue (qiu). The process must be iterative since any pair of concepts may be indirect subsumption. **/
	private static HashSet<OWLAxiom> getInferredAxioms(OntologyInfo myOnto,
			ClassHierarchy classHier, Vector<OWLClassExpression> pair) {
		
		HashSet<OWLAxiom> axiomSet = new HashSet<OWLAxiom>();	
		FindPath findPath = new FindPath(classHier.getClassHierarchy());
		HashSet<HashSet<Vector<OWLClassExpression>>> paths = findPath.findPaths(pair.get(0), pair.get(1));
		for(HashSet<Vector<OWLClassExpression>> path : paths) {			
			for(Vector<OWLClassExpression> edge : path) {
				HashSet<OWLAxiom> axiomSubset = getAxioms(myOnto, edge);
				if(axiomSubset.isEmpty()) {
					System.err.println("Pair: "+edge.get(0).toString()+", "+edge.get(1).toString());
					System.err.println("2-Error to transfer the pair to owlaxiom.");		
				} else {
					axiomSet.addAll(axiomSubset);
				}		
			}
			break; // Only consider the first path since usually there is only on such a path.
		} 
		return axiomSet;
	}

	public static void printInferJusts(HashMap<Vector<OWLClass>, HashSet<HashSet<OWLAxiom>>> inferredJusts){
		if(inferredJusts != null){
			for(Vector<OWLClass> pair : inferredJusts.keySet()){
				for(HashSet<OWLAxiom> p : inferredJusts.get(pair)){
					System.out.println("just");
					for(OWLAxiom a : p){
						System.out.println(" --"+a.toString());
					}
				}
			}
		}
		
	}
	public static HashSet<HashSet<OWLAxiom>> translatePaths(
			HashSet<HashSet<Vector<OWLEntity>>> completeConflicts,
			PropertyHierarchy hierarchy){
		
		HashSet<HashSet<OWLAxiom>> logicConflicts = new HashSet<HashSet<OWLAxiom>>();
		if(completeConflicts == null){
			return logicConflicts;
		}
		if(completeConflicts.size() == 0){
			return logicConflicts;
		}
		HashMap<Vector<OWLEntity>, OWLAxiom> axiomMap = hierarchy.getPairAxiomMap();		
		for(HashSet<Vector<OWLEntity>> conflict : completeConflicts){
			HashSet<OWLAxiom> oneLogicConf = new HashSet<OWLAxiom>();
			for(Vector<OWLEntity> pair : conflict){
				if(axiomMap.containsKey(pair)){
					oneLogicConf.add(axiomMap.get(pair));
				} else {
					System.err.println("Pair: "+pair.get(0).toString()+", "+pair.get(1).toString());
					System.err.println("Error to transfer a pair to owlaxiom.");
				}
			}
			logicConflicts.add(new HashSet<OWLAxiom>(oneLogicConf));
		}
		return logicConflicts;
	}
		
	
}
