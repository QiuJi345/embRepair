package edu.njupt.radon.debug.incoherence.heuristic;

import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLObjectProperty;

import edu.njupt.radon.debug.correctness.CorrectnessCheckerJusts;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.pattern.DebuggingPattern;
import edu.njupt.radon.debug.incoherence.heuristic.pattern.PatternExistAll;
import edu.njupt.radon.debug.incoherence.heuristic.pattern.PatternExistBot;
import edu.njupt.radon.debug.incoherence.heuristic.pattern.PatternExistDomain;
import edu.njupt.radon.debug.incoherence.heuristic.pattern.PatternExistRange;
import edu.njupt.radon.debug.incoherence.heuristic.pattern.PatternIsaDisjoint;


public class PatternControl {	
	OntologyInfo myOnto;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc;	
	HashSet<HashSet<OWLAxiom>> allMUPS = new HashSet<HashSet<OWLAxiom>>();
	
	public PatternControl(
			OntologyInfo myOnto,
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass uc){		
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = uc;		
	}
		
	public HashSet<HashSet<OWLAxiom>> findMUPS(){
		if(HeuristicDebug.visitedConcepts.contains(uc)){ 
			return new HashSet<HashSet<OWLAxiom>>();
		} 
		HeuristicDebug.visitedConcepts.add(uc);		
		
		HashMap<OWLObjectProperty, HashSet<OWLClass>> ranges = myOnto.getPropertyRanges();
		HashMap<OWLEntity, HashSet<OWLClassExpression>> domains = myOnto.getPropertyDomains();
		
		// Compute MUPS by using isBottome pattern
		
		// Compute MUPS by using isa-disj pattern
		this.outputCurrentInfo("Isa-Disj");
		DebuggingPattern debugPattern = new PatternIsaDisjoint(myOnto, classHier, uc);
		HashSet<HashSet<OWLAxiom>> confs = debugPattern.findMUPS();	
		addMUPS(confs);
		
		if(myOnto.getDirectExistentialConditions().size()>0){
			// Detect the pattern of some-unsatConcept
			this.outputCurrentInfo("Some-Bottom");
			debugPattern = new PatternExistBot(myOnto, classHier, propHier, uc);
			confs = debugPattern.findMUPS();
			addMUPS(confs);
			
			// Check whether we use pattern of some-all.
			if(myOnto.getDirectUniversalConditions().size()>0 ){
				this.outputCurrentInfo("Some-All");
				debugPattern = new PatternExistAll(myOnto, classHier, propHier, uc);
				confs = debugPattern.findMUPS();
				addMUPS(confs);				
			}
			
 			// Check whether we use the pattern of some-range
			if(ranges.size() > 0){
				this.outputCurrentInfo("Some-Range");
				debugPattern = new PatternExistRange(myOnto, classHier, propHier, uc);
				confs = debugPattern.findMUPS();
				addMUPS(confs);
			}
			// Check whether we use the pattern of some-domain
			if(domains.size() > 0){
				this.outputCurrentInfo("Some-Domain");
				debugPattern = new PatternExistDomain(myOnto, classHier, propHier, uc);
				confs = debugPattern.findMUPS();
				addMUPS(confs);
			}			
		}
		
		
		/*if(opInCardiMin.size() > 0){
			// Check whether we use the pattern of cardiMin-all
			if(opInAll.size()>0 ){	
				this.outputCurrentInfo("CardiMin-All");
				debugPattern = new PatternCardiAll(myOnto, classHier, propHier, uc);
				confs = debugPattern.findMUPS();
				// Minimize each found conflict set to make it as a MUPS and add the newly found MUPS to allMUPS
				PatternUtils.getMUPS(conflicts, confs, uc);
			}
			// Check whether we use the pattern of cardiMin-range
			if(ranges.size() > 0){
				this.outputCurrentInfo("CardiMin-Range");
				debugPattern = new PatternCardiRange(myOnto, classHier, propHier, uc);
				confs = debugPattern.findMUPS();
				// Minimize each found conflict set to make it as a MUPS and add the newly found MUPS to allMUPS
				PatternUtils.getMUPS(conflicts, confs, uc);
			}
			// Check whether we use the pattern of cardiMin-domain
			if(domains.size() > 0){
				this.outputCurrentInfo("CardiMin-Domain");
				debugPattern = new PatternCardiDomain(myOnto, classHier, propHier, uc);
				confs = debugPattern.findMUPS();
				// Minimize each found conflict set to make it as a MUPS and add the newly found MUPS to allMUPS
				PatternUtils.getMUPS(conflicts, confs, uc);
			}				
		}	*/
		removeNonMinimalMUPS();
		return allMUPS;
	}	
	
	private void removeNonMinimalMUPS(){
		HashSet<HashSet<OWLAxiom>> ucMUPS = new HashSet<HashSet<OWLAxiom>>(allMUPS);
		for(HashSet<OWLAxiom> one : ucMUPS){
			int size1 = one.size();
			for(HashSet<OWLAxiom> theOther : ucMUPS){
				int size2 = theOther.size();
				if(size1 > size2 && one.containsAll(theOther)){
					allMUPS.remove(one);
					break;
				}
			}
		}
	}
	
	private void addMUPS(HashSet<HashSet<OWLAxiom>> ucMUPS){
		if(ucMUPS != null && ucMUPS.size() >0){
			//HashSet<HashSet<OWLAxiom>> ucMUPS = PatternUtils.getMUPS(confs, uc);
			if(ucMUPS != null && ucMUPS.size() > 0){
				allMUPS.addAll(ucMUPS);
			}
		}
	}
	
	public void outputCurrentInfo(String patternStr){
		System.out.println("  [UC] Current UC is : "+uc.toString()+", current pattern is "+patternStr);
	}

}
