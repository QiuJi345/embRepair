package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.PatternControl;
import edu.njupt.radon.debug.incoherence.heuristic.PatternUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindPath;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.UnsatPropagation;

/**
 * This pattern shows that a concept is unsatisfiable if it is disjoint with
 * the top concept.
 * 
 * @author Qiu Ji
 * @date 2013.04.19
 */
public class PatternDisjThing implements DebuggingPattern {

	OntologyInfo myOnto;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc;	
		
	public PatternDisjThing(
			OntologyInfo myOnto,
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass uc){		
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = uc;		
	}
	
	@Override
	public HashSet<HashSet<OWLAxiom>> findMUPS() {

		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		UnsatPropagation propagation = new UnsatPropagation(myOnto.getUCsInOriginalOnto(), myOnto.getDirectExistentialConditions());
				
		// Obtain all classes that are disjoint with the unsatisfiable concept
		//HashMap<OWLClass, HashSet<OWLClassExpression>> disjClasses = myOnto.getClassSuperConditions();
		
		// To be continued
		/*for(OWLClass disjClass : disjClasses){
			
		}*/
		
		
		return conflicts;	
	}
	
	@Override
    public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();		
		
		return allConflicts;
	}

}
