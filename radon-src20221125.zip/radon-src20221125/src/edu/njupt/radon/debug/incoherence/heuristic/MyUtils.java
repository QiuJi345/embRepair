package edu.njupt.radon.debug.incoherence.heuristic;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;

public class MyUtils {	
	public static OWLClass getOWLClass(OWLClassExpression oce){
		OWLClass oc = null;
		if(oce != null && !oce.isAnonymous()){
			oc = oce.asOWLClass();			
		}
		return oc;
	}
	
	public static OWLObjectProperty getOWLObjectProperty(OWLObjectPropertyExpression ope){
		OWLObjectProperty op = null;
		if(ope != null && !ope.isAnonymous()){
			op = ope.asOWLObjectProperty();
		}
		return op;
	}

	public static OWLDataProperty getOWLDataProperty(OWLDataPropertyExpression ope){
		OWLDataProperty op = null;
		if(ope != null && !ope.isAnonymous()){
			op = ope.asOWLDataProperty();
		}
		return op;
	}

	
	public static OWLClassExpression getDefinitionInEquAxiom(OWLAxiom axiom){
		OWLEquivalentClassesAxiom eqAxiom = (OWLEquivalentClassesAxiom)axiom;
		Vector<OWLClassExpression> oces = new Vector<OWLClassExpression>(eqAxiom.getClassExpressions());
		OWLClassExpression interClass = oces.get(0);
		if(!interClass.isAnonymous()){
			interClass = oces.get(1);
		}
		return interClass;
	}
	
	public static Vector<OWLDataProperty> createPair(
			OWLDataProperty oc1, 
			OWLDataProperty oc2){
		
		Vector<OWLDataProperty> pair = new Vector<OWLDataProperty>();
		pair.add(oc1);
		pair.add(oc2);
		return pair;
	}
	
	public static Vector<OWLEntity> createPair(
			OWLEntity oc1, 
			OWLEntity oc2){
		
		Vector<OWLEntity> pair = new Vector<OWLEntity>();
		pair.add(oc1);
		pair.add(oc2);
		return pair;
	}
	
	public static Vector<Object> createPair(
			Object oc1, 
			Object oc2){
		
		Vector<Object> pair = new Vector<Object>();
		pair.add(oc1);
		pair.add(oc2);
		return pair;
	}
	
	public static Vector<OWLClassExpression> createPair(
			OWLClassExpression oc1, 
			OWLClassExpression oc2){
		
		Vector<OWLClassExpression> pair = new Vector<OWLClassExpression>();
		pair.add(oc1);
		pair.add(oc2);
		return pair;
	}
	
	public static void addPair(
			HashSet<Vector<OWLClassExpression>> pairs,
			OWLClassExpression oc1, 
			OWLClassExpression oc2){		
		Vector<OWLClassExpression> pair = createPair(oc1, oc2);
		pairs.add(pair);
	}
	
	public static Vector<OWLClass> createPair(
			OWLClass oc1, 
			OWLClass oc2){
		
		Vector<OWLClass> pair = new Vector<OWLClass>();
		pair.add(oc1);
		pair.add(oc2);
		return pair;
	}
	
	public static Vector<OWLObjectPropertyExpression> createPair(
			OWLObjectPropertyExpression oc1, 
			OWLObjectPropertyExpression oc2){
		
		Vector<OWLObjectPropertyExpression> pair = new Vector<OWLObjectPropertyExpression>();
		pair.add(oc1);
		pair.add(oc2);
		return pair;
	}
	
	public static Vector<OWLObjectProperty> createPair(
			OWLObjectProperty oc1, 
			OWLObjectProperty oc2){
		
		Vector<OWLObjectProperty> pair = new Vector<OWLObjectProperty>();
		pair.add(oc1);
		pair.add(oc2);
		return pair;
	}
	
	public static HashSet<HashSet<OWLAxiom>> addAxiomToSet(
			HashSet<HashSet<OWLAxiom>> sets, OWLAxiom ax){
		HashSet<HashSet<OWLAxiom>> newSets = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<OWLAxiom> set : sets){
			HashSet<OWLAxiom> newSet = new HashSet<OWLAxiom>(set);
			newSet.add(ax);
			newSets.add(newSet);
		}
		return newSets;
	}
	
	public static void printConflicts(
			HashSet<HashSet<OWLAxiom>> conflicts){	
		
		if(conflicts == null || conflicts.size() == 0){
			return;
		}
		System.out.println("  [Info] The found mups are listed as below: ");		
		int j = 0;
		for(HashSet<OWLAxiom> oneConflict : conflicts){
			System.out.println("  Conflict <"+(j++)+">");
			int i = 0;
			for(OWLAxiom axiom : oneConflict){
				System.out.println("  ["+(i++)+"] "+axiom.toString());
			}
			System.out.println();
		}		
	}
	
	public static void printOneConflict(
			HashSet<OWLAxiom> conf){	
		
		if(conf == null || conf.size() == 0){
			return;
		}
		System.out.println("  MUPS: ");		
		int i = 0;
		for(OWLAxiom axiom : conf){
			System.out.println("  ["+(i++)+"] "+axiom.toString());
		}		
	}

	public static void printConflicts(
			HashSet<HashSet<Vector<OWLClass>>> completeConflicts,
			OWLClass disjointClass1,
			OWLClass disjointClass2){		
		System.out.println("[Info] The found mups are listed as below: ");
		
		int j = 0;
		for(HashSet<Vector<OWLClass>> oneConflict : completeConflicts){
			System.out.println("  Conflict <"+(j++)+">");
			int i = 0;
			for(Vector<OWLClass> pair : oneConflict){
				System.out.println("  ["+(i++)+"] "+pair.get(0).toString()+" isa "+pair.get(1).toString());
			}
			System.out.println("  ["+i+"] "+disjointClass1.toString()+" disjointWith "+disjointClass2.toString());
			System.out.println();
		}		
	}

}
