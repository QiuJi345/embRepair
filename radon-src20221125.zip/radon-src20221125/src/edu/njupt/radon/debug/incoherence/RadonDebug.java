package edu.njupt.radon.debug.incoherence;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

public interface RadonDebug {
	// Compute mups for all unsatisfiable concepts
	HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS();
	// Compute mups for a given unsatisfiable concept
	HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass unsatConcept);
	// Compute mups for a given unsatisfiable concept based on existing mups
	HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass unsatConcept, HashSet<HashSet<OWLAxiom>> foundMUPS);
	// The hitting sets found when computing mups
	HashSet<Vector<OWLAxiom>> getHittingSets();
}
