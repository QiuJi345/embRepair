package edu.njupt.radon.debug.incoherence.relevance;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import edu.njupt.radon.selefunc.ALCSelectionFunction;
import edu.njupt.radon.selefunc.SelectionFunction;
import edu.njupt.radon.selefunc.SigBasedSelectionFunction;
import edu.njupt.radon.selefunc.SubBasedSelectionFunction;
import edu.njupt.radon.utils.CommonTools;

/** 
 * A just (i.e. justification) means a minimal sub-ontology T which is incoherent 
 * w.r.t. an unsatisfiable concept C but any subset of T is coherent w.r.t. C.
 * 
 * The strategy provided here includes the one by implementing the black-box
 * algorithm in the paper of "Finding all justifications ..."(Aditya) (ISWC'07), and
 * another one is our new algorithm. 
 *  */
public class ComputeOneMUPS  {
	
	private int mupsCounter = 1;	
	private int pruneWindow = 10;
	// If true, we use the strategy of slow pruning. Otherwise, we use half search strategy.
	private boolean applySlowPrune = true;
	
	// Axioms to be debugged
	HashSet<OWLAxiom> debuggingAxioms;	
	// Selection function to be bused
	SelectionFunction seleFunc;	
	
	RelDebugTools tools = null;
	
	public ComputeOneMUPS(HashSet<OWLAxiom> axioms){
		this.debuggingAxioms = new HashSet<OWLAxiom>(axioms);
		this.iniSelectionFunction(axioms);
		tools = new RelDebugTools();
	}
	
	private void iniSelectionFunction(HashSet<OWLAxiom> axioms){
		if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.SubSeleFunc)){
			seleFunc = new SubBasedSelectionFunction(axioms);
		} else if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.ALCSeleFunc)){
			seleFunc = new ALCSelectionFunction(axioms);
		} else {
			seleFunc = new SigBasedSelectionFunction(axioms);
		}
	}
	/*
	// If the selection function has been constructed, then we can reuse it to save time.
	public ComputeOneMUPS(HashSet<OWLAxiom> axioms, 
			boolean useBlackBox,
			SelectionFunction sf){
		this.debuggingAxioms = new HashSet<OWLAxiom>(axioms);
		this.useBlackBox = useBlackBox;
		seleFunc = sf;
	}*/
		
	public HashSet<OWLAxiom> getOneMUPS(OWLClass unsatConcept) {
		HashSet<OWLAxiom> oneMUPS = new HashSet<OWLAxiom>();
		// If the concept is satisfiable in the debugging axiom set, then return an empty set.
		if(tools.isSatisfiable(debuggingAxioms,unsatConcept)){
			return oneMUPS;
		}
		oneMUPS = this.getOneMUPSBlackbox(unsatConcept);
		if(oneMUPS != null && oneMUPS.size() > 0){
			//if(oneMUPS.size()>20){
				//System.out.println("stop");
				System.out.println("  Found explanation <"+(mupsCounter++)+"> for concept <"+unsatConcept.getIRI().toString()+">" );
				CommonTools.printOneSet(oneMUPS, null);
				//InconsistencyTools.checkOneMUPSCorrectness(oneMUPS, unsatConcept);				
				System.out.println("------------------");
			//}
			
		}		
		//BlackboxDebug.mupsNum ++;
		//System.out.println("num: "+ BlackboxDebug.mupsNum);
		return oneMUPS;
	}
		

	/**
	 * Compute a single MUPS by using the traditional black-box approach
	 * which is similar to Bijan's black-box approach.
	 * 
	 * @param oc
	 * @return
	 */
	private HashSet<OWLAxiom> getOneMUPSBlackbox(OWLClass oc) {
		
		HashSet<OWLAxiom> oneMUPS = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> relatedAxioms = null;
		HashSet<OWLAxiom> allRelatedAxioms = new HashSet<OWLAxiom>();
		Vector<OWLAxiom> allRelated_c = null;
		boolean coherent = true;
	/*
		if(ReasoningTools.isSatisfiable(debuggingAxioms,oc, timerForReasoning)){
			return oneMUPS;
		}*/
		//expand related OWLAxioms by selection function
		relatedAxioms = seleFunc.getRelatedAxioms(oc);		
		while(relatedAxioms.size()>0){				
			allRelatedAxioms.addAll(relatedAxioms);
			if(!tools.isSatisfiable(allRelatedAxioms,oc)){
				coherent = false;
				break;
			}
			relatedAxioms = seleFunc.getRelatedAxioms(allRelatedAxioms);
		}
		
		if(coherent)
			return oneMUPS;
				
		// Fast pruning
		allRelated_c = new Vector<OWLAxiom>(allRelatedAxioms);
		Vector<OWLAxiom> prunedOWLAxioms = this.fastPrune(allRelated_c, oc);				
		// Slow pruning
		HashSet<OWLAxiom> prunedOWLAxioms_t = this.slowPrune(prunedOWLAxioms, oc);
		oneMUPS = new HashSet<OWLAxiom>(prunedOWLAxioms_t);		
		// return the found MUPS
		return oneMUPS;
	}
	
	private HashSet<OWLAxiom> getOneMUPSBlackboxExt( OWLClass oc){
		HashSet<OWLAxiom> allAx = new HashSet<OWLAxiom>(this.debuggingAxioms);	
		HashSet<OWLAxiom> candi = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> related = null;
		HashSet<OWLAxiom> prunedAx = new HashSet<OWLAxiom>();
		int layer=0;				
		
		System.out.println();
		//System.out.println("In singleJust : allAx size = "+allAx.size());		
		related = seleFunc.getRelatedAxioms(oc);
		while(related.size()>0){	
			//System.out.println("In layer "+layer+", axioms size is "+related.size());
			//OWLTools.printOneSet(related, ns);
			
			prunedAx = this.fastPrune(new Vector<OWLAxiom>(related),allAx, oc);
			if(prunedAx.size()>0){				
				//System.out.println("Axioms selected from this layer : ");
				//OWLTools.printOneSet(prunedAx, ns);
				
				candi.addAll(prunedAx);
				//Choose related axioms for those of MUPS candidates
				allAx.removeAll(related);
				allAx.addAll(candi);
				if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.SubSeleFunc)){
					seleFunc = new SubBasedSelectionFunction(allAx);				
				} else if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.ALCSeleFunc)){
					seleFunc = new ALCSelectionFunction(allAx);
				} else {
					seleFunc = new SigBasedSelectionFunction(allAx);
				}
				related = seleFunc.getRelatedAxioms(candi);	
				layer ++;
			} else {
				break;
			}
		}
		//System.out.println("a MUPS with layer ("+layer+") : ");
		//OWLTools.printOneSet(candi, null);
		return candi;	
	}

	public HashSet<OWLAxiom> fastPrune(Vector<OWLAxiom> layer, 
			HashSet<OWLAxiom> allAx_t, OWLClass oc){
		
		HashSet<OWLAxiom> allAx = new HashSet<OWLAxiom>(allAx_t);
		Vector<OWLAxiom> prunedAxioms = new Vector<OWLAxiom>();
		HashSet<OWLAxiom> candi = new HashSet<OWLAxiom>();
		int size, parts;
		
		size = layer.size();
		
		if(size>pruneWindow){
			System.out.println("fast pruning ...");
			parts = size / pruneWindow;
			for (int part = 0; part < parts; part++) {
				prunedAxioms.clear();
				for (int i = part * pruneWindow; i < part * pruneWindow
						+ pruneWindow; i++) {
					prunedAxioms.add(layer.get(i));
				}
				allAx.removeAll(prunedAxioms);
				try{
					if(tools.isSatisfiable(new HashSet<OWLAxiom>(allAx),oc)){
						allAx.addAll(prunedAxioms);
						if(applySlowPrune){
							slowPrune(candi, prunedAxioms, allAx, oc);
						} else {
							halfSearchPrune(candi, prunedAxioms, allAx, oc);	
						}					
					}		
				} catch (Exception ex){
					ex.printStackTrace();
				}					
			}
			
			if (size > parts * pruneWindow) {
				// add remaining from list to axioms
				prunedAxioms.clear();
				for (int i = parts * pruneWindow; i < size; i++) {
					prunedAxioms.add(layer.get(i));
				}
				if(applySlowPrune){
					slowPrune(candi, prunedAxioms, allAx, oc);
				} else {
					halfSearchPrune(candi, prunedAxioms, allAx, oc);	
				}		
			}
			
		} else {
			prunedAxioms.addAll(layer);	
			if(applySlowPrune){
				slowPrune(candi, prunedAxioms, allAx, oc);
			} else {
				halfSearchPrune(candi, prunedAxioms, allAx, oc);	
			}			
		}
		
		return candi;
		
	}
	
	public Vector<OWLAxiom> fastPrune(Vector<OWLAxiom> allRelated, OWLClass oc) {	
		HashSet<OWLAxiom> prunedOWLAxioms = new HashSet<OWLAxiom>(allRelated);
		int size = allRelated.size();
		//System.out.println(OWLTools.isCoherent(new HashSet<OWLAxiom>(prunedOWLAxioms),oc));
		if(size>pruneWindow){
			int parts = size / pruneWindow;
			for (int part = 0; part < parts; part++) {				
				for (int i = part * pruneWindow; i < part * pruneWindow
						+ pruneWindow; i++) {
					prunedOWLAxioms.remove(allRelated.get(i));
				}
								
				if (tools.isSatisfiable(new HashSet<OWLAxiom>(prunedOWLAxioms),oc)) {
					//System.out.println("Fast prune OWLAxioms");
					for (int i = part * pruneWindow; i < part * pruneWindow
							+ pruneWindow; i++) {
						prunedOWLAxioms.add(allRelated.get(i));
						//System.out.println(i+" > "+allRelated.get(i).toString().replace(ns, ""));
					}
				}
			}
			if (size > parts * pruneWindow) {
				// add remaining from list to OWLAxioms
				for (int i = parts * pruneWindow; i < size; i++) {
					prunedOWLAxioms.add(allRelated.get(i));
				}
			}
		}
		return new Vector<OWLAxiom>(prunedOWLAxioms);
	}
	
	/* Assume all the axioms in this layer can not be removed 
	 * at the same time, then try to remove half of them. 
	 */
	private void halfSearchPrune( HashSet<OWLAxiom> candi, 
			Vector<OWLAxiom> layer, HashSet<OWLAxiom> allAx, 
			OWLClass oc){
		
		Vector<OWLAxiom> halfAx = new Vector<OWLAxiom>();
		int size, middle ;
		boolean flag ;
		
		/* Initialize the parameters */
		size = layer.size();

		middle = (int) (size * 0.5);
		/* Test the first half axioms */
		for(int i = 0; i < middle; i++){
			halfAx.add(layer.get(i));
		}
		allAx.removeAll(halfAx);
		try{
			flag = tools.isSatisfiable(allAx, oc);
			if((halfAx.size()==1) && (flag)){
				allAx.addAll(halfAx);
				candi.addAll(halfAx);
			}else if((halfAx.size()>1) && (flag)){
				allAx.addAll(halfAx);
				halfSearchPrune(candi, halfAx, allAx, oc);
			}
			
			/* Test the second half axioms */
			layer.removeAll(halfAx);		
			allAx.removeAll(layer);
			flag = tools.isSatisfiable(allAx, oc);
			if((layer.size()==1) && (flag)){
				allAx.addAll(layer);
				candi.addAll(layer);
			}else if((layer.size()>1) && (flag)){
				allAx.addAll(layer);
				halfSearchPrune(candi, layer, allAx, oc);
			}
			
		} catch (Exception ex){
			ex.printStackTrace();
		}
	}
	
	private void slowPrune(HashSet<OWLAxiom> candi, 
			Vector<OWLAxiom> layer, HashSet<OWLAxiom> allAx, 
			OWLClass oc){
		//System.out.println("slow pruning ...");
		for(OWLAxiom a : layer){
			allAx.remove(a);
			try{
				if(tools.isSatisfiable(allAx, oc)){
					candi.add(a);
					allAx.add(a);
				}
			} catch (Exception ex){
				ex.printStackTrace();
			}
		}
	}
	
	public HashSet<OWLAxiom> slowPrune(Vector<OWLAxiom> prunedOWLAxioms, 
			OWLClass oc) {
		//System.out.println("Slow pruning : "+prunedOWLAxioms.size());
		
		HashSet<OWLAxiom> prunedOWLAxioms_c = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> prunedOWLAxioms_t = new HashSet<OWLAxiom>();
		prunedOWLAxioms_c.addAll(prunedOWLAxioms);		
		prunedOWLAxioms_t.addAll(prunedOWLAxioms);
		
		//System.out.println("slow prunt > unsatisfiable? "+OWLTools.isCoherent(prunedOWLAxioms_t,oc, checkSatTimer));
		
		for(OWLAxiom a : prunedOWLAxioms_c){			
			prunedOWLAxioms_t.remove(a);			
			if(tools.isSatisfiable(prunedOWLAxioms_t, oc)){	
				prunedOWLAxioms_t.add(a);
			}
		}
		return prunedOWLAxioms_t;
	}
	
/*	public HashSet<OWLAxiom> singleJustCSTree(OWLClass C, HashSet<OWLAxiom> Oin) {
		try {
			computeMUPsByCSTree(new HashSet<OWLAxiom>(), Oin, C);
			System.out.println("one MUPS : ");
			OWLTools.printOneSet(just, "");
			System.out.println();
		} catch (Exception e) {

		}
		return just;
	}*/
	
/*
	private void computeMUPSByCSTree(HashSet<OWLAxiom> DSetIn,
			HashSet<OWLAxiom> PSetIn, OWLClass concept) {

		HashSet<OWLAxiom> augmtOWLAxioms = new HashSet<OWLAxiom>();
		augmtOWLAxioms.addAll(DSetIn);
		augmtOWLAxioms.addAll(PSetIn);
		
		if (ReasoningTools.isSatisfiable(augmtOWLAxioms, concept)) {			
			return;
		}
		
		HashSet<OWLAxiom> PSet = (HashSet<OWLAxiom>)PSetIn.clone();
		HashSet<OWLAxiom> DSet = (HashSet<OWLAxiom>)DSetIn.clone();
		//System.out.println("PSet size : "+PSet.size());
		//System.out.println("DSet size : "+DSet.size());
		while (!PSet.isEmpty()) {
			OWLAxiom c = PSet.iterator().next();
			PSet.remove(c);
			computeMUPSByCSTree((HashSet<OWLAxiom>) DSet, PSet, concept);
			DSet.add(c);
		}

		just = DSet;

	}
	
	*/
/*	public HashSet<OWLAxiom> getOneMUPS(
			HashSet<OWLAxiom> axioms, OWLClass unsatConcept){
		
		HashSet<OWLAxiom> oneMUPS = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> axioms_c = new HashSet<OWLAxiom>(axioms);
		this.ini(axioms_c);				
		if(useBlackBox){
		    oneMUPS = this.getOneMUPSBlackbox(unsatConcept);
		} else { 
			oneMUPS = this.getOneMUPSBlackboxExt(unsatConcept);
		}		
		return oneMUPS;
	}*/
	
	/**
	 * Add one axiom to the current ontology and update the information in 
	 * the selected selection function.
	 * 
	 * @param axiom
	 */
	public void addAxiom(OWLAxiom axiom){
		if(!this.debuggingAxioms.contains(axiom)){
			this.debuggingAxioms.add(axiom);
			seleFunc.addAxiom(axiom);
		}		
	}
	
	public void addAxioms(HashSet<OWLAxiom> axioms){
		for(OWLAxiom a : axioms){
			this.addAxiom(a);
		}
	}
	
	/**
	 * Add one axiom to the current ontology and update the information in 
	 * the selected selection function.
	 * 
	 * @param axiom
	 */
	public void removeAxiom(OWLAxiom axiom){
		if(this.debuggingAxioms.contains(axiom)){
			this.debuggingAxioms.remove(axiom);
			seleFunc.removeAxiom(axiom);
		}
	}
	
	public void removeAxioms(HashSet<OWLAxiom> axioms){
		for(OWLAxiom a : axioms){
			this.removeAxiom(a);
		}
	}
	
	/**
	 * This method is used to set the MUPS counter to zero
	 * which will be used when printing the found MUPS.
	 */
	public void resetMUPSCounter(){
		this.mupsCounter = 1;
	}
}
