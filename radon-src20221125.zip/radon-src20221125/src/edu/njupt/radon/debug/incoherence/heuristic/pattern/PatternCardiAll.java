package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectExactCardinality;
import org.semanticweb.owlapi.model.OWLObjectMinCardinality;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.PatternUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindPath;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;

public class PatternCardiAll implements DebuggingPattern {
	
	OntologyInfo myOnto;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc;	
	
	public PatternCardiAll(
			OntologyInfo myOnto,
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass uc){		
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = uc;		
	}
	
	@Override
	public HashSet<HashSet<OWLAxiom>> findMUPS() {
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		for(OWLClass subC1 : myOnto.getDirectCardiConditions().keySet()){
			for(OWLClassExpression condition1 : myOnto.getDirectCardiConditions().get(subC1)){
				OWLObjectPropertyExpression ope1 = null;
				OWLClassExpression oce1 = null;
				if(condition1 instanceof OWLObjectMinCardinality){
					ope1 = ((OWLObjectMinCardinality)condition1).getProperty();
					oce1 = ((OWLObjectMinCardinality)condition1).getFiller();
				} else if(condition1 instanceof OWLObjectExactCardinality){
					ope1 = ((OWLObjectExactCardinality)condition1).getProperty();
					oce1 = ((OWLObjectExactCardinality)condition1).getFiller();
				} else {
					continue;
				}
				OWLClass filler1 = MyUtils.getOWLClass(oce1);
				
				for(OWLClass subC2 : myOnto.getDirectUniversalConditions().keySet()){
					for(OWLClassExpression condition2 : myOnto.getDirectUniversalConditions().get(subC2)){
						OWLObjectPropertyExpression ope2 = ((OWLObjectAllValuesFrom)condition2).getProperty();
						OWLClassExpression oce2 = ((OWLObjectAllValuesFrom)condition2).getFiller();
						OWLClass filler2 = MyUtils.getOWLClass(oce2);
						
						// If the two properties are not the same, there is no pattern to be considered.
						if(!ope1.equals(ope2)){
							continue;
						}
						
						/** Consider the first part */
						ExpandDisjRelations expand = new ExpandDisjRelations(myOnto, classHier, propHier, uc);
						HashSet<HashSet<OWLAxiom>> partialJusts1 = expand.findJustsForDisjRelation(
								filler1, filler2);
						
						if(partialJusts1 != null && partialJusts1.size()>0){
							/** Consider the second part */
							FindPath findPath = new FindPath(classHier.getClassHierarchy());
							HashSet<HashSet<Vector<OWLClassExpression>>> novelPaths = findPath.findPathPairs(uc, subC1, uc, subC2);	
							// transfer paths to axioms
							HashSet<HashSet<OWLAxiom>> logicConflicts = PatternUtils.transferConflicts(
									novelPaths, classHier, myOnto);
							HashSet<HashSet<OWLAxiom>> partialJusts2 = PatternUtils.getMinimalSets(logicConflicts);

							// Combine two partial justs
							partialJusts2 = PatternUtils.combinePartialJusts(partialJusts1, partialJusts2);
							
							/** Consider the third part */
							// Obtain the axiom with two conditions
							Vector<OWLClassExpression> pair1 = MyUtils.createPair(subC1, condition1);
							OWLAxiom axiom1 = myOnto.getPairAxiomMap().get(pair1);
							Vector<OWLClassExpression> pair2 = MyUtils.createPair(subC2, condition2);
							OWLAxiom axiom2 = myOnto.getPairAxiomMap().get(pair2);	
							// Add the axioms to a partial conflict.
							for(HashSet<OWLAxiom> just : partialJusts2){
								just.add(axiom1);
								just.add(axiom2);
								conflicts.add(new HashSet<OWLAxiom>(just));
							}			
						}						
					}						
				}
			}
		}
		
		return conflicts;
	}
	
	@Override
    public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();		
		
		return allConflicts;
	}

}
