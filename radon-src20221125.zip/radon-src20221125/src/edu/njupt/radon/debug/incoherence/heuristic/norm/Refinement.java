package edu.njupt.radon.debug.incoherence.heuristic.norm;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;

/**
 * This class is not used in the project.
 * 
 * @author ����
 *
 */
public class Refinement {
	
	/** The mapping between a pair of OWLClassExpression and the corresponding OWLAxiom. */
	private HashMap<Vector<OWLClassExpression>, OWLAxiom> classAxiomMap = 
		new HashMap<Vector<OWLClassExpression>, OWLAxiom>();
	HashSet<OWLAxiom> refinedAxioms = new HashSet<OWLAxiom>();
	HashSet<OWLAxiom> axiomsInOnto = new HashSet<OWLAxiom>();
	
	public Refinement(HashSet<OWLAxiom> axiomsInOnto){
		this.axiomsInOnto = new HashSet<OWLAxiom>(axiomsInOnto);
	}
	
	public void doRefine(){
		for(OWLAxiom a : axiomsInOnto){
			// Check whether there is a class expression defined with intersectionOf
			if(a instanceof OWLSubClassOfAxiom){				
				OWLSubClassOfAxiom axiom = (OWLSubClassOfAxiom)a;
				OWLClassExpression subC = axiom.getSubClass();
				OWLClassExpression supC = axiom.getSuperClass();
				HashSet<OWLClassExpression> operands2 = this.getOperands(supC);					
				if(operands2.size() == 0){
					refinedAxioms.add(a);
				} else {
					for(OWLClassExpression op2 : operands2){
						OWLAxiom newAxiom = OWL.subClassOf(subC, op2);
						refinedAxioms.add(newAxiom);
						this.addClassAxiomPair(subC, op2, a);
					}
				}				
				this.addClassAxiomPair(subC, supC, axiom);
				
			} else if(a instanceof OWLEquivalentClassesAxiom){
				OWLEquivalentClassesAxiom axiom = (OWLEquivalentClassesAxiom)a;
				Vector<OWLClassExpression> oces = new Vector<OWLClassExpression>(axiom.getClassExpressions());
				OWLClassExpression oc1 = oces.get(0);
				OWLClassExpression oc2 = oces.get(1);	
				
				this.addClassAxiomPair(oc1, oc2, axiom);				
				this.addClassAxiomPair(oc2, oc1, axiom);
				
				if(oc1 instanceof OWLObjectIntersectionOf){
					OWLObjectIntersectionOf inter = (OWLObjectIntersectionOf)oc1;
					for(OWLClassExpression op2 : inter.getOperands()){
						OWLAxiom newAxiom = OWL.subClassOf(oc2, op2);
						refinedAxioms.add(newAxiom);
						this.addClassAxiomPair(oc2, op2, a);
					}				
				} else {
					if(oc2 instanceof OWLObjectIntersectionOf){
						OWLObjectIntersectionOf inter = (OWLObjectIntersectionOf)oc2;
						for(OWLClassExpression op2 : inter.getOperands()){
							OWLAxiom newAxiom = OWL.subClassOf(oc1, op2);
							refinedAxioms.add(newAxiom);
							this.addClassAxiomPair(oc1, op2, a);
						}
					} else {
						refinedAxioms.add(a);
					}					
				}
			} 
		}	
	}
	
	public void addClassAxiomPair(
			OWLClassExpression subC,
			OWLClassExpression supC,
			OWLAxiom axiom){
		Vector<OWLClassExpression> pair = MyUtils.createPair(subC, supC);
		classAxiomMap.put(pair, axiom);
	}
	
	public HashSet<OWLClassExpression> getOperands(OWLClassExpression oce){
		HashSet<OWLClassExpression> operands = new HashSet<OWLClassExpression>();
		if(oce instanceof OWLObjectIntersectionOf){
			OWLObjectIntersectionOf interSub = (OWLObjectIntersectionOf)oce;
			operands.addAll(interSub.getOperands());
		}
		return operands;
	}
	
	public HashSet<OWLAxiom> getRefinedAxioms(){
		return refinedAxioms;
	}
	
	public HashMap<Vector<OWLClassExpression>, OWLAxiom> getClassAxiomMap(){
		return classAxiomMap;
	}

}
