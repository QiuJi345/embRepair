package edu.njupt.radon.debug.incoherence.relevance;

public class RelevanceParameters {
  /*  // 
	public final static int COMPUTE_ALL_HS = 0;
	public final static int COMPUTE_SOME_HS = 1;
	public final static int COMPUTE_SHORTEST_HS = 2;
	public final static int COMPUTE_ANY_HS = 3;
	*/	
	
	// Compute all MUPS by stratify the ontology to be debugged
	public final static String COMPUTE_ALL_HS_REL = "all_hs";
	// Compute all cardinality-minimal MUPS
	public final static String COMPUTE_All_CM_HS_REL = "all_CM_hs";
	// Compute a set of cardinality-minimal MUPS which are sufficient to resolve unsatisfiability of a concept
	public final static String COMPUTE_ONE_CM_HS_REL = "one_CM_hs";
	
	// Specify a debugging strategy
	public static String debugStrategy = COMPUTE_ALL_HS_REL;
	
	// Subsumption based selection function
	public final static String SubSeleFunc = "sub";	
	// ALC based selection function
	public final static String ALCSeleFunc = "alc";
	// Signature based selection function
	public final static String SigSeleFunc = "sig";
	// vector based selection functions
	public final static String SigSimSeleFunc = "sigsim";
	public final static String SimSeleFunc = "sim";
	public final static String SigWinSeleFunc = "sigWin";
	public final static String TopKSeleFunc = "topK";
	
	// Specify a selection function to be used
	public static String selectionFunction = SigSeleFunc; 
	
	// If more than 10 conflict sets have been found, then stop continuing to find new ones.
	// If this value is -1, it means we do not set such a constrain.
	public static int conflictSetsNumLimit = -1;
}
