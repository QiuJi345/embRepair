package edu.njupt.radon.debug.incoherence.heuristic.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLEquivalentDataPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLSubDataPropertyOfAxiom;
import org.semanticweb.owlapi.model.OWLSubObjectPropertyOfAxiom;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;


public class PropertyHierarchy {
	// A key in this map is a class
	// A value in this map indicates the set of super classes explicitly defined in an ontology
	private HashMap<OWLEntity, HashSet<OWLEntity>> opHierarchy = 
		new HashMap<OWLEntity, HashSet<OWLEntity>>();	
	
	private HashMap<OWLEntity, HashSet<OWLEntity>> dpHierarchy = 
		new HashMap<OWLEntity, HashSet<OWLEntity>>();
		
    // The mapping between a pair of object properties and the corresponding axiom.
	private HashMap<Vector<OWLEntity>, OWLAxiom> axiomMap = 
		new HashMap<Vector<OWLEntity>, OWLAxiom>();
	
	
	public PropertyHierarchy(HashSet<OWLAxiom> axiomsInOnto){
		this.computeHierarchy(axiomsInOnto);		
		//this.printHierarchy();
		//this.printAxiomMap();
	}
	
	public PropertyHierarchy(OntologyInfo inf){
		this.computeHierarchy(inf.getRefinedAxioms());		
		//this.printHierarchy();
		//this.printAxiomMap();
	}
		
	private void computeHierarchy(
			HashSet<OWLAxiom> axiomsInOnto){
		
		for(OWLAxiom axiom : axiomsInOnto){
			if(axiom instanceof OWLSubObjectPropertyOfAxiom){
				OWLSubObjectPropertyOfAxiom pa = (OWLSubObjectPropertyOfAxiom)axiom;
				OWLObjectProperty subOp = MyUtils.getOWLObjectProperty(pa.getSubProperty());
				OWLObjectProperty supOp = MyUtils.getOWLObjectProperty(pa.getSuperProperty());
				
				// Check whether the signatures are all atomic.
				if(subOp != null && supOp != null){		
					// Create a pair
					Vector<OWLEntity> pair = MyUtils.createPair((OWLEntity)subOp, (OWLEntity)supOp);
					addSubOpRelation(subOp, supOp);	
					if(!axiomMap.containsKey(pair)){
						axiomMap.put(pair, axiom);
					}
				}
				
			} else if(axiom instanceof OWLEquivalentObjectPropertiesAxiom){
				OWLEquivalentObjectPropertiesAxiom equAxiom = (OWLEquivalentObjectPropertiesAxiom)axiom;
				Vector<OWLObjectPropertyExpression> eqConcepts = new Vector<OWLObjectPropertyExpression>(equAxiom.getProperties());
				OWLObjectProperty oce1 = MyUtils.getOWLObjectProperty(eqConcepts.get(0));
				OWLObjectProperty oce2 = MyUtils.getOWLObjectProperty(eqConcepts.get(1));
				if(oce1 != null && oce2 != null){
					// Create a pair
					Vector<OWLEntity> pair = MyUtils.createPair((OWLEntity)oce1, (OWLEntity)oce2);
					if(!axiomMap.containsKey(pair)){
						axiomMap.put(pair, axiom);
					}
					// Create a pair
					pair = MyUtils.createPair((OWLEntity)oce2, (OWLEntity)oce1);
					if(!axiomMap.containsKey(pair)){
						axiomMap.put(pair, axiom);
					}
					addSubOpRelation(oce1, oce2);	
					addSubOpRelation(oce2, oce1);
				}
				
			} else if(axiom instanceof OWLSubDataPropertyOfAxiom){
				OWLSubDataPropertyOfAxiom pa = (OWLSubDataPropertyOfAxiom)axiom;
				OWLDataProperty subOp = MyUtils.getOWLDataProperty(pa.getSubProperty());
				OWLDataProperty supOp = MyUtils.getOWLDataProperty(pa.getSuperProperty());
				
				// Check whether the signatures are all atomic.
				if(subOp != null && supOp != null){		
					// Create a pair
					Vector<OWLEntity> pair = MyUtils.createPair((OWLEntity)subOp, (OWLEntity)supOp);
				    addSubDpRelation(subOp, supOp);	
					if(!axiomMap.containsKey(pair)){
						axiomMap.put(pair, axiom);
					}
				}				
				
			} else if(axiom instanceof OWLEquivalentDataPropertiesAxiom){
				OWLEquivalentDataPropertiesAxiom equAxiom = (OWLEquivalentDataPropertiesAxiom)axiom;
				Vector<OWLDataPropertyExpression> eqConcepts = new Vector<OWLDataPropertyExpression>(equAxiom.getProperties());
				OWLDataProperty oce1 = MyUtils.getOWLDataProperty(eqConcepts.get(0));
				OWLDataProperty oce2 = MyUtils.getOWLDataProperty(eqConcepts.get(1));
				if(oce1 != null && oce2 != null){
					// Create a pair
					Vector<OWLEntity> pair = MyUtils.createPair((OWLEntity)oce1, (OWLEntity)oce2);
					if(!axiomMap.containsKey(pair)){
						axiomMap.put(pair, axiom);
					}
					// Create a pair
					pair = MyUtils.createPair((OWLEntity)oce2, (OWLEntity)oce1);
					if(!axiomMap.containsKey(pair)){
						axiomMap.put(pair, axiom);
					}
					addSubDpRelation(oce1, oce2);	
					addSubDpRelation(oce2, oce1);
				}				
			}
		}			
	}
	
	private void addSubOpRelation(OWLObjectProperty subC, OWLObjectProperty supC){
		if(opHierarchy.containsKey(subC)){
			opHierarchy.get(subC).add(supC);
		} else {
			HashSet<OWLEntity> superClasses = new HashSet<OWLEntity>();
			superClasses.add(supC);
			opHierarchy.put(subC, superClasses);
		}
	}
	
	private void addSubDpRelation(OWLDataProperty subC, OWLDataProperty supC){
		if(dpHierarchy.containsKey(subC)){
			dpHierarchy.get(subC).add(supC);
		} else {
			HashSet<OWLEntity> superClasses = new HashSet<OWLEntity>();
			superClasses.add(supC);
			dpHierarchy.put(subC, superClasses);
		}
	}
	
	public boolean isSubPropertyOf(OWLObjectProperty op1, OWLObjectProperty op2){
		if(this.opHierarchy.containsKey(op1)){
			HashSet<OWLEntity> superProperties = getSuperProperties(op1);
			if(superProperties.contains(op2)){
				return true;
			}
		}
		return false;
	}
	
	public HashSet<OWLEntity> getSuperProperties(
			OWLEntity ent){
		
		HashSet<OWLEntity> superProperties = new HashSet<OWLEntity>();
		if(ent != null){
			superProperties.add(ent);
			computeSuperProperties(ent, superProperties);	
		}
		return superProperties;
	}
				
	private void computeSuperProperties(
			OWLEntity ent,
			HashSet<OWLEntity> superProperties){
		
		HashSet<OWLEntity> directSuper = new HashSet<OWLEntity>();
		if(ent instanceof OWLObjectProperty){
			directSuper = opHierarchy.get(ent);
		} else if(ent instanceof OWLDataProperty){
			directSuper = dpHierarchy.get(ent);
		}
		if(directSuper!=null){			
			for(OWLEntity superC : directSuper){
				// Avoid circle
				if(superProperties.contains(superC)){
					continue;
				}
				superProperties.add(superC);
				computeSuperProperties(superC, superProperties);
			}
		}
	}
	
	public HashMap<Vector<OWLEntity>, OWLAxiom> getPairAxiomMap(){
		return axiomMap;
	}
		
	public HashMap<OWLEntity, HashSet<OWLEntity>> getObjectpropertyHierarchy(){
		return opHierarchy;
	}	
	
	public HashMap<OWLEntity, HashSet<OWLEntity>> getDatapropertyHierarchy(){
		return dpHierarchy;
	}	
	
	public void printHierarchy(){
		System.out.println("***** Role Hierarchy  ********");
		for(OWLEntity oc : opHierarchy.keySet()){
			System.out.println(oc.toString());
			for(OWLEntity sup : opHierarchy.get(oc)){
				System.out.println("    "+sup.toString());
			}
		}
		System.out.println("***************************\n");	
	}
	
	public void printAxiomMap(){
		System.out.println("***** Property Axiom Map  ********");
		for(Vector<OWLEntity> pair : axiomMap.keySet()){
			System.out.println("pair: "+ pair.get(0).toString() + ", "+ pair.get(1).toString());
			System.out.println("    "+axiomMap.get(pair).toString());
		}
		System.out.println("***************************\n");	
	}
}
