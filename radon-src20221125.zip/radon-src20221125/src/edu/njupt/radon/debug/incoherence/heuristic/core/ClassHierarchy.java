package edu.njupt.radon.debug.incoherence.heuristic.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;

import edu.njupt.radon.debug.incoherence.heuristic.norm.TransformOntology;
import edu.njupt.radon.utils.CommonTools;

public class ClassHierarchy {
    /** The information in an OWLOntology. */
	//OntologyInfo myOnto;	
	/** The mapping between an OWLClass and all its direct superClasses. */
	private HashMap<OWLClassExpression, HashSet<OWLClassExpression>> classHierarchy = 
		new HashMap<OWLClassExpression, HashSet<OWLClassExpression>>();
	/** The mapping between a pair of two concepts and its justification. */
	private HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>> inferredJusts = 
		new HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>>();
	/** A temporary variable to store partial justifications for an inferred subsumption. */
	/*private HashSet<Vector<OWLClassExpression>> justsForSubsumption = 
		new HashSet<Vector<OWLClassExpression>>();*/
	
	OntologyInfo ontoInfo;
	
	public ClassHierarchy(OntologyInfo inf){
		this.ontoInfo = inf;
		this.computeHierarchyStep1(inf.getPairAxiomMap());	
		this.computeHierarchyStep2(inf.getDirectExistentialConditions());
		this.computeHierarchyStep2(inf.getDirectUniversalConditions());
		this.computeHierarchyStep3(inf.getPairAxiomMap());
	}
	

	/**
	 * Step 1 of constructing the class hierarchy:
	 * The computation is based on those explicitly defined OWLSubClassOfAxiom
	 * and OWLEquivalentClassesAxiom, where only atomic concepts are included.
	 */
	private void computeHierarchyStep1(HashMap<Vector<OWLClassExpression>, OWLAxiom> pairAxioms){
		//System.out.println("step 1: obtaining subsumptions....");
		for(Vector<OWLClassExpression> pair : pairAxioms.keySet()){
			OWLClassExpression subC = pair.get(0);
			OWLClassExpression supC = pair.get(1);				
			// Check whether the signatures are all atomic.
			addSubRelation(subC, supC);			
		}			
	}
			
	/**
	 * Step 2 of constructing the class hierarchy:
	 * The computation is based on the class hierarchy obtained from step 1.
	 * This step tries to find those subsumption relations between two complex concepts
	 * with the form of exists r. C (where C is atomic).
	 */
	private void computeHierarchyStep2(HashMap<OWLClass, HashSet<OWLClassExpression>> directConditions) {
		HashSet<OWLClassExpression> conditions = new HashSet<OWLClassExpression>();
		for(OWLClass oc : directConditions.keySet()) {
			conditions.addAll(directConditions.get(oc));
		}
		for(OWLClassExpression subCond : conditions) {
			for(OWLClassExpression supCond : conditions) {
				// Check whether there is is-a relation between a pair of somvaluefrom fillers if sharing the same property
				if(!subCond.equals(supCond) && getProperty(subCond).equals(getProperty(supCond))) {
					OWLClassExpression subC = getFiller(subCond);
					OWLClassExpression supC = getFiller(supCond);					
					if(hasIsaRelationInHier(subC, supC)) {								
						//String str = "step 2: "+subC.toString()+" , "+ supC.toString();
						//System.out.println(str.replaceAll(TransformOntology.prefix, ""));
						// Add inferred subsumption to the concept hierarchy
						addSubRelation(subCond, supCond);	
						// Add inferred information
						Vector<OWLClassExpression> inferrredPair = this.getPair(subCond, supCond);
						this.inferredJusts.put(inferrredPair, this.getInferredJusts(subC, supC));
					}
				}
			}
		}		
	}
	
	
	
	/**
	 * Step 3 of constructing the class hierarchy:
	 * The computation is based on the class hierarchy obtained from step 1 and 2.
	 * This step tries to find those subsumption relation between two complex concepts
	 * which can contain intersectionOf operator.
	 */
	private void computeHierarchyStep3(HashMap<Vector<OWLClassExpression>, OWLAxiom> pairAxioms){
		// Obtain all classExpression in the transformed axioms
		HashSet<OWLClassExpression> oces = new HashSet<OWLClassExpression>();
		for(Vector<OWLClassExpression> pair : pairAxioms.keySet()){
			oces.addAll(pair);			
		}
		
		// find new isa relations between a pair of OWLClassExpressions
		for(OWLClassExpression subC : oces) {
			HashSet<OWLClassExpression> subSet = this.getSubConcepts(subC);
			for(OWLClassExpression supC : oces) {
				/*if(subC.toString().contains("ObjectIntersectionOf") &&
						subC.toString().contains("Retry-Until-Succeed")
						&& supC.toString().contains("ObjectIntersectionOf")
						&& supC.toString().contains("Reliable")) {
					if(subC.toString().contains("ObjectIntersectionOf") &&
							subC.toString().contains("Retry-Until-Succeed")
							&& supC.toString().contains("ObjectIntersectionOf")
							&& supC.toString().contains("Reliable")) {
					System.out.println("decide isa relation for: "+
							   subC.toString().replaceAll(TransformOntology.prefix, "")+", "+
									supC.toString().replaceAll(TransformOntology.prefix, ""));
				}*/
				
				if(subC.equals(supC) || this.hasIsaRelationInHier(subC, supC)) {
					continue;
				}
				//System.out.println("check....");
				if(subC.toString().contains("Retry-Until-SucceedUsernamePolicy")){
					System.out.println();
				}
				HashSet<OWLClassExpression> supSet = this.getSubConcepts(supC);
				HashSet<HashSet<OWLAxiom>> justs = getIsaRelationJusts(subSet, supSet);
				if(!justs.isEmpty()) {
					String str = "step 3 (inferred relation): "+subC.toString()+" , "+ supC.toString();
					System.out.println(str.replaceAll(TransformOntology.prefix, ""));
					System.out.println("just");
					CommonTools.printMultiSets(justs, null);
					System.out.println();
					// Add inferred subsumption to the concept hierarchy
					addSubRelation(subC, supC);	
					// Add inferred information
					Vector<OWLClassExpression> inferrredPair = this.getPair(subC, supC);
					this.inferredJusts.put(inferrredPair, justs);
				}
			}
		}
	}

	
	private Vector<OWLClassExpression> getPair(OWLClassExpression sub, OWLClassExpression sup) {
		Vector<OWLClassExpression> vec = new Vector<OWLClassExpression>();
		vec.add(sub);
		vec.add(sup);
		return vec;
	}
	
	private HashSet<HashSet<OWLAxiom>> getInferredJusts(OWLClassExpression sub, OWLClassExpression sup) {
		HashSet<HashSet<OWLAxiom>> justs = new HashSet<HashSet<OWLAxiom>>();		
		
		Vector<OWLClassExpression> cpair = this.getPair(sub, sup);		
		if(this.ontoInfo.getPairAxiomMap().containsKey(cpair)) {
			HashSet<OWLAxiom> just = new HashSet<OWLAxiom>();
			just.add(ontoInfo.getPairAxiomMap().get(cpair));	
			justs.add(just);
		} else if(this.inferredJusts.containsKey(cpair)){
			justs.addAll(this.inferredJusts.get(cpair));
		} else {
			FindPath findPath = new FindPath(this.classHierarchy);
			// Find all paths between sub and sup
			HashSet<HashSet<Vector<OWLClassExpression>>> paths = findPath.findPaths(sub, sup);
			// Translate each path to a set of explanations
			for(HashSet<Vector<OWLClassExpression>> path : paths) {		
				HashSet<HashSet<OWLAxiom>> partialJusts = new HashSet<HashSet<OWLAxiom>>();
				// For each edge, translate each edge to a set of explanations
				for(Vector<OWLClassExpression> edge : path) {
					HashSet<HashSet<OWLAxiom>> edgeJusts = new HashSet<HashSet<OWLAxiom>>();	
					if(ontoInfo.getPairAxiomMap().containsKey(edge)) {
						HashSet<OWLAxiom> tempJust = new HashSet<OWLAxiom>();
						tempJust.add(ontoInfo.getPairAxiomMap().get(edge));
						edgeJusts.add(tempJust);
					} else if(this.inferredJusts.containsKey(cpair)){
						edgeJusts.addAll(this.inferredJusts.get(cpair));
					} else {
						System.err.println("error to get axiom for a concept pair. ");
					}
					// Obtain the explanations for one edge
					if(!edgeJusts.isEmpty()){
						if(!partialJusts.isEmpty()){
							// Combine the explanations obtained for different edges
							HashSet<HashSet<OWLAxiom>> tempJusts = new HashSet<HashSet<OWLAxiom>>();
							for(HashSet<OWLAxiom> oldJust : partialJusts){
								for(HashSet<OWLAxiom> newJust : edgeJusts){
									HashSet<OWLAxiom> aJust = new HashSet<OWLAxiom>();
									aJust.addAll(oldJust);
									aJust.addAll(newJust);
									tempJusts.add(aJust);
								}
							}
							partialJusts = new HashSet<HashSet<OWLAxiom>>(tempJusts);
						} else {
							// In this case, it is the first edge to be translated
							partialJusts = new HashSet<HashSet<OWLAxiom>>(edgeJusts);
						}						
						
					} else {
						partialJusts.clear();
						break;
					}
				}
				// For the given path, if the explanations can be found, then combined these with existing ones.
				if(!partialJusts.isEmpty()){
					justs.addAll(partialJusts);
				}
			} 			
		}
		return justs;
	}
	
	private OWLObjectPropertyExpression getProperty(OWLClassExpression oce) {
		if(oce instanceof OWLObjectSomeValuesFrom) {
			OWLObjectSomeValuesFrom cond = (OWLObjectSomeValuesFrom)oce;
			return cond.getProperty();
		} else if(oce instanceof OWLObjectAllValuesFrom) {
			OWLObjectAllValuesFrom cond = (OWLObjectAllValuesFrom)oce;
			return cond.getProperty();
		} 
		return null;
	}
	
	private OWLClassExpression getFiller(OWLClassExpression oce) {
		if(oce instanceof OWLObjectSomeValuesFrom) {
			OWLObjectSomeValuesFrom cond = (OWLObjectSomeValuesFrom)oce;
			return cond.getFiller();
		} else if(oce instanceof OWLObjectAllValuesFrom) {
			OWLObjectAllValuesFrom cond = (OWLObjectAllValuesFrom)oce;
			return cond.getFiller();
		} 
		return null;
	}
	
	private HashSet<OWLClassExpression> getSubConcepts(OWLClassExpression oce){
		HashSet<OWLClassExpression> oceSet = new HashSet<OWLClassExpression>();
		if(oce instanceof OWLObjectIntersectionOf) {
			OWLObjectIntersectionOf inter = (OWLObjectIntersectionOf)oce;
			oceSet.addAll(inter.getOperands());
		} else {
			oceSet.add(oce);
		}
		return oceSet;
	}
		
	int counter = 1;
	private void addSubRelation(OWLClassExpression subC, OWLClassExpression supC){
		
		if(supC.toString().contains("http://www.w3.org/2002/07/owl#Thing")){
			return;
		}
		//System.out.println("subsumption : "+ subC.toString().replaceAll(TransformOntology.prefix, "")+", "+	supC.toString().replaceAll(TransformOntology.prefix, ""));
		if(classHierarchy.containsKey(subC)){
			classHierarchy.get(subC).add(supC);
			//System.out.println("hierarchy add "+(counter++));
		} else {
			HashSet<OWLClassExpression> superClasses = new HashSet<OWLClassExpression>();
			superClasses.add(supC);
			classHierarchy.put(subC, superClasses);
			//System.out.println("hierarchy put "+(counter++));
		}
	}
	
	/**
	 * If each sup-concept in supOps has a sub-concept in subOps,  
	 * then subOps is regarded as subclass of supOps.
	 * 
	 * @param subC
	 * @param supC
	 * @return
	 */
	private HashSet<HashSet<OWLAxiom>> getIsaRelationJusts(HashSet<OWLClassExpression> subOps, HashSet<OWLClassExpression> supOps){		
		
		boolean hasChild = false;
		HashSet<HashSet<OWLAxiom>> justs = new HashSet<HashSet<OWLAxiom>>();
		for(OWLClassExpression supOp : supOps) {
			// Check whether there is a subconcept in subOps for supOp.
			hasChild = false;
			HashSet<HashSet<OWLAxiom>> supJusts = new HashSet<HashSet<OWLAxiom>>();
			// Obtain all explanations that support any subOp is a subclass of the given supOp.
			for(OWLClassExpression subOp : subOps) {
				if(subOp.equals(supOp)){
					hasChild = true;					
				} else if(hasIsaRelationInHier(subOp, supOp)) {
					hasChild = true;					
					supJusts.addAll(this.getInferredJusts(subOp, supOp));					
				}
			}
			// If a supOp has no child in subOps, then we cannot decide the relation between subOps and supOps.
			if(hasChild) {
				// combine found explanations
				if(supJusts.size() > 0){
					if(justs.size()>0){
						// Combine newly found explanations with existing ones
						HashSet<HashSet<OWLAxiom>> tempJusts = new HashSet<HashSet<OWLAxiom>>();
						for(HashSet<OWLAxiom> oldJust : justs){
							for(HashSet<OWLAxiom> newJust : supJusts){
								HashSet<OWLAxiom> aJust = new HashSet<OWLAxiom>();
								aJust.addAll(oldJust);
								aJust.addAll(newJust);
								tempJusts.add(aJust);
							}
						}
						justs = new HashSet<HashSet<OWLAxiom>>(tempJusts);
					} else {
						justs = new HashSet<HashSet<OWLAxiom>>(supJusts);
					}
				} 
			} else {
				justs.clear();
				break;
			}
		}
		return justs;
	}		

	
	private boolean hasIsaRelationInHier(OWLClassExpression subC, OWLClassExpression supC){
		HashSet<OWLClassExpression> sups = this.getAllSuperClasses(subC);
		sups.remove(subC);
		if(sups.contains(supC)) {
			return true;
		}
		return false;
	}	
	
	/**
	 * Obtain all direct and indirect superconcepts of a given concept including itself.
	 * @param oc
	 * @return
	 */
	public HashSet<OWLClassExpression> getAllSuperClasses(OWLClassExpression oc){
		HashSet<OWLClassExpression> superClasses = new HashSet<OWLClassExpression>();
		superClasses.add(oc);
		computeSuperclasses(oc, superClasses);
		return superClasses;
	}
	
	private void computeSuperclasses(
			OWLClassExpression oc,
			HashSet<OWLClassExpression> superClasses){
		
		HashSet<OWLClassExpression> directSuper = classHierarchy.get(oc);
		if(directSuper!=null){			
			for(OWLClassExpression superC : directSuper){
				// Avoid circle
				if(superClasses.contains(superC)){
					continue;
				}
				superClasses.add(superC);
				computeSuperclasses(superC, superClasses);
			}
		}
	}

	public HashMap<OWLClassExpression, HashSet<OWLClassExpression>> getClassHierarchy(){
		return classHierarchy;
	}
	
/*	public HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>> getInferredRelationJusts(){		
		HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>> copy = new HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>>();
		for(Vector<OWLClassExpression> key : inferredRelations.keySet()){
			copy.put(key, new HashSet<HashSet<OWLAxiom>>(inferredRelations.get(key)));
		}
		return copy;
	}	
	*/
	
	/**
	 * Make a copy of inferredRelations to avoid the modification.
	 * @return
	 */
	public HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>> getInferredRelationJusts(){		
		HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>> copy = new HashMap<Vector<OWLClassExpression>, HashSet<HashSet<OWLAxiom>>>();
		for(Vector<OWLClassExpression> key : inferredJusts.keySet()){
			copy.put(key, new HashSet<HashSet<OWLAxiom>>(inferredJusts.get(key)));
		}
		return copy;
	}	
	
	public void printHierarchy(){
		System.out.println("***** Hierarchy  ********");
		for(OWLClassExpression oc : classHierarchy.keySet()){
			System.out.println(oc.toString());
			for(OWLClassExpression sup : classHierarchy.get(oc)){
				System.out.println("    "+sup.toString());
			}
		}
		System.out.println("***************************\n");	
	}
	
	public void printAxiomMap(){
		System.out.println("***** Inferred Relations  ********");
		for(Vector<OWLClassExpression> pair : inferredJusts.keySet()){
			System.out.println("pair: "+ pair.get(0).toString() + ", "+ pair.get(1).toString());
			System.out.println("    "+inferredJusts.get(pair).toString());
		}
		System.out.println("***************************\n");	
	}
}
