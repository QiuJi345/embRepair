package edu.njupt.radon.debug.incoherence.relevance;

import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import com.clarkparsia.owlapi.explanation.SatisfiabilityConverter;
import com.clarkparsia.owlapiv3.OWL;
import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class RelevanceJusts {
	
	String newConceptPrefix = "http://radon.org#";
	
	OWLOntology ontology;
	OWLClass subClass;
	OWLClass superClass;
	OWLClass unsatConcept = null;
	OWLAxiom newlyAddedAxiom = null;
	
	public RelevanceJusts(OWLOntology ontology, 
			String subClassName, String superClassName){
		this.ontology = ontology;
		this.subClass = OWLTools.getOWLClass(ontology, subClassName);
		this.superClass = OWLTools.getOWLClass(ontology, superClassName);
		newlyAddedAxiom = this.transferSubsumptionToUnsatiConcept(subClass, superClass);
	}
	
	public RelevanceJusts(OWLOntology ontology,
			OWLClass subClass, OWLClass superClass){
		this.ontology = ontology;
		this.subClass = subClass;
		this.superClass = superClass;
		newlyAddedAxiom = this.transferSubsumptionToUnsatiConcept(subClass, superClass);
	}
	
	public HashSet<HashSet<OWLAxiom>> getRelevantJustifications() {
		// Add a new axiom to the ontology to make the computation of justifications 
		// to the computation of a newly added concept's MUPS		
		// Obtain the axioms in the original ontology
		HashSet<OWLAxiom> axiomsInOnto = new HashSet<OWLAxiom>(ontology.getLogicalAxioms());
		// Add the newly generated axiom to the original ontology
		axiomsInOnto.add(newlyAddedAxiom);
		
		RelevanceParameters.selectionFunction = RelevanceParameters.SigSeleFunc;
		RelevanceParameters.debugStrategy = RelevanceParameters.COMPUTE_ALL_HS_REL;
		RelevanceDebug debug = new RelevanceDebug(axiomsInOnto, newlyAddedAxiom);
		HashSet<HashSet<OWLAxiom>> explanations = debug.getMUPS(unsatConcept);		
		//explanations = getRealJustifications(explanations, newlyAddedAxiom);
		
		return explanations;
	}
	
	public boolean isSatisfiable( OWLClassExpression oc) throws Exception {
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		OWLReasoner reasoner = reasonerFactory.createReasoner(ontology);
		System.out.println(reasoner.isSatisfiable(oc));
		return reasoner.isSatisfiable(oc);
	}
	
	public boolean isEntailed( OWLAxiom entailment) throws Exception {
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		OWLReasoner reasoner = reasonerFactory.createReasoner(ontology);
		System.out.println(reasoner.isEntailed(entailment));
		return reasoner.isEntailed(entailment);
	}
	
	private HashSet<HashSet<OWLAxiom>> getRealJustifications(
			HashSet<HashSet<OWLAxiom>> explanations, OWLAxiom newlyAddedAxiom){
		HashSet<HashSet<OWLAxiom>> realExplanations = new HashSet<HashSet<OWLAxiom>>();
		for(HashSet<OWLAxiom> explanation : explanations){
			explanation.remove(newlyAddedAxiom);
			realExplanations.add(new HashSet<OWLAxiom>(explanation));
		}
		return realExplanations;
	}
	
	private OWLAxiom transferSubsumptionToUnsatiConcept(
			OWLClass subConcept, 
			OWLClass supConcept) {
		        
        IRI newConceptIRI = IRI.create(newConceptPrefix + System.currentTimeMillis());
        unsatConcept = OWL.factory.getOWLClass(newConceptIRI);
        OWLObjectIntersectionOf complexConcept = OWL.factory.getOWLObjectIntersectionOf(subConcept, 
        		OWL.factory.getOWLObjectComplementOf(supConcept));
        OWLAxiom newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(unsatConcept, complexConcept);
        System.out.println("[Info] Newly added axiom: "+newAxiom.toString());
        return newAxiom;
	}

}
