package edu.njupt.radon.debug.incoherence.heuristic.norm;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectComplementOf;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;

/**
 * This class is to normalize the axioms:
 * 1) an equivalent axiom is transfered to two subsumptions
 * 2) Each subsumption will be transfered to be simple.
 *    
 * @author ����
 *
 */
public class TransformOntology {	
	public static String prefix = "http://www.mindswap.org/dav/ontologies/policyContainmentTest.owl#";
	private int number = 0;
	
	private OWLAxiom currentTransferredAxiom = null;
	/** The mapping between a pair of OWLClassExpression and the corresponding OWLAxiom. */
	private HashMap<Vector<OWLClassExpression>, OWLAxiom> conceptPairAxiomMap = new HashMap<Vector<OWLClassExpression>, OWLAxiom>();	
	private HashMap<OWLClass, HashSet<OWLObjectIntersectionOf>> intersectionOfConditions = new HashMap<OWLClass, HashSet<OWLObjectIntersectionOf>>();

	// the refined axioms
	private HashSet<OWLAxiom> transformedAxioms = new HashSet<OWLAxiom>();		
	// The mapping between a class expression and the novel atomic concept to replace the expression
	HashMap<OWLClassExpression, OWLClass> classExpressionReplacement = new HashMap<OWLClassExpression, OWLClass>();
	
    public TransformOntology(HashSet<OWLAxiom> axioms){
    	//System.out.println("Axioms: "+axioms.size());
    	//int i = 1;
		for(OWLAxiom ax : axioms){
			//System.out.println("axiom "+(i++)+" : "+ax.toString().replaceAll(prefix, ""));
			currentTransferredAxiom = ax;
			transformAxiom(ax);
		}
    }
	
    /**
     * This method is to make each axiom to be atomic. For example,
     * 1) transfer each equivalent axiom to two subsumptions
     * 2) transfer each axiom with intersectionOf super-concept to multiple axioms
     * 3) replace recursively each complex concept with atomic one by introducing new concepts
     * 
     * @param ax
     */
	private void transformAxiom(OWLAxiom ax){	
		
		//transfer an equivalent axiom to two subsumptions
		if(ax instanceof OWLEquivalentClassesAxiom){
			//System.out.println(ax.toString());
			OWLEquivalentClassesAxiom eqAxiom = (OWLEquivalentClassesAxiom)ax;	
			//this.addEquRelation(eqAxiom);			
			for(OWLSubClassOfAxiom subAx : eqAxiom.asOWLSubClassOfAxioms()){
				transformAxiom(subAx);
			}
			return;
		} else if(!(ax instanceof OWLSubClassOfAxiom)){			
			transformedAxioms.add(ax);
			return;
		}
				
		OWLSubClassOfAxiom axiom = (OWLSubClassOfAxiom)ax;
		OWLClassExpression supC = axiom.getSuperClass();	
		OWLClassExpression subC = axiom.getSubClass();
		this.addClassAxiomPair(subC, supC, currentTransferredAxiom);
		
		
		if(supC instanceof OWLObjectSomeValuesFrom){
			OWLObjectSomeValuesFrom oceSome = (OWLObjectSomeValuesFrom)supC;
			OWLClassExpression filler = oceSome.getFiller();
			// If the filler is a complex concept, then use an atomic concept that is freshly constructed to instead of the complex concept.
			if(filler.isAnonymous()){
				OWLClass replacement = getReplacement(filler);
				OWLClassExpression newCondition = OWL.factory.getOWLObjectSomeValuesFrom(oceSome.getProperty(), replacement);
				OWLAxiom newAxiom = OWL.factory.getOWLSubClassOfAxiom(subC, newCondition);
				//newOldAxiomMap.put(newAxiom, currentTransferredAxiom);
				transformedAxioms.add(newAxiom);
				addClassAxiomPair(subC, newCondition, currentTransferredAxiom);
				
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(replacement, filler);
				transformedAxioms.add(newAxiom);
				transformAxiom(newAxiom);
			}  else {
				transformedAxioms.add(ax);
			}
		} else if(supC instanceof OWLObjectAllValuesFrom){
			OWLObjectAllValuesFrom allOc = (OWLObjectAllValuesFrom)supC;
			OWLClassExpression filler = allOc.getFiller();
			if(filler.isAnonymous()){
				OWLClass replacement = getReplacement(filler);
				OWLClassExpression newCondition = OWL.factory.getOWLObjectAllValuesFrom(allOc.getProperty(), replacement);
				OWLAxiom newAxiom = OWL.factory.getOWLSubClassOfAxiom(subC, newCondition);
				transformedAxioms.add(newAxiom);
				addClassAxiomPair(subC, newCondition, currentTransferredAxiom);
				
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(replacement, filler);
				transformedAxioms.add(newAxiom);
				transformAxiom(newAxiom);
			}  else {
				transformedAxioms.add(ax);
			}
		} else if(supC instanceof OWLObjectIntersectionOf){
			OWLObjectIntersectionOf interC = (OWLObjectIntersectionOf)supC;		
			if(subC instanceof OWLClass) {
				OWLClass oc = (OWLClass)subC;
				if(intersectionOfConditions.containsKey(oc)) {
					intersectionOfConditions.get(oc).add(interC);
				} else {
					HashSet<OWLObjectIntersectionOf> set = new HashSet<OWLObjectIntersectionOf>();
					set.add(interC);
					intersectionOfConditions.put(oc, set);
				}
			}
			
			for(OWLClassExpression operand : interC.getOperands()){				
				OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(subC, operand);
				transformedAxioms.add(a);
				transformAxiom(a);				
			}	
			
		} else if(supC instanceof OWLObjectComplementOf){
			OWLObjectComplementOf oce = (OWLObjectComplementOf)supC;		
			OWLClassExpression negC = oce.getOperand();
			if(negC.isAnonymous()){
				OWLClass replacement = getReplacement(negC);
				OWLClassExpression newCondition = OWL.factory.getOWLObjectComplementOf(replacement);
				OWLAxiom newAxiom = OWL.factory.getOWLSubClassOfAxiom(subC, newCondition);
				transformedAxioms.add(newAxiom);
				addClassAxiomPair(subC, newCondition, currentTransferredAxiom);
				
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(replacement, negC);
				transformedAxioms.add(newAxiom);
				transformAxiom(newAxiom);
			} else {
				transformedAxioms.add(ax);
			}			
		
		} else {
			transformedAxioms.add(ax);
		}	
	}	
		
	/**
	 * We only consider those equivalent axioms that are definitions of some atomic concept.
	 * In such case, we have A equivalent C, where A is atomic and C may not be atomic.
	 * 
	 * @param eqAxiom
	 */
/*	private void addEquRelation(OWLEquivalentClassesAxiom eqAxiom) {
		OWLClassExpression eqOce = null;
		OWLClass eqOc = null;
		for(OWLClassExpression oce : eqAxiom.getClassExpressions()){
			if(oce.isAnonymous() && oce instanceof OWLObjectIntersectionOf){
				eqOce = oce;
			} else {
				eqOc = oce.asOWLClass();
			}
			System.out.println(oce.toString());
		}
		System.out.println();
		if(eqOce != null && eqOc != null){
			equConditions.put(eqOc, eqOce);
		}
	}*/
	
	
	public void addClassAxiomPair(
			OWLClassExpression subC,
			OWLClassExpression supC,
			OWLAxiom axiom){
		Vector<OWLClassExpression> pair = MyUtils.createPair(subC, supC);
		conceptPairAxiomMap.put(pair, axiom);
		/*System.out.println("   pair : "+subC.toString().replaceAll(prefix, "") +" , "+
				supC.toString().replaceAll(prefix, ""));*/
	}

	public OWLClass getReplacement(OWLClassExpression oce){
		if(classExpressionReplacement.containsKey(oce)){
			return classExpressionReplacement.get(oce);
		} else {
			OWLClass novelConcept = OWL.factory.getOWLClass(IRI.create(
					"http://www.radon.com/concepts/tmpConcept_"+(number++)));
			return novelConcept;
		}		
	}		
	
	public HashMap<Vector<OWLClassExpression>, OWLAxiom> getPairAxiomMap(){
		return conceptPairAxiomMap;
	}
	
	public HashSet<OWLAxiom> getRefinedAxioms(){
		return new HashSet<OWLAxiom>(transformedAxioms);
	}
		
	public HashMap<OWLClass, HashSet<OWLObjectIntersectionOf>> getIntersectionOfConditions() {
		return intersectionOfConditions;
	}

}
