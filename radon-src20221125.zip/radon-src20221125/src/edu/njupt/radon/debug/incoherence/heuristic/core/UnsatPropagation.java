package edu.njupt.radon.debug.incoherence.heuristic.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;

public class UnsatPropagation {
	
	HashMap<OWLClass, HashSet<OWLClassExpression>> someValueConditions = new HashMap<OWLClass, HashSet<OWLClassExpression>>();
	HashSet<OWLClass> ocs = new HashSet<OWLClass>();
	HashMap<Vector<OWLClass>, Integer> isUnsatList = new HashMap<Vector<OWLClass>, Integer>();
	boolean changed = true;
		
	public UnsatPropagation(HashSet<OWLClass> ucs,
			HashMap<OWLClass, HashSet<OWLClassExpression>> conds) {
		someValueConditions = conds;
		ocs = new HashSet<OWLClass>(ucs);
	}
	
/*	public int isUnsatisfiable(OWLClass concept){	
		if(someValueConditions.containsKey(concept)){
			for(OWLClassExpression value : someValueConditions.get(concept)){
				OWLObjectSomeValuesFrom condition = (OWLObjectSomeValuesFrom)value;
				OWLClassExpression filler = condition.getFiller();
				if(!filler.isAnonymous()){
					Vector<OWLClass> pair = new Vector<OWLClass>();
					pair.add(concept);
					pair.add(filler.asOWLClass());
					if(isUnsatList.containsKey(pair)){
						int val = isUnsatList.get(pair);
						return val;
					}
				}
			}
		}
		return 0;
	}*/
	
	public int isUnsatisfiable(OWLClass concept, OWLClass filler){	
		if(filler != null && !filler.isAnonymous()){
			Vector<OWLClass> pair = new Vector<OWLClass>();
			pair.add(concept);
			pair.add(filler.asOWLClass());
			if(isUnsatList.containsKey(pair)){
				int val = isUnsatList.get(pair);
				return val;
			}
		}
		return 0;
	}
	
	public int isUnsatisfiable(OWLClass concept, OWLClassExpression value){	
		OWLObjectSomeValuesFrom condition = (OWLObjectSomeValuesFrom)value;
		OWLClassExpression filler = condition.getFiller();
		if(!filler.isAnonymous()){
			Vector<OWLClass> pair = new Vector<OWLClass>();
			pair.add(concept);
			pair.add(filler.asOWLClass());
			if(isUnsatList.containsKey(pair)){
				int val = isUnsatList.get(pair);
				return val;
			}
		}
		return 0;
	}
	
	private void iniUnsatList(){
		for(OWLClass key : someValueConditions.keySet()){
			for(OWLClassExpression value : someValueConditions.get(key)){
				OWLObjectSomeValuesFrom condition = (OWLObjectSomeValuesFrom)value;
				OWLClassExpression filler = condition.getFiller();
				if(!filler.isAnonymous()){
					Vector<OWLClass> pair = new Vector<OWLClass>();
					pair.add(key);
					pair.add(filler.asOWLClass());
					if(ocs.contains(filler)){
						isUnsatList.put(pair, 1);
						ocs.add(key);
					} else {
						isUnsatList.put(pair, 0);
					}
				}
			}
		}
		
		while(changed){
			propagateUnsat(isUnsatList);
		}
	}
	
	public void propagateUnsat(HashMap<Vector<OWLClass>, Integer> isUnsatList){	
		changed = false;
		for(Vector<OWLClass> pair : isUnsatList.keySet()){
			if(ocs.contains(pair.get(1)) && isUnsatList.get(pair) == 0){
				isUnsatList.put(pair, 1);
				ocs.add(pair.get(0));	
				changed = true;
			}
		}		
	}

	public HashSet<OWLClass> getUnsatConcepts(){
		return ocs;
	}
}
