package edu.njupt.radon.debug.incoherence.heuristic.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceParameters;

public class FindPath {
			
	boolean findSingleConflict = false;	
	boolean isSubclass = false;		
		
	Vector<OWLClassExpression> currentPair = new Vector<OWLClassExpression>();
	HashSet<Vector<OWLClassExpression>> path = new HashSet<Vector<OWLClassExpression>>();
	HashSet<HashSet<Vector<OWLClassExpression >>> paths = new HashSet<HashSet<Vector<OWLClassExpression>>>();
	
	HashMap<OWLClassExpression, HashSet<OWLClassExpression>> classHier ;
		
	public FindPath(HashMap<OWLClassExpression, HashSet<OWLClassExpression>> hier){
		classHier = hier;
	}
	
	/*public FindPath(
			HashMap<Vector<OWLClassExpression>, OWLAxiom> classAxiomMap,
			HashMap<OWLClassExpression, HashSet<OWLClassExpression>> classHierarchy){
		this.classAxiomMap = classAxiomMap;
		this.classHierarchy = classHierarchy;
	}*/
	
	private void ini(){
		path.clear();
		paths.clear();
		isSubclass = false;
	}	
			
	private void findPathDFS(OWLClassExpression currentKey, OWLClassExpression supC){	
		if(RelevanceParameters.conflictSetsNumLimit != -1 && 
				paths.size() >= RelevanceParameters.conflictSetsNumLimit){
			return;
		}
		
		HashSet<OWLClassExpression> superClasses = classHier.get(currentKey);
		/*if(paths.size()>2){
			return;
		}*/
		if(superClasses == null || superClasses.size()==0){
			path.remove(currentPair);
			/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
			System.out.println("---- remove");*/			
		} else {
			HashSet<OWLClassExpression> sigs = getEntitiesInPath(path);
			for(OWLClassExpression sup : superClasses){				
				// If true, there exists a dead circle. We ignore this case.
				if(sigs.contains(sup) || sup.toString().contains(OWL.Thing.toString())){
					continue;
				}				
				
				currentPair = MyUtils.createPair(currentKey, sup);
				/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
				System.out.println("---- add");*/
				path.add(new Vector<OWLClassExpression>(currentPair));	
				if(sup == supC){		
					paths.add(new HashSet<Vector<OWLClassExpression>>(path));						
					path.remove(currentPair);					
				} else {
					findPathDFS(sup, supC);
					currentPair = MyUtils.createPair(currentKey, sup);
					path.remove(currentPair);
					/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
					System.out.println("---- remove");*/
				}				
			}			
		}
	}
	
	private void findPathDFS(OWLClassExpression currentKey, OWLClassExpression supC,
			HashMap<OWLClassExpression, HashSet<OWLClassExpression>> classHierarchy){			
		HashSet<OWLClassExpression> superClasses = classHierarchy.get(currentKey);
		/*if(paths.size()>2){
			return;
		}*/
		if(superClasses == null || superClasses.size()==0){
			path.remove(currentPair);
			/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
			System.out.println("---- remove");*/			
		} else {
			for(OWLClassExpression sup : superClasses){
				HashSet<OWLClassExpression> sigs = getEntitiesInPath(path);
				// If true, there exists a dead circle. We ignore this case.
				if(sigs.contains(sup)){
					continue;
				}				
				
				currentPair = MyUtils.createPair(currentKey, sup);
				/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
				System.out.println("---- add");*/
				path.add(new Vector<OWLClassExpression>(currentPair));	
				if(sup == supC){		
					paths.add(new HashSet<Vector<OWLClassExpression>>(path));	
					path.remove(currentPair);
				} else {
					findPathDFS(sup, supC, classHierarchy);
					currentPair = MyUtils.createPair(currentKey, sup);
					path.remove(currentPair);
					/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
					System.out.println("---- remove");*/
				}				
			}			
		}
	}
	
	// to be checked (qiu)
	public HashSet<HashSet<Vector<OWLClassExpression>>> findPaths(
			HashSet<Vector<OWLClassExpression>> pairs, FindPath findPath){
		
		HashSet<HashSet<Vector<OWLClassExpression>>> combinedPs = new HashSet<HashSet<Vector<OWLClassExpression>>>();
		HashSet<HashSet<Vector<OWLClassExpression>>> ps = null;
		for(Vector<OWLClassExpression> pair : pairs){
			OWLClassExpression subC = pair.get(0);
			OWLClassExpression supC = pair.get(1);
			// If subC is equal to supC, then the path is empty.
			if(subC == supC){
				continue;
			}
			// Compute paths between a pair of entities.
			ps = findPath.findPaths(pair.get(0), pair.get(1));
			// If empty set is returned, we fail to find paths between the pair and MUPS can not be found.
			if(ps == null || (ps != null && ps.size() == 0)){
				combinedPs.clear();
				break;
			}
			// If we find a set of paths, we combine this set with the previously found one. 
			if(combinedPs.size() == 0){
				combinedPs = new HashSet<HashSet<Vector<OWLClassExpression>>>(ps);
			} else {
				combinedPs = this.combinePaths(combinedPs, ps);
			}
		}
		return combinedPs;
	}
		
	public HashSet<HashSet<Vector<OWLClassExpression >>> findPaths(
			OWLClassExpression currentKey, OWLClassExpression supC){
		this.ini();
		if(currentKey != null && supC != null && !currentKey.equals(supC)){
			this.findPathDFS(currentKey, supC);	
		}		
		HashSet<HashSet<Vector<OWLClassExpression >>> foundPaths = new HashSet<HashSet<Vector<OWLClassExpression>>>(paths);	
		return foundPaths;
	}
	
	public HashSet<HashSet<Vector<OWLClassExpression>>> findPathPairs(
			OWLClassExpression subC1,
			OWLClass supC1,
			OWLClassExpression subC2,
			OWLClass supC2){
				
		HashSet<HashSet<Vector<OWLClassExpression>>> partialJusts1 = findPaths(subC1, supC1);	
		/*System.out.println("-- Paths from "+subC1.toString()+" to "+supC1.toString());
		this.printPaths(partialJusts1);*/
		HashSet<HashSet<Vector<OWLClassExpression>>> partialJusts2 = findPaths(subC2, supC2);
			
		return this.combinePartialJusts(partialJusts1, partialJusts2);		
	}
	
	public HashSet<HashSet<Vector<OWLClassExpression>>> combinePaths(			 
			HashSet<HashSet<Vector<OWLClassExpression>>> paths1,
			HashSet<HashSet<Vector<OWLClassExpression>>> paths2){
		
		HashSet<HashSet<Vector<OWLClassExpression>>> completeJusts = new HashSet<HashSet<Vector<OWLClassExpression>>>();
		
		// Combine two partial sets.
		if(paths1 != null && paths1.size() > 0 
				&& paths2 != null && paths2.size() > 0){			
			for(HashSet<Vector<OWLClassExpression>> path1 : paths1){
				for(HashSet<Vector<OWLClassExpression>> path2 : paths2){										
					// Combine two paths
					HashSet<Vector<OWLClassExpression>> combinedPath = new HashSet<Vector<OWLClassExpression>>();
					combinedPath.addAll(path1);
					combinedPath.addAll(path2);
					// Add the combined path to completeJusts
					completeJusts.add(new HashSet<Vector<OWLClassExpression>>(combinedPath));
				}
			}	
			
		} else if(paths1 != null && paths1.size() >0 &&
				(paths2 == null || paths2.size() == 0)){
			completeJusts = paths1;
		} else if(paths2 != null && paths2.size() >0 &&
				(paths1 == null || paths1.size() == 0)){
			completeJusts = paths2;
		}		
		return completeJusts;
	}
	
	public HashSet<HashSet<Vector<OWLClassExpression>>> combinePartialJusts(			 
			HashSet<HashSet<Vector<OWLClassExpression>>> paths1,
			HashSet<HashSet<Vector<OWLClassExpression>>> paths2){
		
		HashSet<HashSet<Vector<OWLClassExpression>>> completeJusts = new HashSet<HashSet<Vector<OWLClassExpression>>>();
		
		// Combine two partial sets.
		if(paths1 != null && paths1.size() > 0 	&& paths2 != null && paths2.size() > 0){			
			for(HashSet<Vector<OWLClassExpression>> path1 : paths1){
				for(HashSet<Vector<OWLClassExpression>> path2 : paths2){										
					// Combine two paths
					HashSet<Vector<OWLClassExpression>> combinedPath = new HashSet<Vector<OWLClassExpression>>();
					combinedPath.addAll(path1);
					combinedPath.addAll(path2);
					// Add the combined path to completeJusts
					completeJusts.add(new HashSet<Vector<OWLClassExpression>>(combinedPath));
				}
			}	
			
		} else if(paths1 != null && paths1.size() >0 && (paths2 == null || paths2.size() == 0)){
			completeJusts = paths1;
		} else if(paths2 != null && paths2.size() >0 &&	(paths1 == null || paths1.size() == 0)){
			completeJusts = paths2;
		}
	
		return completeJusts;
	}
	
	public HashSet<HashSet<Vector<OWLClassExpression>>> removeCircles(HashSet<HashSet<Vector<OWLClassExpression>>> allPaths){
		HashSet<HashSet<Vector<OWLClassExpression>>> newPaths = new HashSet<HashSet<Vector<OWLClassExpression>>>();
		for(HashSet<Vector<OWLClassExpression>> path : allPaths){
			HashSet<Vector<OWLClassExpression>> newPath = new HashSet<Vector<OWLClassExpression>>(path);
			HashMap<OWLClassExpression, HashSet<OWLClassExpression>> localHier = this.constructHier(path);
			HashSet<OWLClassExpression> sigs = this.getEntitiesInPath(path);
			for(OWLClassExpression sig : sigs){
				if(localHier.containsKey(sig) && localHier.values().contains(sig)){
					OWLClassExpression key = this.getKey(localHier, sig);
					this.ini();
					this.findPathDFS(sig, key, localHier);
					if(paths != null && paths.size() >0 ){
						System.out.println("circle");
						Vector<OWLClassExpression> onePair = MyUtils.createPair(key, sig);
						newPath.remove(onePair);
						for(HashSet<Vector<OWLClassExpression>> p : paths){
							newPath.removeAll(p);
						}
					}
				}
			}
			newPaths.add(new HashSet<Vector<OWLClassExpression>>(newPath));
		}
		return newPaths;
	}
	
	public OWLClassExpression getKey(HashMap<OWLClassExpression, HashSet<OWLClassExpression>> localHier, OWLClassExpression value){
		for(OWLClassExpression key : localHier.keySet()){
			if(localHier.get(key).contains(value)){
				return key;
			}
		}
		return null;
	}
	
	public HashMap<OWLClassExpression, HashSet<OWLClassExpression>> constructHier(HashSet<Vector<OWLClassExpression>> path){
		HashMap<OWLClassExpression, HashSet<OWLClassExpression>> localHier = new HashMap<OWLClassExpression, HashSet<OWLClassExpression>>();
		for(Vector<OWLClassExpression> pair : path){
			OWLClassExpression sub = pair.get(0);
			OWLClassExpression sup = pair.get(1);
			if(localHier.containsKey(sub)){
				localHier.get(sub).add(sup);
			} else {
				HashSet<OWLClassExpression> sups = new HashSet<OWLClassExpression>();
				sups.add(sup);
				localHier.put(sub, sups);
			}
		}		
		return localHier;
	}
	
/*	public HashSet<HashSet<OWLAxiom>> combinePartialJusts(			 
			HashSet<HashSet<Vector<OWLClass>>> paths1,
			HashSet<HashSet<Vector<OWLClass>>> paths2){
		
		HashSet<HashSet<Vector<OWLClass>>> completeJusts = new HashSet<HashSet<Vector<OWLClass>>>();
		
		// Combine two partial sets.
		if(paths1 != null && paths1.size() > 0 
				&& paths2 != null && paths2.size() > 0){			
			for(HashSet<Vector<OWLClass>> path1 : paths1){
				for(HashSet<Vector<OWLClass>> path2 : paths2){
					// Remove common parts
					HashSet<Vector<OWLClass>> p1 = new HashSet<Vector<OWLClass>>(path1);
					HashSet<Vector<OWLClass>> p2 = new HashSet<Vector<OWLClass>>(path2);
					HashSet<Vector<OWLClass>> commonParts = this.getCommonParts(p1, p2);
					p1.removeAll(commonParts);
					p2.removeAll(commonParts);
					
					// If there is a subsumption between a signature in path and sup and
					// this subsumption can be inferred by path, then we ignore this case.	
					if(p1.size() >0 && p2.size() > 0){
						System.out.println("common: ");
						for(Vector<OWLClass> pair : commonParts){
							System.out.println("   "+pair.get(0).toString().replaceAll("http://www.text2onto.org/ontology#", "")+
									pair.get(1).toString().replaceAll("http://www.text2onto.org/ontology#",""));
						}
						System.out.println("p1: ");
						for(Vector<OWLClass> pair : p1){
							System.out.println("   "+pair.get(0).toString().replaceAll("http://www.text2onto.org/ontology#", "")+
									pair.get(1).toString().replaceAll("http://www.text2onto.org/ontology#",""));
						}
						System.out.println("p2: ");
						for(Vector<OWLClass> pair : p2){
							System.out.println("   "+pair.get(0).toString().replaceAll("http://www.text2onto.org/ontology#", "")+
									pair.get(1).toString().replaceAll("http://www.text2onto.org/ontology#",""));
						}
						System.out.println("\n");
						HashSet<Vector<OWLClass>> set1 = this.getRedundantAxiomsInFirstPath(p1, p2);
						if(set1.size() > 0){
							p1.removeAll(set1);
						}
						HashSet<Vector<OWLClass>> set2 = this.getRedundantAxiomsInFirstPath(p2, p1);
						if(set2.size() > 0){
							p2.removeAll(set2);
						}
					}					
					// Combine two paths
					HashSet<Vector<OWLClass>> combinedPath = new HashSet<Vector<OWLClass>>();
					combinedPath.addAll(commonParts);
					combinedPath.addAll(p1);
					combinedPath.addAll(p2);
					// Add the combined path to completeJusts
					completeJusts.add(new HashSet<Vector<OWLClass>>(combinedPath));
				}
			}	
			
		} else if(paths1 != null && paths1.size() >0 &&
				(paths2 == null || paths2.size() == 0)){
			completeJusts = paths1;
		} else if(paths2 != null && paths2.size() >0 &&
				(paths1 == null || paths1.size() == 0)){
			completeJusts = paths2;
		}
		
		HashSet<HashSet<OWLAxiom>> logicConflicts = PatternUtils.transferConflicts(
				completeJusts, classAxiomMap, inferredRelations);
		//HashSet<HashSet<OWLAxiom>> conflicts = PatternUtils.getMinimalConflicts(logicConflicts);
		// Return the found set of justifications.
		return logicConflicts;
	}*/
	
	private HashSet<Vector<OWLClassExpression>> getRedundantAxiomsInFirstPath(
			HashSet<Vector<OWLClassExpression>> path1,
			HashSet<Vector<OWLClassExpression>> path2){
		
		HashSet<Vector<OWLClassExpression>> p1 = new HashSet<Vector<OWLClassExpression>>();
		HashSet<OWLClassExpression> sigs1 = this.getEntitiesInPath(p1);
		for(Vector<OWLClassExpression> pair : path2){
			HashSet<OWLClassExpression> sigs2 = new HashSet<OWLClassExpression>();
			sigs2.add(pair.get(0));
			sigs2.add(pair.get(1));
			if(sigs1.containsAll(sigs2)){
				this.findPath(path1, pair.get(0), pair.get(1));
				if(paths.size() > 0){
					for(HashSet<Vector<OWLClassExpression>> set : paths){
						p1.addAll(set);
					}
					if(p1.equals(path1)){
						break;
					}
				}
			}						
		}
		return p1;
	}
	
	private void findPath(
			HashSet<Vector<OWLClassExpression>> path,
			OWLClassExpression beginOc,
			OWLClassExpression endOc){
		HashMap<OWLClassExpression, HashSet<OWLClassExpression>> mapping = new HashMap<OWLClassExpression, HashSet<OWLClassExpression>>();
		for(Vector<OWLClassExpression> pair : path){
			OWLClassExpression sub = pair.get(0);
			OWLClassExpression sup = pair.get(1);
			if(mapping.containsKey(sub)){
				mapping.get(sub).add(sup);
			} else {
				HashSet<OWLClassExpression> ocs = new HashSet<OWLClassExpression>();
				ocs.add(sup);
				mapping.put(sub, ocs);
			}
		}
		this.ini();
		findPathDFS(beginOc, endOc, mapping);			
	}
	
	private HashSet<Vector<OWLClass>> getCommonParts(
			HashSet<Vector<OWLClass>> path1,
			HashSet<Vector<OWLClass>> path2){
		HashSet<Vector<OWLClass>> commonParts = new HashSet<Vector<OWLClass>>();
		for(Vector<OWLClass> pair1 : path1){
			if(path2.contains(pair1)){
				commonParts.add(pair1);
			}			
		}
		return commonParts;
	}
	
/*	public HashSet<HashSet<OWLAxiom>> combinePartialJusts(			 
			HashSet<HashSet<OWLAxiom>> paths1,
			HashSet<HashSet<OWLAxiom>> paths2){
		
		HashSet<HashSet<OWLAxiom>> completeJusts = new HashSet<HashSet<OWLAxiom>>();
		
		// Combine two partial sets.
		if(paths1 != null && paths1.size() > 0 
				&& paths2 != null && paths2.size() > 0){			
			for(HashSet<OWLAxiom> path1 : paths1){
				for(HashSet<OWLAxiom> path2 : paths2){
					HashSet<OWLAxiom> combinedPath = new HashSet<OWLAxiom>();
					combinedPath.addAll(path1);
					combinedPath.addAll(path2);
					completeJusts.add(new HashSet<OWLAxiom>(combinedPath));
					
					// If there is a subsumption between a signature in path and sup 
					// and this subsumption can be inferred by path, then
					// we ignore this case.
					
					if(path != null && path.size() >0 ){
						sigs.remove(currentKey);
						for(OWLClass sig : sigs){
							if(classHierarchy.containsKey(sig)){
								if(classHierarchy.get(sig).contains(sup)){
									continue;
								}
							}
						}
					}
				}
			}	
			completeJusts = PatternUtils.getMinimalConflicts(completeJusts);
		} else if(paths1 != null && paths1.size() >0 &&
				(paths2 == null || paths2.size() == 0)){
			completeJusts = paths1;
		} else if(paths2 != null && paths2.size() >0 &&
				(paths1 == null || paths1.size() == 0)){
			completeJusts = paths2;
		}
		// Return the found set of justifications.
		return completeJusts;
	}*/

	private HashSet<OWLClassExpression> getEntitiesInPath(HashSet<Vector<OWLClassExpression>> path){
		HashSet<OWLClassExpression> ents = new HashSet<OWLClassExpression>();
		for(Vector<OWLClassExpression> pair : path){
			ents.addAll(pair);
		}
		return ents;
	}
	
	public void printPaths(HashSet<HashSet<Vector<OWLClass>>> paths){
		int n = 0;
		for(HashSet<Vector<OWLClass>> path : paths){
			this.printPath(path, n++);
		}
	}
	
	public void printPath(HashSet<Vector<OWLClass>> path, int n){
		System.out.println("-- Path "+n);
		for(Vector<OWLClass> pair : path){
			System.out.println("    <"+pair.get(0).toString()+", "+pair.get(1).toString()+">");
		}
	}
}
