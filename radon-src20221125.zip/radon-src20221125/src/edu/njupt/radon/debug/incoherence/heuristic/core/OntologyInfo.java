package edu.njupt.radon.debug.incoherence.heuristic.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataExactCardinality;
import org.semanticweb.owlapi.model.OWLDataMinCardinality;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDataPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLDataSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLInverseObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectComplementOf;
import org.semanticweb.owlapi.model.OWLObjectExactCardinality;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectMinCardinality;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectUnionOf;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.norm.TransformOntology;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * Obtain the information from the transformed axioms:
 * -- The mapping between a pair of entities and the corresponding axiom.
 * -- The mapping between a domain/range axiom and its justifications
 * -- The mapping between a property and its domains
 * -- The mapping between an objectproperty and its ranges
 * -- The mapping between an atomic concept and its super conditions
 * -- The mapping between an atomic concept and its super conditions defined with intersectionOf
 * -- The mapping between an atomic concept and its super conditions defined with someValuesFrom
 * 
 * @author Qiu Ji
 *
 */
public class OntologyInfo {	
	/** The existing information */
    private HashSet<OWLAxiom> axiomsInOnto ;
	private HashSet<OWLAxiom> transformedAxioms ;
	private HashSet<OWLClass> unsatConceptsInOriginalOnto;
	private HashSet<OWLClass> unsatConceptsInTransformedOnto;	
	// The mapping between a pair of OWLClassExpression and the corresponding OWLAxiom. 
	private HashMap<Vector<OWLClassExpression>, OWLAxiom> pairAxiomMap;	
	private DisjointRelations disjRelations;
	private HashMap<OWLClass, HashSet<OWLObjectIntersectionOf>> intersectionOfConditions;


	/**  New information to be obtained by the current class */
	private HashMap<OWLClass, HashSet<OWLClassExpression>> unionOfConditions = new HashMap<OWLClass, HashSet<OWLClassExpression>>();	
	private HashMap<OWLClass, HashSet<OWLClassExpression>> directExistentialConditions = new HashMap<OWLClass, HashSet<OWLClassExpression>>();
	private HashSet<Vector<OWLClassExpression>> directExistentialCondition = new HashSet<Vector<OWLClassExpression>>();
	private HashMap<OWLClass, HashSet<OWLClassExpression>> directUniversalConditions = new HashMap<OWLClass, HashSet<OWLClassExpression>>();
	private HashSet<Vector<OWLClassExpression>> directUniversalCondition = new HashSet<Vector<OWLClassExpression>>();
    private HashMap<OWLClass, HashSet<OWLClassExpression>> directCardiMinConditions = new HashMap<OWLClass, HashSet<OWLClassExpression>>();
	private HashMap<OWLClass, HashSet<OWLClassExpression>> directComplementConditions = new HashMap<OWLClass, HashSet<OWLClassExpression>>();
		
	// The mapping between an ObjectProperty and its defined domains.
	private HashMap<OWLEntity, HashSet<OWLClassExpression>> propertyDomains = new HashMap<OWLEntity, HashSet<OWLClassExpression>>();
	// The mapping between an ObjectProperty and its defined ranges. */
	private HashMap<OWLObjectProperty, HashSet<OWLClass>> propertyRanges = new HashMap<OWLObjectProperty, HashSet<OWLClass>>();		
	// The mapping between a domain/range relation and the corresponding axiom to state this relation. */
	private HashMap<Vector<Object>, HashSet<HashSet<OWLAxiom>>> domRanJusts = new HashMap<Vector<Object>, HashSet<HashSet<OWLAxiom>>>();
	
	private HashSet<OWLDisjointClassesAxiom> disjointAxioms = new HashSet<OWLDisjointClassesAxiom>();
	
	private static HashMap<OWLClass, HashSet<OWLAxiom>> ucSelfJusts = new HashMap<OWLClass, HashSet<OWLAxiom>>();
			
	public OntologyInfo(HashSet<OWLAxiom> axioms)  {
		axiomsInOnto = new HashSet<OWLAxiom>(axioms);
		// Transform axioms
		TransformOntology transf = new TransformOntology(axiomsInOnto);
		transformedAxioms = transf.getRefinedAxioms();
		pairAxiomMap = transf.getPairAxiomMap();
		intersectionOfConditions = transf.getIntersectionOfConditions();
	
		// Find all unsatisfiable concepts		
		unsatConceptsInOriginalOnto = ReasoningTools.getUnsatiConcepts(axiomsInOnto);
		unsatConceptsInTransformedOnto = ReasoningTools.getUnsatiConcepts(transformedAxioms);
		System.out.println("ucs in original ontology: " + unsatConceptsInOriginalOnto.size());			
		System.out.println("ucs in transformed ontology: " + unsatConceptsInTransformedOnto.size());			
		// Obtain various information from the transformed axiom set
		this.parseAxioms();		
		disjRelations = new DisjointRelations(this.disjointAxioms);
	}
	

	/** 
	 * For each axiom in an ontology, we obtain the information that we are interested in.
	 */
	private void parseAxioms(){	
		for(OWLAxiom a : transformedAxioms){
			this.parseAxiom(a);
		}	
		// Based on the information obtained in the first loop
		for(OWLAxiom a : transformedAxioms){
			this.parseAxiom2(a);
		}	
	}
	
	private void parseAxiom(OWLAxiom a){		
		if(a instanceof OWLSubClassOfAxiom){
			OWLSubClassOfAxiom subAxiom = (OWLSubClassOfAxiom)a;
			OWLClassExpression subOce = subAxiom.getSubClass();
			OWLClassExpression supOce = subAxiom.getSuperClass();
			// Currently we do not consider the case that the sub-concept is a complex concept.
			if(subOce.isAnonymous()){
				return;
			}
			OWLClass subC = subOce.asOWLClass();
			if(supOce.isAnonymous()){
				//this.addSuperCondition(subOce.asOWLClass(), supOce);
				if(supOce instanceof OWLObjectSomeValuesFrom){		
					this.addCondition(directExistentialConditions, subC, supOce);
					
				} else if(supOce instanceof OWLDataSomeValuesFrom){			
					this.addCondition(directExistentialConditions, subC, supOce);
					
				} else if(supOce instanceof OWLObjectAllValuesFrom){	
					this.addCondition(directUniversalConditions, subC, supOce);
					/*
				} else if(supOce instanceof OWLDataAllValuesFrom){			
					OWLDataAllValuesFrom ent = (OWLDataAllValuesFrom)oce;
					OWLDataPropertyExpression ope = ent.getProperty();
					OWLDataProperty op = MyUtils.getOWLDataProperty(ope);
					relevantOpsInAll.add(op);
					this.addCondition(allValuesConditions, oce, oc);*/
					
				} else if(supOce instanceof OWLObjectMinCardinality){	
					this.addCondition(directCardiMinConditions, subC, supOce);
					
		        } else if(supOce instanceof OWLObjectExactCardinality){	
					this.addCondition(directCardiMinConditions, subC, supOce);
					
		        } else if(supOce instanceof OWLDataMinCardinality){	
					this.addCondition(directCardiMinConditions, subC, supOce);	
					
		        } else if(supOce instanceof OWLDataExactCardinality){	
					this.addCondition(directCardiMinConditions, subC, supOce);
					
				} else if(supOce instanceof OWLObjectUnionOf){			
					this.addCondition(unionOfConditions, subC, supOce);
					
				} else if(supOce instanceof OWLObjectComplementOf){
					this.addCondition(directComplementConditions, subC, supOce);
				}
			} else if(supOce.asOWLClass().isBottomEntity()){
				if(ucSelfJusts.get(subC) == null){
					HashSet<OWLAxiom> justs = new HashSet<OWLAxiom>();
					justs.add(a);
					ucSelfJusts.put(subC, justs);
				} else {
					ucSelfJusts.get(subC).add(a);
				}
			}
		} else if(a instanceof OWLObjectPropertyDomainAxiom){
			OWLObjectPropertyDomainAxiom domainAxiom = (OWLObjectPropertyDomainAxiom)a;
			OWLObjectPropertyExpression opInDomainAxiom = domainAxiom.getProperty();
			OWLClassExpression domain = domainAxiom.getDomain();
			OWLObjectProperty ent = MyUtils.getOWLObjectProperty(opInDomainAxiom);
			this.addPropertyDomain(domainAxiom, ent, domain);
			
		} else if(a instanceof OWLDataPropertyDomainAxiom){
			OWLDataPropertyDomainAxiom domainAxiom = (OWLDataPropertyDomainAxiom)a;
			OWLDataPropertyExpression opInDomainAxiom = domainAxiom.getProperty();
			OWLClassExpression domain = domainAxiom.getDomain();					
			if(opInDomainAxiom != null && domain != null){
				OWLDataProperty ent = MyUtils.getOWLDataProperty(opInDomainAxiom);
				this.addPropertyDomain(domainAxiom, ent, domain);
			}					
			
		} else if(a instanceof OWLObjectPropertyRangeAxiom){
			OWLObjectPropertyRangeAxiom rangeAxiom = (OWLObjectPropertyRangeAxiom)a;
			OWLObjectPropertyExpression opInRangeAxiom = rangeAxiom.getProperty();
			OWLClassExpression range = rangeAxiom.getRange();
			this.addPropertyRange(rangeAxiom, opInRangeAxiom.asOWLObjectProperty(), range);
			
		} else if(a instanceof OWLDisjointClassesAxiom) {
			OWLDisjointClassesAxiom disjAxiom = (OWLDisjointClassesAxiom)a;
			this.disjointAxioms.add(disjAxiom);
		}
	}

	private void parseAxiom2(OWLAxiom a){	
		if(a instanceof OWLInverseObjectPropertiesAxiom){
			this.parseInversePropAxiom((OWLInverseObjectPropertiesAxiom)a);
		} 
	}
	
	private void addCondition(
			HashMap<OWLClass, HashSet<OWLClassExpression>> conditionMap, 
			OWLClass oc,
			OWLClassExpression condition){
		
		if(conditionMap.containsKey(oc)){
			conditionMap.get(oc).add(condition);
		} else {
			HashSet<OWLClassExpression> conditions = new HashSet<OWLClassExpression>();
			conditions.add(condition);
			conditionMap.put(oc, conditions);
		}
	}
	
	private void addCondition(
			HashSet<Vector<OWLClassExpression>> conditions, 			
			OWLClass oc, OWLClassExpression condition){
		Vector<OWLClassExpression> pair = new Vector<OWLClassExpression>();
		pair.addElement(oc);
		pair.addElement(condition);	
		conditions.add(pair);
	}
		
	private void parseInversePropAxiom(OWLInverseObjectPropertiesAxiom propAxiom){
		OWLObjectPropertyExpression op1 = propAxiom.getFirstProperty();
		OWLObjectPropertyExpression op2 = propAxiom.getSecondProperty();
		OWLObjectPropertyExpression firstOp = null;
		OWLObjectPropertyExpression secondOp = null;
		// Add range axioms according to domains and inverse-properties.
		if(propertyDomains.containsKey(op1)){				
			firstOp = op1;
			secondOp = op2;				
		} else if(propertyDomains.containsKey(op2)){
			firstOp = op2;
			secondOp = op1;
		}			
		if(firstOp != null && secondOp != null){
			HashSet<OWLClassExpression> oces = propertyDomains.get(firstOp);
			for(OWLClassExpression oce : oces){
				Vector<Object> pair = new Vector<Object>();
				pair.add(firstOp);
				pair.add(oce);
				
				HashSet<HashSet<OWLAxiom>> justs = new HashSet<HashSet<OWLAxiom>>(this.domRanJusts.get(pair));
				for(HashSet<OWLAxiom> just : justs){
					HashSet<OWLAxiom> set = new HashSet<OWLAxiom>(just);
					set.add(propAxiom);
					this.addPropertyRange(set, secondOp.asOWLObjectProperty(), oce);
				}				
			}	
			firstOp = null;
			secondOp = null;
		}			
		
		// Add domain axioms according to ranges and inverse-properties.
		if(propertyRanges.containsKey(op1)){
			firstOp = op1;
			secondOp = op2;	
		} else if(propertyRanges.containsKey(op2)){
			firstOp = op2;
			secondOp = op1;
		}
		if(firstOp != null && secondOp != null){
			for(OWLClassExpression oce : propertyRanges.get(firstOp)){
				Vector<Object> pair = new Vector<Object>();
				pair.add(firstOp);
				pair.add(oce);

				for(HashSet<OWLAxiom> just : this.domRanJusts.get(pair)){
					HashSet<OWLAxiom> set = new HashSet<OWLAxiom>(just);
					set.add(propAxiom);
					this.addPropertyDomain(set, secondOp.asOWLObjectProperty(), oce);
				}	
			}
		}
	
	}
/*	
	private void addSuperCondition(OWLClassExpression oc, OWLClassExpression oce){
		OWLClass concept = oc.asOWLClass();
		if(concept == null){
			return;
		}
		if(this.classSuperConditions.containsKey(oc)){
			classSuperConditions.get(oc).add(oce);
		} else {
			HashSet<OWLClassExpression> conditions = new HashSet<OWLClassExpression>();
			conditions.add(oce);
			classSuperConditions.put(concept, conditions);
		}
	}*/
	
	private void addPropertyDomain(
			OWLAxiom axiom, 
			OWLEntity ope, 
			OWLClassExpression domain){
		
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		axioms.add(axiom);
		this.addPropertyDomain(axioms, ope, domain);		
	}
	
	private void addPropertyDomain(
			HashSet<OWLAxiom> axioms, 
			OWLEntity op, 
			OWLClassExpression domain){
		
		if(op == null || domain == null)
			return;

		this.addDomRanJusts(op, domain, axioms);			
		if(propertyDomains.containsKey(op)){
			propertyDomains.get(op).add(domain);
		} else {
			HashSet<OWLClassExpression> ocs = new HashSet<OWLClassExpression>();
			ocs.add(domain);
			propertyDomains.put(op, ocs);
		}	
	}
	
	private void addPropertyRange(
			HashSet<OWLAxiom> axioms,
			OWLObjectProperty ope, 
			OWLClassExpression oce){
		
		OWLObjectProperty op = MyUtils.getOWLObjectProperty(ope);
		OWLClass oc = MyUtils.getOWLClass(oce);
		if(op != null && oc != null){
			this.addDomRanJusts( op, oc, axioms);
			if(propertyRanges.containsKey(op)){
				propertyRanges.get(op).add(oc);
			} else {
				HashSet<OWLClass> ocs = new HashSet<OWLClass>();
				ocs.add(oc);
				propertyRanges.put(op, ocs);
			}
		}		
	}
	
	private void addPropertyRange(
			OWLAxiom axiom, 
			OWLObjectProperty ope, 
			OWLClassExpression oce){
		
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		axioms.add(axiom);
		
		this.addPropertyRange(axioms, ope, oce);		
	}
	
	private void addDomRanJusts(OWLEntity op, OWLClassExpression oc, HashSet<OWLAxiom> axioms){
		Vector<Object> pair = new Vector<Object>();
		pair.add(op);
		pair.add(oc);
		
		if(domRanJusts.containsKey(pair)){
			domRanJusts.get(pair).add(new HashSet<OWLAxiom>(axioms));
		} else {
			HashSet<HashSet<OWLAxiom>> justs = new HashSet<HashSet<OWLAxiom>>();
			justs.add(new HashSet<OWLAxiom>(axioms));
			domRanJusts.put(pair, justs);
		}
	}
	
	public DisjointRelations getDisjointRelations(){
		return this.disjRelations;
	}
	
	public HashMap<Vector<OWLClass>, OWLDisjointClassesAxiom> getDisjointAxiomsMap(){
		return disjRelations.getDisjointAxiomsMap();
	}
	
	public HashMap<Vector<Object>, HashSet<HashSet<OWLAxiom>>> getPropertyAxiomMap(){
		return domRanJusts;
	}
	
	public HashMap<OWLEntity, HashSet<OWLClassExpression>> getPropertyDomains(){
		return propertyDomains;
	}
	
	public HashMap<OWLObjectProperty, HashSet<OWLClass>> getPropertyRanges(){
		return propertyRanges;
	}
	
	public HashMap<Vector<OWLClassExpression>, OWLAxiom> getPairAxiomMap(){
		return pairAxiomMap;
	}
			
	
	/*public UnsatisfiabilityPropagation getUnsatProp(){
		return unsatProp;
	}*/
	
	/*public HashSet<OWLClass> getUnsatisfiableConcepts(){
		return allUnsatConcepts;
	}*/
	

	
	public HashMap<OWLClass, HashSet<OWLClassExpression>> getDirectUnionOfConditions(){
		return unionOfConditions;
	}
	
	public HashMap<OWLClass, HashSet<OWLClassExpression>> getDirectExistentialConditions(){
		return directExistentialConditions;
	}
	
	public HashMap<OWLClass, HashSet<OWLClassExpression>> getDirectUniversalConditions(){
		return directUniversalConditions;
	}
	
	public HashMap<OWLClass, HashSet<OWLClassExpression>> getDirectCardiConditions(){
		return directCardiMinConditions;
	}
	
	public HashSet<OWLClass> getUCsInOriginalOnto(){
		return unsatConceptsInOriginalOnto;
	}
	
	public HashSet<OWLClass> getUCsInTransformedOnto(){
		return unsatConceptsInTransformedOnto;
	}
	
	public HashSet<OWLAxiom> getRefinedAxioms(){
		return transformedAxioms;
	}
	
	public HashSet<OWLAxiom> getOriginalAxioms(){
		return axiomsInOnto;
	}
	
	public HashMap<OWLClass, HashSet<OWLObjectIntersectionOf>> getIntersectionOfConditions() {
		return intersectionOfConditions;
	}
	
	public HashSet<Vector<OWLClassExpression>> getDirectExistentialCondition() {
		return directExistentialCondition;
	}
	public HashSet<Vector<OWLClassExpression>> getDirectUniversalCondition() {
		return directUniversalCondition;
	}
}
