package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;

public class PatternExistRange implements DebuggingPattern {
	OntologyInfo myOnto = null;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc = null;
	
	public PatternExistRange(OntologyInfo myOnto, 
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass unsatConcept){
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = unsatConcept;
	}
	
	@Override
	public HashSet<HashSet<OWLAxiom>> findMUPS() {
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		HashSet<OWLClassExpression> superClasses = classHier.getAllSuperClasses(uc);
		for(OWLClassExpression superClass : superClasses){
			if(myOnto.getDirectExistentialConditions().containsKey(superClass)){
				for(OWLClassExpression condition : myOnto.getDirectExistentialConditions().get(superClass)){
					if(!(condition instanceof OWLObjectSomeValuesFrom)){
						continue;
					}
					OWLObjectPropertyExpression ope = ((OWLObjectSomeValuesFrom)condition).getProperty();
					OWLObjectProperty opInCond = MyUtils.getOWLObjectProperty(ope);
					OWLClassExpression oce = ((OWLObjectSomeValuesFrom)condition).getFiller();
					// If the filler is not an atomic concept, we ignore such kind of cases currently.
					OWLClass filler = MyUtils.getOWLClass(oce);
					if(filler == null){
						continue;
					}
					ExpandDomRan expand = new ExpandDomRan(myOnto, classHier, propHier, uc);
					HashSet<HashSet<OWLAxiom>> conflicts2 = expand.findPatternOfRange(superClass.asOWLClass(), condition, opInCond, filler);
					if(conflicts2 != null && conflicts2.size()>0){
						conflicts.addAll(conflicts2);
					}
					
					/*if(DebuggingParameters.conflictSetsNumLimit != -1 && 
							conflicts2.size() >= DebuggingParameters.conflictSetsNumLimit){
						return conflicts;
					}*/
				}
			
			}
		}
		
		return conflicts;
	}
	
	@Override
    public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();		
		
		return allConflicts;
	}

}
