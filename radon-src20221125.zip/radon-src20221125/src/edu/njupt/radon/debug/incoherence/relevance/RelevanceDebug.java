package edu.njupt.radon.debug.incoherence.relevance;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxForOneMUPS;
import edu.njupt.radon.selefunc.ALCSelectionFunction;
import edu.njupt.radon.selefunc.SelectionFunction;
import edu.njupt.radon.selefunc.SigBasedSelectionFunction;
import edu.njupt.radon.selefunc.SigSimBasedSelectionFunction;
import edu.njupt.radon.selefunc.SigWindowBasedSelectionFunction;
import edu.njupt.radon.selefunc.SimBasedSelectionFunction;
import edu.njupt.radon.selefunc.SubBasedSelectionFunction;
import edu.njupt.radon.utils.OWLTools;


/**
 * This class is used to compute those relevant MUPS according to 
 * the given requirement of hitting set which consists of computing
 * one / all shortest hitting sets and all hitting sets.
 * 
 * @author Qiu Ji
 * @version 2012.11.14
 */
public class RelevanceDebug implements RadonDebug {	
	private SelectionFunction seleFunc ;	
	private BlackboxForOneMUPS computeOneMUPS = null;
	
	// The set of MUPS w.r.t. the input ontology of the method expandHST
	private HashSet<HashSet<OWLAxiom>> localMUPSSet;
	// The set of MUPS w.r.t. the input ontology of this class
	private HashSet<HashSet<OWLAxiom>> globalMUPSSet ;
	// The hitting sets w.r.t. the input ontology of the method expandHST
	private HashSet<Vector<OWLAxiom>> localHittingSets;
	// The hitting sets w.r.t. the input ontology of this class
	private HashSet<Vector<OWLAxiom>> globalHS; 
	// The set of axioms to be debugged
	private HashSet<OWLAxiom> debuggingAxioms = null;
	
	private OWLAxiom newlyAddedAxiom = null;
	
	OWLOntology debuggedOnto = null;

	private long debugTime = 0;
	
	RelDebugTools tools = null;
	/**
	 * 
	 * @param axioms
	 * @param newlyAddedAxiom This axiom is used to compute justifications for an entailment 
	 *        by transferring the entailment to an unsatisfiable concept.  
	 */
	public RelevanceDebug(HashSet<OWLAxiom> axioms, OWLAxiom newlyAddedAxiom){
		this.ini(axioms, newlyAddedAxiom);
	}

	public RelevanceDebug(HashSet<OWLAxiom> axioms){		
		this.ini(axioms, null);
	}
	
	public RelevanceDebug(OWLOntology o){	
		this.debuggedOnto = o;
		HashSet<OWLAxiom> axioms = new HashSet<>(o.getLogicalAxioms());
		this.ini(axioms, null);
	}
	

	private void ini(HashSet<OWLAxiom> axioms, OWLAxiom newlyAddedAxiom) {
		System.out.println("module size : "+axioms.size());
		this.newlyAddedAxiom = newlyAddedAxiom;
		this.debuggingAxioms = new HashSet<OWLAxiom>(axioms);
		computeOneMUPS = new BlackboxForOneMUPS(new HashSet<OWLAxiom>());
		
		if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.SubSeleFunc)){
			seleFunc = new SubBasedSelectionFunction(axioms);
		} else if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.ALCSeleFunc)){
			seleFunc = new ALCSelectionFunction(axioms);
		} else if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.SigSeleFunc)){
			seleFunc = new SigBasedSelectionFunction(axioms);
		} else if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.SimSeleFunc)){
			seleFunc = new SimBasedSelectionFunction(axioms);	
		} else if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.SigWinSeleFunc)){
			seleFunc = new SigWindowBasedSelectionFunction(axioms);
		} else if(RelevanceParameters.selectionFunction.equals(RelevanceParameters.SigSimSeleFunc)){
			seleFunc = new SigSimBasedSelectionFunction(axioms);	
		} else {
			seleFunc = new SigBasedSelectionFunction(axioms);
		}
		tools = new RelDebugTools();
		resetParas();		
	}
	
	public void resetParas() {
		globalHS = new HashSet<Vector<OWLAxiom>>();	
		globalMUPSSet = new HashSet<HashSet<OWLAxiom>>();
		localMUPSSet = new HashSet<HashSet<OWLAxiom>>();
		localHittingSets = new HashSet<Vector<OWLAxiom>>();
		computeOneMUPS.resetMUPSCounter();
	}
	
	public HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS() {
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = 
			new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		boolean coherent = tools.isCoherent(debuggingAxioms);	
		//OWLTools.printOWLAxioms(o);
		if(coherent){	
			System.out.println("This ontology is coherent.");
			return allMUPS;
		}
				
		HashSet<OWLClass> unsatConcepts = tools.getUnsatiConcepts(debuggingAxioms);
		System.out.println("The number of unsatisfiable concepts is "+unsatConcepts.size());
		HashSet<HashSet<OWLAxiom>> ucMUPS = null;
		//HashSet<OWLClass> roots = DebugTools.getRootUcs(unsatConcepts, o);
		
		int i = 0;
		long st = System.currentTimeMillis();
		for (OWLClass unsatConcept : unsatConcepts) {		
			String s = unsatConcept.toString();
			System.out.println((i++)+"> Unsati concept : "+s);
			
			if(debuggedOnto != null) {
				Set<OWLAxiom> module = OWLTools.extractModule(debuggedOnto, unsatConcept);
				System.out.println("    current module : "+module.size());
				this.ini(new HashSet<>(module), null);				
			}
						
			ucMUPS = this.getMUPS(unsatConcept, null);
			if (ucMUPS!=null && ucMUPS.size()>0) {
				if(newlyAddedAxiom != null){
					ucMUPS.remove(newlyAddedAxiom);
				}				
				allMUPS.put(unsatConcept, (HashSet<HashSet<OWLAxiom>>) ucMUPS.clone());
			}
			this.resetParas();
		}
		System.out.println("** Time to compute all MUPS for all Ucs: "+(System.currentTimeMillis()-st));
		return allMUPS;
	}
	
	
	public HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS(HashSet<String> ucUris) {
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = 
			new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		boolean coherent = tools.isCoherent(debuggingAxioms);	
		//OWLTools.printOWLAxioms(o);
		if(coherent){	
			System.out.println("This ontology is coherent.");
			return allMUPS;
		}
				
		HashSet<OWLClass> unsatConcepts = tools.getUnsatiConcepts(debuggingAxioms);
		System.out.println("The number of unsatisfiable concepts is "+unsatConcepts.size());
		HashSet<HashSet<OWLAxiom>> ucMUPS = null;
		//HashSet<OWLClass> roots = DebugTools.getRootUcs(unsatConcepts, o);
		
		int i = 0;
		long st = System.currentTimeMillis();
		for (OWLClass unsatConcept : unsatConcepts) {		
			String s = unsatConcept.toString();
			System.out.println((i++)+"> Unsati concept : "+s);
			
			if(ucUris.contains(s)) {
				System.out.println("    This uc has been debugged.");
				continue;
			}
			
			Set<OWLAxiom> module = OWLTools.extractModule(debuggedOnto, unsatConcept);
			System.out.println("    current axioms : "+module.size());
			this.ini(new HashSet<>(module), null);
			
			
			ucMUPS = this.getMUPS(unsatConcept, null);
			
		
			if (ucMUPS!=null && ucMUPS.size()>0) {
				if(newlyAddedAxiom != null){
					ucMUPS.remove(newlyAddedAxiom);
				}				
				allMUPS.put(unsatConcept, (HashSet<HashSet<OWLAxiom>>) ucMUPS.clone());
			}
			this.resetParas();
		}
		System.out.println("** Time to compute all MUPS for all Ucs: "+(System.currentTimeMillis()-st));
		return allMUPS;
	}
	
	/**
	 * Compute all MUPS for the specified unsatisfiable concept.
	 * 
	 * @param unsatConcept The unsatisfiable concept to be debugged.
	 * @return All MUPS found by the method.
	 */
	public HashSet<HashSet<OWLAxiom>> getMUPS(
			OWLClass unsatConcept)  {		
		return this.getMUPS(unsatConcept, null);
	}
				
	public HashSet<HashSet<OWLAxiom>> getMUPS(			 
			OWLClass oc,
			HashSet<HashSet<OWLAxiom>> foundMUPS) {	
		
		HashSet<HashSet<OWLAxiom>> reusedMUPS = new HashSet<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> allRelatedAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> currentRelatedAxioms = null;
		HashSet<Vector<OWLAxiom>> hs_tmp = new HashSet<Vector<OWLAxiom>>();
		int layer = 0;	
		this.resetParas();
		
		
		long st = System.currentTimeMillis();
		currentRelatedAxioms = seleFunc.getRelatedAxioms(oc);
		while(currentRelatedAxioms.size()>0){
			allRelatedAxioms.addAll(currentRelatedAxioms);
			computeOneMUPS.addAxioms(currentRelatedAxioms);
			
			System.out.println("Layer_"+(layer++)+" : "+currentRelatedAxioms.size()+" ( total = "+allRelatedAxioms.size()+" )");
			//OWLTools.printOneSet(related, null);	
			System.out.println("   Axioms in current layer: ");
			for(OWLAxiom ax : currentRelatedAxioms) {
				System.out.println(ax.toString());
			}
						
			// If globalHS is not empty and new related axioms are found, then we need to 
			// check whether those hs in globalHS are still hitting sets in the currently selected sub-ontology.
			if(globalHS.size()>0){	
				System.out.println("the number of hs_local: "+globalHS.size());
				
				//For those branches which do not need to be further expanded in the current layer
				hs_tmp.clear();
				for(Vector<OWLAxiom> oneHS : globalHS){	
					if(tools.isSatisfiable(allRelatedAxioms, oc, oneHS)){
						hs_tmp.add(new Vector<OWLAxiom>(oneHS));						
					}
				}	
				
				if(RelevanceParameters.debugStrategy.equals(RelevanceParameters.COMPUTE_ALL_HS_REL) || 
						(RelevanceParameters.debugStrategy.equals(RelevanceParameters.COMPUTE_All_CM_HS_REL) && hs_tmp.size() == 0)||
						(RelevanceParameters.debugStrategy.equals(RelevanceParameters.COMPUTE_ONE_CM_HS_REL) && hs_tmp.size() == 0)){
									
					HashSet<Vector<OWLAxiom>> globalHS_copy = new HashSet<Vector<OWLAxiom>>(globalHS);
					for(Vector<OWLAxiom> oneHS : globalHS_copy){
						// Those hitting sets in hs_tmp do not need to be further expanded in the currently layer.
						if(hs_tmp.contains(oneHS)){
							continue;
						}
						// Reuse those found MUPS
						reusedMUPS.clear();
						for (HashSet<OWLAxiom> exJust : globalMUPSSet ){
							if (allRelatedAxioms.containsAll(exJust)){
								reusedMUPS.add(exJust);	
							}
						}			
						// Compute new MUSP
						expandHST(oc, allRelatedAxioms, reusedMUPS);		
						// Update relevant information
						if(localMUPSSet.size()>0){							
							// Update the set of found MUPS
							globalMUPSSet.addAll(localMUPSSet);							
							// Update the "fake" hitting sets by adding branches newly found.
							globalHS.remove(oneHS);
							for(Vector<OWLAxiom> path : localHittingSets){
								Vector<OWLAxiom> newPath = new Vector<OWLAxiom>(oneHS);
								newPath.addAll(path);
								globalHS.add(newPath);
							}		
							

						} else {
							System.out.println("No new explanation found in this layer.");
						}							
					} //end_for					
				} else {
					globalHS = new HashSet<Vector<OWLAxiom>>(hs_tmp);
				}
				// test: �����ǰ���ҵ�������MUPS�еĹ���
				System.out.println("   found MUPS: "+localMUPSSet.size());
				System.out.println("   Axioms in current found MUPS: ");
				printAxioms(localMUPSSet);
			}  //end if(hs_local.size>0)	
			
			// The first time to compute MUPS (these codes will be invoked only once)
			if(globalHS.size()==0 && !tools.isSatisfiable(allRelatedAxioms, oc)){					
				expandHST(oc, allRelatedAxioms, null);
				globalMUPSSet.addAll(localMUPSSet);
				globalHS.addAll(localHittingSets);
				System.out.println("the number of hs_local found at the first iteration: "+globalHS.size());	
				// test: �����ǰ���ҵ�������MUPS�еĹ���
				System.out.println("   found MUPS: "+localMUPSSet.size());
				System.out.println("   Axioms in current found MUPS: ");
				printAxioms(localMUPSSet);
			} 
						
			//Select more axioms
			currentRelatedAxioms = seleFunc.getRelatedAxioms(allRelatedAxioms);			
		} 	
		long ucDebugTime = System.currentTimeMillis()-st;
		debugTime += ucDebugTime;		
		System.out.println("The time (ms) to compute all MUPS for a concept is: "+(ucDebugTime)+"\n");		
		return globalMUPSSet;
	}
	
	public void printAxioms(HashSet<HashSet<OWLAxiom>> sets) {
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		for(HashSet<OWLAxiom> set : sets) {
			axioms.addAll(set);
		}
		int counter = 0;
		for(OWLAxiom ax : axioms) {
			System.out.println("    "+(counter++)+" > "+ax.toString());
		}
	}

	private void expandHST(
			OWLClass unsatConcept, 
			HashSet<OWLAxiom> currentDebuggingAxioms,
			HashSet<HashSet<OWLAxiom>> foundMUPS)  {
		
		HashSet<OWLAxiom> firstMUPS = null;
		HashSet<OWLAxiom> currentDebuggingAxioms_c = new HashSet<OWLAxiom>(currentDebuggingAxioms);
		HashSet<Vector<OWLAxiom>> hs_temp1 = new HashSet<Vector<OWLAxiom>>();	
		HashSet<Vector<OWLAxiom>> hs_temp2 = new HashSet<Vector<OWLAxiom>>();	
		
		localMUPSSet.clear();
		localHittingSets.clear();
		//reuse mups of previous layers
		if(foundMUPS!=null && foundMUPS.size()>0){			
			localMUPSSet.addAll(foundMUPS);
			firstMUPS = foundMUPS.iterator().next();			
		}
				
		// Compute one MUPS
		if(firstMUPS==null){
			firstMUPS = computeOneMUPS.getOneMUPS(unsatConcept);			    
		}	        
		// Obtain all branches to be expanded
		if (firstMUPS != null && firstMUPS.size()>0) {	
			localMUPSSet.add(new HashSet<OWLAxiom>(firstMUPS));
			for(OWLAxiom a : firstMUPS){					
				Vector<OWLAxiom> p = new Vector<OWLAxiom>();
				p.add(a);
				hs_temp1.add(p);
			}
		} else {
			return;
		}
		
		// 
		while(true){	
			hs_temp2.clear();
			for(Vector<OWLAxiom> path : hs_temp1){				
				// If the current ontology by removing those axioms in a path becomes satisfiable 
				// w.r.t. the given unsatisfiable concept, then this path is a hitting set.
				// Otherwise, this branch needs to be further expanded.
				if(tools.isSatisfiable(currentDebuggingAxioms_c, unsatConcept, path)){
					//System.out.println("This path is final HS.");
					localHittingSets.add(new Vector<OWLAxiom>(path));
					if(RelevanceParameters.debugStrategy.equals(RelevanceParameters.COMPUTE_ONE_CM_HS_REL)){
						return;
					}					
				} else {
					//System.out.println("This path is not a final HS.");
					hs_temp2.add(new Vector<OWLAxiom>(path));
				}
			}
			
			// Early termination
			if(hs_temp1.size() == 0 || hs_temp2.size() == 0 || 
					(RelevanceParameters.debugStrategy.equals(RelevanceParameters.COMPUTE_All_CM_HS_REL) 
							&& localHittingSets.size()>0)){
				return;
			}
			
			// Further expand the branches which are not hitting sets in the entire ontology
			hs_temp1.clear();
			for(Vector<OWLAxiom> p : hs_temp2){					
				currentDebuggingAxioms_c.removeAll(p);	
				computeOneMUPS.removeAxioms(new HashSet<OWLAxiom>(p));
				
				// MUPS reuse
				HashSet<OWLAxiom> newMUPS = null;
				for (HashSet<OWLAxiom> exJust : localMUPSSet ){
					if (currentDebuggingAxioms_c.containsAll(exJust)){
						newMUPS = exJust;	
						break;
					}
				}
				// If no existing MUPS can be reused, then we compute a new one.
				if(newMUPS == null){
					newMUPS = computeOneMUPS.getOneMUPS(unsatConcept);	
					localMUPSSet.add(new HashSet<OWLAxiom>(newMUPS));
				}
				// Expand each branch in the newly found MUPS.
				for(OWLAxiom a : newMUPS){
					Vector<OWLAxiom> newPath = new Vector<OWLAxiom>(p);
					newPath.add(a);
					//Early path termination
					boolean earlyPath = false;
					for (Vector<OWLAxiom> h : localHittingSets) {							
						if (newPath.containsAll(h)||(h.indexOf(p)==0)) { 
							earlyPath = true;
							break;								
						}							
					}	
					if(!earlyPath){
						hs_temp1.add(new Vector<OWLAxiom>(newPath));
					}						
				}
				currentDebuggingAxioms_c.addAll(p);
				computeOneMUPS.addAxioms(new HashSet<OWLAxiom>(p));
			} //end_for_hs_temp2				
			hs_temp2.clear();
			hs_temp2.addAll(hs_temp1);
			
		} //end_while
	}
	
	/**
	 * Obtain hitting sets.
	 */
	public HashSet<Vector<OWLAxiom>> getHittingSets(){
		return globalHS;
	}
	

	
	
}

class A {
	int i = 1;
	public int getI(){
		return i;
	}
}
