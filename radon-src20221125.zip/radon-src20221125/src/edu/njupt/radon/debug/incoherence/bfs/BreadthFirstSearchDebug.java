package edu.njupt.radon.debug.incoherence.bfs;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxForOneMUPS;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.Timer;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class BreadthFirstSearchDebug implements RadonDebug {
	
	// The set of axioms to be debugged
	private HashSet<OWLAxiom> debuggingAxioms;
	// All MUPS for an unsatisfiable concept
	private HashSet<HashSet<OWLAxiom>> ucAllMUPS;
	
	
	private HashMap<Integer, HashSet<Vector<OWLAxiom>>> stratifiedHS;
	private BlackboxForOneMUPS computeOneMUPS = null; 
	//private boolean useBreadthFirstSearch = false;
	
	private Timer timerForReuse;
	private Timer timerForEarlyPathCheck;
	
	private int hsNumber = 0;		
	
		
	public BreadthFirstSearchDebug(HashSet<OWLAxiom> axioms){
		debuggingAxioms = new HashSet<OWLAxiom>(axioms);
		
		computeOneMUPS = new BlackboxForOneMUPS(axioms);
				
		ucAllMUPS = new HashSet<HashSet<OWLAxiom>>();
		//hittingSets.clear();
		computeOneMUPS.resetMUPSCounter();
		stratifiedHS = new HashMap<Integer, HashSet<Vector<OWLAxiom>>>();
		
		timerForReuse = new Timer();
		timerForEarlyPathCheck = new Timer();
	}

    /**
     * Compute all MUPS for all unsatisfiable concepts in the debugging axioms.
     * 
     * @return All MUPS for all unsatisfiable concepts.
     */
	public HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS() {
		// All MUPS of each unsatisfiable concept in an ontology
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		boolean coherent = ReasoningTools.isCoherent(debuggingAxioms);	
		//OWLTools.printOWLAxioms(o);
		if(coherent){	
			System.out.println("This ontology is coherent.");
			return allMUPS;
		}
		
		HashSet<OWLClass> unsatConcepts = ReasoningTools.getUnsatiConcepts(debuggingAxioms);
		System.out.println("The number of unsatisfiable concepts is "+unsatConcepts.size());
		HashSet<HashSet<OWLAxiom>> ucMUPS = null;
		
		int i = 0;
		for (OWLClass unsatConcept : unsatConcepts) {				
			System.out.println((i++)+"> concept : "+unsatConcept.toString());
			long st = System.currentTimeMillis();
			ucMUPS = this.getMUPS(unsatConcept);
			System.out.println("The time (ms) to compute all MUPS is: "+(System.currentTimeMillis()-st)+"\n");
					
			if (ucMUPS!=null && ucMUPS.size()>0) {
				allMUPS.put(unsatConcept, (HashSet<HashSet<OWLAxiom>>) ucMUPS.clone());
			}
		}
		return allMUPS;
	}
	
	/**
	 * Compute all MUPS for a specified unsatisfiable concept.
	 * 
	 * @param unsatConcept The unsatisfiable concept to be debugged.
	 * @return All MUPS found by the method.
	 */
	public HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass unsatConcept) {		
		return this.getMUPS(unsatConcept, null);
	}
		
	/**
	 * Compute all MUPS for a specified unsatisfiable concept based on the existing MUPS.
	 * 
	 * @param unsatConcept
	 * @param foundMUPS
	 * @return
	 */
	public HashSet<HashSet<OWLAxiom>> getMUPS(
			OWLClass unsatConcept, 
			HashSet<HashSet<OWLAxiom>> foundMUPS)  {

		// Reuse the existing MUPS
		if (foundMUPS != null && foundMUPS.size()>0) {			
			ucAllMUPS.addAll(foundMUPS);
		}
		HashSet<OWLAxiom> debuggingAxioms_c = new HashSet<OWLAxiom>(debuggingAxioms);
		
		long startTime = System.currentTimeMillis();		
		computeMUPSBFS(unsatConcept, debuggingAxioms_c);	
        long debugTime = System.currentTimeMillis() -startTime;
		
		Timer timerForReasoning = computeOneMUPS.getTimerForReasoning();
		Timer timerForSingleMUPS = computeOneMUPS.getTimerForSingleMUPS();
		Timer timerForTerminationCheck = computeOneMUPS.getTimerForTerminationCheck();
		System.out.println("Time (ms) and times for reasoning when computing single MUPS: "+
				timerForReasoning.getTotal()+", "+timerForReasoning.getCount());
		System.out.println("Time (ms) and times to compute single MUPS: "+
				timerForSingleMUPS.getTotal()+", "+timerForSingleMUPS.getCount());
		System.out.println("Time (ms) and times to check whether a path need to be terminated: "+
				timerForTerminationCheck.getTotal()+", "+timerForTerminationCheck.getCount());
		System.out.println("Time (ms) and times to reuse MUPS: "+
				timerForReuse.getTotal()+", "+timerForReuse.getCount());
		System.out.println("Time (ms) and times to early path checking: "+
				timerForEarlyPathCheck.getTotal()+", "+timerForEarlyPathCheck.getCount());
		System.out.println("Time to construct hitting set tree wihout time to reuse MUPS or check early path: "+
				(debugTime - timerForReuse.getTotal()-timerForEarlyPathCheck.getTotal()-
						timerForSingleMUPS.getTotal()-timerForTerminationCheck.getTotal()));
		
		return ucAllMUPS;
	}
	
	private void computeMUPSBFS(
			OWLClass unsatConcept, 
			HashSet<OWLAxiom> debuggingAxioms) {
		
		//HashSet<Vector<OWLAxiom>> exploredPaths = new HashSet<Vector<OWLAxiom>>();
		HashSet<OWLAxiom> singleJust = null;
		HittingSetTree hst = new HittingSetTree();
		
		// Reuse the existing MUPS
		if (ucAllMUPS.size()>0) {	
			singleJust = ucAllMUPS.iterator().next();
		}
		
		// If no MUPS can be reused, then compute one MUPS.
		if(singleJust==null){
			singleJust = computeOneMUPS.getOneMUPS(unsatConcept);	
		}
		
		// Create the root node
		Node rootnode = new Node(singleJust);
		Queue<Node> queue = new LinkedList<Node>();
		queue.add(rootnode);
		// Iterate on the nodes in the queue
		while(!queue.isEmpty()){
			// Obtain the node on the top of the queue
			Node node = (Node)queue.remove();
			// Iterate on the axioms in the node
			for(OWLAxiom axiom : node.data){
				// Get the path from the current node to the root node
				Vector<OWLAxiom> path = hst.getPathToRoot(node);
				// Expand the current path
                path.add(axiom);
                // Early path termination
        		if(canBeTerminated(path)){
        			continue;
        		}
        		
        		// Reuse existing MUPS
				HashSet<OWLAxiom> newMUPS = getNonIntersectingMUPS(path);
				// If no MUPS can be reused, then compute a new one
				if(newMUPS == null){
					computeOneMUPS.removeAxioms(new HashSet<OWLAxiom>(path));
					newMUPS = computeOneMUPS.getOneMUPS(unsatConcept);
					computeOneMUPS.addAxioms(new HashSet<OWLAxiom>(path));
					// If an empty MUPS is returned, then the ontology becomes satisfiable by removing the current path
					if(newMUPS.size() == 0){
						// Add the current path to the set of hitting sets.
						addOneHisttingSet(path);						
						continue;
					}					
				}
				// Create a new node for the MUPS that are newly discovered.
				Node newNode = new Node(newMUPS);
				queue.add(newNode);	
				// Add a MUPS to the set of all MUPS
				ucAllMUPS.add(newMUPS);
				// expand the hitting set tree
				hst.addEdge(node, newNode, axiom);
			}
		}
	}
	
	
	private boolean canBeTerminated(Vector<OWLAxiom> path){
		// Early path termination
		timerForEarlyPathCheck.start();			
		int pathLength = path.size();
		for(int hsLength : stratifiedHS.keySet()){
			// If the size of the path is not larger than that of a hitting set,
			// then this path must not contain all elements in the hitting set.
			if(pathLength < hsLength){
				continue;
			}
			for(Vector<OWLAxiom> hs : stratifiedHS.get(hsLength)) {			
				if(path.containsAll(hs)) { 
					timerForEarlyPathCheck.stop();
					return true;
				}
			}
		}
		timerForEarlyPathCheck.stop();
		return false;
	}
			
	private HashSet<OWLAxiom> getNonIntersectingMUPS(Vector<OWLAxiom> path){
		//Justification reuse
		timerForReuse.start();
		for (HashSet<OWLAxiom> oneMUPS : ucAllMUPS ){
			if (!CommonTools.hasIntersection(oneMUPS, path)){
				timerForReuse.stop();
				return oneMUPS;
			}
		}
		timerForReuse.stop();
		return null;
	}
		
	private void addOneHisttingSet(Vector<OWLAxiom> newPath){
		//hittingSets.add(new Vector<OWLAxiom>(newPath));
		int size = newPath.size();
		if(stratifiedHS.containsKey(size)){
			stratifiedHS.get(size).add(new Vector<OWLAxiom>(newPath));
		} else {
			HashSet<Vector<OWLAxiom>> paths = new HashSet<Vector<OWLAxiom>>();
			paths.add(new Vector<OWLAxiom>(newPath));
			stratifiedHS.put(size, paths);
		}
		hsNumber ++;
	}
	
	public HashSet<Vector<OWLAxiom>> getHittingSets(){
		HashSet<Vector<OWLAxiom>> hittingSets = new HashSet<Vector<OWLAxiom>>();
		for(int length : stratifiedHS.keySet()){
			hittingSets.addAll(stratifiedHS.get(length));
		}
		return hittingSets; 	
	}


}
