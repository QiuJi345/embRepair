package edu.njupt.radon.debug.incoherence.bfs;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;

public class Node {
	
	public HashSet<OWLAxiom> data;
	
	public Node(HashSet<OWLAxiom> currentNode){
		this.data = currentNode;
	}

	
}
