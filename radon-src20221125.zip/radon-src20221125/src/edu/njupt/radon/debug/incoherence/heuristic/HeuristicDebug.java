package edu.njupt.radon.debug.incoherence.heuristic;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapi.explanation.SatisfiabilityConverter;
import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.correctness.CorrectnessCheckerJusts;
import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;

public class HeuristicDebug  implements RadonDebug {	
	public static HashSet<OWLClass> visitedConcepts = new HashSet<OWLClass>();
	// To compute the MUPS of a uc, it may need to compute MUPS of other uc.
	// So we use this variable to store the MUPS of all debugged uc.
	//public static HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
	OntologyInfo myOnto;
	ClassHierarchy classHier ;
	PropertyHierarchy propHier;
	long debugTime = 0;	
	
	public HeuristicDebug(HashSet<OWLAxiom> axioms){	
		myOnto = new OntologyInfo(axioms);
		classHier = new ClassHierarchy(myOnto);
		propHier = new PropertyHierarchy(myOnto);		
	}	
			
	public HeuristicDebug(
			OntologyInfo myOntology,
			ClassHierarchy hier,
			PropertyHierarchy hier2){	
		myOnto = myOntology;
		classHier = hier;
		propHier = hier2;
	}	
		
	public HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS() {			
		
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		HashSet<OWLClass> ucs = myOnto.getUCsInOriginalOnto();
		System.out.println("All unsatisfiable concepts: "+ucs.size()+"\n"); 
		int i = 1;
		for(OWLClass uc : ucs){	
			System.out.print("["+(i++) + "] ");
			// Compute mups for the given concept			
			HashSet<HashSet<OWLAxiom>> ucMUPS = getMUPS(uc);		
        	allMUPS.put(uc, new HashSet<HashSet<OWLAxiom>>(ucMUPS));
        	
		}				
		// Save info to local disk
        //DumpFile.dumpObject(HeuristicDebugMain.resPath+"mups.dump", mupsString);
        // Return all found MUPS
        return allMUPS;
	}
	
	public HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass uc){	
		System.out.println(" UC: "+uc.toString());
		if(uc.toString().contains("IncoherentPolicy")){
			System.out.println("stop");
		}
		// Compute MUPS for the given concept
		visitedConcepts.clear(); 
		long st = System.currentTimeMillis();
		PatternControl control = new PatternControl(myOnto, classHier, propHier, uc);
		HashSet<HashSet<OWLAxiom>> ucMUPS = control.findMUPS();	
		long ucDebugTime = System.currentTimeMillis() - st;
		debugTime += ucDebugTime;
		System.out.println("Time to debug an UC: "+ucDebugTime+"\n\n");
		
		//CorrectnessCheckerJusts.checkJustsCorrectness(ucMUPS, uc);
		return ucMUPS;
	}
	
	public HashSet<HashSet<OWLAxiom>> getMUPS(
			OWLClass unsatConcept, 
			HashSet<HashSet<OWLAxiom>> foundMUPS){
		return null;
	}
	
	/**
	 * Obtain hitting sets.
	 */
	public HashSet<Vector<OWLAxiom>> getHittingSets(){
		return null;
	}
	
	

	
	/**
	 * This method is to 
	 * @param axiom
	 */
	public void getMUPS(OWLAxiom axiom){
		// Transfer an OWLAxiom to an unsatisfiable concept.
		SatisfiabilityConverter con = new SatisfiabilityConverter(OWL.factory);
		OWLClassExpression oce = con.convert(axiom);
		// Create a new concept to indicate an unsatisfiable concept.
		OWLClass uc = OWL.Class("");
		// Add class description to the unsat. concept above.
		OWLAxiom equAxiom = OWL.equivalentClasses(uc, oce);
		System.out.println("> Uc: "+uc.toString());
		if(uc.toString().contains("http://miniTambis#Peptide")){
			System.out.println("stop");
		}
		HashSet<HashSet<OWLAxiom>> conflicts = null;
		System.out.println("Find patterns ...");
		
		visitedConcepts.clear();
		PatternControl control = new PatternControl(myOnto, classHier, propHier, uc);
		conflicts = control.findMUPS();
		MyUtils.printConflicts(conflicts);
		//compare(uc, conflicts);
	}
}
