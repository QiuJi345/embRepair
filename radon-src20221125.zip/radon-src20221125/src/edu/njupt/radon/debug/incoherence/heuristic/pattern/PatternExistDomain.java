package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLDataSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
/**
 * 
 * @author Qiu Ji
 * @since 2011.07
 * Modified (2012.11.19): 
 *     Consider the existential restrictions associated with uc's super-classes 
 *     instead of iterating all existential restrictions in the ontology.
 */
public class PatternExistDomain implements DebuggingPattern {

	OntologyInfo myOnto = null;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc = null;
	
	public PatternExistDomain(OntologyInfo myOnto, 
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass unsatConcept){
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = unsatConcept;
	}
	
	@Override
	public HashSet<HashSet<OWLAxiom>> findMUPS() {
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		HashSet<OWLClassExpression> superClasses = classHier.getAllSuperClasses(uc);
		for(OWLClassExpression superClass : superClasses){
			// If a superClass has no existential restriction associated, 
			// it will be useless for detecting some-range pattern.
			if(!myOnto.getDirectExistentialConditions().containsKey(superClass)){
				continue;
			}
			// Iterate on the existential restrictions of superClass
			for(OWLClassExpression condition : myOnto.getDirectExistentialConditions().get(superClass)){
				// Obtain the property involved in the given existential restriction
				OWLEntity opInCond = null;
				if(condition instanceof OWLObjectSomeValuesFrom){					
					OWLObjectPropertyExpression ope = ((OWLObjectSomeValuesFrom)condition).getProperty();
					opInCond = MyUtils.getOWLObjectProperty(ope);
				} else {
					OWLDataPropertyExpression ope = ((OWLDataSomeValuesFrom)condition).getProperty();
					opInCond = MyUtils.getOWLDataProperty(ope);
				}				
				// 
				ExpandDomRan expand = new ExpandDomRan(myOnto, classHier, propHier, uc);
				HashSet<HashSet<OWLAxiom>> conflicts2 = expand.findPatternOfDomain(
						uc, superClass.asOWLClass(), condition, opInCond);
				if(conflicts2 != null && conflicts2.size()>0){
					conflicts.addAll(conflicts2);
				}
			}
		}	
		return conflicts;
	}
	
	@Override
    public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();		
		
		return allConflicts;
	}

}
