package edu.njupt.radon.debug.incoherence.heuristic.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLObjectProperty;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;


public class FindRolePath {
		
	Vector<OWLEntity> currentPair = new Vector<OWLEntity>();
	HashSet<Vector<OWLEntity>> path = new HashSet<Vector<OWLEntity>>();
	HashSet<HashSet<Vector<OWLEntity >>> paths = new HashSet<HashSet<Vector<OWLEntity>>>();	
	PropertyHierarchy propHier;
		
	public FindRolePath(PropertyHierarchy hier){
		this.propHier = hier;
	}
	
	private void ini(){
		path.clear();
		paths.clear();
	}	
				
	private void findPathDFS(OWLEntity currentKey, OWLEntity supC){	
		HashSet<OWLEntity> superProperties = null;
		if(currentKey instanceof OWLObjectProperty){
			superProperties = propHier.getObjectpropertyHierarchy().get(currentKey);
		} else if(currentKey instanceof OWLDataProperty){
			superProperties = propHier.getDatapropertyHierarchy().get(currentKey);
		}
			
		/*if(paths.size()>2){
			return;
		}*/
		if(superProperties == null || superProperties.size()==0){
			path.remove(currentPair);
			/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
			System.out.println("---- remove");*/			
		} else {
			for(OWLEntity sup : superProperties){
				// If true, there exists a dead circle. We ignore this case.	
				HashSet<OWLEntity> ents = new HashSet<OWLEntity>();
				for(Vector<OWLEntity> pair : path){
					for(OWLEntity ent : pair){
						ents.add(ent);
					}
				}
				if(ents.contains(sup)){
					continue;
				}
				currentPair = MyUtils.createPair(currentKey, sup);
				/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
				System.out.println("---- add");*/
				path.add(new Vector<OWLEntity>(currentPair));	
				if(sup == supC){		
					paths.add(new HashSet<Vector<OWLEntity>>(path));	
					path.remove(currentPair);
				} else {
					findPathDFS(sup, supC);
					this.
					currentPair = MyUtils.createPair(currentKey, sup);
					path.remove(currentPair);
					/*System.out.println("Current pair: sub = "+currentPair.get(0).toString()+", sup = "+currentPair.get(1).toString());
					System.out.println("---- remove");*/
				}				
			}			
		}
	}
		
	public HashSet<HashSet<Vector<OWLEntity >>> findPaths(
			OWLEntity currentKey, OWLEntity supC){
		if(currentKey == null || supC == null || currentKey.equals(supC)){
			return null;
		}		
		this.ini();
		this.findPathDFS(currentKey, supC);
		return paths;
	}
		
}
