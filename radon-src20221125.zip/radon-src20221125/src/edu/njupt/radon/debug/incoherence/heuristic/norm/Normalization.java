package edu.njupt.radon.debug.incoherence.heuristic.norm;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLInverseObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;

public class Normalization {
	
	public static final String subClassOfRelation = "subClassOf";
	public static final String equivalentClassOfRelation = "equivalentClassOf";
	
	/** The mapping between a pair of OWLClassExpression and the corresponding OWLAxiom. */
	private HashMap<Vector<OWLClassExpression>, OWLAxiom> classAxiomMap = 
		new HashMap<Vector<OWLClassExpression>, OWLAxiom>();
	/** The mapping between a pair of an ObjectProperty and its range and the justifications for this pair */
	private HashMap<Vector<Object>, HashSet<HashSet<OWLAxiom>>> domRanAxiomsMap = 
		new HashMap<Vector<Object>, HashSet<HashSet<OWLAxiom>>>();
	/** The mapping between an ObjectProperty and its defined domains. */
	private HashMap<OWLEntity, HashSet<OWLClassExpression>> propertyDomains = 
		new HashMap<OWLEntity, HashSet<OWLClassExpression>>();
	/** The mapping between an ObjectProperty and its defined ranges. */
	private HashMap<OWLObjectProperty, HashSet<OWLClass>> propertyRanges = 
		new HashMap<OWLObjectProperty, HashSet<OWLClass>>();
	/** The mapping between an OWLClass and its super conditions which are anonymous OWLClassExpression. */
	private HashMap<OWLClass, HashSet<OWLClassExpression>> classSuperConditions = 
		new HashMap<OWLClass, HashSet<OWLClassExpression>>();
		
	OWLOntology ontology = null;
	HashSet<OWLAxiom> axiomsInOnto = new HashSet<OWLAxiom>();
	HashSet<OWLAxiom> refinedAxioms = new HashSet<OWLAxiom>();
	HashMap<OWLAxiom, OWLAxiom> map =  new HashMap<OWLAxiom, OWLAxiom>();
	int number = 0;
	
	public Normalization(OWLOntology onto){
		this.ontology = onto;
		axiomsInOnto = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
	}
	
	public void doNormalization(){
		this.refineOntology();
		this.transfer(refinedAxioms);
	}
	/** 
	 * For each axiom in an ontology, we obtain the information what we are interested in.
	 * 
	 */
	public void refineOntology(){
		for(OWLAxiom a : axiomsInOnto){
			// Check whether there is a class expression defined with intersectionOf
			if(a instanceof OWLSubClassOfAxiom){				
				OWLSubClassOfAxiom axiom = (OWLSubClassOfAxiom)a;
				OWLClassExpression subC = axiom.getSubClass();
				OWLClassExpression supC = axiom.getSuperClass();
				HashSet<OWLClassExpression> operands2 = this.getOperands(supC);					
				if(operands2.size() == 0){
					this.addSuperCondition(subC, supC);
					refinedAxioms.add(a);
				} else {
					for(OWLClassExpression op2 : operands2){
						OWLAxiom newAxiom = OWL.subClassOf(subC, op2);
						refinedAxioms.add(newAxiom);
						Vector<OWLClassExpression> pair = MyUtils.createPair(subC, op2);
						this.classAxiomMap.put(pair, a);
						this.addSuperCondition(subC, op2);
					}
				}				
				Vector<OWLClassExpression> pair = MyUtils.createPair(subC, supC);
				classAxiomMap.put(pair, axiom);
				
			} else if(a instanceof OWLEquivalentClassesAxiom){
				OWLEquivalentClassesAxiom axiom = (OWLEquivalentClassesAxiom)a;
				Vector<OWLClassExpression> oces = new Vector<OWLClassExpression>(axiom.getClassExpressions());
				OWLClassExpression oc1 = oces.get(0);
				OWLClassExpression oc2 = oces.get(1);	
				
				Vector<OWLClassExpression> pair = MyUtils.createPair(oc1, oc2);				
				classAxiomMap.put(new Vector<OWLClassExpression>(pair), axiom);
				pair = MyUtils.createPair(oc2, oc1);
				classAxiomMap.put(new Vector<OWLClassExpression>(pair), axiom);
				
				if(oc1 instanceof OWLObjectIntersectionOf){
					OWLObjectIntersectionOf inter = (OWLObjectIntersectionOf)oc1;
					for(OWLClassExpression op2 : inter.getOperands()){
						OWLAxiom newAxiom = OWL.subClassOf(oc2, op2);
						refinedAxioms.add(newAxiom);
						Vector<OWLClassExpression> pair1 = MyUtils.createPair(oc2, op2);
						this.classAxiomMap.put(pair1, a);
						this.addSuperCondition(oc2, op2);
					}
				} else if(oc2 instanceof OWLObjectIntersectionOf){
					OWLObjectIntersectionOf inter = (OWLObjectIntersectionOf)oc2;
					for(OWLClassExpression op2 : inter.getOperands()){
						OWLAxiom newAxiom = OWL.subClassOf(oc1, op2);
						refinedAxioms.add(newAxiom);
						Vector<OWLClassExpression> pair1 = MyUtils.createPair(oc1, op2);
						this.classAxiomMap.put(pair1, a);
						this.addSuperCondition(oc1, op2);
					}
				} else {
					this.addSuperCondition(oc2, oc1);
					refinedAxioms.add(a);
				}
			} else if(a instanceof OWLObjectPropertyDomainAxiom){
				OWLObjectPropertyDomainAxiom domainAxiom = (OWLObjectPropertyDomainAxiom)a;
				OWLObjectPropertyExpression opInDomainAxiom = domainAxiom.getProperty();
				OWLClassExpression domain = domainAxiom.getDomain();					
				if(opInDomainAxiom != null && domain != null){
					// Obtain the inverse properties of opInDomainAxiom
					Set<OWLInverseObjectPropertiesAxiom> set = ontology.getInverseObjectPropertyAxioms(opInDomainAxiom);
					if(set != null){
						for(OWLInverseObjectPropertiesAxiom inverseAxiom : set){
							OWLObjectPropertyExpression inverseOpe = this.getInverseObjectProperty(inverseAxiom, opInDomainAxiom);
							if(inverseOpe == null){
								continue;
							}
							// This set of axioms shows the justifications about why inverseOpe has domain as Domain.
							HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
							axioms.add(inverseAxiom);
							axioms.add(domainAxiom);
							this.addPropertyRange(axioms, inverseOpe, domain);							
						}
					}
				}	
				OWLEntity ent = MyUtils.getOWLObjectProperty(opInDomainAxiom);
				this.addPropertyDomain(domainAxiom, ent, domain);
				
			} else if(a instanceof OWLDataPropertyDomainAxiom){
				OWLDataPropertyDomainAxiom domainAxiom = (OWLDataPropertyDomainAxiom)a;
				OWLDataPropertyExpression opInDomainAxiom = domainAxiom.getProperty();
				OWLClassExpression domain = domainAxiom.getDomain();					
				if(opInDomainAxiom != null && domain != null){
					OWLEntity ent = MyUtils.getOWLDataProperty(opInDomainAxiom);
					this.addPropertyDomain(domainAxiom, ent, domain);
				}					
				
			} else if(a instanceof OWLObjectPropertyRangeAxiom){
				OWLObjectPropertyRangeAxiom rangeAxiom = (OWLObjectPropertyRangeAxiom)a;
				OWLObjectPropertyExpression opInRangeAxiom = rangeAxiom.getProperty();
				OWLClassExpression range = rangeAxiom.getRange();				
				if(opInRangeAxiom != null && range != null){
					// Obtain the inverse properties of opInDomainAxiom
					Set<OWLInverseObjectPropertiesAxiom> set = ontology.getInverseObjectPropertyAxioms(opInRangeAxiom);
					if(set != null){
						for(OWLInverseObjectPropertiesAxiom inverseAxiom : set){
							OWLObjectPropertyExpression inverseOpe = this.getInverseObjectProperty(inverseAxiom, opInRangeAxiom);
							if(inverseOpe == null){
								continue;
							}
							// This set of axioms shows the justifications about why inverseOpe has domain as Domain.
							HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
							axioms.add(inverseAxiom);
							axioms.add(rangeAxiom);
							OWLEntity ent = MyUtils.getOWLObjectProperty(inverseOpe);
							this.addPropertyDomain(axioms, ent, range);
						}
					}
				}	
				this.addPropertyRange(rangeAxiom, opInRangeAxiom, range);				
			} 
		}
	}
	
	
	public HashMap<OWLAxiom, OWLAxiom> transfer(HashSet<OWLAxiom> axioms){
		System.out.println("Axioms: "+axioms.size());
		for(OWLAxiom a : axioms){
			System.out.println(a.toString());
			this.transferAxiom(a);
		}
		return map;
	}
	
	public void transferAxiom(OWLAxiom a){		
		// Check whether there is a class expression defined with intersectionOf
		if(a instanceof OWLSubClassOfAxiom){				
			OWLSubClassOfAxiom axiom = (OWLSubClassOfAxiom)a;
			OWLClassExpression supC = axiom.getSuperClass();	
			OWLClassExpression subC = axiom.getSubClass();
			if(supC.isAnonymous() && subC.isAnonymous()){	
				OWLClass novelConcept1 = this.getNovelConcept();
				OWLClass novelConcept2 = this.getNovelConcept();
				OWLAxiom newAxiom = OWL.factory.getOWLSubClassOfAxiom(novelConcept1, novelConcept2);
				map.put(newAxiom, a);
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(novelConcept1, subC);
				map.put(newAxiom, a);
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(novelConcept2, supC);
				map.put(newAxiom, a);
				this.transferConcept(a, novelConcept1, subC, subClassOfRelation);
				this.transferConcept(a, novelConcept2, supC, subClassOfRelation);
			} else if(supC.isAnonymous()){
				OWLClass novelConcept = this.getNovelConcept();
				OWLAxiom newAxiom = OWL.factory.getOWLSubClassOfAxiom(subC, novelConcept);
				map.put(newAxiom, a);
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(novelConcept, supC);
				map.put(newAxiom, a);
				this.transferConcept(a, novelConcept, supC, subClassOfRelation);
			} else if(subC.isAnonymous()){
				OWLClass novelConcept = this.getNovelConcept();
				OWLAxiom newAxiom = OWL.factory.getOWLSubClassOfAxiom(novelConcept, supC);
				map.put(newAxiom, a);
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(novelConcept, subC);
				map.put(newAxiom, a);
				this.transferConcept(a, novelConcept, subC, subClassOfRelation);
			} else {
				map.put(a, a);
			}
			
		} else if(a instanceof OWLEquivalentClassesAxiom){
			OWLEquivalentClassesAxiom axiom = (OWLEquivalentClassesAxiom)a;
			Vector<OWLClassExpression> oces = new Vector<OWLClassExpression>(axiom.getClassExpressions());
			OWLClassExpression oc1 = oces.get(0);
			OWLClassExpression oc2 = oces.get(1);					
			OWLClassExpression subC = null;
			OWLClassExpression condition = null;
			if(oc1.isAnonymous()){
				subC = oc2;
				condition = oc1;
				
			} else if(oc2.isAnonymous()){
				subC = oc1;
				condition = oc2;
			} else {
				map.put(a, a);
			}
			//
			if(condition != null){
				OWLClass novelConcept = this.getNovelConcept();
				OWLAxiom newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(subC, novelConcept);
				map.put(newAxiom, a);
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(novelConcept, condition);
				map.put(newAxiom, a);
				this.transferConcept(a, novelConcept, condition, subClassOfRelation);
			}
		} else if(a instanceof OWLObjectPropertyDomainAxiom){
			OWLObjectPropertyDomainAxiom axiom = (OWLObjectPropertyDomainAxiom)a;
			OWLObjectPropertyExpression ope = axiom.getProperty();
			OWLClassExpression domain = axiom.getDomain();
			if(domain.isAnonymous()){
				OWLClass novelConcept = this.getNovelConcept();
				OWLAxiom newAxiom = OWL.factory.getOWLObjectPropertyDomainAxiom(ope, novelConcept);
				map.put(newAxiom, a);
				newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(novelConcept, domain);
				map.put(newAxiom, a);
				this.transferConcept(a, novelConcept, domain, subClassOfRelation);
			} else {
				map.put(a, a);
			}
		}
	}
	
	public void transferConcept(OWLAxiom axiom, 
			OWLClassExpression subC, 
			OWLClassExpression condition, 
			String relation){
		
		if(condition instanceof OWLObjectSomeValuesFrom){
			OWLObjectSomeValuesFrom oceSome = (OWLObjectSomeValuesFrom)condition;
			OWLClassExpression filler = oceSome.getFiller();
			if(filler.isAnonymous()){
				// create a novel concept
				OWLClass novelConcept = getNovelConcept();
				// create an equivalent relation between the novel concept and the filler.
				OWLAxiom newAxiom = null;				
				if(relation.equals(equivalentClassOfRelation)){
					newAxiom = OWL.factory.getOWLEquivalentClassesAxiom(subC, novelConcept);
				} else if(relation.equals(subClassOfRelation)){
					newAxiom = OWL.factory.getOWLSubClassOfAxiom(subC, novelConcept);
				}
				map.put(newAxiom, axiom);
				newAxiom = OWL.factory.getOWLSubClassOfAxiom(novelConcept, condition);
				map.put(newAxiom, axiom);
				
				this.transferConcept(axiom, novelConcept, filler, subClassOfRelation);
			} 
		} else if(condition instanceof OWLObjectIntersectionOf){
			OWLObjectIntersectionOf interC = (OWLObjectIntersectionOf)condition;
			for(OWLClassExpression operand : interC.getOperands()){				
				if(operand.isAnonymous()){
					this.transferConcept(axiom, subC, operand, subClassOfRelation);
				} else {
					OWLAxiom a = OWL.factory.getOWLSubClassOfAxiom(subC, operand);
					map.put(a, axiom);
				}
			}
		}
	}
	

	public HashSet<OWLClassExpression> getOperands(OWLClassExpression oce){
		HashSet<OWLClassExpression> operands = new HashSet<OWLClassExpression>();
		if(oce instanceof OWLObjectIntersectionOf){
			OWLObjectIntersectionOf interSub = (OWLObjectIntersectionOf)oce;
			operands.addAll(interSub.getOperands());
		}
		return operands;
	}
	

	
	private OWLObjectPropertyExpression getInverseObjectProperty(
			OWLInverseObjectPropertiesAxiom inverseAxiom,
			OWLObjectPropertyExpression ope){
		// Obtain the inverse property of opInRangeAxiom
		for(OWLObjectPropertyExpression invOpe : inverseAxiom.getProperties()){
			if(invOpe != ope){
				return invOpe;
			}
		}
		return null;
	}
	
	private void addSuperCondition(OWLClassExpression oc, OWLClassExpression oce){
		if(oc instanceof OWLClass){
			OWLClass concept = oc.asOWLClass();			
			if(this.classSuperConditions.containsKey(oc)){
				classSuperConditions.get(oc).add(oce);
			} else {
				HashSet<OWLClassExpression> conditions = new HashSet<OWLClassExpression>();
				conditions.add(oce);
				classSuperConditions.put(concept, conditions);
			}
		}		
	}
	
	private void addPropertyDomain(
			OWLAxiom axiom, 
			OWLEntity ope, 
			OWLClassExpression domain){
		
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		axioms.add(axiom);
		this.addPropertyDomain(axioms, ope, domain);		
	}
	
	private void addPropertyDomain(
			HashSet<OWLAxiom> axioms, 
			OWLEntity op, 
			OWLClassExpression domain){
		
		if(op != null && domain != null){
			this.addDomRanJusts(axioms, op, domain);			
			if(propertyDomains.containsKey(op)){
				propertyDomains.get(op).add(domain);
			} else {
				HashSet<OWLClassExpression> ocs = new HashSet<OWLClassExpression>();
				ocs.add(domain);
				propertyDomains.put(op, ocs);
			}
		}
	}
	
	private void addPropertyRange(
			HashSet<OWLAxiom> axioms,
			OWLObjectPropertyExpression ope, 
			OWLClassExpression oce){
		
		OWLObjectProperty op = MyUtils.getOWLObjectProperty(ope);
		OWLClass oc = MyUtils.getOWLClass(oce);
		if(op != null && oc != null){
			this.addDomRanJusts(axioms, op, oc);
			if(propertyRanges.containsKey(op)){
				propertyRanges.get(op).add(oc);
			} else {
				HashSet<OWLClass> ocs = new HashSet<OWLClass>();
				ocs.add(oc);
				propertyRanges.put(op, ocs);
			}
		}		
	}
	
	private void addPropertyRange(
			OWLAxiom axiom, 
			OWLObjectPropertyExpression ope, 
			OWLClassExpression oce){
		
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>();
		axioms.add(axiom);
		
		this.addPropertyRange(axioms, ope, oce);		
	}
	
	private void addDomRanJusts(
			HashSet<OWLAxiom> axioms, 
			OWLEntity op, 
			OWLClassExpression oc){
		Vector<Object> pair = new Vector<Object>();
		pair.add(op);
		pair.add(oc);
		
		if(domRanAxiomsMap.containsKey(pair)){
			domRanAxiomsMap.get(pair).add(new HashSet<OWLAxiom>(axioms));
		} else {
			HashSet<HashSet<OWLAxiom>> justs = new HashSet<HashSet<OWLAxiom>>();
			justs.add(new HashSet<OWLAxiom>(axioms));
			domRanAxiomsMap.put(pair, justs);
		}
	}
	
	public OWLClass getNovelConcept(){
		OWLClass novelConcept = OWL.factory.getOWLClass(IRI.create(
				"http://www.radon.com/concepts/tmpConcept_"+(number++)));
		return novelConcept;
	}
	
	
		
	public HashMap<Vector<Object>, HashSet<HashSet<OWLAxiom>>> getPropertyAxiomMap(){
		return domRanAxiomsMap;
	}
	
	public HashMap<OWLClass, HashSet<OWLClassExpression>> getClassSuperConditions(){
		return classSuperConditions;
	}
	
	public HashMap<OWLEntity, HashSet<OWLClassExpression>> getPropertyDomains(){
		return propertyDomains;
	}
	
	public HashMap<OWLObjectProperty, HashSet<OWLClass>> getPropertyRanges(){
		return propertyRanges;
	}
		
	public HashMap<Vector<OWLClassExpression>, OWLAxiom> getClassAxiomMap(){
		return classAxiomMap;
	}
	
	public HashSet<OWLAxiom> getRefinedAxioms(){
		return refinedAxioms;
	}
	
	
}
