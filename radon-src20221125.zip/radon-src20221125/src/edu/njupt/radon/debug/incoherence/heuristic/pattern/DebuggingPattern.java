package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;

public interface DebuggingPattern {
	
	public HashSet<HashSet<OWLAxiom>> findMUPS();	
	
	public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom);
}
