package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.PatternUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindPath;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;

public class PatternExistAll implements DebuggingPattern {
	OntologyInfo myOnto;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc;	
	
	public PatternExistAll(
			OntologyInfo myOnto,
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass uc){		
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = uc;		
	}
	
	@Override
	public HashSet<HashSet<OWLAxiom>> findMUPS() {
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		// Obtain all super concepts of the debugged concept
		HashSet<OWLClassExpression> superClasses = classHier.getAllSuperClasses(uc);
		for(OWLClassExpression superClass1 : superClasses){
			if(!myOnto.getDirectExistentialConditions().containsKey(superClass1)){
				continue;
			}
            // Obtain the direct existential conditions of the superclass
			for(OWLClassExpression existentialCondition : myOnto.getDirectExistentialConditions().get(superClass1)){
				if(!(existentialCondition instanceof OWLObjectSomeValuesFrom)){
					continue;
				}
				OWLObjectPropertyExpression ope1 = ((OWLObjectSomeValuesFrom)existentialCondition).getProperty();
				OWLClassExpression oce1 = ((OWLObjectSomeValuesFrom)existentialCondition).getFiller();
				OWLClass filler1 = MyUtils.getOWLClass(oce1);
				if(filler1 == null){
					continue;
				}
				
				for(OWLClassExpression superClass2 : superClasses){
					if(!myOnto.getDirectUniversalConditions().containsKey(superClass2)){
						continue;
					}
                    // Obtain the direct universal conditions of the superclass
					for(OWLClassExpression allCondition : myOnto.getDirectUniversalConditions().get(superClass2)){
						OWLObjectPropertyExpression ope2 = ((OWLObjectAllValuesFrom)allCondition).getProperty();
						OWLClassExpression oce2 = ((OWLObjectAllValuesFrom)allCondition).getFiller();
						OWLClass filler2 = MyUtils.getOWLClass(oce2);
						
						// If the two properties are not the same, there is no pattern to be considered.
						if(!ope1.equals(ope2) || filler2 == null){
							continue;
						}
												
						/** Consider the first part */
						ExpandDisjRelations expand = new ExpandDisjRelations(myOnto, classHier, propHier, uc);
						HashSet<HashSet<OWLAxiom>> partialJusts1 = expand.findJustsForDisjRelation(
								filler1, filler2);
						
						if(partialJusts1 != null && partialJusts1.size()>0){
							/** Consider the second part */
							FindPath findPath = new FindPath(classHier.getClassHierarchy());
							HashSet<HashSet<Vector<OWLClassExpression>>> novelPaths = findPath.findPathPairs(
									uc, superClass1.asOWLClass(), uc, superClass2.asOWLClass());	
							// transfer paths to axioms
							HashSet<HashSet<OWLAxiom>> logicConflicts = PatternUtils.transferConflicts(
									novelPaths, classHier, myOnto);
							HashSet<HashSet<OWLAxiom>> partialJusts2 = PatternUtils.getMinimalSets(logicConflicts);

							
							partialJusts2 = PatternUtils.combinePartialJusts(partialJusts1, partialJusts2);
							
							/** Consider the third part */
							// Obtain the axiom with two conditions
							Vector<OWLClassExpression> pair1 = MyUtils.createPair(superClass1, existentialCondition);
							OWLAxiom axiom1 = myOnto.getPairAxiomMap().get(pair1);
							Vector<OWLClassExpression> pair2 = MyUtils.createPair(superClass2, allCondition);
							OWLAxiom axiom2 = myOnto.getPairAxiomMap().get(pair2);	
							// Add the axioms to a partial conflict.
							for(HashSet<OWLAxiom> just : partialJusts2){
								just.add(axiom1);
								just.add(axiom2);
								conflicts.add(new HashSet<OWLAxiom>(just));
							}
						}						
					}
				
				}
			}
		
		}
		
		return conflicts;
	}

	@Override
    public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();		
		
		return allConflicts;
	}
}
