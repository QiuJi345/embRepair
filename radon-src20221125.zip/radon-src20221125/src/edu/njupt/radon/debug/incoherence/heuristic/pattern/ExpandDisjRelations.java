package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.heuristic.PatternControl;
import edu.njupt.radon.debug.incoherence.heuristic.PatternUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.DisjointRelations;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindPath;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceParameters;

public class ExpandDisjRelations {
	
	OntologyInfo myOnto;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc;			
	
	public ExpandDisjRelations(
			OntologyInfo myOnto,
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass uc){		
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = uc;		
	}
	
	public HashSet<HashSet<OWLAxiom>> findJustsForDisjRelation(
			OWLClassExpression filler1, OWLClassExpression filler2){
		
		// Compute justifications which may consist of at most three parts.
		HashSet<HashSet<OWLAxiom>> partialJusts = new HashSet<HashSet<OWLAxiom>>();
		boolean hasUnsatConcept = false;
		HashMap<OWLClass, HashSet<OWLClassExpression>> unionOfConditions = myOnto.getDirectUnionOfConditions();	
		// If one filler is unsatisfiable, then find out the corresponding justifications.
		if(unionOfConditions.containsKey(filler1) && filler2.equals(OWL.Thing) 
				&& !filler1.isAnonymous()){			
			PatternControl patControl = new PatternControl(myOnto, classHier, propHier, filler1.asOWLClass());
			partialJusts = patControl.findMUPS();				
			hasUnsatConcept = true;
		} 
		if(filler1.equals(OWL.Thing) &&  unionOfConditions.containsKey(filler2) 
				&& !filler2.isAnonymous()){ 
			PatternControl patControl = new PatternControl(myOnto, classHier, propHier, filler2.asOWLClass());
			partialJusts = patControl.findMUPS();		
			hasUnsatConcept = true;
		}
		// If both fillers are satisfiable, then we check whether two fillers are disjoint.
		if(!hasUnsatConcept){
			HashSet<HashSet<Vector<OWLClassExpression>>> newJusts = new HashSet<HashSet<Vector<OWLClassExpression>>>();
			// Check whether the two fillers are disjoint
			// If the return values are not empty, it shows the two fillers are indeed disjoint.			
			HashSet<Vector<OWLClass>> disjPairs = myOnto.getDisjointRelations().findDisjRelations(classHier, filler1, filler2);
			// If the two fillers are disjoint, it shows that a pattern is recognized.
			if(disjPairs == null || disjPairs.size() == 0){
				return partialJusts;
			}
			// Compute partial conflicts from two fillers to the classes in a disjointness axiom.							
			for(Vector<OWLClass> disjPair : disjPairs){	
				//OWLAxiom disjAxiom = OWL.disjointClasses(disjPair.get(0), disjPair.get(1));
				HashSet<HashSet<Vector<OWLClassExpression>>> partialJusts1  = new HashSet<HashSet<Vector<OWLClassExpression>>>();
				HashSet<Vector<OWLClassExpression>> just = new HashSet<Vector<OWLClassExpression>>();
				just.add(new Vector<OWLClassExpression>(disjPair));
				partialJusts1.add(just);
								
				// Qiu Ji 2012.11.16
				FindPath findPath = new FindPath(classHier.getClassHierarchy());
				HashSet<HashSet<Vector<OWLClassExpression>>> partialJusts2 =  findPath.findPathPairs(
						filler1, disjPair.get(0).asOWLClass(), 
						filler2, disjPair.get(1).asOWLClass());				
				partialJusts1 = PatternUtils.combinePartialPaths(partialJusts1, partialJusts2);
				if(partialJusts1 != null && partialJusts1.size() > 0){
					newJusts.addAll(partialJusts1);
				}
				if(RelevanceParameters.conflictSetsNumLimit != -1 && 
						newJusts.size() >= RelevanceParameters.conflictSetsNumLimit){
					break;
				}
			}		
			// transfer paths to logical axioms
			HashSet<HashSet<OWLAxiom>> logicConflicts = PatternUtils.transferConflicts(
					newJusts, classHier, myOnto);
			HashSet<HashSet<OWLAxiom>> conflicts = PatternUtils.getMinimalSets(logicConflicts);
			partialJusts = PatternUtils.combinePartialJusts(partialJusts, conflicts);
		}		
	    return partialJusts;
	}

}
