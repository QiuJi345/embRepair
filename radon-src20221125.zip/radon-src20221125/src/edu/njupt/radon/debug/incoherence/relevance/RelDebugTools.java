package edu.njupt.radon.debug.incoherence.relevance;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

public class RelDebugTools {
	

	OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
	OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
	
	public boolean isCoherent(HashSet<OWLAxiom> axioms) {
		boolean isCoh = true;
		
		OWLOntology onto = this.createOntology(axioms);	   		
		OWLDataFactory factory = manager.getOWLDataFactory();
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		OWLReasoner owlReasoner = reasonerFactory.createReasoner(onto);
		
		for (OWLClass oc : onto.getClassesInSignature()) {
			if (oc.equals(factory.getOWLNothing())) {
				isCoh =  false;
				break;
			} else if (!owlReasoner.isSatisfiable(oc)) {
				isCoh =  false;
				break;
			}
		}
		owlReasoner.dispose();
		manager.removeOntology(onto);
		// 娴嬭瘯鐢�
		//System.out.println(uncon);
		return isCoh;
	}
	
	public HashSet<OWLClass> getUnsatiConcepts(HashSet<OWLAxiom> axioms) {
		HashSet<OWLClass> uncon = new HashSet<OWLClass>();
		OWLOntology onto = this.createOntology(axioms);	   
		
		OWLDataFactory factory = manager.getOWLDataFactory();
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		OWLReasoner owlReasoner = reasonerFactory.createReasoner(onto);
		
		for (OWLClass oc : onto.getClassesInSignature()) {
			if (oc.equals(factory.getOWLNothing()) || oc.equals(factory.getOWLThing())) {
				continue;
			}
			boolean f = true;
			if (onto.containsClassInSignature(oc.getIRI())) {
				f = owlReasoner.isSatisfiable(oc);
			}
			if (!f) {
				uncon.add(oc);
			}
		}
		owlReasoner.dispose();
		manager.removeOntology(onto);
		// 娴嬭瘯鐢�
		//System.out.println(uncon);
		return uncon;
	}

	
	/**
	 * Check whether the given concept is satisfiable or not in the given axioms by removing the axioms in path.
	 * 
	 * @param axioms
	 * @param unsatConcept
	 * @param path
	 * @return
	 */
	public boolean isSatisfiable(HashSet<OWLAxiom> axioms, OWLClass unsatConcept, Vector<OWLAxiom> path){		
		axioms.removeAll(path);
		boolean flag = this.isSatisfiable(axioms,unsatConcept);		
		axioms.addAll(path);
		return flag;
	}
	
	
	public boolean isSatisfiable(HashSet<OWLAxiom> axioms, OWLClass concept) {
		boolean isSat = true;
	    OWLOntology onto = this.createOntology(axioms);	    
	    OWLReasoner owlReasoner = reasonerFactory.createReasoner(onto);
	    if(onto.containsClassInSignature(concept.getIRI())){
			isSat = owlReasoner.isSatisfiable(concept);
		}
		owlReasoner.dispose();
	    manager.removeOntology(onto);
	    return isSat;
	}
		
	public OWLOntology createOntology(HashSet<OWLAxiom> axioms) {
		OWLOntology ont = null;
		try {
			ont = manager.createOntology(axioms);
		} catch(Exception ex) {
			System.err.println("Fail to craete a new ontology");
		}
		return ont;
	}

}
