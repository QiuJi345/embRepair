package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.heuristic.PatternUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindPath;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceParameters;
import edu.njupt.radon.utils.CommonTools;

public class PatternIsaDisjoint implements DebuggingPattern {	
	OntologyInfo myOnto ;
	ClassHierarchy classHier ;
	OWLClass uc ;
	
	public PatternIsaDisjoint(OntologyInfo myOnto, 
			ClassHierarchy hier,
			OWLClass unsatConcept){
		this.myOnto = myOnto;	
		this.classHier = hier;
		this.uc = unsatConcept;
	}
	
	public HashSet<HashSet<OWLAxiom>> findMUPS(){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();					
		// Find those disjointness axioms which are included in conflict sets of an unsatisfiable concept.				
		HashSet<Vector<OWLClass>> disjAxioms = myOnto.getDisjointRelations().findDisjRelations(classHier, uc, uc);				
		// For each found disjointness axiom, we compute all related conflict sets w.r.t. uc.
		//DisjointRelatedDebug disjDebug = new DisjointRelatedDebug(axiomsInOnto, hier);
		FindPath findPath = new FindPath(classHier.getClassHierarchy());
		for(Vector<OWLClass> disjAxiom : disjAxioms){
			System.out.println("    [Info] Problematic disjoint axiom: "+disjAxiom.toString());
			// Compute conflicts
			HashSet<HashSet<Vector<OWLClassExpression>>> novelPaths = findPath.findPathPairs(
					uc, disjAxiom.get(0).asOWLClass(), uc, disjAxiom.get(1).asOWLClass());
			
			//transfer paths to axioms
			HashSet<HashSet<OWLAxiom>> conflicts = PatternUtils.transferConflicts(
					novelPaths, classHier, myOnto);
			//HashSet<HashSet<OWLAxiom>> conflicts = PatternUtils.getMinimalSets(logicConflicts);
			
			if(conflicts != null && conflicts.size() > 0){
				OWLAxiom axiom = OWL.disjointClasses(disjAxiom.get(0), disjAxiom.get(1));
				for(HashSet<OWLAxiom> conf : conflicts){
					conf.add(axiom);
					allConflicts.add(new HashSet<OWLAxiom>(conf));					
				}
				// Output conflicts
				CommonTools.printMultiSets(conflicts, null);
				// Check 
				System.out.println("    [Info] All conflict sets = "+allConflicts.size()+
						", newly found conflict sets = "+conflicts.size());
				//PatternUtils.check(conflicts, uc);
			} else {
				System.out.println("      [Number] No conflict sets are found!");
			}
			
			if(RelevanceParameters.conflictSetsNumLimit != -1 && 
					conflicts.size() >= RelevanceParameters.conflictSetsNumLimit){
				return conflicts;
			}
		}	
		return allConflicts;
	}
	
    public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();		
		// For the disjointness axiom, we compute all related conflict sets w.r.t. uc.
		FindPath findPath = new FindPath(classHier.getClassHierarchy());
		System.out.println("  [Info] Problematic disjoint axiom: "+disjAxiom.toString());
		// Compute conflicts
		Vector<OWLClass> disjConcepts = new Vector<OWLClass>(disjAxiom.getClassesInSignature());
		HashSet<HashSet<Vector<OWLClassExpression>>> novelPaths = findPath.findPathPairs(
				uc, disjConcepts.get(0).asOWLClass(), uc, disjConcepts.get(1).asOWLClass());
		
		// transfer paths to axioms
		HashSet<HashSet<OWLAxiom>> logicConflicts = PatternUtils.transferConflicts(
				novelPaths, classHier, myOnto);
		HashSet<HashSet<OWLAxiom>> conflicts = PatternUtils.getMinimalSets(logicConflicts);
		
		System.out.println("found conflicts number: "+conflicts.size());
		
		if(conflicts != null && conflicts.size() > 0){
			OWLAxiom axiom = OWL.disjointClasses(disjConcepts.get(0), disjConcepts.get(1));
			for(HashSet<OWLAxiom> conf : conflicts){
				conf.add(axiom);
				allConflicts.add(new HashSet<OWLAxiom>(conf));
			}
		}	
		return allConflicts;
	}

}
