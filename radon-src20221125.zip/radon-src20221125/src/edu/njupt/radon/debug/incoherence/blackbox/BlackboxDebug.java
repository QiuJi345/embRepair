package edu.njupt.radon.debug.incoherence.blackbox;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.Timer;
import edu.njupt.radon.utils.reasoning.DebugTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * This class is to compute all MUPS for an unsatisfiable concept by using black-box approach.
 * 
 * @author QiuJi
 * @modified 2018.11.1
 */
public class BlackboxDebug implements RadonDebug {	
	
	public static int mupsNum = 0;
	
	private static int mupsNumLimit = 100;
	
	
	// The set of axioms to be debugged
	private HashSet<OWLAxiom> debuggingAxioms;
	// All MUPS for an unsatisfiable concept
	private HashSet<HashSet<OWLAxiom>> ucAllMUPS;	
	// The class to compute a single MUPS
	private BlackboxForOneMUPS computeOneMUPS = null; 
	private HashMap<Integer, HashSet<Vector<OWLAxiom>>> stratifiedHS;
	
	private Timer timerForReuse;
	private Timer timerForEarlyPathCheck;
	private long debugTime = 0;
	
	
	OWLOntology ont=null;
	
	
	public BlackboxDebug(OWLOntology ont){
		this.ont = ont;
		this.ini(new HashSet<OWLAxiom>(ont.getAxioms()));
	}
		
	public BlackboxDebug(HashSet<OWLAxiom> axioms){
		this.ini(axioms);
	}

	private void ini(HashSet<OWLAxiom> axioms) {
		debuggingAxioms = new HashSet<OWLAxiom>(axioms);		
		computeOneMUPS = new BlackboxForOneMUPS(axioms);				
		ucAllMUPS = new HashSet<HashSet<OWLAxiom>>();
		//hittingSets.clear();
		computeOneMUPS.resetMUPSCounter();
		stratifiedHS = new HashMap<Integer, HashSet<Vector<OWLAxiom>>>();
		
		timerForReuse = new Timer();
		timerForEarlyPathCheck = new Timer();
		mupsNum = 0;
	}

    /**
     * Compute all MUPS for all unsatisfiable concepts in the debugging axioms.
     * 
     * @return All MUPS for all unsatisfiable concepts.
     */
	public HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS() {
		// All MUPS of each unsatisfiable concept in an ontology
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		boolean coherent = ReasoningTools.isCoherent(debuggingAxioms);	
		//OWLTools.printOWLAxioms(o);
		if(coherent){	
			System.out.println("This ontology is coherent.");
			return allMUPS;
		}
		
		HashSet<OWLClass> unsatConcepts = ReasoningTools.getUnsatiConcepts(debuggingAxioms);
		System.out.println("The number of unsatisfiable concepts is "+unsatConcepts.size());
		HashSet<HashSet<OWLAxiom>> ucMUPS = null;
		//HashSet<OWLClass> roots = DebugTools.getRootUcs(unsatConcepts, ont);
		
		int i = 1;
		for (OWLClass unsatConcept : unsatConcepts) {	
			String s = unsatConcept.toString();
			System.out.println((i++)+"> Unsati concept : "+s);
			/*if(!s.contains("DerivedUC_")) {
				continue;
			}*/
						
			ucMUPS = this.getMUPS(unsatConcept);		
					
			if (ucMUPS!=null && ucMUPS.size()>0) {
				allMUPS.put(unsatConcept, new HashSet<HashSet<OWLAxiom>>(ucMUPS));
			}
		}
		
		System.out.println("** Time to compute all MUPS for all Ucs: "+debugTime);
		return allMUPS;
	}
	
	public HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS(HashSet<String> ucUris) {
		// All MUPS of each unsatisfiable concept in an ontology
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		boolean coherent = ReasoningTools.isCoherent(debuggingAxioms);	
		//OWLTools.printOWLAxioms(o);
		if(coherent){	
			System.out.println("This ontology is coherent.");
			return allMUPS;
		}
		
		HashSet<OWLClass> unsatConcepts = ReasoningTools.getUnsatiConcepts(debuggingAxioms);
		System.out.println("The number of unsatisfiable concepts is "+unsatConcepts.size());
		HashSet<HashSet<OWLAxiom>> ucMUPS = null;
		//HashSet<OWLClass> roots = DebugTools.getRootUcs(unsatConcepts, ont);
		
		int i = 1;
		for (OWLClass unsatConcept : unsatConcepts) {	
			String s = unsatConcept.toString();
			System.out.println((i++)+"> Unsati concept : "+s);
			
			if(ucUris.contains(s)) {
				System.out.println("    This uc has been debugged.");
				continue;
			}
			
			ucMUPS = this.getMUPS(unsatConcept);		
					
			if (ucMUPS!=null && ucMUPS.size()>0) {
				allMUPS.put(unsatConcept, new HashSet<HashSet<OWLAxiom>>(ucMUPS));
			}
		}
		
		System.out.println("** Time to compute all MUPS for all Ucs: "+debugTime);
		return allMUPS;
	}
	
	/**
	 * Compute all MUPS for a specified unsatisfiable concept.
	 * 
	 * @param unsatConcept The unsatisfiable concept to be debugged.
	 * @return All MUPS found by the method.
	 */
	public HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass unsatConcept) {		
		return this.getMUPS(unsatConcept, null);
	}
		
	/**
	 * Compute all MUPS for a specified unsatisfiable concept based on the existing MUPS.
	 * 
	 * @param unsatConcept
	 * @param foundMUPS
	 * @return
	 */
	public HashSet<HashSet<OWLAxiom>> getMUPS(
			OWLClass unsatConcept, 
			HashSet<HashSet<OWLAxiom>> foundMUPS)  {
		mupsNum = 0;
		// Reuse the existing MUPS
		if (foundMUPS != null && foundMUPS.size()>0) {			
			ucAllMUPS.addAll(foundMUPS);
			mupsNum = foundMUPS.size();
		}
		computeOneMUPS.resetMUPSCounter();
		ucAllMUPS.clear();	
		
		HashSet<OWLAxiom> debuggingAxioms_c = new HashSet<OWLAxiom>(debuggingAxioms);	
		long st = System.currentTimeMillis();
		computeMUPSDFS(unsatConcept, debuggingAxioms_c);	
		
		/*Timer timerForReasoning = computeOneMUPS.getTimerForReasoning();
		Timer timerForSingleMUPS = computeOneMUPS.getTimerForSingleMUPS();
		Timer timerForTerminationCheck = computeOneMUPS.getTimerForTerminationCheck();*/
		/*System.out.println("Time (ms) and times for reasoning when computing single MUPS: "+
				timerForReasoning.getTotal()+", "+timerForReasoning.getCount());
		System.out.println("Time (ms) and times to compute single MUPS: "+
				timerForSingleMUPS.getTotal()+", "+timerForSingleMUPS.getCount());
		System.out.println("Time (ms) and times to check whether a path need to be terminated: "+
				timerForTerminationCheck.getTotal()+", "+timerForTerminationCheck.getCount());
		System.out.println("Time (ms) and times to reuse MUPS: "+
				timerForReuse.getTotal()+", "+timerForReuse.getCount());
		System.out.println("Time (ms) and times to early path checking: "+
				timerForEarlyPathCheck.getTotal()+", "+timerForEarlyPathCheck.getCount());*/
		long ucDebugTime = System.currentTimeMillis() - st;
		debugTime += ucDebugTime;
		System.out.println("* The time (ms) to compute all MUPS for the unsatisfiable concept is: "+ucDebugTime+"\n");
		
		return ucAllMUPS;
	}
	
	
    /**
     * Compute all MUPS for a specified unsatisfiable concept 
     * by considering some MUPS of unsatConcept which have been found.
     * 
     * @param unsatConcept The unsatisfiable concept to be debugged.
     * @param foundMUPS Assume these MUPS are w.r.t. unsatConcept 
     * @return All MUPS found by the method.
     */
	public void computeMUPSDFS(
			OWLClass unsatConcept, 
			HashSet<OWLAxiom> debuggingAxioms)  {
		mupsNum = 0;
		HashSet<OWLAxiom> singleJust = null;		
		// Reuse the existing MUPS
		if (ucAllMUPS.size() > 0) {
			singleJust = ucAllMUPS.iterator().next();
		}
		
		// If no MUPS can be reused, then compute one MUPS.
		if(singleJust==null){
			singleJust = computeOneMUPS.getOneMUPS(unsatConcept);			
		}
		
		// If a new MUPS has been discovered, then begin to construct the hitting set tree.
		if (singleJust != null && singleJust.size()>0) {
			ucAllMUPS.add(new HashSet<OWLAxiom>(singleJust));	           
			for (OWLAxiom axiom : singleJust) {
				Vector<OWLAxiom> path = new Vector<OWLAxiom>();
				debuggingAxioms.remove(axiom);
				computeOneMUPS.removeAxiom(axiom);
				depthFirstSearchHST(unsatConcept, debuggingAxioms, axiom, path);				
				debuggingAxioms.add(axiom);
				computeOneMUPS.addAxiom(axiom);
			}
		}	
	}
		
	/**
	 * This method is similar to that in Bijan's ISWC'07 paper
	 * 
	 * @param unsatConcept
	 * @param currentDebuggingAxioms
	 * @param currentBranchAxiom
	 * @param path
	 */
	private void depthFirstSearchHST(OWLClass unsatConcept, 
			HashSet<OWLAxiom> currentDebuggingAxioms, 
			OWLAxiom currentBranchAxiom,
			Vector<OWLAxiom> path) {
		
		HashSet<OWLAxiom> currentDebuggingAxioms_c = new HashSet<OWLAxiom>(currentDebuggingAxioms);		
		Vector<OWLAxiom> newPath = new Vector<OWLAxiom>(path);
		newPath.add(currentBranchAxiom);
		
		// Reuse existing MUPS
		HashSet<OWLAxiom> newJust = getNonIntersectingMUPS(newPath);		
		// No MUPS can be reused
		if(newJust == null){
			//Early path termination		
			if(this.canBeTerminated(newPath)){
				return;
			}	
			// Compute a new MUPS
			newJust = computeOneMUPS.getOneMUPS(unsatConcept);	
		}
			
		//If a MUPS is newly found, then it further expand the hitting set tree.
		if (newJust != null && newJust.size() > 0) {
			ucAllMUPS.add(new HashSet<OWLAxiom>(newJust));
			 if(mupsNum >= mupsNumLimit) {
					return;
				}
			for (OWLAxiom newBranchAxiom : newJust) {
				currentDebuggingAxioms_c.remove(newBranchAxiom);
				computeOneMUPS.removeAxiom(newBranchAxiom);
				depthFirstSearchHST(unsatConcept, currentDebuggingAxioms_c, newBranchAxiom, newPath); 
				currentDebuggingAxioms_c.add(newBranchAxiom);
				computeOneMUPS.addAxiom(newBranchAxiom);
			}
		}		  		
	}
	
	
	private boolean canBeTerminated(Vector<OWLAxiom> path){
		// Early path termination
		timerForEarlyPathCheck.start();			
		int pathLength = path.size();
		for(int hsLength : stratifiedHS.keySet()){
			// If the size of the path is not larger than that of a hitting set,
			// then this path must not contain all elements in the hitting set.
			if(pathLength < hsLength){
				continue;
			}
			for(Vector<OWLAxiom> hs : stratifiedHS.get(hsLength)) {			
				if(path.containsAll(hs)) { 
					timerForEarlyPathCheck.stop();
					return true;
				}
			}
		}
		timerForEarlyPathCheck.stop();
		return false;
	}
	
	
	private HashSet<OWLAxiom> getNonIntersectingMUPS(Vector<OWLAxiom> path){
		//Justification reuse
		timerForReuse.start();
		for (HashSet<OWLAxiom> oneMUPS : ucAllMUPS ){
			if (!CommonTools.hasIntersection(oneMUPS, path)){
				timerForReuse.stop();
				return oneMUPS;
			}
		}
		timerForReuse.stop();
		return null;
	}
		
	public HashSet<Vector<OWLAxiom>> getHittingSets(){
		HashSet<Vector<OWLAxiom>> hittingSets = new HashSet<Vector<OWLAxiom>>();
		for(int length : stratifiedHS.keySet()){
			hittingSets.addAll(stratifiedHS.get(length));
		}
		return hittingSets; 	
	}
		
	public static void setMUPSNumLimit(int num) {
		mupsNumLimit = num;
	}

}

