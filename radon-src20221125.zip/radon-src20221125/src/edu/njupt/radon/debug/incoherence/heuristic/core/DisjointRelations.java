package edu.njupt.radon.debug.incoherence.heuristic.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;


public class DisjointRelations {
		
	Set<OWLDisjointClassesAxiom> disjAxioms = null;
	/** All disjointness relations in the given set of axioms. */
	private HashMap<OWLClass, HashSet<OWLClass>> disjointClassesMap = 
		new HashMap<OWLClass, HashSet<OWLClass>>();
	/** The mapping between a pair of concepts and the corresponding OWLDisjointClassesAxiom. */
	private HashMap<Vector<OWLClass>, OWLDisjointClassesAxiom> disjointAxiomsMap = 
		new HashMap<Vector<OWLClass>, OWLDisjointClassesAxiom>();
		
	public DisjointRelations(Set<OWLDisjointClassesAxiom> disjAxioms){
		this.disjAxioms = new HashSet<OWLDisjointClassesAxiom>(disjAxioms);
		this.computeDisjointClassesMap();
	}
	
	private void computeDisjointClassesMap(){		
		// Iterate on all axioms to compute the disjointness relations.
		for(OWLDisjointClassesAxiom disjAxiom : disjAxioms){
			OWLClass oneClass = null;
			OWLClass anotherClass = null;
			// Obtain two atomic and named classes in the disjointness axiom.
			for(OWLClass oc : disjAxiom.getClassesInSignature()){
				if(!oc.isAnonymous()){
					if(oneClass == null){
						oneClass = oc;
					} else {
						anotherClass = oc;
					}
				}
			}	
			// If there are two atomic classes which are disjoint, we add this pair to the relation.
			if(oneClass!=null && anotherClass!=null){
				// Consider both directions of a disjointness relation.
				addDisjointRelation(disjAxiom, oneClass, anotherClass);
				addDisjointRelation(disjAxiom, anotherClass, oneClass);
				
			} else {
				System.err.println("Can not transfer a disjoint axiom to a pair of classes.");
			}		
		}
	}		

	/**
	 * Find those disjointness axioms which make oc1 is disjoint with oc2.
	 * If oc1 equals to oc2, then this method finds those disjointness axioms
	 * which make oc1 / oc2 unsatisfiable. These found disjointness axioms
	 * are the closest to input classes. That is, 
	 * 
	 * @param oc1
	 * @param oc2
	 * @return
	 */
	/*public HashSet<Vector<OWLClass>> findClosestDisjPairs(
			OWLClass oc1, OWLClass oc2){		
		
		HashSet<Vector<OWLClass>> disjPairs = new HashSet<Vector<OWLClass>>();
		// Check whether oc1 disjointWith oc2 is specifically defined in the ontology.
		if(disjointClassesMap.containsKey(oc1) && disjointClassesMap.get(oc1).contains(oc2)){
			Vector<OWLClass> pair = MyUtils.createPair(oc1, oc2);
			disjPairs.add(pair);			
		} else if(disjointClassesMap.containsKey(oc2) && disjointClassesMap.get(oc2).contains(oc1)){
			// Check whether oc2 disjointWith oc1 is specifically defined in the ontology.
			Vector<OWLClass> pair = MyUtils.createPair(oc2, oc1);
			disjPairs.add(pair);	
		} else {
			disjPairs = this.findClosestUndirectDisjPairs(oc1, oc2);
		}		a
		return disjPairs;
	}*/
	
	
	public HashSet<Vector<OWLClass>> findDisjRelations(
			ClassHierarchy classHierarchy,
			OWLClassExpression oc1, OWLClassExpression oc2){
				
		// Obtain all super classes of oc1
		HashSet<OWLClassExpression> superClasses1 = classHierarchy.getAllSuperClasses(oc1);	
		// Obtain all super classes of oc2
		HashSet<OWLClassExpression> superClasses2 = classHierarchy.getAllSuperClasses(oc2);
					
		// If oc1 is not declared to be disjoint with oc2 explicitly, 
		// then we check whether there is some disjointness relation between their superclasses.		
		HashSet<Vector<OWLClass>> problematicDisjPairs = new HashSet<Vector<OWLClass>>();
		for(OWLClassExpression super1 : superClasses1){
			for(OWLClassExpression super2 : superClasses2){
				// If both super classes are the same, then ignore this pair 
				// since this case does not exist in the real ontologies.
				if(super1 == super2){
					continue;
				}
				OWLClass atomicSuper1 = MyUtils.getOWLClass(super1);
				OWLClass atomicSuper2 = MyUtils.getOWLClass(super2);
				if(atomicSuper1 != null && atomicSuper2 != null){
					if(disjointClassesMap.containsKey(atomicSuper1)){
						if(disjointClassesMap.get(atomicSuper1).contains(atomicSuper2)){
							this.addDisjointPair(problematicDisjPairs, oc1, oc2, atomicSuper1, atomicSuper2);						
						}
					}	
				}		
			}
		}		
		return problematicDisjPairs;
	}

	private void addDisjointPair(
			HashSet<Vector<OWLClass>> disjointPairs,
			OWLClassExpression oc1,
			OWLClassExpression oc2,
			OWLClass disjOc1,
			OWLClass disjOc2){
		
		Vector<OWLClass> pair = MyUtils.createPair(disjOc1, disjOc2);
		if(!disjointPairs.contains(pair)){
			if(oc1 == oc2){
				pair = MyUtils.createPair(disjOc2, disjOc1);
				if(!disjointPairs.contains(pair)){
					disjointPairs.add(new Vector<OWLClass>(pair));
				}
			} else {
				disjointPairs.add(new Vector<OWLClass>(pair));	
			}
		}		
	}
		
	private void addDisjointRelation(
			OWLDisjointClassesAxiom disjAxiom,
			OWLClass oneC, 
			OWLClass anotherC){
		
		if(disjointClassesMap.containsKey(oneC)){
			disjointClassesMap.get(oneC).add(anotherC);
		} else {
			HashSet<OWLClass> classes = new HashSet<OWLClass>();
			classes.add(anotherC);
			disjointClassesMap.put(oneC, classes);
		}		
		// Create a mapping between a pair of owlclass and a disjointness axiom.
		Vector<OWLClass> pair = new Vector<OWLClass>();
		pair.add(oneC);
		pair.add(anotherC);
		disjointAxiomsMap.put(new Vector<OWLClass>(pair), disjAxiom);		
	}
	

	public HashMap<OWLClass, HashSet<OWLClass>> getDisjointClassesMap(){
		return this.disjointClassesMap;
	}
	
	public HashMap<Vector<OWLClass>, OWLDisjointClassesAxiom> getDisjointAxiomsMap(){
		return this.disjointAxiomsMap;
	} 
	
	public HashSet<OWLClass> getDisjointClasses(OWLClass oc){
		HashSet<OWLClass> disjClasses = this.disjointClassesMap.get(oc);
		return disjClasses;
	} 
	
	public void printDisjointRelations(){
		System.out.println("***** Disjoint Relations  ********");
		for(OWLClass oc : disjointClassesMap.keySet()){
			System.out.println(oc.toString());
			for(OWLClass disjOc : disjointClassesMap.get(oc)){
				System.out.println("    "+disjOc.toString());
			}
		}
		System.out.println("***************************\n");	
	}
}
