package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLEntity;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.PatternControl;
import edu.njupt.radon.debug.incoherence.heuristic.PatternUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindPath;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindRolePath;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceParameters;

public class ExpandDomRan {	
	OntologyInfo myOnto = null;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc = null;
	
	public ExpandDomRan(OntologyInfo myOnto, 
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass unsatConcept){
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = unsatConcept;
	}
	
	public HashSet<HashSet<OWLAxiom>> findPatternOfDomain(
			OWLClass unsatConcept, 
			OWLClass subC,
			OWLClassExpression condition,
			OWLEntity opInCond){
		
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();		
		// Obtain all super properties of opInCond
		HashSet<OWLEntity> superOps = propHier.getSuperProperties(opInCond);	
		// For each super property, check whether there is problematic axiom with range.
		for(OWLEntity superOp : superOps){
			if(!myOnto.getPropertyDomains().containsKey(superOp)){
				continue;
			}
			for(OWLClassExpression domain : myOnto.getPropertyDomains().get(superOp)){
				/** Meet a circle. */
				if(domain.equals(subC)){
					continue;
				}
				/** Consider the first part of a conflict. */
				//HashSet<HashSet<OWLAxiom>> partialJusts1 = this.findJustsForDisjRelation(uc, domain);
				
				// Compute justifications which may consist of at most three parts.
				HashSet<HashSet<OWLAxiom>> partialJusts1 = null;
				boolean hasUnsatConcept = false;						
				// If one filler is unsatisfiable, then find out the corresponding justifications.
				if(myOnto.getUCsInOriginalOnto().contains(unsatConcept) && domain.equals(OWL.Thing) 
						&& !unsatConcept.isAnonymous()){			
					PatternControl patControl = new PatternControl(myOnto, classHier, propHier, unsatConcept.asOWLClass());
					partialJusts1 = patControl.findMUPS();							
					hasUnsatConcept = true;
				} 
				if(unsatConcept.equals(OWL.Thing) &&  myOnto.getUCsInOriginalOnto().contains(domain) 
						&& !domain.isAnonymous()){ 
					PatternControl patControl = new PatternControl(myOnto, classHier, propHier, domain.asOWLClass());
					partialJusts1 = patControl.findMUPS();		
					hasUnsatConcept = true;
				}
				// If both fillers are satisfiable, then we check whether two fillers are disjoint.
				if(!hasUnsatConcept){
					// Check whether the two fillers are disjoint
					// If the return values are not empty, it shows the two fillers are indeed disjoint.
					
					HashSet<Vector<OWLClass>> disjPairs = myOnto.getDisjointRelations().findDisjRelations(classHier,
							unsatConcept, domain);
					// Compute partial conflicts from two fillers to the classes in a disjointness axiom.							
					for(Vector<OWLClass> disjPair : disjPairs){								
						// Combine the edges to be expanded.
						HashSet<Vector<OWLClassExpression>> pairs = new HashSet<Vector<OWLClassExpression>>();
						MyUtils.addPair(pairs, unsatConcept, subC);
						MyUtils.addPair(pairs, unsatConcept, disjPair.get(0));
						MyUtils.addPair(pairs, domain, disjPair.get(1));
						
						// Expand each edge and combine the expanded parts.
						FindPath findPath = new FindPath(classHier.getClassHierarchy());
						HashSet<HashSet<Vector<OWLClassExpression>>> combinedPs = findPath.findPaths(pairs, findPath);
						if(combinedPs.size() == 0){
							continue;
						}
						// Transfer each path to logical axioms.
						HashSet<HashSet<OWLAxiom>> logicConflicts = PatternUtils.transferConflicts(
								combinedPs, classHier, myOnto);
						// Obtain minimal sets of axioms.
						partialJusts1 = PatternUtils.getMinimalSets(logicConflicts);
						// Add disjointness axiom to each set.
						OWLAxiom disjAxiom = OWL.disjointClasses(disjPair.get(0), disjPair.get(1));
						partialJusts1 = MyUtils.addAxiomToSet(partialJusts1, disjAxiom);
					}							
				}		
				
				if(partialJusts1 != null && partialJusts1.size()>0){
					/** Consider the second part of a conflict. */
					FindRolePath findRolePath = new FindRolePath(propHier);
				    HashSet<HashSet<Vector<OWLEntity>>> ps2 = findRolePath.findPaths(opInCond, superOp);
				    // Transfer each path to logical axioms.
				    HashSet<HashSet<OWLAxiom>> partialJusts2 = PatternUtils.translatePaths(
				    		ps2, propHier);
					
					/** Consider the third part of a conflict. */
					// Obtain the axiom with cardinality condition
					Vector<OWLClassExpression> pair1 = MyUtils.createPair(subC, condition);
					OWLAxiom axiom1 = myOnto.getPairAxiomMap().get(pair1);
					// Obtain the axiom with domain restriction
					Vector<Object> pair2 = MyUtils.createPair(superOp, domain);
					HashSet<HashSet<OWLAxiom>> justs = myOnto.getPropertyAxiomMap().get(pair2);
					// Add axioms to each conflict.
					for(HashSet<OWLAxiom> just1 : partialJusts1){
						for(HashSet<OWLAxiom> just2 : partialJusts2){
							for(HashSet<OWLAxiom> just3 : justs){
								HashSet<OWLAxiom> oneJust = new HashSet<OWLAxiom>(just1);
								oneJust.addAll(just2);
								oneJust.addAll(just3);
								oneJust.add(axiom1);								
								conflicts.add(new HashSet<OWLAxiom>(oneJust));
								//MyUtils.printOneConflict(oneJust);
								//System.out.println("Real? "+InconsistencyTools.isMUPSReal(oneJust, uc));
							}
							
						}
					}
				}	
			}
		}
		return conflicts;	
	}
	
	public HashSet<HashSet<OWLAxiom>> findPatternOfRange(
			OWLClass subC,
			OWLClassExpression condition,
			OWLEntity opInCond, 
			OWLClass filler){
		// All conflict sets
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		
		// Obtain all super properties of opInCond
		HashSet<OWLEntity> superOps = propHier.getSuperProperties(opInCond);	
		// For each super property, check whether there is problematic axiom with range.
		for(OWLEntity superOp : superOps){
			if(!myOnto.getPropertyRanges().containsKey(superOp)){
				continue;
			}
			for(OWLClass range : myOnto.getPropertyRanges().get(superOp)){
				// In such cases, this pattern becomes some-bottom pattern.
				if(filler == null || range == null){
					System.out.println("stop");					
				}
				if(filler.equals(range) || (myOnto.getUCsInOriginalOnto().contains(filler) 
						&& !myOnto.getUCsInOriginalOnto().contains(range))){
					continue;
				}				
				// The conflict sets found according to one specific range
				HashSet<HashSet<OWLAxiom>> conflicts2 = this.computeJusts(subC, condition, filler, opInCond, superOp, range);				
				// Add the conflict sets according to one specific range to the set of all conflict sets
				if(conflicts2 != null && conflicts2.size() > 0){
					conflicts.addAll(conflicts2);
				}
				// Terminate the loop according to the specified number restriction
				if(RelevanceParameters.conflictSetsNumLimit != -1 && 
						conflicts.size() >= RelevanceParameters.conflictSetsNumLimit){
					return conflicts;
				}
			}
		}
		return conflicts;	
	}
	
	public HashSet<HashSet<OWLAxiom>> computeJusts(
			OWLClass subC,
			OWLClassExpression condition,
			OWLClass filler,
			OWLEntity opInCond, 
			OWLEntity superOp,			
			OWLClass range){
		
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> partialJusts1 = null;
		if(myOnto.getUCsInOriginalOnto().contains(range)){
			// Consider the first part of a conflict: if the range is unsatisfiable then compute its MUPS
			PatternControl patControl = new PatternControl(myOnto, classHier, propHier, range);
			partialJusts1 = patControl.findMUPS();
		} else {
			// Consider the first part of a conflict: whether a filler is disjoint with a range
			ExpandDisjRelations expand = new ExpandDisjRelations(myOnto, classHier,propHier,  uc);		
			partialJusts1 = expand.findJustsForDisjRelation(filler, range);
		}		
		
		if(partialJusts1 != null && partialJusts1.size()>0){
			// Consider the second part of a conflict: the path between the original uc and a superclass
			// and the path between the property in an existential condition and a super-property.
			HashSet<HashSet<OWLAxiom>> partialJusts2 = findPathPairs(uc, subC, opInCond, superOp);
			if(partialJusts2 != null && partialJusts2.size()>0){
				partialJusts2 = PatternUtils.combinePartialJusts(partialJusts1, partialJusts2);
				
				/** Consider the third part of a conflict. */
				// Obtain the axiom with someValuesFrom
				Vector<OWLClassExpression> pair1 = MyUtils.createPair(subC, condition);
				OWLAxiom axiom1 = myOnto.getPairAxiomMap().get(pair1);
				// Obtain the axiom with allValuesFrom
				Vector<OWLEntity> pair2 = new Vector<OWLEntity>();
				pair2.add(superOp);
				pair2.add(range);
				HashSet<HashSet<OWLAxiom>> justs = myOnto.getPropertyAxiomMap().get(pair2);
				// Add axioms to each conflict.
				for(HashSet<OWLAxiom> just1 : justs){
					for(HashSet<OWLAxiom> just : partialJusts2){
						HashSet<OWLAxiom> oneJust = new HashSet<OWLAxiom>();
						oneJust.addAll(just);
						oneJust.add(axiom1);
						oneJust.addAll(just1);
						conflicts.add(new HashSet<OWLAxiom>(oneJust));
					}
				}
			}			
		}	
		return conflicts;
	}
	
	private HashSet<HashSet<OWLAxiom>> findPathPairs(
			OWLClass subOc,
			OWLClass supOc,
			OWLEntity subOp,
			OWLEntity supOp){
						
		FindPath findPath = new FindPath(classHier.getClassHierarchy());
		HashSet<HashSet<Vector<OWLClassExpression>>> partialJusts1 = findPath.findPaths(subOc, supOc);
		HashSet<HashSet<OWLAxiom>> logicConflicts1 = PatternUtils.transferConflicts(
				partialJusts1, classHier, myOnto);
		
		FindRolePath findRolePath = new FindRolePath(propHier);
		HashSet<HashSet<Vector<OWLEntity>>> partialJusts2 = findRolePath.findPaths(subOp, supOp);
		HashSet<HashSet<OWLAxiom>> logicConflicts2 = PatternUtils.translatePaths(
				partialJusts2, propHier);
		
		HashSet<HashSet<OWLAxiom>> justs = PatternUtils.combinePartialJusts(logicConflicts1, logicConflicts2);
		return justs;	
	}	

}
