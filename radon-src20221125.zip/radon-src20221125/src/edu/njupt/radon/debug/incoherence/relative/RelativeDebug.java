package edu.njupt.radon.debug.incoherence.relative;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.utils.Timer;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

/**
 * Assume we have two ontologies o1 and o2 where o1 is coherent and the union of the two ontologies is incoherent.
 * This class is to compute mups for an unsatisfiable concept oc from O2 such that oc is unsatisfiable in the union of a mups and o1.
 * This class is original designed for ontology revision work given in ISWC'08.
 * 
 * @author QiuJi
 * @modified 2018.11.01 
 */
public class RelativeDebug implements RadonDebug {
	HashSet<OWLAxiom> allAxioms;
	HashSet<OWLAxiom> incoAxioms;
	Timer testTimer;	
	Timer checkSatTimer ;	
	private HashSet<HashSet<OWLAxiom>> conflicts;
	private HashSet<Vector<OWLAxiom>> hittingSets;
	
	public RelativeDebug(HashSet<OWLAxiom> allAxioms_t,
			HashSet<OWLAxiom> incoAxioms){
		this.allAxioms = allAxioms_t;
		this.incoAxioms = incoAxioms;
		conflicts = new HashSet<HashSet<OWLAxiom>>();
		hittingSets = new HashSet<Vector<OWLAxiom>>();
		testTimer = new Timer();
		checkSatTimer = new Timer();
	}
	
	
	@Override
	public HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS() {
		// All MUPS of each unsatisfiable concept in an ontology
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		boolean coherent = ReasoningTools.isCoherent(allAxioms);	
		//OWLTools.printOWLAxioms(o);
		if(coherent){	
			System.out.println("This ontology is coherent.");
			return allMUPS;
		}
		
		HashSet<OWLClass> unsatConcepts = ReasoningTools.getUnsatiConcepts(allAxioms);
		System.out.println("The number of unsatisfiable concepts is "+unsatConcepts.size());
		HashSet<HashSet<OWLAxiom>> ucMUPS = null;
		
		int i = 0;
		for (OWLClass unsatConcept : unsatConcepts) {				
			System.out.println((i++)+"> concept : "+unsatConcept.toString());
			long st = System.currentTimeMillis();
			ucMUPS = this.getMUPS(unsatConcept);
			System.out.println("The time (ms) to compute all MUPS is: "+(System.currentTimeMillis()-st)+"\n");
					
			if (ucMUPS!=null && ucMUPS.size()>0) {
				allMUPS.put(unsatConcept, (HashSet<HashSet<OWLAxiom>>) ucMUPS);
			}
		}
		return allMUPS;		
	}

	
	/**
	 * Compute all MUPS for a given unsatisfiable concept in incoAxioms
	 * w.r.t. stableAxioms
	 * 
	 * @param oc
	 * @param incoAxioms
	 * @param stableAxioms
	 * @param foundMUPS
	 * @return
	 */
	@Override
	public HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass oc) {
		
		HashSet<OWLAxiom> singleJust = null;
		conflicts.clear();
		hittingSets.clear();
				
		if(singleJust==null){
			singleJust = getSingleJustBlackBox( oc, allAxioms, incoAxioms);
		}
        		        
		testTimer.start();
		if (singleJust != null && singleJust.size()!=0) {
			conflicts.add(singleJust);
			for (OWLAxiom a : singleJust) {
				Vector<OWLAxiom> path = new Vector<OWLAxiom>();
				allAxioms.remove(a);
				testTimer.stop();
				searchHST(oc, allAxioms, incoAxioms, a, path);
				testTimer.start();
				allAxioms.add(a);
			}
		}
		testTimer.stop();

		return new HashSet<HashSet<OWLAxiom>>(conflicts);

	}

	@Override
	public HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass unsatConcept, HashSet<HashSet<OWLAxiom>> foundMUPS) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public HashSet<HashSet<OWLAxiom>> getMIPS(
			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups) {

		HashSet<HashSet<OWLAxiom>> mips = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> mupsUnion = new HashSet<HashSet<OWLAxiom>>();

		testTimer.start();
		for (OWLClass oc : mups.keySet()) {
			mupsUnion.addAll(mups.get(oc));
		}

		mips = this.getMIPS(mupsUnion);
		testTimer.stop();

		return mips;
	}
	
	public HashSet<HashSet<OWLAxiom>> getMIPS(HashSet<HashSet<OWLAxiom>> mupsUnion) {

		HashSet<HashSet<OWLAxiom>> ret = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> allMups = (HashSet<HashSet<OWLAxiom>>) mupsUnion
				.clone();
		HashSet<HashSet<OWLAxiom>> mips = new HashSet<HashSet<OWLAxiom>>();

		for (HashSet<OWLAxiom> v : allMups) {
			boolean min = true;
			for (HashSet<OWLAxiom> c : allMups) {
				if (v.containsAll(c) && !v.equals(c)) {
					min = false;
					break;
				}
			}

			if (min) {
				ret.add(v);
			}
		}
		

		for(HashSet<OWLAxiom> one : ret){
			mips.add((HashSet<OWLAxiom>)one.clone());
		}

		return mips;

	}
	
	private void searchHST(
			OWLClass C, 
			HashSet<OWLAxiom> allAxioms, 
			HashSet<OWLAxiom> incoAxioms, 
			OWLAxiom a,
			Vector<OWLAxiom> path) {
		
		HashSet<OWLAxiom> O = new HashSet<OWLAxiom>(allAxioms);
		HashSet<OWLAxiom> O2 = new HashSet<OWLAxiom>(allAxioms);
		Vector<OWLAxiom> newPath = new Vector<OWLAxiom>(path);
		HashSet<OWLAxiom> newJust = null;	
		
		testTimer.start();
		newPath.add(a);
		//Early path termination
		for (Vector<OWLAxiom> h : hittingSets) {			
			if (newPath.containsAll(h)) { 
				testTimer.stop();
				return;
			}
		}
				
		//Justification reuse		
		O2.removeAll(newPath);			
		for (HashSet<OWLAxiom> exJust : conflicts ){
			if (O2.containsAll(exJust)){
				newJust = exJust;					
				break;
			}
		}		
		testTimer.stop();	
		
        //If no existing justification can be used, look for a new one
		if (newJust == null) { 
			newJust = getSingleJustBlackBox(C, O, incoAxioms);						
		}		
			
		//If there is new justification found, then regard this one as a new root node for HSTree.
		if (newJust != null && newJust.size() > 0) {
			testTimer.start();			
			conflicts.add(newJust);
			for (OWLAxiom b : newJust) {
				O.remove(b);
				testTimer.stop();
				searchHST(C, O, incoAxioms, b, newPath); 
				testTimer.start();
				O.add(b);
			}
			testTimer.stop();		
		} else {
			testTimer.start();
			hittingSets.add(newPath);
			testTimer.stop();
			return;  //Currently, we only expand one branch in HST.
		}		   		
	}
	
	/**
	 * Given an unsatisfiable concept and a set of axioms allAxioms 
	 * including the problematic part incoAxioms, we find the minimal
	 * subset of incoAxioms which are responsible for incoherence w.r.t.
	 * allAxioms\incoAxioms.
	 * 
	 * @param oc
	 * @param allAxioms
	 * @param incoAxioms
	 * @return
	 */
	public HashSet<OWLAxiom> getSingleJustBlackBox( 
			OWLClass oc, 
			HashSet<OWLAxiom> allAxioms_t,
			HashSet<OWLAxiom> incoAxioms_t){
		
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(allAxioms_t);
		HashSet<OWLAxiom> incoAxioms  = new HashSet<OWLAxiom>(incoAxioms_t);		
		
		try {
			if(ReasoningTools.isSatisfiable(allAxioms, oc, checkSatTimer)){
				return new HashSet<OWLAxiom>();
			}
			
			//Fast pruning
			Vector<OWLAxiom> prunedAxioms = this.fastPrune(allAxioms, new Vector<OWLAxiom>(incoAxioms), oc);				
			//slow pruning
			HashSet<OWLAxiom> prunedAxioms_t = this.slowPrune(allAxioms, prunedAxioms, oc);
			return prunedAxioms_t;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new HashSet<OWLAxiom>();
		}
	}
	
	public Vector<OWLAxiom> fastPrune(
			HashSet<OWLAxiom> all, 
			Vector<OWLAxiom> incoAx, 
			OWLClass oc) throws Exception {
		
		testTimer.start();
		int pruneWindow = 10;
		HashSet<OWLAxiom> testAxioms = new HashSet<OWLAxiom>(all);
		Vector<OWLAxiom> incoAxioms = new Vector<OWLAxiom>(incoAx);
		int size = incoAxioms.size();
		//System.out.println(OWLTools.isCoherent(new HashSet<OWLAxiom>(prunedAxioms),oc));
		if(size>pruneWindow){
			int parts = size / pruneWindow;
			for (int part = 0; part < parts; part++) {
				for (int i = part * pruneWindow; i < part * pruneWindow
						+ pruneWindow; i++) {
					testAxioms.remove(incoAxioms.get(i));
				}
				testTimer.stop();
								
				if (ReasoningTools.isSatisfiable(testAxioms, oc, checkSatTimer)) {
					//System.out.println("Fast prune axioms");
					testTimer.start();						
					for (int i = part * pruneWindow; i < part * pruneWindow
							+ pruneWindow; i++) {
						testAxioms.add(incoAxioms.get(i));
						//System.out.println(i+" > "+allRelated.get(i).toString().replace(ns, ""));
					}
					
					//this.prune(part * pruneWindow, part * pruneWindow+ pruneWindow-1, allRelated, prunedAxioms, oc);
					
					testTimer.stop();
				}
				testTimer.start();
			}
			if (size > parts * pruneWindow) {
				// add remaining from list to axioms
				for (int i = parts * pruneWindow; i < size; i++) {
					testAxioms.add(incoAxioms.get(i));
				}
			}
		}
		testTimer.stop();
		return new Vector<OWLAxiom>(incoAxioms);
	}
	
	//This method prunes the axioms one by one
	public HashSet<OWLAxiom> slowPrune(
			HashSet<OWLAxiom> all, 
			Vector<OWLAxiom> incoAx, 
			OWLClass oc) throws Exception {
		//System.out.println("Slow pruning : "+prunedAxioms.size());
		
		HashSet<OWLAxiom> testAxioms = new HashSet<OWLAxiom>(all);
		Vector<OWLAxiom> incoAxioms = new Vector<OWLAxiom>(incoAx);
		HashSet<OWLAxiom> sos = new HashSet<OWLAxiom>();
		
		testTimer.start();
		for(OWLAxiom a : incoAxioms){			
			testAxioms.remove(a);
			testTimer.stop();
			
			if(ReasoningTools.isSatisfiable(testAxioms, oc, checkSatTimer)){				
				testTimer.start();
				testAxioms.add(a);
				sos.add(a);
				testTimer.stop();
			}
			testTimer.start();
		}
		testTimer.stop();		
		
		return sos;
	}
	
	public HashSet<Vector<OWLAxiom>> getHittingSets(){
		return new HashSet<Vector<OWLAxiom>>(hittingSets);
	}
	
	public long getCheckSatTime(){
		return checkSatTimer.getTotal();
	}

	public long getTestTime(){
		return testTimer.getTotal();
	}
	
	public int getCheckSatTimes(){
		return checkSatTimer.getCount();
	}
	
	public void setAllAxioms(HashSet<OWLAxiom> allAxioms_t){
		this.allAxioms = allAxioms_t;
	}

	public void setIncoAxioms(HashSet<OWLAxiom> incoAxioms){
		this.incoAxioms = incoAxioms;
	}


}
