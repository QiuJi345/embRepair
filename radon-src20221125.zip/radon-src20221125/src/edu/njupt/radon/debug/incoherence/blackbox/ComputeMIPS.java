package edu.njupt.radon.debug.incoherence.blackbox;

import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parameters.DebuggingParameters;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTask;

/**
 * This class is to compute MIPS. This can be done by computing all MUPS first.
 * Or it can be done by providing all MUPS beforehand.
 * 
 * @author Qiu Ji
 * @version 2012.11.15
 *
 */
public class ComputeMIPS {
		
	public static void main(String[] args) throws Exception {
		ReasoningTask.reasoner = "factpp";
		String ontoPath = "G:/Data/2014-kbs/data/incoherent/Terrorism.owl";
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		
		ComputeMIPS.computeMIPS(new HashSet<OWLAxiom>(onto.getAxioms()));
	}
				
	public static HashSet<HashSet<OWLAxiom>> computeMIPS(HashSet<OWLAxiom> debuggingAxioms) {
		BlackboxDebug debug = new BlackboxDebug(debuggingAxioms);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = debug.getMUPS();
		HashSet<HashSet<OWLAxiom>> mips = computeMIPS(mups);
		return mips;
	}

	public static HashSet<HashSet<OWLAxiom>> computeMIPS(
			HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups) {

		HashSet<HashSet<OWLAxiom>> mupsUnion = new HashSet<HashSet<OWLAxiom>>();
		for (OWLClass oc : mups.keySet()) {
			mupsUnion.addAll(mups.get(oc));
		}
		HashSet<HashSet<OWLAxiom>> mips = doCompute(mupsUnion);
		return mips;
	}

	public static HashSet<HashSet<OWLAxiom>> doCompute(HashSet<HashSet<OWLAxiom>> mupsUnion) {

		HashSet<HashSet<OWLAxiom>> ret = new HashSet<HashSet<OWLAxiom>>();
		HashSet<HashSet<OWLAxiom>> allMups = (HashSet<HashSet<OWLAxiom>>) mupsUnion.clone();
		HashSet<HashSet<OWLAxiom>> mips = new HashSet<HashSet<OWLAxiom>>();

		for (HashSet<OWLAxiom> mups1 : allMups) {
			boolean min = true;
			for (HashSet<OWLAxiom> mups2 : allMups) {
				if (mups1.containsAll(mups2) && !mups2.containsAll(mups1)) {
					min = false;
					break;
				}
			}

			if (min) {
				ret.add(mups1);
			}
		}
		
		for(HashSet<OWLAxiom> one : ret){
			mips.add((HashSet<OWLAxiom>)one.clone());
		}
		return mips;
	}	
	
}
