package edu.njupt.radon.debug.incoherence.heuristic.core;

public class MyConstants {
	public static final String UNKNOWN = "unknown";
	
	public static final String LEQ = "less and equal to";
	
	public static final String GEQ = "greater and equal to";
	
	public static final String EQ = "equal to";

}
