package edu.njupt.radon.debug.incoherence.blackbox;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapi.explanation.PelletExplanation;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.utils.io.MyPrinter;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class PelletDebug implements RadonDebug {
	
	private HashSet<OWLClass> ucs;
	
	PelletExplanation pelletExplanation;
	
	private long debugTime = 0;
	
	public PelletDebug(OWLOntology onto, boolean useGlassBox) {
		//ucs = ReasoningTools.getUnsatiConcepts(onto);
		//System.out.println("The number of unsatisfiable concepts is "+ucs.size());
		pelletExplanation = new PelletExplanation(onto, useGlassBox);
	}
	
	public HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> getMUPS() {
		// All MUPS of each unsatisfiable concept in an ontology
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		if(ucs.size()==0){	
			System.out.println("This ontology is coherent.");
			return allMUPS;
		}
		
		HashSet<HashSet<OWLAxiom>> ucMUPS = null;		
		int i = 1;
		for (OWLClass unsatConcept : ucs) {				
			System.out.println((i++)+"> concept : "+unsatConcept.toString());					
			ucMUPS = this.getMUPS(unsatConcept);						
			if (ucMUPS!=null && ucMUPS.size()>0) {
				allMUPS.put(unsatConcept, new HashSet<HashSet<OWLAxiom>>(ucMUPS));
			}
		}
		System.out.println("** Time to compute all MUPS for all Ucs: "+debugTime);
		return allMUPS;
	}
	
	public HashSet<HashSet<OWLAxiom>> getMUPS(OWLClass unsatConcept) {	
		Set<Set<OWLAxiom>> mups = pelletExplanation.getUnsatisfiableExplanations(unsatConcept);	
		HashSet<HashSet<OWLAxiom>> ucMUPS = new HashSet<>();	
		for(Set<OWLAxiom> oneMUPS : mups) {
			ucMUPS.add(new HashSet<>(oneMUPS));
		}
		MyPrinter.printMultiSets(ucMUPS, null);
		return ucMUPS;
	}
	
	/**
	 * 这个方法暂时没有实现完整
	 */
	public HashSet<HashSet<OWLAxiom>> getMUPS(
			OWLClass unsatConcept, 
			HashSet<HashSet<OWLAxiom>> foundMUPS)  {
		long st = System.currentTimeMillis();
		HashSet<HashSet<OWLAxiom>> ucMUPS = this.getMUPS(unsatConcept);
		long ucDebugTime = System.currentTimeMillis() - st;
		debugTime += ucDebugTime;
		System.out.println("* The time (ms) to compute all MUPS for the unsatisfiable concept is: "+ucDebugTime+"\n");
		return ucMUPS;
	}
	
	public HashSet<Vector<OWLAxiom>> getHittingSets(){
		HashSet<Vector<OWLAxiom>> hittingSets = new HashSet<Vector<OWLAxiom>>();
		
		return hittingSets; 	
	}

}
