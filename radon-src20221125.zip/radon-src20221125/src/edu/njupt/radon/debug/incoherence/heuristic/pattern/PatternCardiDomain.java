package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataExactCardinality;
import org.semanticweb.owlapi.model.OWLDataMinCardinality;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLObjectExactCardinality;
import org.semanticweb.owlapi.model.OWLObjectMinCardinality;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceParameters;

public class PatternCardiDomain implements DebuggingPattern {

	OntologyInfo myOnto = null;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc = null;
	
	public PatternCardiDomain(OntologyInfo myOnto, 
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass unsatConcept){
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = unsatConcept;
	}
	
	@Override
	public HashSet<HashSet<OWLAxiom>> findMUPS() {
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		for(OWLClass subC : myOnto.getDirectCardiConditions().keySet()){
			for(OWLClassExpression condition : myOnto.getDirectCardiConditions().get(subC)){
				OWLEntity opInCond = null;
				if(condition instanceof OWLObjectMinCardinality){
					OWLObjectPropertyExpression ope = ((OWLObjectMinCardinality)condition).getProperty();
					opInCond = MyUtils.getOWLObjectProperty(ope);
				} else if(condition instanceof OWLObjectExactCardinality){
					OWLObjectPropertyExpression ope = ((OWLObjectExactCardinality)condition).getProperty();
					opInCond = MyUtils.getOWLObjectProperty(ope);
				} else if(condition instanceof OWLDataMinCardinality){
					OWLDataPropertyExpression ope = ((OWLDataMinCardinality)condition).getProperty();
					opInCond = MyUtils.getOWLDataProperty(ope);
				} else if(condition instanceof OWLDataExactCardinality){
					OWLDataPropertyExpression ope = ((OWLDataExactCardinality)condition).getProperty();
					opInCond = MyUtils.getOWLDataProperty(ope);
				}				 
				
				ExpandDomRan expand = new ExpandDomRan(myOnto, classHier, propHier, uc);
				HashSet<HashSet<OWLAxiom>> conflicts2 = expand.findPatternOfDomain(uc, subC, condition, opInCond);
				if(conflicts2 != null && conflicts2.size()>0){
					conflicts.addAll(conflicts2);
				}
				
				if(RelevanceParameters.conflictSetsNumLimit != -1 && 
						conflicts2.size() >= RelevanceParameters.conflictSetsNumLimit){
					return conflicts;
				}
			}
		}		
		return conflicts;
	}
	
	@Override
    public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();		
		
		return allConflicts;
	}

}
