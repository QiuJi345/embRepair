package edu.njupt.radon.debug.incoherence.heuristic.pattern;

import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;

import edu.njupt.radon.debug.incoherence.heuristic.MyUtils;
import edu.njupt.radon.debug.incoherence.heuristic.PatternControl;
import edu.njupt.radon.debug.incoherence.heuristic.PatternUtils;
import edu.njupt.radon.debug.incoherence.heuristic.core.ClassHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.FindPath;
import edu.njupt.radon.debug.incoherence.heuristic.core.OntologyInfo;
import edu.njupt.radon.debug.incoherence.heuristic.core.PropertyHierarchy;
import edu.njupt.radon.debug.incoherence.heuristic.core.UnsatPropagation;
import edu.njupt.radon.utils.OWLTools;

public class PatternExistBot implements DebuggingPattern {

	OntologyInfo myOnto;
	ClassHierarchy classHier;
	PropertyHierarchy propHier;
	OWLClass uc;	
		
	public PatternExistBot(
			OntologyInfo myOnto,
			ClassHierarchy hier,
			PropertyHierarchy hier2,
			OWLClass uc){		
		this.myOnto = myOnto;
		this.classHier = hier;
		this.propHier = hier2;
		this.uc = uc;		
	}
	
	@Override
	public HashSet<HashSet<OWLAxiom>> findMUPS() {

		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		UnsatPropagation propagation = new UnsatPropagation(myOnto.getUCsInOriginalOnto(), myOnto.getDirectExistentialConditions());
				
		HashSet<OWLClassExpression> superClasses = classHier.getAllSuperClasses(uc);
		for(OWLClassExpression superClass : superClasses){
			if(myOnto.getDirectExistentialConditions().containsKey(superClass)){
				for(OWLClassExpression condition1 : myOnto.getDirectExistentialConditions().get(superClass)){
					if(!(condition1 instanceof OWLObjectSomeValuesFrom)){
						continue;
					}
					
					OWLClassExpression oce1 = ((OWLObjectSomeValuesFrom)condition1).getFiller();
					if(oce1.toString().contains("xsd:")){
						continue;
					}
					
					OWLClass filler1 = MyUtils.getOWLClass(oce1);
					if(filler1 == null){
						continue;
					}
					boolean cont = false;
					
					if(myOnto.getUCsInOriginalOnto().contains(filler1) && !filler1.equals(this.uc)){
						cont = true;
					} else if(!myOnto.getUCsInOriginalOnto().contains(filler1)){
						if(myOnto.getDirectExistentialConditions().containsKey(filler1)){						
							if(propagation.isUnsatisfiable(superClass.asOWLClass(), filler1) == 1){
								cont = true;
							}
						}
					}
					if(!cont){	
						continue;
					}
					/** Consider the first part */
					// If the filler is unsatisfiable, we compute the corresponding justifications.					
					PatternControl patControl = new PatternControl(myOnto, classHier, propHier, filler1);
					HashSet<HashSet<OWLAxiom>> partialJusts1 = patControl.findMUPS();
					//HashSet<HashSet<OWLAxiom>> partialJusts1 = basicPattern.findConflicts(filler1);						
					if(partialJusts1 != null && partialJusts1.size()>0){
						/** Compute the second part of a conflict */
						FindPath findPath = new FindPath(classHier.getClassHierarchy());
						HashSet<HashSet<Vector<OWLClassExpression>>> partialJustsPairs2 = 
							findPath.findPaths(uc, superClass);
						if(partialJustsPairs2 != null && partialJustsPairs2.size()>0){
							HashSet<HashSet<OWLAxiom>> partialJusts2 = PatternUtils.transferConflicts(
									partialJustsPairs2,	classHier, myOnto);
							// Combine the first two parts
							partialJusts1 = PatternUtils.combinePartialJusts(partialJusts1, partialJusts2);			
						}
						/** Compute the third part of a conflict */
						Vector<OWLClassExpression> pair1 = MyUtils.createPair(superClass, condition1);
						OWLAxiom axiom = myOnto.getPairAxiomMap().get(pair1);
						for(HashSet<OWLAxiom> just : partialJusts1){								
							just.add(axiom);
							conflicts.add(new HashSet<OWLAxiom>(just));
						}
					}	
				
				}			
			}
		}
		return conflicts;	
	}
	
	@Override
    public HashSet<HashSet<OWLAxiom>> findMUPS(OWLDisjointClassesAxiom disjAxiom){
		
		HashSet<HashSet<OWLAxiom>> allConflicts =  new HashSet<HashSet<OWLAxiom>>();		
		
		return allConflicts;
	}

}
