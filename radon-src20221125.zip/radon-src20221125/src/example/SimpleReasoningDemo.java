package example;

import java.util.HashSet;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class SimpleReasoningDemo {

	static String ontoName = "proton_50_studis"; //
	//static String ontoName = "test";
	static String ontoRoot = "data/";
	//String ontoRoot = "d:/data/debugging/neon/proton/";
	static String ontoPath = "file:"+ontoRoot+ontoName+".owl";

	public static void main(String[] args) throws Exception {
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		IRI physicalURI = IRI.create(ontoPath);
		OWLOntology ontology = manager.loadOntology(physicalURI);
		
		
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		OWLReasoner owlReasoner = reasonerFactory.createReasoner(ontology);
		System.out.println(owlReasoner.isConsistent());
		
		HashSet<OWLClass>  allUnsat = ReasoningTools.getUnsatiConcepts(ontology, manager);

	}

}
