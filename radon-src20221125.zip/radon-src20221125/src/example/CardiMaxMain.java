package example;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.inconsistency.InconsistencyTolarent;
import edu.njupt.radon.tolerant.IncoherenceTolarent;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;

public class CardiMaxMain {

	public static void main(String[] args) throws Exception {
		//test1();
		test2();
		
	}
	
	static void test1() throws Exception {
		String ontoPath = "data/buggyPolicy-inconsistent.owl";
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);		
		HashSet<OWLAxiom> abox = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		abox.removeAll(tbox);
		System.out.println(" \n tbox:");
		CommonTools.printAxioms(tbox);
		System.out.println(" \n abox: ");
		CommonTools.printAxioms(abox);
		
		InconsistencyTolarent ct = new InconsistencyTolarent();
		//Get a maximal consistent subset
		HashSet<OWLAxiom> subset = ct.getMaxConsistentSubset(tbox, abox);
		if(subset!=null){
			System.out.println(" \n A maximal consistent subset: ");
			CommonTools.printAxioms(subset);
		}
		//Get a cardinality-maximal consistent subset
		subset = ct.getCardiMaxConsistentSubset(tbox, abox);
		if(subset!=null){
			System.out.println(" \n\n A cardinality-maximal consistent subset: ");
			CommonTools.printAxioms(subset);
		}
	}

	static void test2() throws Exception {
		String ontoPath = "data/buggyPolicy-incoherent.owl";
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);
		System.out.println(" \n tbox:");
		CommonTools.printAxioms(tbox);
				
		IncoherenceTolarent ct = new IncoherenceTolarent();
		//Get a maximal coherent subset
		HashSet<OWLAxiom> subset = ct.getMaxCoherentSubset(tbox);
		if(subset!=null){
			System.out.println(" \n A maximal coherent subset: ");
			CommonTools.printAxioms(subset);
		}
		//Get a cardinality-maximal coherent subset
		subset = ct.getCardiMaxCoherentSubset(tbox);
		if(subset!=null){
			System.out.println(" \n\n A cardinality-maximal coherent subset: ");
			CommonTools.printAxioms(subset);
		}
	}

}
