package example;

import java.io.File;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.FileTools;

public class OntoContained {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String root = "D:/Data/debugging/just/ontologies/ontologies/";
		aa(root);
		/*String onto1Name = "UOBM-lite-10";
		String onto2Name = "UOBM-lite-20";
		String dataset = "tool";
		String ontoRoot = "d:/Data/debugging/journal-paper-data/inconsistent/";
		String sourceOntoPath = "file:"+ontoRoot+dataset+"/"+onto1Name+".owl";
		String targetOntoPath = "file:"+ontoRoot+dataset+"/"+onto2Name+".owl";
				    
	    //read two ontologies
		OWLOntology sourceOnto = OWL.manager.loadOntology( IRI.create( sourceOntoPath ) );
		for(OWLAxiom axiom : sourceOnto.getLogicalAxioms()){
			System.out.println(axiom.toString());
		}
		//OWLOntology targetOnto = OWL.manager.loadOntology( IRI.create( targetOntoPath ) );
		HashSet<OWLAxiom> ax1 = new HashSet<OWLAxiom>(sourceOnto.getLogicalAxioms());
		//HashSet<OWLAxiom> ax2 = new HashSet<OWLAxiom>(targetOnto.getLogicalAxioms());
		//System.out.println(ax2.containsAll(ax1));
*/		
		
	}
	
	public static void aa(String ontosRoot){
		File f = new File(ontosRoot);
		boolean begin = false;
		for(File ontoFile : f.listFiles()){
			String ontoName = ontoFile.getName();
			
			if(ontoName.equals("nci-thesaurus")){
				begin = true;
			}
			if(!begin || ontoName.equals("nci-thesaurus")){
				continue;
			}
			System.out.println("Ontology : "+ontoName);
			String entailmentsPath = ontosRoot+ontoName+"/selectedentailments.xml";
			String text = FileTools.getString(entailmentsPath);
			if(text.contains("nothing")||text.contains("Nothing")){
				System.out.println("    Contain unsatisfiable concept!");
			}
		}
	}
	
}
