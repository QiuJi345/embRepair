package example;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parser.AlignmentParser;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class MergeOntologies {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		
		String system = "asmov";
		
		String onto1Name = "ekaw";
		String onto2Name = "sigkdd";
		
		String mergedName = system+"-"+onto1Name.toLowerCase()+"-"+onto2Name.toLowerCase();
		String sourceOntoPath = "data/conference2010/"+onto1Name+".owl";
		String targetOntoPath = "data/conference2010/"+onto2Name+".owl";
		String mappingPath = "data/conference2010/conference_submissions/"+mergedName+".rdf";
				
		String resultPath = "D:/programming-workspace/noise/radon/data/conference2010/merged/"+mergedName;
		
		System.setOut((new PrintStreamObject(resultPath+"-")).ps);
		
		System.out.println("Source ontology: "+onto1Name);
		System.out.println("Target ontology: "+onto2Name);
		
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	    HashMap<OWLAxiom,Double> weights = null;	    
	    //read two ontologies
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+sourceOntoPath);	
		OWLOntology targetOnto = OWLTools.openOntology("file:"+targetOntoPath);	
		allAxioms.addAll(sourceOnto.getLogicalAxioms());
		allAxioms.addAll(targetOnto.getLogicalAxioms());			
		
		//read mapping
		AlignmentParser align = new AlignmentParser(sourceOnto, targetOnto);
		weights = align.readMappingsFromFile(mappingPath);
		allAxioms.addAll(weights.keySet());
		
		// output information
		System.out.println("Axioms in source ontology: "+sourceOnto.getLogicalAxiomCount());
		System.out.println("Axioms in target ontology: "+targetOnto.getLogicalAxiomCount());
		System.out.println("Axioms in the mapping: "+weights.size());
		System.out.println("All axioms: "+allAxioms.size());
		
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(allAxioms);
		System.out.println("\n Unsatisfiable concepts: "+ucs.size());
		int i = 0;
		for(OWLClass oc : ucs){
			System.out.println("UC "+(i++)+"> "+oc.toString());
		}
		
		// save the merged ontology to the local disk
		OWLTools.saveOntology(allAxioms, "file:/"+resultPath+".owl");
	}
	
	public void mergeMultiPairOntos(String path) {
		File f = new File(path);
		System.out.println(f.exists());
		for(File subF : f.listFiles()) {
			String fName = subF.getName();
			String system = fName.substring(0, fName.indexOf("-"));
			if(!system.equals("LogMap")) {
				continue;
			}
			String o1Name = fName.substring(fName.indexOf("-")+1,fName.lastIndexOf("-"));
			String o2Name = fName.substring(fName.lastIndexOf("-")+1, fName.indexOf(".rdf"));
			checkMappingCoherence(o1Name, o2Name, system);
		}
		
	}
	
	/**
	 * Merge two source ontologies with their mapping by translating the mapping to 
	 * a set of OWL axioms.
	 * 
	 * @param sourceOntoPath
	 * @param targetOntoPath
	 * @param mappingPath
	 */
    public void mergeOnePairOntos(String sourceOntoPath, String targetOntoPath, String mappingPath) {			
		
		System.out.println("Source ontology: "+sourceOntoPath);
		System.out.println("Target ontology: "+targetOntoPath);
		
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	    HashMap<OWLAxiom,Double> weights = null;	    
	    //read two ontologies
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+sourceOntoPath);	
		OWLOntology targetOnto = OWLTools.openOntology("file:"+targetOntoPath);	
		allAxioms.addAll(sourceOnto.getLogicalAxioms());
		allAxioms.addAll(targetOnto.getLogicalAxioms());			
		
		//read mapping
		AlignmentParser align = new AlignmentParser(sourceOnto, targetOnto);
		weights = align.readMappingsFromFile(mappingPath);
		allAxioms.addAll(weights.keySet());	
		
	}
    

	
	public void checkMappingCoherence(String o1Name, String o2Name, String system) {
		String sourceOntoPath = "data/oaei2018/"+o1Name+".owl";
		String targetOntoPath = "data/oaei2018/"+o2Name+".owl";
		String mappingPath = "data/oaei2018/results/"+system+"-"+o1Name+"-"+o2Name+".rdf";			
				
	    //read two source ontologies
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+sourceOntoPath);	
		OWLOntology targetOnto = OWLTools.openOntology("file:"+targetOntoPath);	
		HashSet<OWLAxiom> stableAxioms = new HashSet<OWLAxiom>(sourceOnto.getLogicalAxioms());		
		stableAxioms.addAll(targetOnto.getLogicalAxioms());			
		
		//read the mapping between two source ontologies
		AlignmentParser align = new AlignmentParser(sourceOnto, targetOnto);
		HashMap<OWLAxiom,Double> weights = align.readMappingsFromFile(mappingPath);		
		HashSet<OWLAxiom> incoAxioms = new HashSet<OWLAxiom>(weights.keySet());
		
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(stableAxioms);
		allAxioms.addAll(incoAxioms);
		
		if(!ReasoningTools.isConsistent(allAxioms)) {
			return;
		}
				

		if(!ReasoningTools.isCoherent(allAxioms)) {
			try {
				OWLTools.saveOntology(allAxioms, "data/oaei2018/merged/"+system+"-"+o1Name+"-"+o2Name+".owl");
			} catch (Exception ex) {
				ex.printStackTrace();
			}			
		}
		System.out.println(system+"-"+o1Name+"-"+o2Name+": "+ReasoningTools.isCoherent(allAxioms));
	}

	
}
