package example;


import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.relevance.RelevanceDebug;
import edu.njupt.radon.debug.inconsistency.ComputeMIS;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.MyPrinter;
import edu.njupt.radon.utils.reasoning.ReasoningTools;


public class IncoHandlingMain {
	
	static String ontoName = "proton_50_all"; //
	//static String ontoName = "test";
	static String ontoRoot = "onto/";
	//String ontoRoot = "d:/data/debugging/neon/proton/";
	static String ontoPath = "file:"+ontoRoot+ontoName+".owl";
	/*static String ontoPath = "file:data/conference2010/merged/"+ontoName+".owl";
	static String resPath = "results/mups/"+ontoName+"/";*/
	//static String ontoPath = "file:///F:/Data/debugging/oaei/conference/"+ontoName+".owl";
	static String resPath = "results/mups/"+ontoName+"/";
	
	static String ucName = "http://proton.semanticweb.org/2004/12/protonu#CEO";

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		/*
		CommonTools.checkPath(resPath);
		System.setOut((new PrintStreamObject(resPath)).ps);*/
		ontoPath = "D:/Data/lod/schema/geonames-ontology_v2.2.1.rdf";
		OWLOntology onto = OWLTools.openOntology(ontoPath);	
		
		System.out.println(onto.getClassesInSignature().size());
		System.out.println("All axioms: "+onto.getLogicalAxiomCount());
		System.out.println("TBox : "+OWLTools.getTBox(onto).size());
		CommonTools.printAxioms(OWLTools.getTBox(onto));
		System.out.println("ABox : "+OWLTools.getABox(onto).size());
		computeMUPS(onto);
		//computeMUPSRel(onto);	
		//computeMUPSRel(onto, ucName);	
	}
	
	public static void computeMUPS(OWLOntology onto){
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
	    //OWLTools.printAllLogicAxioms(onto);
	    System.out.println("Tbox : "+axioms.size());
		
		BlackboxDebug debug = new BlackboxDebug(axioms);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = debug.getMUPS();
	}
	
	public static void computeMUPSRel(OWLOntology onto){
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
	    //OWLTools.printAllLogicAxioms(onto);
	    System.out.println("Tbox : "+axioms.size());
		
		RelevanceDebug debug = new RelevanceDebug(axioms, null);
        debug.getMUPS();
	}
	
	public static void computeMUPSRel(OWLOntology onto, String ucName) throws Exception {
		HashSet<OWLAxiom> axioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
	    //OWLTools.printAllLogicAxioms(onto);
	    System.out.println("Tbox : "+axioms.size());
		OWLEntity ent = OWLTools.getEntity(onto, ucName);
		if(ent != null){
			OWLClass unsatConcept = ent.asOWLClass();
			RelevanceDebug debug = new RelevanceDebug(axioms, null);
	        debug.getMUPS(unsatConcept, null);
		}		
	}
	
	public static void computeMIS(OWLOntology onto){
		System.out.println("Consistent?" + ReasoningTools.isConsistent(onto, OWLTools.manager , null));
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(onto.getLogicalAxioms());
		ComputeMIS debug = new ComputeMIS();
		HashSet<HashSet<OWLAxiom>> mis = debug.computeAllMIS(allAxioms);
		MyPrinter.printMultiSets(mis, null);
	}
	
	public static void printUcs(HashSet<OWLAxiom> axioms) throws Exception{
		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(axioms);
		System.out.println("uc number: "+ ucs.size());
		int i = 0;
		for(OWLClass uc : ucs){
			System.out.println("   Uc_"+(i++)+" > "+uc.toString());
		}
	}
	
}
