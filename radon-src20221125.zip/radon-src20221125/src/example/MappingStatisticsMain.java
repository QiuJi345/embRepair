package example;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parser.AlignmentParser;
import edu.njupt.radon.utils.CommonTools;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class MappingStatisticsMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		
		String ontoRoot = "data/conference2010/";
		String mappingRoot = "data/conference2010/conference_submissions/";				
		String resultRoot = "results/conference2010/merged/";
		String tablePath = resultRoot+"statisticsTable.xls";	
		
		CommonTools.mkdirs(resultRoot);
		System.setOut((new PrintStreamObject(resultRoot+"statistics-")).ps);
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(tablePath)),true);    	
    	
		    
	    //read two ontologies
		OWLOntology cmt = OWLTools.openOntology("file:"+ontoRoot+"cmt.owl");	
		OWLOntology cocus = OWLTools.openOntology("file:"+ontoRoot+"Cocus.owl");	
		OWLOntology conference = OWLTools.openOntology("file:"+ontoRoot+"Conference.owl");	
		//OWLOntology confious = OWLTools.openOntology("file:"+ontoRoot+"confious.owl");	
		OWLOntology confOf = OWLTools.openOntology("file:"+ontoRoot+"confOf.owl");	
		//OWLOntology crs_dr = OWLTools.openOntology("file:"+ontoRoot+"crs_dr.owl");	
		OWLOntology edas = OWLTools.openOntology("file:"+ontoRoot+"edas.owl");	
		OWLOntology ekaw = OWLTools.openOntology("file:"+ontoRoot+"ekaw.owl");	
		OWLOntology iasted = OWLTools.openOntology("file:"+ontoRoot+"iasted.owl");	
		OWLOntology pcs = OWLTools.openOntology("file:"+ontoRoot+"PCS.owl");	
		OWLOntology sigkdd = OWLTools.openOntology("file:"+ontoRoot+"sigkdd.owl");	
		
		File f = new File(mappingRoot);
		for(File subF : f.listFiles()){
			if(subF.isDirectory()){
				continue;
			}
			String mappingName = subF.getName();
			String ontoName1 = mappingName.substring(mappingName.indexOf("-")+1, mappingName.lastIndexOf("-"));
			String ontoName2 = mappingName.substring(mappingName.lastIndexOf("-")+1, mappingName.lastIndexOf("."));
			OWLOntology sourceOnto = null;
			OWLOntology targetOnto = null;
			if(ontoName1.equalsIgnoreCase("cmt")){
				sourceOnto = cmt;
			} else if(ontoName1.equalsIgnoreCase("cocus")){
				sourceOnto = cocus;
			} else if(ontoName1.equalsIgnoreCase("conference")){
				sourceOnto = conference;
			} else if(ontoName1.equalsIgnoreCase("confOf")){
				sourceOnto = confOf;
			} else if(ontoName1.equalsIgnoreCase("edas")){
				sourceOnto = edas;
			} else if(ontoName1.equalsIgnoreCase("ekaw")){
				sourceOnto = ekaw;
			} else if(ontoName1.equalsIgnoreCase("iasted")){
				sourceOnto = iasted;
			} else if(ontoName1.equalsIgnoreCase("pcs")){
				sourceOnto = pcs;
			} else if(ontoName1.equalsIgnoreCase("sigkdd")){
				sourceOnto = sigkdd;
			}
			
			if(ontoName2.equalsIgnoreCase("cmt")){
				targetOnto = cmt;
			} else if(ontoName2.equalsIgnoreCase("cocus")){
				targetOnto = cocus;
			} else if(ontoName2.equalsIgnoreCase("conference")){
				targetOnto = conference;
			} else if(ontoName2.equalsIgnoreCase("confOf")){
				targetOnto = confOf;
			} else if(ontoName2.equalsIgnoreCase("edas")){
				targetOnto = edas;
			} else if(ontoName2.equalsIgnoreCase("ekaw")){
				targetOnto = ekaw;
			} else if(ontoName2.equalsIgnoreCase("iasted")){
				targetOnto = iasted;
			} else if(ontoName2.equalsIgnoreCase("pcs")){
				targetOnto = pcs;
			} else if(ontoName2.equalsIgnoreCase("sigkdd")){
				targetOnto = sigkdd;
			}
			
			HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
			if(sourceOnto != null && targetOnto != null){
				allAxioms.addAll(sourceOnto.getLogicalAxioms());
				allAxioms.addAll(targetOnto.getLogicalAxioms());	
				
				//read mapping
				AlignmentParser align = new AlignmentParser(sourceOnto, targetOnto);
				HashMap<OWLAxiom, Double> weights = align.readMappingsFromFile(mappingRoot+mappingName);
		        allAxioms.addAll(weights.keySet());
		        
		        // output infomation
		        int o1Size = sourceOnto.getLogicalAxiomCount();
		        int o2Size = targetOnto.getLogicalAxiomCount();
				System.out.println("Axioms in "+sourceOnto.getOntologyID().toString()+": "+o1Size);
				System.out.println("Axioms in "+targetOnto.getOntologyID().toString()+": "+o2Size);
				System.out.println("Axioms in the mapping "+mappingName+": "+weights.size());
				System.out.println("All axioms: "+allAxioms.size());
				
				
				HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(allAxioms);
				System.out.println("\n Unsatisfiable concepts: "+ucs.size());
				int i = 0;
				for(OWLClass oc : ucs){
					System.out.println("UC "+(i++)+"> "+oc.toString());
				}
				output.print(mappingName.subSequence(0, mappingName.indexOf(".")));
		        output.print('\t'); 
		    	output.print(o1Size);
		        output.print('\t'); 
		        output.print(o2Size);
		        output.print('\t'); 
		    	output.print(weights.size());
		        output.print('\t'); 
		        output.print(allAxioms.size());
		        output.print('\t'); 
		        output.print(ucs.size());       
		        output.println();
		        
				// save the merged ontology to the local disk
		        
				OWLTools.saveOntology(allAxioms, "file:///d:/merged/"+mappingName.substring(0, mappingName.indexOf("."))+".owl");
			}
		}		
	}
	
	public void outputHeader(PrintWriter output){
//		Output the titles for each column
		output.print("mappingName");
        output.print('\t'); 
    	output.print("o1 size");
        output.print('\t'); 
        output.print("o2 size");
        output.print('\t'); 
    	output.print("mapping size");
        output.print('\t'); 
        output.print("mergedOnto size");
        output.print('\t'); 
        output.print("Unsat concepts");       
        output.println();
	}
	
}
