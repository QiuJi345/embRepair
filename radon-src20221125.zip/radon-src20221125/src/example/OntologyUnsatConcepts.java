package example;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class OntologyUnsatConcepts {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String injectMethod = "generateUCs"; 
		//RelevantMUPSParameters.selectionFunction = RelevantMUPSParameters.SubSeleFunc;
		// Specify an ontology name
		String ontoName = "AUTOMSv2-cocus-edas"; //km1500-4000 proton_100_all
		String ontoRoot = "G:/Data/2014-kbs/data/inconsistent/";
		String ontoPath = "file:"+ontoRoot+ontoName+".owl";
		//ontoPath = "file:D:/data/debugging/neon/learning/km1500.owl";
		
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		System.out.println(OWLTools.getTBox(onto).size());
		System.out.println(OWLTools.getABox(onto).size());
		System.out.println(onto.getLogicalAxiomCount());
		
		/*HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(onto, OWLTools.manager);
		for(OWLClass uc : ucs){
			System.out.println(uc.getIRI().toString());
		}*/

	}

}
