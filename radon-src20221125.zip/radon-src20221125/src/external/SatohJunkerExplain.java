package external;
import java.util.ArrayList;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.reasoning.ReasoningTools;


public class SatohJunkerExplain {

	protected static OWLAxiom[] axioms;
	protected static boolean[] fixed;
	protected static ArrayList<ArrayList<Integer>> conflicts;
	protected static int numDiag;
	protected static int numCheck;
	protected static long startTime;

	/**
	 * @param args
	 * @throws OWLOntologyCreationException 
	 */
	public static void main(String[] args) throws Exception {
		if (args.length != 1 && args.length != 3) {
			System.out.println("Usage java SatohDiagnosis [-r|-f removable/fixed part] <ontology>");
			return;
		}

		startTime = System.currentTimeMillis();
		int i = (args.length == 1)? 0: 2;
		String file = (args[i].indexOf(':') < 0)? "file:" + args[i]: args[i];
		OWLOntology ontology = OWL.manager.loadOntology(IRI.create(file));
		axioms = new OWLAxiom[ontology.getAxiomCount()];
		axioms = ontology.getAxioms().toArray(axioms);
		OWL.manager.removeOntology(ontology);

        fixed = new boolean[axioms.length];
        if (args.length == 3) {
		    boolean removable = args[0].equalsIgnoreCase("-r"); 
		    file = (args[1].indexOf(':') < 0)? "file:" + args[1]: args[1];
		    ontology = OWL.manager.loadOntology(IRI.create(file));
		    for (i = 0; i < axioms.length; i++)
			    if (ontology.containsAxiom(axioms[i]))
				    fixed[i] = !removable;
			    else
				    fixed[i] = removable;
		    OWL.manager.removeOntology(ontology);
		}
		System.out.printf("%%Loaded ontology in %dms%n", System.currentTimeMillis()-startTime);

		conflicts = new ArrayList<ArrayList<Integer>>();
		numDiag = 0;
		numCheck = 0;
		constructConflicts(0, new ArrayList<Integer>(), null);
		System.out.println();
		for (int j = 0; j < conflicts.size(); j++) {
			System.out.printf("#%d minimal conflict set (%d axioms):%n", j+1, conflicts.get(j).size());
			for (Integer num: conflicts.get(j))
				System.out.println(axioms[num.intValue()]);
		}
	}

	private static void constructConflicts(int i, ArrayList<Integer> mhs,
			ArrayList<Integer>[] crit) throws Exception {
		if (i == conflicts.size()) {
			boolean[] absent = new boolean[axioms.length]; 
			for (Integer num: mhs)
				absent[num.intValue()] = true;
			HashSet<OWLAxiom> as = new HashSet<OWLAxiom>();
			for (int j = 0; j < absent.length; j++)
				if (!absent[j])
					as.add(axioms[j]);
			numCheck++;
			OWLOntology ontology = OWL.manager.createOntology(as);
			//PelletReasoner reasoner = PelletReasonerFactory.getInstance().createReasoner(ontology);
			if (ReasoningTools.isConsistent(ontology, OWL.manager )) {
				//reasoner.dispose();
				OWL.manager.removeOntology(ontology);
				numDiag++;
				System.out.printf("%%Found diagnosis #%d (%d axioms, %d consistency checks) in %dms%n",
						numDiag, mhs.size(), numCheck, System.currentTimeMillis()-startTime);
				//for (Integer num: mhs)
				//	System.out.println(axioms[num.intValue()]);
				return;
			}
			//reasoner.dispose();
			OWL.manager.removeOntology(ontology);
			ArrayList<Integer> fixPart = new ArrayList<Integer>();
			for (int j = 0; j < axioms.length; j++)
				if (fixed[j])
					fixPart.add(j);
			ArrayList<Integer> remPart = new ArrayList<Integer>();
			for (int j = 0; j < axioms.length; j++)
				if (!fixed[j] && !absent[j])
					remPart.add(j);
			ArrayList<Integer> newConf = computeConflict(fixPart, remPart, fixPart.size()>0); 
			conflicts.add(newConf);
			System.out.printf("%%Found minimal conflict set #%d (%d axioms) in %dms%n",
					conflicts.size(), newConf.size(), System.currentTimeMillis()-startTime);
		}
		ArrayList<Integer> its = intersect(conflicts.get(i), mhs);
		if (its.size() > 0) {
			ArrayList<Integer>[] newCrit = new ArrayList[mhs.size()];
			for (int j = 0; j < mhs.size(); j++) {
				newCrit[j] = new ArrayList<Integer>();
				newCrit[j].addAll(crit[j]);
				if (its.size() == 1 && its.get(0) == mhs.get(j))
					newCrit[j].add(i);
			}
			constructConflicts(i+1, mhs, newCrit);
		}
		else {
			ArrayList<Integer>[] newCrit = (crit == null)? new ArrayList[1]: new ArrayList[mhs.size()+1];
			for (int j = 0; j <= mhs.size(); j++)
				newCrit[j] = new ArrayList<Integer>();
			newCrit[mhs.size()].add(i);
			ArrayList<Integer> newMhs = new ArrayList<Integer>();
			for (int j = 0; j < conflicts.get(i).size(); j++) {
				newMhs.clear();
				if (crit == null) {
					newMhs.add(conflicts.get(i).get(j));
					constructConflicts(i+1, newMhs, newCrit);
				}
				else {
					int k = 0;
					for (; k < mhs.size(); k++) {
						newCrit[k].clear();
						for (Integer num: crit[k])
							if (!binarySearch(conflicts.get(num.intValue()), conflicts.get(i).get(j)))
								newCrit[k].add(num);
						if (newCrit[k].size() == 0)
							break;
					}
					if (k == mhs.size()) {
						newMhs.addAll(mhs);
						newMhs.add(conflicts.get(i).get(j));
						constructConflicts(i+1, newMhs, newCrit);
					}
				}
			}
		}
	}

	private static ArrayList<Integer> computeConflict(ArrayList<Integer> fixPart, ArrayList<Integer> remPart,
			boolean nonempty) throws Exception {
		if (nonempty) {
			HashSet<OWLAxiom> as = new HashSet<OWLAxiom>();
			for (int i = 0; i < fixPart.size(); i++)
				as.add(axioms[fixPart.get(i).intValue()]);
			numCheck++;
			OWLOntology ontology = OWL.manager.createOntology(as);
			//PelletReasoner reasoner = PelletReasonerFactory.getInstance().createReasoner(ontology);
			if (!ReasoningTools.isConsistent(ontology, OWL.manager)) {
				OWL.manager.removeOntology(ontology);
				return new ArrayList<Integer>();
			}
			OWL.manager.removeOntology(ontology);
		}
		if (remPart.size() == 1)
			return remPart;
		ArrayList<Integer> fPart = union(fixPart, remPart, remPart.size()>>1);
		ArrayList<Integer> rPart = copy(remPart, remPart.size()>>1, remPart.size());
		ArrayList<Integer> c1 = computeConflict(fPart, rPart, true);
		fPart = union(fixPart, c1, c1.size());
		rPart = copy(remPart, 0, remPart.size()>>1);
		ArrayList<Integer> c2 = computeConflict(fPart, rPart, c1.size()>0);
		return union(c1, c2, c2.size());
	}

	private static ArrayList<Integer> copy(ArrayList<Integer> remPart, int start, int end) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (int i = start; i < end; i++)
			result.add(remPart.get(i));
		return result;
	}

	private static ArrayList<Integer> union(ArrayList<Integer> fixPart,
			ArrayList<Integer> remPart, int size) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		int i = 0, j = 0;
		while (i < fixPart.size() && j < size) {
			if (fixPart.get(i).intValue() < remPart.get(j).intValue()) {
				result.add(fixPart.get(i));
				i++;
			}
			else if (fixPart.get(i).intValue() == remPart.get(j).intValue()) {
				result.add(fixPart.get(i));
				i++;
				j++;
			}
			else {
				result.add(remPart.get(j));
				j++;
			}
		}
		for (; i < fixPart.size(); i++)
			result.add(fixPart.get(i));
		for (; j < size; j++)
			result.add(remPart.get(j));
		return result;
	}

	private static ArrayList<Integer> intersect(ArrayList<Integer> diag, ArrayList<Integer> mhs) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (int i = 0; i < mhs.size(); i++)
			if (binarySearch(diag, mhs.get(i).intValue()))
				result.add(mhs.get(i));
		return result;
	}

	private static boolean binarySearch(ArrayList<Integer> diag, int key) {
		int start = 0, end = diag.size();
		while (start < end) {
			int k = (start+end)>>1;
			if (diag.get(k).intValue() == key)
				return true;
			if (diag.get(k).intValue() < key)
				start = k+1;
			else
				end = k;
		}
		return false;
	}

}
