package external;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;

public class HittingSetTree {/*
	
	private static String dataProperty = "data";
	private static String nodeIndexName = "nodesIndex";
	
	private EmbeddedGraphDatabase graphDb;	
	private  Index<Node> nodeIndex;     
	
	public HittingSetTree(String dbPath){			
		graphDb = new EmbeddedGraphDatabase(dbPath);
		//Tools.registerShutdownHook(graphDb);
		nodeIndex = graphDb.index().forNodes(nodeIndexName); 
	}
	
	public Node createNode(String name, String type, String comefrom){
		//System.out.println(name);
		Node node = nodeIndex.query(NAMEPROPERTY, name).getSingle();
		if(node == null){			
			node = graphDb.createNode();
			node.setProperty(dataProperty, name);
			node.setProperty(TYPEPROPERTY, type);			
			node.setProperty(COMEFROMPROPERTY, comefrom);			
			nodeIndex.add(node, NAMEPROPERTY,name);
		}
		
		return node;
	}

*/}

class AxiomSet {
	HashSet<OWLAxiom> axiomSet;
	public AxiomSet(HashSet<OWLAxiom> set){
		this.axiomSet = set;
	}
}
