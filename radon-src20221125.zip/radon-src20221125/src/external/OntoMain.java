package external;

import java.io.File;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;

public class OntoMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		//String ontoPath = "data/GeoSkills.owl";
		String ontoName = "wine_0-219"; //km1500-4000 proton_100_all
		String dataset = "abox-tool";
		String ontoRoot = "d:/Data/debugging/journal-paper-data/coherent/";
		String ontoPath = "file:"+ontoRoot+dataset+"/"+ontoName+".owl";
		String inferredOntoPath = "file:"+ontoRoot+dataset+"/"+ontoName+"-inferred.owl";
		String allEntailmentsPath = ontoRoot + "inferredAxioms/allentailments/"+ontoName+".txt";
		
		OWLOntology onto = OWLTools.openOntology(ontoPath);
		OWLOntology inferredOnto = OWLTools.openOntology(inferredOntoPath);
		if(dataset.contains("abox")){
			outputInferredClassAssertions(onto, inferredOnto);
		} else {
			outputInferredSubsumptions(onto, inferredOnto, allEntailmentsPath);		
		}
		
		//outputOntoInfo(onto);
		/*HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);
		System.out.println(ReasoningTools.isConsistent(onto, OWLTools.manager));;
		System.out.println(ReasoningTools.isCoherent(tbox));;*/
	}
		
	public static void outputInferredSubsumptions(
			OWLOntology onto, OWLOntology inferredOnto,
			String allEntailmentsPath){
		
		int i = 1;
		for(OWLAxiom axiom : inferredOnto.getLogicalAxioms()){
			if(onto.containsAxiom(axiom)){
				continue;				
			}		
			i ++;
		}
		System.out.println();
		System.out.println("Axioms in inferred onto: "+inferredOnto.getLogicalAxiomCount());
		System.out.println("Inferred Axioms : "+(i-1));
		
		
		File f = new File(allEntailmentsPath);
		if(f.exists()){
			f.delete();
		}
		System.setOut((new PrintStreamObject(allEntailmentsPath)).ps);
		for(OWLAxiom axiom : inferredOnto.getLogicalAxioms()){
			if(onto.containsAxiom(axiom)){
				continue;				
			}
			OWLSubClassOfAxiom subAxiom = (OWLSubClassOfAxiom)axiom;
			OWLClass subConcept = subAxiom.getSubClass().asOWLClass();
			OWLClass superConcept = subAxiom.getSuperClass().asOWLClass();
			System.out.println(OWLTools.getLocalName(subConcept)+ 
					" subClassOf "+OWLTools.getLocalName(superConcept));
		}
	}
	
    public static void outputInferredClassAssertions(OWLOntology onto, OWLOntology inferredOnto){
		
		int i = 1;
		for(OWLAxiom axiom : inferredOnto.getLogicalAxioms()){
			if(onto.containsAxiom(axiom)){
				continue;				
			}
			/*OWLClassAssertionAxiom assertion = (OWLClassAssertionAxiom)axiom;
			OWLIndividual indi = assertion.getIndividual();
			OWLClass type = assertion.getClassExpression().asOWLClass();
			System.out.println(OWLTools.getLocalName(indi.toString())+ 
					" types "+OWLTools.getLocalName(type));*/
			i ++;
		}
		System.out.println();
		System.out.println("Axioms in inferred onto: "+inferredOnto.getLogicalAxiomCount());
		System.out.println("Inferred Axioms : "+(i-1));
	}

	public static void outputOntoInfo(OWLOntology onto){
		//System.out.println(ReasoningTools.isCoherent(onto, OWLTools.manager));
		//System.out.println(ReasoningTools.isConsistent(onto, OWLTools.manager));
		System.out.println("ABox: "+OWLTools.getABox(onto).size());
		HashSet<OWLAxiom> tbox = OWLTools.getTBox(onto);
		System.out.println("TBox: "+ tbox.size());
		for(OWLAxiom a : tbox){
			OWLSubClassOfAxiom subAxiom = (OWLSubClassOfAxiom)a;
			OWLClass subConcept = subAxiom.getSubClass().asOWLClass();
			OWLClass superConcept = subAxiom.getSuperClass().asOWLClass();
			System.out.println(OWLTools.getLocalName(subConcept)+ 
					" subClassOf "+OWLTools.getLocalName(superConcept));
		}
	}
	
	public static void aa(){
		
	}

}
