package external;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/*import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.index.Index;
import org.neo4j.graphdb.index.IndexHits;
import org.neo4j.kernel.EmbeddedGraphDatabase;*/
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLDisjointObjectPropertiesAxiom;

/**
 * ��һ������������ͼ���ݿ�
 * @author Xuefeng Fu
 */
public class SingleOWLToGraphDB {/*		
	private String comefrom; //�ñ����ǵ�һ�����壬���ǵڶ�������
	private EmbeddedGraphDatabase graphDb;	
	private OWLInfo owlInfo;
	private  Index<Node> nodeIndex;                                       //�ڵ�������������ҽڵ�	
	private Index<Relationship> relationshipIndex;
	
	public static void createGraphDb(String dbPath, String owl, String comefrom,boolean isClear){
		SingleOWLToGraphDB app = new SingleOWLToGraphDB(dbPath, owl, comefrom, isClear);
		app.createDbFromOwl();
		app.shutdown();
	}
	
	//��ͷ����һ��
	public SingleOWLToGraphDB(String dbPath, String owl, String comefrom,boolean isClear){		
		//�Ƿ�������ݿ�
		if(isClear){
			Tools.clearDb(dbPath);
		}
		System.out.println(dbPath);
		this.comefrom = comefrom;
	
		graphDb = new EmbeddedGraphDatabase(dbPath);
		Tools.registerShutdownHook(graphDb);
		nodeIndex = graphDb.index().forNodes(NODEINDEX);  //����������������
		relationshipIndex = graphDb.index().forRelationships(RELATIONSHIPINDEX); //
		owlInfo = new OWLInfo(owl);		
	}
	
	public void createDbFromOwl(){		
		//clearDb();		
		System.out.println("Create graph database from owls");
		createNodes(owlInfo, comefrom);		
		createRelationshipsFromOwl(owlInfo, comefrom);
		
	}
	
	public void shutdown(){
		System.out.println("Creating graph database end.");
		this.graphDb.shutdown();
	}
	
	*//**
	 * ��owlinfo�д����ڵ㣬���ڼ�¼�ڵ����Դ
	 * @param owl owl��Ϣ�ṹ
	 * @param comefrom ��Դ��Ϣ
	 *//*
	public void createNodes(OWLInfo owl, String comefrom){
		System.out.println(String.format("    #Creating class nodes from %s...", owl.getOwlFileName()));
		//ȡ������(��)
		Set<String> concepts = owl.getConceptTokens();
		Set<String> roles = owl.getRoleTokens();
		
		//System.out.println("concepts:"+concepts.size());
		
		List<String> newConcepts = this.getEntitiesFromDisjointClass(owl);
		List<String> newRoles = this.getEntitiesFromDisjointObjectProperty(owl);
		for(String newConcept : newConcepts){
			concepts.add(newConcept);
		}
		
		//System.out.println("concepts:"+concepts.size());
		
		for(String newRole : newRoles){
			roles.add(newRole);
		}
		//���
		newRoles.clear();
		newConcepts.clear();
		
		Transaction tx = graphDb.beginTx(); 
		//Node node = null;
		try{
			//��������ڵ�
			for(String concept : concepts){				
				createNode(concept,CONCEPTTYPE,comefrom);				
			}			
			for(String role : roles){				
			    createNode(role,ROLETYPE,comefrom);				
			  //��ʼ����ԭ�Ӹ�����������negativeǰ׺��˵���÷񶨽�ɫ�Ѿ����ӣ����ҷ񶨸��������ڷ񶨰����л�����
				if(role.startsWith("negative_")) continue;  
				//���ӽ�ɫ������������ʽ
				String[] roleForms = Tools.getRoleForms(role);
				//inverse_�ǽ�ɫ
				createNode(roleForms[0],ROLETYPE,comefrom);
				newRoles.add(roleForms[0]);
				//existence_�Ǹ���
				createNode(roleForms[1],CONCEPTTYPE,comefrom);
				createNode(roleForms[2],CONCEPTTYPE,comefrom);				
				newConcepts.add(roleForms[1]);
				newConcepts.add(roleForms[2]);
			}
			for(String newConcept : newConcepts){
				concepts.add(newConcept);
			}
			for(String newRole : newRoles){
				roles.add(newRole);
			}
			newRoles.clear(); //���
			newConcepts.clear();
			tx.success();
		}finally{
			tx.finish();
		}
	}	
	
	*//**
	 * �����ڵ㲢���ӵ�index��
	 * @param name �ڵ����������
	 * @param type   �ڵ���������
	 * @param comefrom �ڵ���Դ�ĸ�����
	 * @return
	 *//*
	public Node createNode(String name, String type, String comefrom){
		//System.out.println(name);
		Node node = nodeIndex.query(NAMEPROPERTY, name).getSingle();
		if(node == null){			
			node = graphDb.createNode();
			node.setProperty(NAMEPROPERTY, name);
			node.setProperty(TYPEPROPERTY, type);			
			node.setProperty(COMEFROMPROPERTY, comefrom);			
			nodeIndex.add(node, NAMEPROPERTY,name);
		}
		//����Ҫ�ˣ���Ϊ�����Ǵ�һ��������ȡ����
		else{ //����ڵ���ڣ�ȡ������comefrom,������߲�ͬ����˵���������������ж�����
			String come = node.getProperty(COMEFROMPROPERTY).toString();
			if(!come.equals(comefrom)){
				node.removeProperty(COMEFROMPROPERTY); //��ɾ��������
				node.setProperty(COMEFROMPROPERTY, CONJUNCTION); //����comefrom����Ϊconjunct
			}
		}		
		return node;
	}	
	
	*//**
	 * �ӱ����й�����ϵ
	 * @param owl
	 *//*
	public void createRelationshipsFromOwl(OWLInfo owl, String comefrom){
		System.out.println("    #create relationship in ontology "+owl.getOwlFileName());
		Set<OWLAxiom> Axioms = owl.getAxiomsInTBox();
		Transaction tx = graphDb.beginTx(); 
		try{
			for(OWLAxiom axiom : Axioms){
				AuxiliaryMapping mapping = Tools.getAxiomInString(axiom);
				if(mapping != null){
					String axiomInStr = mapping.getValue();
					String subToken = mapping.getKey();
					String supToken = mapping.getSupKey();
					//����Class					
					if(axiomInStr.contains("includedby")){						
						if(axiomInStr.startsWith("Class")){	//���İ���													
							 //System.out.println(axiomInStr);
							createRelationshipByType(owl, subToken, supToken, comefrom, "Class");		
							//������ཻ�ڵ�
							if(supToken.contains(NEGATIVESIGN)){
								System.out.println(axiomInStr);
							}
						}					
						else if(axiomInStr.startsWith("Property")){
						   //System.out.println(axiomInStr);
							createRelationshipByType(owl, subToken, supToken, comefrom, "Property");	
						}
					}
				}
			}
			tx.success();
		}
		finally{
			tx.finish();
		}
	}
	
	*//**
	 * �������ڵ��н�����ϵ
	 * @param owl 
	 * @param subToken subnode
	 * @param supToken supnode
	 * @param comefrom owl
	 * @param entityType Class or Property
	 *//*
	public void createRelationshipByType(OWLInfo owl, String subToken, String supToken, String comefrom, String entityType){
		//System.out.println(entityType);
		Set<String> concepts = owl.getConceptTokens();
		Set<String> roles = owl.getRoleTokens();
		
		if(entityType.equals("Class")){			
			createRelationship(subToken, supToken, comefrom);
		}
		else if(entityType.equals("Property")){
			createRelationship(subToken, supToken, comefrom);
			//���Ϊ�϶�����,һ�����ԵĻ������ԣ������޶����Ѿ�����node��
			if(!supToken.startsWith("negative_")){
				//System.out.println(supToken);
				//createRelationship(subToken, supToken, comefrom);
				createRelationship(Tools.getExistenceToken(subToken), Tools.getExistenceToken(supToken), comefrom);
				createRelationship(Tools.getInverseToken(subToken), Tools.getInverseToken(supToken), comefrom);
				createRelationship(Tools.getExistenceInverseToken(subToken), Tools.getExistenceInverseToken(supToken), comefrom);
			}
			else{ //Ϊ�񶨰���
				//System.out.println("Negative**"+supToken);
				//createRelationship(subToken, supToken, comefrom);					
				String inverseSubToken = Tools.getInverseToken(subToken);//inverse_sub��������				
				String existenceSubToken = Tools.getExistenceToken(subToken);//existence_sub���Ǹ���
				String existenceInverseSubToken = Tools.getExistenceInverseToken(subToken);//existence_inverse_sub���Ǹ���
				
				roles.add(inverseSubToken);
				concepts.add(existenceSubToken);
				concepts.add(existenceInverseSubToken);				
				
				createNode(inverseSubToken, ROLETYPE,comefrom);
				createNode(existenceSubToken, CONCEPTTYPE,comefrom);
				createNode(existenceInverseSubToken, CONCEPTTYPE,comefrom);
				
				//String positiveSupToken = supToken.split("_")[1];
				String positiveSupToken = supToken.substring(supToken.indexOf("_")+1); //�ӵ�һ��"_"�п�ʼȡ,ȡ��ԭ��
				String nInverseSupToken = Tools.getNegativeToken(Tools.getInverseToken(positiveSupToken));//negative_inverse_sup������				
				String nExistenceSupToken = Tools.getNegativeToken(Tools.getExistenceToken(positiveSupToken));//negative_existence_sup������				
				String nExistenceInverseSupToken = Tools.getNegativeToken(Tools.getExistenceInverseToken(positiveSupToken));//negative_existence_inverse_sup������
				
				roles.add(nInverseSupToken);
				concepts.add(nExistenceSupToken);
				concepts.add(nExistenceInverseSupToken);	
				
				createNode(nInverseSupToken, ROLETYPE,comefrom);
				createNode(nExistenceSupToken, CONCEPTTYPE,comefrom);
				createNode(nExistenceInverseSupToken, CONCEPTTYPE,comefrom);			
				
				createRelationship(inverseSubToken,nInverseSupToken, comefrom); 				
				createRelationship(existenceSubToken,nExistenceSupToken, comefrom); 
				createRelationship(existenceInverseSubToken,nExistenceInverseSupToken, comefrom); 
			}				
		}
	}
	
	//����һ����ϵ
	public void createRelationship(String subToken, String supToken, String comefrom){
		Relationship relationship = null;		
		//Get node by name
		Node subNode=null, supNode=null;		
		try{
			 subNode = nodeIndex.query(NAMEPROPERTY, subToken).getSingle();		
			 supNode = nodeIndex.query(NAMEPROPERTY, supToken).getSingle();		
		}catch(Exception e){
			System.out.println("Exception: "+subToken + " * " + supToken);
		}
			
		//System.out.println("create:"+subNode.getProperty(NAMEPROPERTY)+"  "+supNode.getProperty(NAMEPROPERTY));
		if(subNode!=null && supNode!=null){
			String relationshipName = Tools.getRelationshipName(subToken, supToken);
			relationship = subNode.createRelationshipTo(supNode,	GlobalAttribute.RelTypes.INCLUDEDBY);
			relationship.setProperty(COMEFROMPROPERTY, comefrom);
			relationship.setProperty(NAMEPROPERTY, relationshipName);
			
			IndexHits<Relationship> hits = relationshipIndex.query(NAMEPROPERTY,relationshipName);
			if(hits.size()<1)
				relationshipIndex.add(relationship, NAMEPROPERTY, relationshipName);
		}
	}
	
	*//**
	 * ��OWLInfo�Ĳ��ཻ���г�ȡ�µĽڵ�, A��B����������negative_A, negative_B
	 * @return negative concepts.
	 *//*
	public List<String> getEntitiesFromDisjointClass(OWLInfo owl){
		List<String> newConcepts = new ArrayList<String>();
		//Set<String> conceptsInSet = new HashSet<String>();
		for(OWLDisjointClassesAxiom odcAxiom : owl.getAxiomsOfDisjoint()){
			//List<String> oClassesInString = Tools.owlClassSetToStringSet(odcAxiom.getClassesInSignature());
			List<OWLClassExpression> classExpressionList =  odcAxiom.getClassExpressionsAsList();
			for(OWLClassExpression oClass : classExpressionList){
				//Tools.saveToFile(oClass);
				String negativeClass = Tools.getNegativeToken(Tools.splitIRI(oClass.toString()));
				if(!newConcepts.contains(negativeClass)){  //�����������
					newConcepts.add(negativeClass);			
					//Tools.saveToFile(negativeClass);
				}
			}
		}
		return newConcepts;
	}
	
	*//**
	 * ��ĳ��OWLInfo�еĲ��ཻ�����г�ȡ�µĽڵ�, R1��R2����������negative_R1, negative_R2
	 * @return negative roles.
	 *//*
	public List<String> getEntitiesFromDisjointObjectProperty(OWLInfo owl){
		List<String> newRoles = new ArrayList<String>();
		for(OWLDisjointObjectPropertiesAxiom odcAxiom : owl.getAxiomsOfDisjointObjProperty()){
			List<String> oObjPropertyInString = Tools.owlObjPropertySetToStringSet(odcAxiom.getObjectPropertiesInSignature());
			for(String oObjProperty : oObjPropertyInString){
				String negativeObjProperty = Tools.getNegativeToken(oObjProperty);
				if(!newRoles.contains(negativeObjProperty)){
					newRoles.add(negativeObjProperty);					
				}
			}
		}
		return newRoles;
	}

	public static void main(String[] args) {
		Clock.begin();
		SingleOWLToGraphDB owlToGraph = new SingleOWLToGraphDB("target/neo4j-O1-db", Tools.o[0], COMEFROMFIRST);
		owlToGraph.createDbFromOwl();
		owlToGraph.shutdown();
		
		SingleOWLToGraphDB owlToGraph2 = new SingleOWLToGraphDB("target/neo4j-O2-db", Tools.o[1], COMEFROMSECOND);
		owlToGraph2.createDbFromOwl();
		owlToGraph2.shutdown();
		
		SingleOWLToGraphDB owlToGraph = new SingleOWLToGraphDB("target/neo4j-proton1-db", Tools.proton_50_studis[0], COMEFROMFIRST);
		owlToGraph.createDbFromOwl();
		owlToGraph.shutdown();
		
		SingleOWLToGraphDB owlToGraph2 = new SingleOWLToGraphDB("target/neo4j-proton2-db", Tools.proton_50_studis[1], COMEFROMSECOND);
		owlToGraph2.createDbFromOwl();
		owlToGraph2.shutdown();
		
		SingleOWLToGraphDB owlToGraph2 = new SingleOWLToGraphDB("target/neo4j-univBenchmark-db", "owls/univ-bench-lite.owl", COMEFROMSECOND,true);
		owlToGraph2.createDbFromOwl();
		owlToGraph2.shutdown();
		
		SingleOWLToGraphDB owlToGraph2 = new SingleOWLToGraphDB("target/neo4j-aeo-db", "ClassicalOwls/aeo.owl", COMEFROMSECOND);
		owlToGraph2.createDbFromOwl();
		owlToGraph2.shutdown();

		Clock.end();
		Clock.showInfo("Create graph db");
	}
*/}
